# Zenith Orbitron Ground Station — modular VS Code project

This project is a modular split of the supplied `zenith_orbitron_dual_avionics_crc16.py`. The original GUI code is retained in `zenith_gs.py`, and its existing theme, embedded logo images, UI colors, stylesheets, and layout are preserved. The communication, telemetry, attitude, transmitter, serial, and optional-dependency code is split into the `zenith/` package.

## Run in Visual Studio Code

1. Open the **`zenith-orbitron`** folder in VS Code.
2. Create and activate a virtual environment:

   **Windows (PowerShell)**
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   ```

   **macOS / Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install -r requirements.txt
   ```

3. Run the **Zenith Orbitron Ground Station** configuration in Run and Debug, or:
   ```bash
   python zenith_gs.py
   ```

`zenith_gs.py` keeps the original GUI and theme. Edit the modules under `zenith/` for protocol, telemetry, receiver, attitude, transmitter, serial-link, and dependency changes.

## Project layout

```text
zenith-orbitron/
├── .vscode/
│   ├── launch.json
│   └── settings.json
├── tests/
│   ├── test_protocol.py
│   └── test_telemetry.py
├── zenith/
│   ├── config.py
│   ├── protocol.py
│   ├── receiver.py
│   ├── telemetry.py
│   ├── attitude.py
│   ├── transmitter.py
│   ├── serial_link.py
│   └── deps.py
├── zenith_gs.py                 # Original GUI/theme and application entry point
├── requirements.txt
└── pyproject.toml
```

## Shared Teensy serial stream

Both avionics streams arrive over **one Teensy COM port** and use one serial reader. The Teensy tags each 15-field record so the GUI can keep Rocket and CanSat telemetry in their separate stores and plots:

```text
{Roc}<15-field payload>
{Can}<15-field payload>
```

The payload fields follow the source protocol order: Team ID, timestamp, packet count, altitude, pressure, temperature, voltage, GNSS time, GNSS latitude, GNSS longitude, GNSS altitude, GNSS satellites, accelerometer data, gyro spin rate, and flight-software state. A `*ABCD` CRC-16 suffix is accepted after the payload. Rocket records are checked against the configured Rocket Team ID; `{Can}` records can carry the CanSat Team ID.

## Component Status tab

The appended **Component Status** tab shows the shared Teensy USB-link state and separate Rocket/CanSat stream freshness. For each stream it reports whether the BMP390L, BNO085 IMU, GNSS receiver, and INA219 voltage data are arriving, along with their latest readings. It also shows the flight computer's Team ID, packet count, and flight state; the existing 6.6 V low-voltage warning is shown for INA219 voltage. Status is inferred from fresh telemetry fields, not from hardware self-test bits; RF RSSI/SNR and INA219 current/power are marked as not reported because they are not in the 15-field payload. The existing tabs and application theme are unchanged.

## Dependencies and optional features

The application requires PyQt6 and pyqtgraph. `requirements.txt` also installs pyserial, NumPy, Folium, PyQt6-WebEngine, trimesh, and PyOpenGL for the serial, map, and 3D features. The program includes dependency checks for optional map/3D components.

To run the core tests from the project folder:

```bash
python -m unittest discover -s tests -v
```
