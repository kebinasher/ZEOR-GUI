import unittest

from zenith.config import TEAM_ID
from zenith.protocol import (
    append_crc16,
    crc16_ccitt_false,
    extract_and_verify_crc16,
    parse_legacy_frame,
    parse_zenith_frame,
    SRC_CANSAT_TAG,
    SRC_ROCKET_TAG,
)
from zenith.receiver import ReceiverDecoder
from zenith.transmitter import build_frame


def make_frame(team_id=TEAM_ID, packet_count=17):
    return build_frame(
        timestamp_ms=12345,
        altitude_m=12.34,
        pressure_hpa=1013.25,
        temperature_c=28.1,
        voltage_v=7.94,
        accel=(0.1, -0.02, 9.78),
        gyro=(0.1, -0.2, 0.0),
        gnss=("12:34:56", 13.0827, 80.2707, 12.3, 9),
        flight_state="ASCENT",
        team_id=team_id,
        packet_count=packet_count,
    )


class ProtocolTests(unittest.TestCase):
    def test_crc_ccitt_false_standard_vector(self):
        self.assertEqual(crc16_ccitt_false("123456789"), 0x29B1)

    def test_crc_wrapped_frame_decodes(self):
        frame = make_frame()
        payload = frame.strip()[1:]
        checked, received, calculated = extract_and_verify_crc16(append_crc16(payload))
        self.assertEqual(checked, payload)
        self.assertEqual(received, calculated)

        decoder = ReceiverDecoder()
        samples, messages = decoder.feed(("@" + append_crc16(payload) + "\n").encode())
        self.assertEqual(len(samples), 1)
        sample = samples[0]
        self.assertEqual(sample["team_id"], TEAM_ID)
        self.assertEqual(sample["packet_count"], 17)
        self.assertAlmostEqual(sample["bmp_alt"], 12.34)
        self.assertAlmostEqual(sample["gnss_latitude"], 13.0827)
        self.assertEqual(sample["_crc_status"], "OK")

    def test_corrupt_crc_is_rejected(self):
        payload = make_frame().strip()[1:]
        checked = append_crc16(payload)
        damaged = checked[:-1] + ("0" if checked[-1] != "0" else "1")
        samples, messages = ReceiverDecoder().feed("@" + damaged + "\n")
        self.assertEqual(samples, [])
        self.assertTrue(any(level == "error" and "CRC" in message for level, message in messages))

    def test_wrong_team_is_rejected(self):
        payload = make_frame(team_id="OTHER").strip()[1:]
        self.assertIsNone(parse_zenith_frame(payload))
        self.assertIsNotNone(parse_zenith_frame(payload, team_id_expected=None))

    def test_one_teensy_stream_routes_tagged_rocket_and_cansat_records(self):
        decoder = ReceiverDecoder()
        rocket_payload = make_frame().strip()[1:]
        cansat_payload = make_frame(team_id="INSPACe-CanSat-032", packet_count=8).strip()[1:]

        rocket_samples, _ = decoder.feed("{Roc}" + rocket_payload + "\n")
        cansat_samples, _ = decoder.feed("{Can}" + append_crc16(cansat_payload) + "\n")

        self.assertEqual(len(rocket_samples), 1)
        self.assertEqual(rocket_samples[0]["_source"], SRC_ROCKET_TAG)
        self.assertEqual(rocket_samples[0]["team_id"], TEAM_ID)
        self.assertEqual(len(cansat_samples), 1)
        self.assertEqual(cansat_samples[0]["_source"], SRC_CANSAT_TAG)
        self.assertEqual(cansat_samples[0]["team_id"], "INSPACe-CanSat-032")

    def test_tagged_rocket_still_enforces_configured_team_id(self):
        payload = make_frame(team_id="OTHER").strip()[1:]
        samples, _ = ReceiverDecoder().feed("{Roc}" + payload + "\n")
        self.assertEqual(samples, [])

    def test_legacy_can_frame(self):
        values = [float(i) for i in range(18)]
        payload = "CAN,1234," + ",".join(str(value) for value in values)
        sample = parse_legacy_frame(payload)
        self.assertIsNotNone(sample)
        self.assertEqual(sample["_source"], "legacy-can")
        self.assertEqual(sample["time_ms"], 1234.0)

    def test_build_frame_has_current_field_count_and_newline(self):
        frame = make_frame()
        self.assertTrue(frame.startswith("@"))
        self.assertTrue(frame.endswith("\n"))
        self.assertEqual(len(frame.strip()[1:].split(",")), 15)


if __name__ == "__main__":
    unittest.main()
