import math
import unittest

from zenith.config import CHANNELS
from zenith.protocol import blank_sample
from zenith.telemetry import PacketLossTracker, TelemetryStore, autoscale_ranges


class TelemetryTests(unittest.TestCase):
    def test_store_keeps_one_history_per_configured_channel(self):
        store = TelemetryStore(history_len=2)
        for value in (1.0, 2.0, 3.0):
            sample = blank_sample()
            sample["bmp_alt"] = value
            sample["time_ms"] = value * 1000
            store.push(sample)
        self.assertEqual(set(store.history), {channel.key for channel in CHANNELS})
        self.assertEqual(store.series("bmp_alt"), [2.0, 3.0])
        self.assertEqual(store.times(), [2.0, 3.0])
        self.assertEqual(store.packet_count, 3)

    def test_packet_loss_gap_and_duplicate(self):
        tracker = PacketLossTracker()
        self.assertEqual(tracker.update(10), [])
        warning = tracker.update(13)
        self.assertEqual(tracker.lost, 2)
        self.assertTrue(any("2 telemetry packet" in message for _, message in warning))
        duplicate = tracker.update(13)
        self.assertEqual(tracker.duplicates, 1)
        self.assertTrue(any("duplicate" in message for _, message in duplicate))

    def test_packet_counter_wrap(self):
        tracker = PacketLossTracker()
        tracker.update(0xFFFFFFFF)
        warning = tracker.update(0)
        self.assertEqual(tracker.lost, 0)
        self.assertEqual(warning, [])

    def test_autoscale_ignores_non_finite_values(self):
        result = autoscale_ranges([0.0, 1.0, float("nan")], [[2.0, 4.0, float("inf")]])
        self.assertIsNotNone(result)
        self.assertTrue(math.isfinite(result[2]))
        self.assertTrue(math.isfinite(result[3]))


if __name__ == "__main__":
    unittest.main()
