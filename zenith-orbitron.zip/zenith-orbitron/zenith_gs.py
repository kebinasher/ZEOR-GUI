from __future__ import annotations

# Modular imports replacing the flat-build global namespace. The GUI remains
# based on the supplied source; its original theme is preserved, with the serial
# controls adapted for one shared Teensy port.
from zenith import config as ZCFG
from zenith import protocol as ZPROTO
from zenith.config import *
from zenith.protocol import *
from zenith.receiver import *
from zenith.telemetry import *
from zenith.attitude import *
from zenith.transmitter import *
from zenith.serial_link import *
from zenith.deps import *


# ==========================================================================

import sys
import time
import csv
import math
import json  # NEW (used by the Live Map tab to pass data safely to JavaScript)
import base64  # NEW (decodes the logos embedded in this file)
import os
from collections import deque

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QComboBox, QTextEdit, QGroupBox, QGridLayout, QMessageBox,
    QSizePolicy, QDialog, QStackedLayout,
    QTabWidget, QCheckBox, QFileDialog, QScrollArea,  # NEW: vertical scrolling
    QSplitter,  # NEW: draggable divider dashboard <-> Serial Monitor
)
from PyQt6.QtCore import (
    QThread, pyqtSignal, Qt, QRectF, QPointF,
    QTimer,  # NEW (was previously imported locally inside __init__)
)
from PyQt6.QtGui import (
    QPainter, QColor, QPen, QBrush, QFont, QPolygonF, QPainterPath,
    QLinearGradient,  # NEW
    QPixmap,  # NEW (logo images on the first dashboard)
)

import pyqtgraph as pg
try:
    import serial
    import serial.tools.list_ports
    SERIAL_LIBRARY_AVAILABLE = True
    SERIAL_IMPORT_ERROR = ""
except Exception as _serial_exc:            # pragma: no cover - GUI must still start
    serial = None
    SERIAL_LIBRARY_AVAILABLE = False
    SERIAL_IMPORT_ERROR = str(_serial_exc)

try:
    import folium
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    MAP_SUPPORT_AVAILABLE = True
except ImportError:
    folium = None
    QWebEngineView = None
    MAP_SUPPORT_AVAILABLE = False


try:
    import numpy as np
    import trimesh
    import pyqtgraph.opengl as gl
    from PyQt6.QtGui import QVector3D
    STL_3D_AVAILABLE = True
except ImportError:
    np = None
    trimesh = None
    gl = None
    QVector3D = None
    STL_3D_AVAILABLE = False

# ============================================================================
# ZENITH ORBITRON  —  INTEGRATION LAYER  (v7.0)
# ----------------------------------------------------------------------------
# The GUI is retained from the supplied ground station, including its theme;
# serial controls now use the shared Teensy stream. Communication logic lives
# in the ``zenith`` package:
#
#   zenith.config     - channel table, field mapping, constants
#   zenith.protocol   - wire protocol (15-field '@' frame, receiver report,
#                       'RX,' echo, legacy 'CAN,' frame) and validation
#   zenith.receiver   - streaming decoder used by the serial worker
#   zenith.serial_link- QThread owning the port (no widget is touched there)
#   zenith.telemetry  - TelemetryStore: THE single shared data source
#   zenith.attitude   - attitude derived from the received accelerometer/gyro
#   zenith.transmitter- Python mirror of the TX frame builder (tests / HIL only)
#
# The module search path is extended first so the package is found no matter
# which directory the application is started from.
# ============================================================================
# (flat build) zenith.config / zenith.protocol / zenith.receiver /
# zenith.telemetry / zenith.attitude / zenith.serial_link are inlined
# above; ZCFG and ZPROTO are the aliases built in section 9.

VERSION = ("Zenith Orbitron Ground Station v7.1 — integrated: "
           "Teensy 4.1 TX → LoRa E22 → USB → this GUI")


# ---- NEW: logos shown on the first dashboard only ----
# The logo images are embedded in this file (see "EMBEDDED LOGO IMAGES" near the
# bottom), so no external image files are needed.
LOGO_HEIGHT_PX = 150  # larger logo header; aspect ratios are preserved

# ============================================================
# CONFIGURATION
# ============================================================

# E22-900T22D factory UART default is 9600 8N1. Must match the
# ground-side module's UART setting (NOT the LoRa air rate).
BAUD_CHOICES = ["9600", "19200", "38400", "57600", "115200"]
# The PC is connected directly to the E22-900T22D through a USB-UART adapter.
# The E22 UART is configured for 9600 baud, so 9600 is the correct default.
DEFAULT_BAUD = "9600"

EXPECTED_FIELDS = 15      # current rocket frame: @ + 15 CSV fields
GPS_FIELDS = 22           # legacy frame with latitude/longitude appended

LOW_VOLTAGE_WARN = 6.6      # volts, change for your battery pack
LINK_LOST_TIMEOUT_S = 5.0   # "NO SIGNAL" if no packet for this long
MAP_DEFAULT_LAT = 28.6139   # launch-site default
MAP_DEFAULT_LON = 77.2090
MAP_REFRESH_S = 2.0         # folium re-render throttle

FIELD_KEYS = [
    "time_ms",
    "bmp_alt", "bmp_temp", "bmp_press",
    "dps_alt", "dps_temp", "dps_press",
    "ax", "ay", "az",
    "gx", "gy", "gz",
    "roll", "pitch", "yaw",
    "vbus", "cur", "pwr",
]

# ---------------------------------------------------------------------------
# CHANNEL AVAILABILITY  (what the current firmware does and does not send)
# ---------------------------------------------------------------------------
# The rocket transmits 15 CSV fields.  Channels that are not among them are
# reported as "--" everywhere; they are NEVER filled with a made-up value.
CHANNELS_NOT_TRANSMITTED = tuple(c.key for c in ZCFG.missing_channels())
NOT_TRANSMITTED_TEXT = (
    "NOT TRANSMITTED BY THIS FIRMWARE\n"
    + ", ".join(c.name for c in ZCFG.missing_channels())
)
# Roll/pitch/yaw are not transmitted either, but they CAN be derived from real
# received data (tilt from the accelerometer, yaw integrated from gyro Z).
# The euler tile therefore shows them as dashed "derived" traces.
DERIVED_KEYS = ("roll", "pitch", "yaw")
DERIVED_TEXT = ("DERIVED, NOT TRANSMITTED\n"
                "tilt from accelerometer, yaw integrated from gyro Z (drifts)")

FLIGHT_STATE_COLORS = ZCFG.FLIGHT_STATE_COLORS

# id, title, y label, units, [(key, color, legend name)]
PLOT_SPECS = [
    ("alt", "Altitude", "Altitude", "m",
     [("bmp_alt", "#00FFCC", "BMP390L")]),
    ("temp", "Temperature", "Temperature", "°C",
     [("bmp_temp", "#00FFCC", "BMP390L")]),
    ("press", "Pressure", "Pressure", "hPa",
     [("bmp_press", "#00FFCC", "BMP390L")]),
    ("accel", "BNO085 Acceleration", "Acceleration", "m/s²",
     [("ax", "#FF5252", "Ax"), ("ay", "#69F0AE", "Ay"), ("az", "#40C4FF", "Az")]),
    ("gyro", "BNO085 Angular Rate", "Angular Rate", "°/s",
     [("gx", "#FF5252", "Gx"), ("gy", "#69F0AE", "Gy"), ("gz", "#40C4FF", "Gz")]),
    ("euler", "BNO085 Orientation (derived)", "Angle", "°",
     [("roll", "#FF4081", "Roll*"), ("pitch", "#00E5FF", "Pitch*"),
      ("yaw", "#FFD400", "Yaw*")]),
    ("vbus", "INA219 Bus Voltage", "Voltage", "V",
     [("vbus", "#B388FF", "Vbus")]),
    ("cur", "INA219 Current", "Current", "mA",
     [("cur", "#FFD400", "Current (not transmitted)")]),
]

# ============================================================
# NEW — CONFIGURATION FOR THE TWO NEW TABS
# ============================================================

# ---- Tab 2: Live Map ----
MAP_TAB_DEFAULT_ZOOM = 15      # zoom before the first GPS fix
MAP_TAB_FOLLOW_ZOOM = 17       # zoom applied on the first GPS fix
MAP_TAB_FLUSH_MS = 400         # max rate at which the marker is pushed to the map
MAP_TAB_GPS_STALE_S = 10.0     # "GPS STALE" if no new fix for this long
MAP_TAB_TRAIL_MAX = 5000       # max points kept in the flight-path polyline

# ---- Tab 3: 2D Flight Simulation ----
SIM_ALT_KEY = "bmp_alt"             # telemetry field that drives the simulation
SIM_ALT_FALLBACK_KEY = None    # no second barometer in current telemetry
# True : altitude shown = sensor altitude minus the pad (ground) reference that
#        is measured from the first packets, so the rocket starts at 0 m even if
#        the barometer reports height above sea level.
# False: the raw sensor value is used as the altitude directly.
SIM_USE_RELATIVE_ALTITUDE = True
SIM_BASELINE_SAMPLES = 10           # packets averaged to find the ground level
SIM_BASELINE_EMA = 0.02             # slow weather-drift tracking while READY
SIM_HISTORY = 5000                  # altitude-graph points kept
SIM_FRAME_MS = 33                   # animation timer (~30 fps)
SIM_SMOOTH_TAU_S = 0.25             # visual smoothing time constant
SIM_VIEW_TAU_S = 0.5                # smoothing of the altitude-scale zoom
SIM_MIN_VIEW_M = 100.0              # smallest altitude range shown on the scale
SIM_SPEED_WINDOW_S = 1.0            # vertical speed is measured over ~this window
SIM_SPEED_MIN_DT_S = 0.15           # never divide by a smaller time step
SIM_LAUNCH_ALT_M = 3.0              # READY -> ASCENDING needs altitude above this ...
SIM_LAUNCH_SPEED_MS = 2.0           # ... and climb rate above this ...
SIM_LAUNCH_CONFIRM = 2              # ... on this many consecutive packets
SIM_DESCENT_SPEED_MS = 1.0          # ASCENDING -> DESCENDING: sink rate above this ...
SIM_DESCENT_CONFIRM = 2             # ... on this many consecutive packets ...
SIM_APOGEE_DROP_M = 1.0             # ... and altitude at least this far below apogee
SIM_LANDED_ALT_M = 2.5              # LANDED: below this altitude ...
SIM_LANDED_SPEED_MS = 1.0           # ... with |vertical speed| below this ...
SIM_LANDED_HOLD_S = 3.0             # ... for this long (flight time)

SIM_STATUS_COLORS = {
    "READY": "#FFD400",
    "ASCENDING": "#00FFCC",
    "DESCENDING": "#FF8A00",
    "LANDED": "#40C4FF",
}


# ============================================================
# ATTITUDE INDICATOR (driven directly by BNO085 roll / pitch)
# ============================================================

class AttitudeIndicator(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.pitch_deg = 0.0
        self.roll_deg = 0.0
        self.yaw_deg = 0.0
        self.setMinimumSize(220, 190)
        self.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Expanding)

    def set_attitude(self, pitch, roll, yaw=0.0):
        self.pitch_deg = max(min(float(pitch), 90.0), -90.0)
        self.roll_deg = max(min(float(roll), 180.0), -180.0)
        self.yaw_deg = float(yaw)
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        cx, cy = w / 2, h / 2 - 8
        r = min(w, h) * 0.36
        p.fillRect(self.rect(), QColor("#121212"))

        circle = QRectF(cx - r, cy - r, r * 2, r * 2)
        p.setPen(QPen(QColor("#CFCFCF"), 4))
        p.setBrush(QBrush(QColor("#050505")))
        p.drawEllipse(circle)

        # --- moving horizon, clipped to the dial ---
        p.save()
        clip = QPainterPath()
        clip.addEllipse(QRectF(cx - r + 5, cy - r + 5, 2 * r - 10, 2 * r - 10))
        p.setClipPath(clip)
        p.translate(cx, cy + self.pitch_deg * 3.0)
        p.rotate(-self.roll_deg)
        big = r * 4
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#1976D2"))
        p.drawRect(QRectF(-big, -big, big * 2, big))
        p.setBrush(QColor("#8B4A20"))
        p.drawRect(QRectF(-big, 0, big * 2, big))
        p.setPen(QPen(QColor("#FFFFFF"), 3))
        p.drawLine(int(-big), 0, int(big), 0)

        p.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        p.setPen(QPen(QColor("#FFFFFF"), 2))
        for mark in range(-60, 65, 10):
            if mark == 0:
                continue
            y = -mark * 3.0
            half = 40 if mark > 0 else 26
            p.drawLine(-half, int(y), half, int(y))
            p.drawText(-half - 28, int(y + 4), str(abs(mark)))
            p.drawText(half + 8, int(y + 4), str(abs(mark)))
        p.restore()

        # --- outline, fixed aircraft symbol, roll pointer ---
        p.setPen(QPen(QColor("#D0D0D0"), 4))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(circle)

        p.setPen(QPen(QColor("#FFD400"), 4))
        ix = lambda v: int(v)
        p.drawLine(ix(cx - r * .5), ix(cy), ix(cx - r * .12), ix(cy))
        p.drawLine(ix(cx + r * .12), ix(cy), ix(cx + r * .5), ix(cy))
        p.drawLine(ix(cx - r * .12), ix(cy), ix(cx), ix(cy + r * .12))
        p.drawLine(ix(cx), ix(cy + r * .12), ix(cx + r * .12), ix(cy))

        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#FFFFFF"))
        p.drawPolygon(QPolygonF([
            QPointF(cx, cy - r + 9),
            QPointF(cx - 10, cy - r + 30),
            QPointF(cx + 10, cy - r + 30),
        ]))

        p.save()
        p.translate(cx, cy)
        p.setPen(QPen(QColor("#FFFFFF"), 2))
        for a in (-60, -45, -30, -20, -10, 10, 20, 30, 45, 60):
            p.save()
            p.rotate(a)
            p.drawLine(0, int(-(r - 17)), 0, int(-(r - 6)))
            p.restore()
        p.restore()

        # --- numeric readout ---
        p.setPen(QColor("#FFFFFF"))
        p.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        ty = int(cy + r + 20)
        p.drawText(6, ty, f"P:{self.pitch_deg:+.1f}°")
        p.drawText(int(w * 0.34), ty, f"R:{self.roll_deg:+.1f}°")
        p.drawText(int(w * 0.67), ty, f"Y:{self.yaw_deg:+.0f}°")
        p.end()


# ============================================================
# MAP OVERLAY + FULLSCREEN DIALOG
# ============================================================

class ClickableMapOverlay(QWidget):
    """Transparent widget above the QWebEngineView to catch clicks."""
    clicked = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("Click to view fullscreen")
        self.setStyleSheet("background-color: rgba(0,0,0,0);")

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)

    def enterEvent(self, event):
        self.setStyleSheet("background-color: rgba(255,255,255,25);")
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.setStyleSheet("background-color: rgba(0,0,0,0);")
        super().leaveEvent(event)


class MapFullscreenDialog(QDialog):
    def __init__(self, html, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Payload Location — Fullscreen")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        bar = QHBoxLayout()
        bar.setContentsMargins(10, 8, 10, 8)
        hint = QLabel("Press ESC or click Close to exit fullscreen")
        hint.setStyleSheet("color: #BDBDBD;")
        btn = QPushButton("Close (ESC)")
        btn.clicked.connect(self.close)
        bar.addWidget(hint)
        bar.addStretch()
        bar.addWidget(btn)
        layout.addLayout(bar)

        self.view = QWebEngineView()
        layout.addWidget(self.view, 1)
        self.view.setHtml(html)
        self.showFullScreen()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(event)


# ============================================================
# NEW — TAB 2 : FOLIUM LIVE MAP
# ============================================================

class LiveMapTab(QWidget):
    """
    Dedicated, self-contained Folium map tab.

    * Fed by GroundStationGUI.handle_telemetry_packet() through
      update_from_packet(pkt) — it never touches the serial port.
    * The Folium page is generated ONCE. Marker / trail updates are pushed to
      the already-loaded Leaflet map with runJavaScript(), so the map does not
      flicker or reload and keeps whatever zoom / pan the user chose.
    * No GPS fix  -> no marker is drawn and no coordinates are invented.
      The map is simply centred on MAP_DEFAULT_LAT / MAP_DEFAULT_LON
      (a viewing position only, not a rocket position).
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.lat = None
        self.lon = None
        self.alt = None
        self.fix_count = 0
        self.last_fix_wall = None
        self.page_ready = False
        self.map_name = None
        self.view = None
        self._dirty = False

        root = QVBoxLayout(self)

        # ---- info panel ----
        info = QGroupBox("ROCKET LOCATION (GPS)")
        g = QGridLayout(info)
        self.lbl_gps_status = QLabel("GPS: WAITING FOR DATA")
        self.lbl_gps_status.setStyleSheet(
            "color: #FF8A00; font-size: 12pt; font-weight: bold;")
        self.lbl_lat = QLabel("Latitude: --")
        self.lbl_lon = QLabel("Longitude: --")
        self.lbl_alt = QLabel("Altitude (BMP581): --")
        self.lbl_fixes = QLabel("GPS fixes received: 0")
        self.lbl_last_fix = QLabel("Last fix: --")
        for lbl in (self.lbl_lat, self.lbl_lon, self.lbl_alt):
            lbl.setStyleSheet("color: #00FFCC; font-weight: bold;")
        g.addWidget(self.lbl_gps_status, 0, 0, 1, 3)
        g.addWidget(self.lbl_lat, 1, 0)
        g.addWidget(self.lbl_lon, 1, 1)
        g.addWidget(self.lbl_alt, 1, 2)
        g.addWidget(self.lbl_fixes, 2, 0)
        g.addWidget(self.lbl_last_fix, 2, 1)

        self.lbl_note = QLabel(
            "No GPS coordinates received yet. No marker is shown and no position "
            "is simulated. The marker appears automatically as soon as the "
            "telemetry carries the optional latitude/longitude fields "
            "(22-field packet with a valid, non-zero fix).")
        self.lbl_note.setWordWrap(True)
        self.lbl_note.setStyleSheet("color: #BDBDBD;")
        g.addWidget(self.lbl_note, 3, 0, 1, 3)
        root.addWidget(info)

        # ---- controls ----
        ctl = QHBoxLayout()
        self.chk_follow = QCheckBox("Auto-follow rocket")
        self.chk_follow.setChecked(True)
        self.btn_center = QPushButton("Center on rocket")
        self.btn_center.clicked.connect(self._center_on_rocket)
        self.btn_clear = QPushButton("Clear trail")
        self.btn_clear.clicked.connect(self._clear_trail)
        ctl.addWidget(self.chk_follow)
        ctl.addWidget(self.btn_center)
        ctl.addWidget(self.btn_clear)
        ctl.addStretch()
        root.addLayout(ctl)

        # ---- map ----
        if MAP_SUPPORT_AVAILABLE:
            self.view = QWebEngineView()
            self.view.loadFinished.connect(self._on_loaded)
            root.addWidget(self.view, 1)
            self._load_map()
        else:
            fb = QLabel("Map unavailable — install the map dependencies with:\n\n"
                        "pip install folium PyQt6-WebEngine\n\n"
                        "(GPS values above will still update.)")
            fb.setAlignment(Qt.AlignmentFlag.AlignCenter)
            fb.setStyleSheet("color: #FF8A00; font-size: 12pt;")
            root.addWidget(fb, 1)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(MAP_TAB_FLUSH_MS)

    # ---------------- map page ----------------
    def _load_map(self):
        fmap = folium.Map(
            location=[MAP_DEFAULT_LAT, MAP_DEFAULT_LON],
            zoom_start=MAP_TAB_DEFAULT_ZOOM,
            tiles="OpenStreetMap",
            zoom_control=True,       # +/- zoom buttons
            control_scale=True,
        )
        self.map_name = fmap.get_name()   # JS variable name of the Leaflet map
        self.page_ready = False
        self.view.setHtml(fmap.get_root().render())

    def _on_loaded(self, ok):
        self.page_ready = bool(ok)
        if ok and self.lat is not None:
            self._dirty = True

    def _run_js(self, js, callback=None):
        if self.view is None:
            return
        page = self.view.page()
        try:
            if callback is None:
                page.runJavaScript(js)
            else:
                page.runJavaScript(js, callback)
        except TypeError:
            page.runJavaScript(js, 0, callback)

    def _js_update(self):
        lat, lon = self.lat, self.lon
        tip = f"<b>Rocket</b><br>Lat {lat:.6f}<br>Lon {lon:.6f}"
        if self.alt is not None:
            tip += f"<br>Alt {self.alt:.1f} m"
        follow = "true" if self.chk_follow.isChecked() else "false"
        return f"""
(function() {{
  var m = window[{json.dumps(self.map_name)}];
  if (!m || typeof L === 'undefined') {{ return false; }}
  var ll = [{lat:.7f}, {lon:.7f}];
  var tip = {json.dumps(tip)};
  if (!window.__rocketMarker) {{
    var icon = L.divIcon({{
      html: '<div style="font-size:26px;line-height:26px;">🚀</div>',
      className: '', iconSize: [28, 28], iconAnchor: [14, 14]
    }});
    window.__rocketMarker = L.marker(ll, {{icon: icon, title: 'Rocket'}}).addTo(m);
    window.__rocketMarker.bindTooltip(tip, {{permanent: true, direction: 'right', offset: [14, 0]}});
    window.__rocketTrail = L.polyline([ll], {{color: '#FF3333', weight: 3, opacity: 0.8}}).addTo(m);
    m.setView(ll, {MAP_TAB_FOLLOW_ZOOM});
  }} else {{
    window.__rocketMarker.setLatLng(ll);
    window.__rocketMarker.setTooltipContent(tip);
    window.__rocketTrail.addLatLng(ll);
    var pts = window.__rocketTrail.getLatLngs();
    if (pts.length > {MAP_TAB_TRAIL_MAX}) {{
      pts.shift();
      window.__rocketTrail.setLatLngs(pts);
    }}
  }}
  if ({follow}) {{ m.panTo(ll); }}
  return true;
}})();
"""

    def _on_update_result(self, ok):
        if ok is not True:
            # Leaflet not loaded yet (e.g. offline) -> retry on the next tick
            self._dirty = True
            self.lbl_note.setText(
                "Map library has not loaded (internet connection needed for "
                "map tiles / Leaflet). Retrying automatically…")
        else:
            self.lbl_note.setText(
                "Live GPS marker active. Scroll / +/- buttons to zoom, drag to "
                "pan. 'Auto-follow' keeps the rocket centred.")

    def _center_on_rocket(self):
        if self.view is None or not self.page_ready or self.lat is None:
            return
        self._run_js(f"""
(function() {{
  var m = window[{json.dumps(self.map_name)}];
  if (m && window.__rocketMarker) {{
    m.setView(window.__rocketMarker.getLatLng(), Math.max(m.getZoom(), 15));
  }}
}})();""")

    def _clear_trail(self):
        if self.view is None or not self.page_ready:
            return
        self._run_js("""
(function() {
  if (window.__rocketTrail && window.__rocketMarker) {
    window.__rocketTrail.setLatLngs([window.__rocketMarker.getLatLng()]);
  }
})();""")

    # ---------------- telemetry hook ----------------
    def update_from_packet(self, pkt):
        alt = pkt.get("bmp_alt")
        if alt is not None and math.isfinite(alt):
            self.alt = alt
            self.lbl_alt.setText(f"Altitude (BMP581): {alt:.2f} m")

        if "latitude" in pkt and "longitude" in pkt:
            self.lat = pkt["latitude"]
            self.lon = pkt["longitude"]
            self.fix_count += 1
            self.last_fix_wall = time.time()
            self.lbl_lat.setText(f"Latitude: {self.lat:.6f}°")
            self.lbl_lon.setText(f"Longitude: {self.lon:.6f}°")
            self.lbl_fixes.setText(f"GPS fixes received: {self.fix_count}")
            self.lbl_last_fix.setText(
                f"Last fix: {time.strftime('%H:%M:%S')}")
            self._dirty = True

    def _refresh_status(self):
        if self.last_fix_wall is None:
            self.lbl_gps_status.setText("GPS: WAITING FOR DATA")
            self.lbl_gps_status.setStyleSheet(
                "color: #FF8A00; font-size: 12pt; font-weight: bold;")
            return
        age = time.time() - self.last_fix_wall
        if age > MAP_TAB_GPS_STALE_S:
            self.lbl_gps_status.setText(f"GPS: STALE (last fix {age:.0f}s ago)")
            self.lbl_gps_status.setStyleSheet(
                "color: #FF3333; font-size: 12pt; font-weight: bold;")
        else:
            self.lbl_gps_status.setText("GPS: FIX OK")
            self.lbl_gps_status.setStyleSheet(
                "color: #00FFCC; font-size: 12pt; font-weight: bold;")

    def _tick(self):
        self._refresh_status()
        if (self._dirty and self.view is not None and self.page_ready
                and self.lat is not None):
            self._dirty = False
            self._run_js(self._js_update(), self._on_update_result)


# ============================================================
# NEW — TAB 3 : 2D ROCKET FLIGHT SIMULATION
#       Mode 1 "Live Sensor Data"      (driven by received altitude only)
#       Mode 2 "Automatic Simulation"  (internal flight-profile engine)
#
#   Only this section differs from the previous revision. Tabs 1 and 2,
#   the serial thread and the telemetry handler are untouched; this tab is
#   still fed through RocketSimulationTab.update_from_packet(pkt), which the
#   existing GroundStationGUI._feed_new_tabs() calls. No second serial
#   connection is ever opened.
# ============================================================

from PyQt6.QtWidgets import QDoubleSpinBox  # NEW (tab 3 only)

SIM_MODE_LIVE = "Live Sensor Data"
SIM_MODE_AUTO = "Automatic Simulation"

# ---- live mode: protection against bad data ----
SIM_MAX_PLAUSIBLE_SPEED_MS = 600.0   # altitude jumps implying more are glitches
SIM_GLITCH_MAX_CONSEC = 5            # ... but accept a new level after this many
SIM_TRAJ_DRAW_POINTS = 800           # max trajectory points painted per frame

# ---- automatic mode: flight-profile constants ----
AUTO_G = 9.81                  # m/s^2, deceleration while coasting
AUTO_IGNITION_S = 1.0          # motor ignition on the pad before lift-off
AUTO_CLEAR_TOWER_M = 5.0       # LAUNCH phase ends once the rocket is this high
AUTO_APOGEE_HOLD_S = 1.5       # time spent in the APOGEE phase
AUTO_CHUTE_RAMP_S = 2.0        # parachute deployment: sink rate ramps 0 -> descent speed
AUTO_MIN_DESCENT_MS = 1.0
AUTO_MAX_DESCENT_MS = 200.0
AUTO_DEFAULT_MAX_ALT_M = 1000.0
AUTO_DEFAULT_BURN_S = 3.5
AUTO_DEFAULT_DESCENT_MS = 12.0
AUTO_DEFAULT_DURATION_S = 120.0
AUTO_SPEEDS = [("0.5x", 0.5), ("1x", 1.0), ("2x", 2.0), ("5x", 5.0), ("10x", 10.0)]

SIM_PHASE_COLORS = dict(SIM_STATUS_COLORS)
SIM_PHASE_COLORS.update({
    "STANDBY": "#9E9E9E",
    "LAUNCH": "#FF5252",
    "POWERED ASCENT": "#00FFCC",
    "COASTING": "#40C4FF",
    "APOGEE": "#E040FB",
    "DESCENT": "#FF8A00",
    "LANDING": "#B2FF59",
})


def _mix(c1, c2, f):
    f = max(0.0, min(1.0, f))
    a, b = QColor(c1), QColor(c2)
    return QColor(int(a.red() + (b.red() - a.red()) * f),
                  int(a.green() + (b.green() - a.green()) * f),
                  int(a.blue() + (b.blue() - a.blue()) * f))


def _nice_ceil(v):
    """Round v up to a 'nice' scale limit (1, 2, 2.5, 5, 10 x 10^n)."""
    if v <= 0:
        return 1.0
    e = math.floor(math.log10(v))
    base = 10.0 ** e
    f = v / base
    for n in (1, 2, 2.5, 5, 10):
        if f <= n + 1e-9:
            return n * base
    return 10.0 * base


def _nice_step(raw):
    """Tick spacing (1, 2, 5, 10 x 10^n) close to raw."""
    if raw <= 0:
        return 1.0
    e = math.floor(math.log10(raw))
    base = 10.0 ** e
    f = raw / base
    for n in (1, 2, 5, 10):
        if f <= n + 1e-9:
            return n * base
    return 10.0 * base


# ------------------------------------------------------------------
# AUTOMATIC SIMULATION ENGINE (no telemetry involved)
# ------------------------------------------------------------------

class FlightProfile:
    """
    Closed-form flight profile used by the automatic mode.

        t0 .. t_ign   LAUNCH            ignition on the pad, then lift-off
        .. t2         POWERED ASCENT    constant net acceleration for burn time
        .. t3         COASTING          decelerates at g until v = 0
        .. t4         APOGEE            short hold at maximum altitude
        .. t_end      DESCENT / LANDING parachute: sink rate ramps up to the
                                        descent speed, then constant
        >= t_end      LANDED

    The net burn acceleration is solved so that the apogee equals exactly the
    requested maximum altitude for the chosen burn time.
    """

    def __init__(self, max_alt, burn_s, descent_speed,
                 duration=None, fit_duration=False):
        g = AUTO_G
        self.H = max(float(max_alt), 1.0)
        self.tb = max(float(burn_s), 0.2)
        self.note = ""

        A = self.tb ** 2 / (2.0 * g)
        B = self.tb ** 2 / 2.0
        self.a = (-B + math.sqrt(B * B + 4.0 * A * self.H)) / (2.0 * A)
        self.vb = self.a * self.tb                  # burnout speed (max speed)
        self.hb = 0.5 * self.a * self.tb ** 2       # burnout altitude

        self.t_ign = AUTO_IGNITION_S
        clear = min(AUTO_CLEAR_TOWER_M, 0.8 * self.hb)
        self.t_clear = math.sqrt(2.0 * clear / self.a)
        self.t1 = self.t_ign + self.t_clear         # end of LAUNCH
        self.t2 = self.t_ign + self.tb              # burnout
        self.t3 = self.t2 + self.vb / g             # apogee reached
        self.t4 = self.t3 + AUTO_APOGEE_HOLD_S      # start of descent

        if fit_duration and duration is not None:
            raw_vd = self._fit_descent_speed(self.H, float(duration) - self.t4)
        else:
            raw_vd = float(descent_speed)
        vd = min(max(raw_vd, AUTO_MIN_DESCENT_MS), AUTO_MAX_DESCENT_MS)
        if fit_duration and abs(vd - raw_vd) > 1e-9:
            self.note = "Requested duration not reachable - descent speed limited."
        self.vd = vd
        self.tr = min(AUTO_CHUTE_RAMP_S, self.H / self.vd)
        self.t_end = self.t4 + self.tr + (self.H - self.vd * self.tr / 2.0) / self.vd
        self.duration = self.t_end
        self.zone = min(max(10.0, 0.03 * self.H), 0.3 * self.H)  # LANDING zone
        self.sample_dt = max(0.05, self.duration / 2000.0)

        n = 240
        self.ghost = [(self.duration * i / (n - 1),
                       self.state(self.duration * i / (n - 1))[0])
                      for i in range(n)]

    @staticmethod
    def _fit_descent_speed(H, td):
        """Descent speed that makes the descent last td seconds."""
        ramp = AUTO_CHUTE_RAMP_S
        if td > ramp / 2.0:
            v1 = H / (td - ramp / 2.0)
            if H / v1 >= ramp:
                return v1
        return 1.5 * H / max(td, 0.2)

    def state(self, t):
        """-> (altitude m, vertical speed m/s, phase, flame 0..1, chute 0..1)"""
        g = AUTO_G
        if t < self.t_ign:
            return 0.0, 0.0, "LAUNCH", 0.15 + 0.35 * (t / self.t_ign), 0.0
        if t < self.t2:
            tau = t - self.t_ign
            ph = "LAUNCH" if t < self.t1 else "POWERED ASCENT"
            return 0.5 * self.a * tau * tau, self.a * tau, ph, 1.0, 0.0
        if t < self.t3:
            d = t - self.t2
            return (self.hb + self.vb * d - 0.5 * g * d * d,
                    self.vb - g * d, "COASTING", 0.0, 0.0)
        if t < self.t4:
            return self.H, 0.0, "APOGEE", 0.0, 0.0
        if t < self.t4 + self.tr:
            d = t - self.t4
            return (self.H - self.vd * d * d / (2.0 * self.tr),
                    -self.vd * d / self.tr, "DESCENT", 0.0, d / self.tr)
        if t < self.t_end:
            alt = max(self.H - self.vd * self.tr / 2.0
                      - self.vd * (t - self.t4 - self.tr), 0.0)
            ph = "LANDING" if alt <= self.zone else "DESCENT"
            return alt, -self.vd, ph, 0.0, 1.0
        return 0.0, 0.0, "LANDED", 0.0, 0.0


class AutoSimulationEngine:
    """Clock + state holder for the automatic mode. Pure Python (no Qt)."""

    def __init__(self):
        self.profile = None
        self.speed = 1.0
        self.reset()

    def reset(self):
        self.state = "idle"          # idle | running | paused | finished
        self.t = 0.0
        self.alt = 0.0
        self.vel = 0.0
        self.phase = "READY"
        self.flame = 0.0
        self.chute = 0.0
        self.separation = 0.0
        self.cansat_alt = 0.0
        self.rocket_chute = 0.0
        self.cansat_chute = 0.0
        self.max_alt = 0.0
        self.tx = deque(maxlen=SIM_HISTORY)
        self.ty = deque(maxlen=SIM_HISTORY)
        self._last_sample_t = -1e9

    def configure(self, profile):
        self.reset()
        self.profile = profile

    def start(self):
        if self.profile is None or self.state != "idle":
            return
        self.state = "running"
        self._evaluate(force_sample=True)

    def pause(self):
        if self.state == "running":
            self.state = "paused"

    def resume(self):
        if self.state == "paused":
            self.state = "running"

    def advance(self, dt):
        if self.state != "running" or self.profile is None:
            return False
        self.t += dt * self.speed
        finished = self.t >= self.profile.t_end
        if finished:
            self.t = self.profile.t_end
        self._evaluate(force_sample=finished)
        if finished:
            self.state = "finished"
        return True

    def _evaluate(self, force_sample=False):
        alt, vel, phase, flame, chute = self.profile.state(self.t)
        self.alt, self.vel, self.phase = alt, vel, phase
        self.flame, self.chute = flame, chute
        self.max_alt = max(self.max_alt, alt)

        # Mid-body CanSat separation is armed only after apogee, on descent.
        # The trigger is the first descending crossing of 800 m.
        prof = self.profile
        if prof.H > 800.0:
            ramp_end_alt = prof.H - prof.vd * prof.tr / 2.0
            if 800.0 >= ramp_end_alt:
                t_sep = prof.t4 + math.sqrt(
                    max(0.0, 2.0 * (prof.H - 800.0) * prof.tr / prof.vd))
            else:
                t_sep = prof.t4 + prof.tr + (ramp_end_alt - 800.0) / prof.vd
            elapsed = self.t - t_sep
            self.separation = min(1.0, max(0.0, elapsed / 1.8))
            # Both vehicles receive their own parachute after the CanSat clears.
            deploy = min(1.0, max(0.0, (elapsed - 1.0) / 1.5))
            self.rocket_chute = deploy
            self.cansat_chute = deploy
            self.cansat_alt = (800.0 if elapsed <= 1.0 else
                               max(0.0, 800.0 - 5.0 * (elapsed - 1.0)))
        else:
            self.separation = 0.0
            self.rocket_chute = 0.0
            self.cansat_chute = 0.0
            self.cansat_alt = 0.0

        if force_sample or self.t - self._last_sample_t >= self.profile.sample_dt:
            self.tx.append(self.t)
            self.ty.append(alt)
            self._last_sample_t = self.t


# ------------------------------------------------------------------
# SCENE WIDGET
# ------------------------------------------------------------------

class RocketSceneWidget(QWidget):
    """
    Painter-based 2D scene: launch pad, ground line, altitude scale, rocket
    and a flight-trajectory (altitude vs time) panel.

    `target_alt` is the REAL altitude (source of truth, shown as text).
    `disp_alt` only exists to make the drawing glide smoothly toward it; it is
    never used for any number on screen.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(520, 420)
        self.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Expanding)
        self.smooth = True
        self.reset()

    def reset(self):
        self.target_alt = 0.0
        self.disp_alt = 0.0
        self.max_alt = 0.0
        self.view_max = SIM_MIN_VIEW_M
        self.fixed_view = None
        self.status = "READY"
        self.vspeed = None
        self.signal_ok = True
        self.has_data = False
        self.note = ""
        self.flame = 0.0
        self.chute = 0.0
        self.separation = 0.0
        self.cansat_alt = 0.0
        self.rocket_chute = 0.0
        self.cansat_chute = 0.0
        self.streak = False
        self.traj_x = []
        self.traj_y = []
        self.span = None
        self.ghost = None
        self.update()

    def set_state(self, alt, max_alt, status, vspeed, has_data, note="",
                  flame=0.0, chute=0.0, streak=False, separation=0.0,
                  cansat_alt=0.0, rocket_chute=None, cansat_chute=0.0):
        self.target_alt = alt
        self.max_alt = max_alt
        self.status = status
        self.vspeed = vspeed
        self.has_data = has_data
        self.note = note
        self.flame = flame
        self.chute = chute
        self.separation = min(1.0, max(0.0, separation))
        self.cansat_alt = max(0.0, cansat_alt)
        self.rocket_chute = chute if rocket_chute is None else rocket_chute
        self.cansat_chute = cansat_chute
        self.streak = streak
        self.update()

    def set_trajectory(self, xs, ys, span=None, ghost=None):
        self.traj_x = xs
        self.traj_y = ys
        self.span = span
        self.ghost = ghost

    def set_signal(self, ok):
        if ok != self.signal_ok:
            self.signal_ok = ok
            self.update()

    def set_smooth(self, flag):
        self.smooth = bool(flag)

    def set_fixed_view(self, v):
        self.fixed_view = v
        if v:
            self.view_max = v
        self.update()

    def snap(self):
        self.disp_alt = self.target_alt
        self.view_max = self._target_view_max()
        self.update()

    def _target_view_max(self):
        top = max(self.target_alt, self.max_alt, 0.0) * 1.15
        if self.fixed_view:
            return max(self.fixed_view, _nice_ceil(top))
        return _nice_ceil(max(SIM_MIN_VIEW_M, top))

    def advance(self, dt):
        """Smoothing step. Returns True if something moved and a repaint is needed."""
        changed = False
        d = self.target_alt - self.disp_alt
        if self.smooth:
            if abs(d) > 0.005:
                self.disp_alt += d * (1.0 - math.exp(-dt / SIM_SMOOTH_TAU_S))
                changed = True
            elif d != 0.0:
                self.disp_alt = self.target_alt
                changed = True
        elif d != 0.0:
            self.disp_alt = self.target_alt
            changed = True
        dv = self._target_view_max() - self.view_max
        if abs(dv) > 0.01:
            self.view_max += dv * (1.0 - math.exp(-dt / SIM_VIEW_TAU_S))
            changed = True
        if self.flame > 0.02:
            changed = True            # flame flickers every frame
        return changed

    # ---------------- trajectory panel ----------------
    def _paint_trajectory(self, p, left, w, pad_y, y_of):
        """Draws the panel + trace. Returns tick labels to draw after the ground."""
        tx0 = left + (w - left) * 0.52
        tx1 = w - 16.0
        if tx1 - tx0 < 90:
            return []
        top = 72.0
        xs = list(self.traj_x)
        ys = list(self.traj_y)
        if self.span is not None:
            t0, t1 = self.span
        elif xs:
            t0 = xs[0]
            t1 = t0 + max(xs[-1] - t0, 10.0) * 1.04
        else:
            t0, t1 = 0.0, 10.0
        if t1 - t0 < 1e-6:
            t1 = t0 + 1.0
        span_t = t1 - t0

        def x_of(t):
            return tx0 + (t - t0) / span_t * (tx1 - tx0)

        panel = QRectF(tx0 - 6, top, (tx1 - tx0) + 12, pad_y - top)
        p.setPen(QPen(QColor(255, 255, 255, 40), 1))
        p.setBrush(QColor(0, 0, 0, 70))
        p.drawRect(panel)
        p.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        p.setPen(QColor(220, 220, 220, 200))
        p.drawText(QPointF(tx0 + 2, top + 14), "FLIGHT TRAJECTORY  (altitude vs time)")

        labels = []
        step = _nice_step(span_t / 4.0)
        k = 0
        while k * step <= span_t + 1e-9 and k < 40:
            x = x_of(t0 + k * step)
            p.setPen(QPen(QColor(255, 255, 255, 28), 1, Qt.PenStyle.DotLine))
            p.drawLine(QPointF(x, top), QPointF(x, pad_y))
            labels.append((x, f"{k * step:g}s"))
            k += 1

        p.save()
        p.setClipRect(panel)
        p.setBrush(Qt.BrushStyle.NoBrush)

        if self.ghost:                                  # planned profile (auto mode)
            gp = QPainterPath()
            for i, (t, a) in enumerate(self.ghost):
                pt = QPointF(x_of(t), y_of(a))
                if i == 0:
                    gp.moveTo(pt)
                else:
                    gp.lineTo(pt)
            p.setPen(QPen(QColor(255, 255, 255, 85), 1.5, Qt.PenStyle.DotLine))
            p.drawPath(gp)

        n = min(len(xs), len(ys))
        if n >= 1:
            stride = max(1, n // SIM_TRAJ_DRAW_POINTS)
            idx = list(range(0, n, stride))
            if idx[-1] != n - 1:
                idx.append(n - 1)
            tp = QPainterPath()
            for j, i in enumerate(idx):
                pt = QPointF(x_of(xs[i]), y_of(ys[i]))
                if j == 0:
                    tp.moveTo(pt)
                else:
                    tp.lineTo(pt)
            p.setPen(QPen(QColor("#00FFCC"), 2))
            p.drawPath(tp)
            p.setPen(QPen(QColor("#FFFFFF"), 1.5))
            p.setBrush(QColor("#00FFCC"))
            p.drawEllipse(QPointF(x_of(xs[n - 1]), y_of(ys[n - 1])), 4.5, 4.5)
        p.restore()
        return labels

    # ---------------- drawing ----------------
    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        left = 66                                   # altitude-scale strip
        ground_h = max(56, int(h * 0.13))
        pad_y = h - ground_h                        # y of altitude = 0
        rh = max(60.0, min(120.0, h * 0.16))        # rocket height (px)
        rw = rh * 0.26
        top_m = rh * 1.9 + 40                       # room for nose + parachute
        scale_px = max(10.0, pad_y - top_m)
        cx = left + (w - left) * 0.28
        vmax = max(self.view_max, 1.0)

        def y_of(alt):
            return pad_y - (max(alt, 0.0) / vmax) * scale_px

        # --- sky (darkens with altitude) + stars ---
        f = min(1.0, max(0.0, self.disp_alt) / 3000.0)
        g = QLinearGradient(0, 0, 0, pad_y)
        g.setColorAt(0.0, _mix("#071226", "#000000", f))
        g.setColorAt(1.0, _mix("#2B5F8E", "#0B1B33", f))
        p.fillRect(QRectF(0, 0, w, pad_y), QBrush(g))

        p.setPen(Qt.PenStyle.NoPen)
        star_alpha = int(50 + 205 * f)
        for i in range(70):   # fixed, decorative star positions (not data)
            sx = left + ((math.sin(i * 12.9898) * 43758.5453) % 1.0) * (w - left)
            sy = ((math.sin(i * 78.233) * 12345.6789) % 1.0) * pad_y * 0.85
            sr = 0.8 + ((i * 37) % 10) / 10.0
            p.setBrush(QColor(255, 255, 255, star_alpha))
            p.drawEllipse(QPointF(sx, sy), sr, sr)

        # --- flight trajectory panel (shares the altitude scale) ---
        tick_labels = self._paint_trajectory(p, left, w, pad_y, y_of)

        # --- altitude scale ---
        p.fillRect(QRectF(0, 0, left, pad_y), QColor(0, 0, 0, 110))
        p.setPen(QPen(QColor("#CFCFCF"), 1))
        p.drawLine(QPointF(left, 0), QPointF(left, pad_y))
        step = _nice_step(vmax / 6.0)
        p.setFont(QFont("Consolas", 8))
        k = 0
        while k * step <= vmax + 1e-9 and k < 60:
            a = k * step
            y = y_of(a)
            p.setPen(QPen(QColor(255, 255, 255, 45), 1, Qt.PenStyle.DashLine))
            p.drawLine(QPointF(left, y), QPointF(w, y))
            p.setPen(QColor("#CFCFCF"))
            p.drawText(QRectF(0, y - 8, left - 8, 16),
                       Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                       f"{a:g} m")
            k += 1

        # --- apogee marker ---
        if self.max_alt > 0.5:
            y = y_of(self.max_alt)
            p.setPen(QPen(QColor("#FF8A00"), 1.5, Qt.PenStyle.DashLine))
            p.drawLine(QPointF(left, y), QPointF(w, y))
            p.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
            p.setPen(QColor("#FF8A00"))
            p.drawText(QPointF(left + 8, y - 5), f"APOGEE {self.max_alt:.1f} m")

        # --- ground ---
        gg = QLinearGradient(0, pad_y, 0, h)
        gg.setColorAt(0.0, QColor("#3A5A3A"))
        gg.setColorAt(1.0, QColor("#142014"))
        p.fillRect(QRectF(0, pad_y, w, ground_h), QBrush(gg))
        p.setPen(QPen(QColor("#E0E0E0"), 2))
        p.drawLine(QPointF(0, pad_y), QPointF(w, pad_y))
        p.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        p.setPen(QColor("#E6E6E6"))
        p.drawText(QPointF(left + 8, pad_y + 18), "GROUND LEVEL  ·  0 m")
        p.setFont(QFont("Consolas", 8))
        p.setPen(QColor("#E6E6E6"))
        for x, txt in tick_labels:
            p.drawText(QPointF(x - 10, pad_y + 18), txt)

        # --- launch pad + gantry tower ---
        pad_w = rw * 3.4
        p.setPen(QPen(QColor("#BDBDBD"), 1))
        p.setBrush(QColor("#6E6E6E"))
        p.drawRect(QRectF(cx - pad_w / 2, pad_y, pad_w, 10))
        p.setBrush(QColor("#4A4A4A"))
        p.drawRect(QRectF(cx - pad_w / 2 + 6, pad_y + 10, 8, ground_h * 0.35))
        p.drawRect(QRectF(cx + pad_w / 2 - 14, pad_y + 10, 8, ground_h * 0.35))

        tx = cx - pad_w / 2 - 14
        th = rh * 1.25
        p.setPen(QPen(QColor("#9E9E9E"), 2))
        p.drawLine(QPointF(tx, pad_y), QPointF(tx, pad_y - th))
        p.drawLine(QPointF(tx + 12, pad_y), QPointF(tx + 12, pad_y - th))
        n_seg = 6
        for i in range(n_seg):
            y0 = pad_y - th * i / n_seg
            y1 = pad_y - th * (i + 1) / n_seg
            p.drawLine(QPointF(tx, y0), QPointF(tx + 12, y1))
            p.drawLine(QPointF(tx + 12, y0), QPointF(tx, y1))

        # --- rocket (vertical position = smoothed real altitude) ---
        by = y_of(self.disp_alt)
        p.save()
        p.translate(cx, by)

        # live mode: motion streak while the measured altitude is increasing
        if self.streak:
            trail = min(rh * 1.8, max(0.0, pad_y - by))
            if trail > 4:
                tg = QLinearGradient(0, 0, 0, trail)
                tg.setColorAt(0.0, QColor(255, 190, 70, 170))
                tg.setColorAt(1.0, QColor(255, 190, 70, 0))
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(tg))
                p.drawRect(QRectF(-rw * 0.2, 0, rw * 0.4, trail))

        # automatic mode: engine flame
        if self.flame > 0.02:
            now = time.monotonic()
            fl = (rh * 0.6 * self.flame
                  * (0.85 + 0.15 * math.sin(now * 40.0)
                     + 0.08 * math.sin(now * 97.0)))
            fw = rw * 0.34
            outer = QPainterPath()
            outer.moveTo(-fw, 0)
            outer.quadTo(-fw * 0.6, fl * 0.55, 0, fl)
            outer.quadTo(fw * 0.6, fl * 0.55, fw, 0)
            outer.closeSubpath()
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(255, 120, 0, 210))
            p.drawPath(outer)
            inner = QPainterPath()
            inner.moveTo(-fw * 0.5, 0)
            inner.quadTo(-fw * 0.3, fl * 0.35, 0, fl * 0.62)
            inner.quadTo(fw * 0.3, fl * 0.35, fw * 0.5, 0)
            inner.closeSubpath()
            p.setBrush(QColor(255, 235, 130, 235))
            p.drawPath(inner)

        nh = rh * 0.05                 # nozzle height
        bh = rh * 0.67                 # body height
        body_bottom = -nh
        body_top = -nh - bh

        # fins
        p.setPen(QPen(QColor("#8E0000"), 1))
        p.setBrush(QColor("#E53935"))
        p.drawPolygon(QPolygonF([
            QPointF(-rw / 2, body_top + bh * 0.62),
            QPointF(-rw / 2 - rw * 0.6, body_bottom + rh * 0.02),
            QPointF(-rw / 2, body_bottom)]))
        p.drawPolygon(QPolygonF([
            QPointF(rw / 2, body_top + bh * 0.62),
            QPointF(rw / 2 + rw * 0.6, body_bottom + rh * 0.02),
            QPointF(rw / 2, body_bottom)]))

        # nozzle
        p.setPen(QPen(QColor("#222222"), 1))
        p.setBrush(QColor("#4A4A4A"))
        p.drawPolygon(QPolygonF([
            QPointF(-rw * 0.28, body_bottom), QPointF(rw * 0.28, body_bottom),
            QPointF(rw * 0.38, 0), QPointF(-rw * 0.38, 0)]))

        # body (shaded cylinder)
        bg = QLinearGradient(-rw / 2, 0, rw / 2, 0)
        bg.setColorAt(0.0, QColor("#90A4AE"))
        bg.setColorAt(0.45, QColor("#FFFFFF"))
        bg.setColorAt(1.0, QColor("#78909C"))
        p.setPen(QPen(QColor("#546E7A"), 1))
        p.setBrush(QBrush(bg))
        p.drawRect(QRectF(-rw / 2, body_top, rw, bh))

        # colour band
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#E53935"))
        p.drawRect(QRectF(-rw / 2, body_bottom - bh * 0.22, rw, bh * 0.1))

        # nose cone
        nose = QPainterPath()
        nose.moveTo(-rw / 2, body_top)
        nose.cubicTo(-rw / 2, body_top - rh * 0.16,
                     -rw * 0.12, -rh + rh * 0.03, 0, -rh)
        nose.cubicTo(rw * 0.12, -rh + rh * 0.03,
                     rw / 2, body_top - rh * 0.16, rw / 2, body_top)
        nose.closeSubpath()
        p.setPen(QPen(QColor("#8E0000"), 1))
        p.setBrush(QColor("#E53935"))
        p.drawPath(nose)

        # window
        p.setPen(QPen(QColor("#37474F"), 1.5))
        p.setBrush(QColor("#4FC3F7"))
        p.drawEllipse(QPointF(0, body_top + bh * 0.38), rw * 0.17, rw * 0.17)

        # Mid-body payload bay: CanSat is visible inside before ejection.
        bay_y = body_top + bh * 0.60
        bay_h = bh * 0.22
        p.setPen(QPen(QColor("#263238"), 1.2))
        p.setBrush(QColor("#263238"))
        p.drawRect(QRectF(-rw * 0.34, bay_y, rw * 0.68, bay_h))
        # The CanSat stays seated in the payload bay while the rocket is
        # ascending, at apogee, and while descending above the 800 m trigger.
        # Separation progress is zero in all those phases, so both doors remain
        # fully closed and the CanSat remains inside the rocket.

        # Two-stage sequence after the descent-only separation trigger:
        #   0.00-0.35: both mid-body doors open outward together.
        #   0.35-1.00: the CanSat is pushed outward through the open bay.
        sep_progress = min(1.0, max(0.0, self.separation))
        door_progress = min(1.0, sep_progress / 0.35)
        eject_progress = min(1.0, max(0.0, (sep_progress - 0.35) / 0.65))
        door_angle = 82.0 * door_progress
        door_w = rw * 0.42
        door_h = bay_h * 1.10

        # Left mid-body door and hinge.
        p.save()
        p.translate(-rw / 2, bay_y + bay_h / 2)
        p.rotate(-door_angle)
        p.setPen(QPen(QColor("#8E0000"), 1))
        p.setBrush(QColor("#EF5350"))
        p.drawRect(QRectF(-door_w, -door_h / 2, door_w, door_h))
        p.setBrush(QColor("#B0BEC5"))
        p.drawEllipse(QPointF(0, 0), 2.5, 2.5)
        p.restore()

        # Right mid-body door and hinge.
        p.save()
        p.translate(rw / 2, bay_y + bay_h / 2)
        p.rotate(door_angle)
        p.setPen(QPen(QColor("#8E0000"), 1))
        p.setBrush(QColor("#EF5350"))
        p.drawRect(QRectF(0, -door_h / 2, door_w, door_h))
        p.setBrush(QColor("#B0BEC5"))
        p.drawEllipse(QPointF(0, 0), 2.5, 2.5)
        p.restore()

        # Draw one CanSat only. It is initially centred inside the bay, then
        # moves smoothly outwards only after the doors have opened.
        p.save()
        p.translate(rw * (0.12 + 2.0 * eject_progress),
                    bay_y + bay_h * 0.5)
        p.setPen(QPen(QColor("#004D40"), 1))
        p.setBrush(QColor("#26A69A"))
        p.drawRoundedRect(QRectF(-rw * 0.22, -bay_h * 0.38,
                                 rw * 0.44, bay_h * 0.76), 2, 2)
        p.setPen(QPen(QColor("#E0F2F1"), 1))
        p.drawLine(QPointF(-rw * 0.13, -bay_h * 0.20),
                   QPointF(rw * 0.13, -bay_h * 0.20))
        p.restore()

        # Independent rocket parachute deploys after separation.
        if self.rocket_chute > 0.02:
            c = min(1.0, self.rocket_chute)
            cw = rw * 1.8 * c + 2.0
            cy = -rh - rh * 0.8 * c
            ch = rh * 0.42 * c + 1.0
            p.setPen(QPen(QColor(235, 235, 235, 190), 1))
            for sx in (-cw, -cw * 0.5, cw * 0.5, cw):
                p.drawLine(QPointF(sx, cy), QPointF(0, -rh))
            canopy = QPainterPath()
            canopy.moveTo(-cw, cy)
            canopy.cubicTo(-cw, cy - ch * 1.4, cw, cy - ch * 1.4, cw, cy)
            canopy.quadTo(cw * 0.5, cy + ch * 0.25, 0, cy)
            canopy.quadTo(-cw * 0.5, cy + ch * 0.25, -cw, cy)
            p.setPen(QPen(QColor("#BF360C"), 1.2))
            p.setBrush(QColor("#FF7043"))
            p.drawPath(canopy)
        p.restore()

        # Separate CanSat + its own parachute after it has cleared the bay.
        if self.separation >= 1.0:
            cs_y = y_of(self.cansat_alt) - rh * 0.45
            cs_x = cx + rw * 2.12
            cs_h = rh * 0.17
            cs_w = rw * 0.62
            p.save()
            p.translate(cs_x, cs_y)
            p.setPen(QPen(QColor("#004D40"), 1.2))
            p.setBrush(QColor("#26A69A"))
            p.drawRoundedRect(QRectF(-cs_w / 2, -cs_h, cs_w, cs_h), 3, 3)
            p.setPen(QPen(QColor("#E0F2F1"), 1))
            p.drawLine(QPointF(-cs_w * 0.25, -cs_h * 0.72),
                       QPointF(cs_w * 0.25, -cs_h * 0.72))
            if self.cansat_chute > 0.02:
                cc = min(1.0, self.cansat_chute)
                canopy_w = rw * 1.05 * cc + 1.0
                canopy_y = -cs_h - rh * 0.48 * cc
                canopy_h = rh * 0.24 * cc + 1.0
                p.setPen(QPen(QColor("#E0E0E0"), 1))
                p.drawLine(QPointF(-cs_w * 0.25, -cs_h),
                           QPointF(-canopy_w, canopy_y))
                p.drawLine(QPointF(cs_w * 0.25, -cs_h),
                           QPointF(canopy_w, canopy_y))
                cp = QPainterPath()
                cp.moveTo(-canopy_w, canopy_y)
                cp.cubicTo(-canopy_w, canopy_y - canopy_h,
                           canopy_w, canopy_y - canopy_h,
                           canopy_w, canopy_y)
                cp.quadTo(0, canopy_y + canopy_h * 0.25,
                          -canopy_w, canopy_y)
                p.setPen(QPen(QColor("#1565C0"), 1.2))
                p.setBrush(QColor("#42A5F5"))
                p.drawPath(cp)
            p.restore()

        # real (unsmoothed) altitude tag beside the rocket
        tag_x = cx + rw * 0.5 + rw * 0.6 + 12
        tag_y = min(max(by - rh * 0.5, 70), pad_y - 8)
        p.setFont(QFont("Consolas", 10, QFont.Weight.Bold))
        p.setPen(QColor("#00FFCC"))
        p.drawText(QPointF(tag_x, tag_y), f"{self.target_alt:.1f} m")
        if self.vspeed is not None and self.signal_ok:
            p.setFont(QFont("Consolas", 9))
            p.setPen(QColor("#E6E6E6"))
            p.drawText(QPointF(tag_x, tag_y + 15), f"{self.vspeed:+.1f} m/s")

        # --- HUD: phase pill ---
        col = QColor(SIM_PHASE_COLORS.get(self.status, "#FFFFFF"))
        p.setFont(QFont("Consolas", 12, QFont.Weight.Bold))
        tw = p.fontMetrics().horizontalAdvance(self.status)
        pill = QRectF(left + 10, 10, tw + 44, 28)
        p.setPen(QPen(col, 2))
        p.setBrush(QColor(0, 0, 0, 150))
        p.drawRoundedRect(pill, 8, 8)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(col)
        p.drawEllipse(QPointF(pill.left() + 14, pill.center().y()), 5, 5)
        p.setPen(col)
        p.drawText(QPointF(pill.left() + 28, pill.top() + 19), self.status)

        note = self.note
        if not self.has_data:
            note = "Awaiting telemetry…"
        if note:
            p.setFont(QFont("Consolas", 9))
            p.setPen(QColor("#E6E6E6"))
            p.drawText(QPointF(left + 12, 56), note)

        if self.has_data and not self.signal_ok:
            bw = 330.0
            ban = QRectF(w - bw - 10, 10, bw, 28)
            p.setPen(QPen(QColor("#FF3333"), 2))
            p.setBrush(QColor(60, 0, 0, 200))
            p.drawRoundedRect(ban, 8, 8)
            p.setFont(QFont("Consolas", 10, QFont.Weight.Bold))
            p.setPen(QColor("#FF3333"))
            p.drawText(ban, Qt.AlignmentFlag.AlignCenter,
                       "⚠ TELEMETRY LOST — HOLDING LAST ALTITUDE")
        p.end()


# ------------------------------------------------------------------
# TAB 3 WIDGET
# ------------------------------------------------------------------

class RocketSimulationTab(QWidget):
    """
    Tab 3: 2D rocket flight simulation with two selectable modes.

    LIVE SENSOR DATA
        Data path:  SerialReaderThread -> telemetry_packet_signal ->
                    GroundStationGUI.handle_telemetry_packet(pkt) ->
                    GroundStationGUI._feed_new_tabs(pkt) ->
                    RocketSimulationTab.update_from_packet(pkt)
        Altitude comes only from pkt[SIM_ALT_KEY] (bmp_alt). Vertical speed is
        the slope of recent altitude samples and the flight status is derived
        from those two measured values. Missing / invalid / duplicate / glitch
        packets are rejected and the last valid position is held.

    AUTOMATIC SIMULATION
        Independent AutoSimulationEngine + FlightProfile; no telemetry needed.

    Both modes share the animation timer (QTimer, GUI thread, ~30 fps); all
    work per frame is a few arithmetic operations, so the GUI never blocks.
    Live telemetry keeps being tracked in the background while the automatic
    mode is displayed (and while the live display is paused).
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.mode = SIM_MODE_LIVE
        self.live_state = "running"          # idle | running | paused
        self.engine = AutoSimulationEngine()
        self._preview = None
        self._status_col = None
        self._link_col = None
        self._reset_live_state()
        self._build_ui()

        self._last_frame = time.monotonic()
        self._frame_n = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._on_frame)
        self.timer.start(SIM_FRAME_MS)
        self._on_mode_changed()

    # ------------------------------------------------------------
    # UI
    # ------------------------------------------------------------
    def _build_ui(self):
        self.setStyleSheet(
            "QDoubleSpinBox { background-color: #1B1B1B;"
            " border: 1px solid #383838; padding: 3px; }")
        root = QVBoxLayout(self)

        # ---- control bar ----
        gb_ctl = QGroupBox("SIMULATION CONTROL")
        cl = QHBoxLayout(gb_ctl)
        cl.addWidget(QLabel("Mode:"))
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems([SIM_MODE_LIVE, SIM_MODE_AUTO])
        self.cmb_mode.setMinimumWidth(190)
        cl.addWidget(self.cmb_mode)
        cl.addSpacing(14)

        def mkbtn(text, tip, color):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.setMinimumWidth(84)
            b.setStyleSheet(
                f"QPushButton {{ color: {color}; font-weight: bold; }}"
                "QPushButton:disabled { color: #555555; }")
            return b

        self.btn_start = mkbtn("▶ Start", "Start the simulation / live tracking",
                               "#00FFCC")
        self.btn_pause = mkbtn("⏸ Pause", "Freeze the animation", "#FFD400")
        self.btn_resume = mkbtn("⏵ Resume", "Continue after a pause", "#69F0AE")
        self.btn_reset = mkbtn("⟲ Reset", "Clear the simulation back to its start",
                               "#FF8A00")
        for b in (self.btn_start, self.btn_pause, self.btn_resume, self.btn_reset):
            cl.addWidget(b)
        cl.addSpacing(14)
        self.btn_rezero = QPushButton("Re-zero ground level")
        self.btn_rezero.setToolTip(
            "Live mode: use the latest sensor altitude as the 0 m reference "
            "(only while READY or LANDED)")
        cl.addWidget(self.btn_rezero)
        self.lbl_speed_cap = QLabel("Playback speed:")
        self.cmb_speed = QComboBox()
        for txt, _v in AUTO_SPEEDS:
            self.cmb_speed.addItem(txt)
        self.cmb_speed.setCurrentIndex(1)
        cl.addWidget(self.lbl_speed_cap)
        cl.addWidget(self.cmb_speed)
        cl.addStretch()
        root.addWidget(gb_ctl)

        # ---- main row: scene | side panel ----
        row = QHBoxLayout()
        self.scene = RocketSceneWidget()
        gb_scene = QGroupBox("2D ROCKET FLIGHT SIMULATION")
        QVBoxLayout(gb_scene).addWidget(self.scene)
        row.addWidget(gb_scene, 3)

        side = QWidget()
        side.setMinimumWidth(380)
        side_l = QVBoxLayout(side)
        side_l.setContentsMargins(0, 0, 0, 0)

        # ---- automatic-mode parameters ----
        self.gb_params = QGroupBox("AUTOMATIC SIMULATION PARAMETERS")
        pg_ = QGridLayout(self.gb_params)

        def spin(lo, hi, val, dec, step, suffix):
            s = QDoubleSpinBox()
            s.setRange(lo, hi)
            s.setDecimals(dec)
            s.setSingleStep(step)
            s.setValue(val)
            s.setSuffix(suffix)
            return s

        self.spn_alt = spin(1000, 1000, 1000, 0, 50, " m")
        self.spn_alt.setToolTip("Fixed mission apogee: 1000 m")
        self.spn_burn = spin(0.5, 60, AUTO_DEFAULT_BURN_S, 1, 0.5, " s")
        self.spn_desc = spin(AUTO_MIN_DESCENT_MS, AUTO_MAX_DESCENT_MS,
                             AUTO_DEFAULT_DESCENT_MS, 1, 1.0, " m/s")
        self.spn_dur = spin(10, 7200, AUTO_DEFAULT_DURATION_S, 0, 10, " s")
        self.chk_fit = QCheckBox("Fit descent speed to the flight duration")
        self.chk_fit.setToolTip(
            "Off: you set the descent speed and the duration is calculated.\n"
            "On : you set the duration and the descent speed is calculated.")
        pg_.addWidget(QLabel("Maximum altitude (apogee):"), 0, 0)
        pg_.addWidget(self.spn_alt, 0, 1)
        pg_.addWidget(QLabel("Motor burn time (ascent):"), 1, 0)
        pg_.addWidget(self.spn_burn, 1, 1)
        pg_.addWidget(QLabel("Descent speed:"), 2, 0)
        pg_.addWidget(self.spn_desc, 2, 1)
        pg_.addWidget(QLabel("Total flight duration:"), 3, 0)
        pg_.addWidget(self.spn_dur, 3, 1)
        pg_.addWidget(self.chk_fit, 4, 0, 1, 2)
        self.lbl_profile = QLabel("")
        self.lbl_profile.setWordWrap(True)
        self.lbl_profile.setStyleSheet("color: #BDBDBD;")
        pg_.addWidget(self.lbl_profile, 5, 0, 1, 2)
        side_l.addWidget(self.gb_params)

        # ---- flight data ----
        gb = QGroupBox("FLIGHT DATA")
        g = QGridLayout(gb)
        self.lbl_status = QLabel("READY")
        self.lbl_status.setStyleSheet(
            f"color: {SIM_STATUS_COLORS['READY']}; font-size: 18pt; font-weight: bold;")
        self.lbl_alt = QLabel("Altitude: 0.0 m")
        self.lbl_alt.setStyleSheet(
            "color: #00FFCC; font-size: 15pt; font-weight: bold;")
        self.lbl_apogee = QLabel("Apogee: 0.0 m")
        self.lbl_apogee.setStyleSheet(
            "color: #FF8A00; font-size: 13pt; font-weight: bold;")
        self.lbl_speed = QLabel("Vertical Speed: -- m/s")
        self.lbl_speed.setStyleSheet("font-size: 13pt; font-weight: bold;")
        self.lbl_info1 = QLabel("")
        self.lbl_info2 = QLabel("")
        self.lbl_info3 = QLabel("")
        self.lbl_time = QLabel("Flight Time: 0.00 s")
        self.lbl_link = QLabel("")
        self.lbl_link.setStyleSheet("color: #888888; font-weight: bold;")
        g.addWidget(self.lbl_status, 0, 0, 1, 2)
        g.addWidget(self.lbl_alt, 1, 0, 1, 2)
        g.addWidget(self.lbl_apogee, 2, 0, 1, 2)
        g.addWidget(self.lbl_speed, 3, 0, 1, 2)
        g.addWidget(self.lbl_info1, 4, 0, 1, 2)
        g.addWidget(self.lbl_info2, 5, 0, 1, 2)
        g.addWidget(self.lbl_info3, 6, 0, 1, 2)
        g.addWidget(self.lbl_time, 7, 0)
        g.addWidget(self.lbl_link, 7, 1)
        side_l.addWidget(gb)

        # ---- altitude vs time graph ----
        gb_plot = QGroupBox("ALTITUDE vs TIME")
        pw = pg.PlotWidget(title="Altitude above launch pad")
        pw.setLabel("left", "Altitude", units="m")
        pw.setLabel("bottom", "Time", units="s")
        pw.showGrid(x=True, y=True, alpha=0.25)
        pw.setBackground("#121212")
        pw.setMinimumHeight(200)
        pw.getPlotItem().getAxis("left").setWidth(70)
        self.plot = pw
        self.curve = pw.plot(pen=pg.mkPen(color="#00FFCC", width=2))
        self.ground_line = pg.InfiniteLine(
            pos=0, angle=0, pen=pg.mkPen("#777777", width=1))
        self.apogee_line = pg.InfiniteLine(
            pos=0, angle=0,
            pen=pg.mkPen("#FF8A00", width=1, style=Qt.PenStyle.DashLine))
        pw.addItem(self.ground_line, ignoreBounds=True)
        pw.addItem(self.apogee_line, ignoreBounds=True)
        self.apogee_line.setVisible(False)
        QVBoxLayout(gb_plot).addWidget(pw)
        side_l.addWidget(gb_plot, 1)
        row.addWidget(side, 2)
        root.addLayout(row, 1)

        # ---- wiring (after every widget exists) ----
        self.cmb_mode.currentIndexChanged.connect(self._on_mode_changed)
        self.cmb_speed.currentIndexChanged.connect(self._on_speed_changed)
        self.btn_start.clicked.connect(self._on_start)
        self.btn_pause.clicked.connect(self._on_pause)
        self.btn_resume.clicked.connect(self._on_resume)
        self.btn_reset.clicked.connect(self._on_reset)
        self.btn_rezero.clicked.connect(self._rezero)
        for s in (self.spn_alt, self.spn_burn, self.spn_desc, self.spn_dur):
            s.valueChanged.connect(self._on_params_changed)
        self.chk_fit.toggled.connect(self._on_params_changed)
        self._on_params_changed()

    # ------------------------------------------------------------
    # LIVE-MODE STATE
    # ------------------------------------------------------------
    def _reset_live_state(self):
        self.status = "READY"
        self.baseline = None if SIM_USE_RELATIVE_ALTITUDE else 0.0
        self.base_samples = []
        self.win = deque()                       # (time_s, altitude_m)
        self.hx = deque(maxlen=SIM_HISTORY)
        self.hy = deque(maxlen=SIM_HISTORY)
        self.t_offset = 0.0
        self.prev_raw_t = None
        self.last_x = None
        self.max_alt = 0.0
        self.cur_alt = 0.0
        self.raw_alt = None
        self.alt_source = SIM_ALT_KEY
        self.vspeed = None
        self.launch_count = 0
        self.descent_count = 0
        self.land_since = None
        self.launch_x = None
        self._launch_cand = None
        self.land_x = None
        self.glitch_count = 0
        self.last_packet_wall = None
        self.signal_ok = True
        self.packets = 0
        self.rejected = 0
        self._live_sep_started = None

    def _live_flight_time(self):
        if self.launch_x is None or self.last_x is None:
            return 0.0
        end = self.land_x if self.land_x is not None else self.last_x
        return max(0.0, end - self.launch_x)

    # ------------------------------------------------------------
    # BUTTON / MODE HANDLERS
    # ------------------------------------------------------------
    def _on_mode_changed(self, _idx=None):
        new = self.cmb_mode.currentText()
        if (new != self.mode and self.mode == SIM_MODE_AUTO
                and self.engine.state == "running"):
            self.engine.pause()          # never run unseen in the background
        self.mode = new
        live = new == SIM_MODE_LIVE
        self.gb_params.setVisible(not live)
        self.lbl_speed_cap.setVisible(not live)
        self.cmb_speed.setVisible(not live)
        self.btn_rezero.setVisible(live)
        self.scene.reset()
        self.scene.set_smooth(live)
        self._last_frame = time.monotonic()
        self._present()
        self.scene.snap()

    def _on_speed_changed(self, _idx=None):
        self.engine.speed = AUTO_SPEEDS[max(0, self.cmb_speed.currentIndex())][1]
        if self.mode == SIM_MODE_AUTO:
            self._present_auto(graph=False)

    def _on_start(self):
        if self.mode == SIM_MODE_LIVE:
            if self.live_state == "idle":
                self.live_state = "running"
                self._present()
            return
        if self.engine.state == "finished":
            self.engine.reset()
        if self.engine.state == "idle":
            self.engine.configure(self._make_profile())
            self.engine.speed = AUTO_SPEEDS[self.cmb_speed.currentIndex()][1]
            self.engine.start()
            self._last_frame = time.monotonic()
        self._present()

    def _on_pause(self):
        if self.mode == SIM_MODE_LIVE:
            if self.live_state == "running":
                self.live_state = "paused"
        else:
            self.engine.pause()
        self._present()

    def _on_resume(self):
        if self.mode == SIM_MODE_LIVE:
            if self.live_state == "paused":
                self.live_state = "running"
        else:
            self.engine.resume()
            self._last_frame = time.monotonic()
        self._present()
        if self.mode == SIM_MODE_LIVE:
            self.scene.snap()

    def _on_reset(self):
        if self.mode == SIM_MODE_LIVE:
            self._reset_live_state()
            self.live_state = "idle"     # press Start to track again
            self.scene.reset()
            self.scene.set_smooth(True)
        else:
            self.engine.reset()
            self.engine.speed = AUTO_SPEEDS[self.cmb_speed.currentIndex()][1]
            self.scene.reset()
            self.scene.set_smooth(False)
            self._on_params_changed()
        self._present()
        self.scene.snap()

    def reset(self):
        """Kept for compatibility with the previous revision."""
        self._on_reset()

    def _rezero(self):
        if (self.status in ("READY", "LANDED") and self.raw_alt is not None
                and self.live_state != "idle"):
            self.baseline = self.raw_alt
            self.base_samples = [self.raw_alt]
            self.cur_alt = 0.0
            self.max_alt = 0.0
            self.status = "READY"
            self.launch_count = 0
            self.launch_x = None
            self.land_x = None
            self.land_since = None
            self.win.clear()
            self.vspeed = None
            if self.mode == SIM_MODE_LIVE and self.live_state == "running":
                self._present()

    # ------------------------------------------------------------
    # AUTOMATIC-MODE PARAMETERS
    # ------------------------------------------------------------
    def _make_profile(self):
        return FlightProfile(self.spn_alt.value(), self.spn_burn.value(),
                             self.spn_desc.value(), self.spn_dur.value(),
                             self.chk_fit.isChecked())

    def _on_params_changed(self, *_args):
        prof = self._make_profile()
        self._preview = prof
        # the field that is "derived" is shown for information (and disabled)
        if self.chk_fit.isChecked():
            self.spn_desc.blockSignals(True)
            self.spn_desc.setValue(prof.vd)
            self.spn_desc.blockSignals(False)
        else:
            self.spn_dur.blockSignals(True)
            self.spn_dur.setValue(prof.duration)
            self.spn_dur.blockSignals(False)
        txt = (f"Burnout: {prof.hb:.0f} m at {prof.vb:.0f} m/s "
               f"(net accel {prof.a:.1f} m/s²)\n"
               f"Apogee at T+{prof.t3:.1f} s · landing at T+{prof.t_end:.1f} s · "
               f"descent {prof.vd:.1f} m/s\n"
               "Mid-body CanSat ejection: 800 m on descent only")
        if prof.note:
            txt += f"\n{prof.note}"
        self.lbl_profile.setText(txt)
        self._apply_param_enable()
        if self.mode == SIM_MODE_AUTO and self.engine.state == "idle":
            self._present_auto(graph=True)

    def _apply_param_enable(self):
        unlocked = self.engine.state in ("idle", "finished")
        fit = self.chk_fit.isChecked()
        self.spn_alt.setEnabled(unlocked)
        self.spn_burn.setEnabled(unlocked)
        self.chk_fit.setEnabled(unlocked)
        self.spn_desc.setEnabled(unlocked and not fit)
        self.spn_dur.setEnabled(unlocked and fit)

    # ------------------------------------------------------------
    # LIVE TELEMETRY HOOK
    # ------------------------------------------------------------
    def update_from_packet(self, pkt):
        # --- choose altitude source, reject invalid values ---
        alt = pkt.get(SIM_ALT_KEY)
        source = SIM_ALT_KEY
        t_ms = pkt.get("time_ms")
        self.last_packet_wall = time.time()
        valid = alt is not None and math.isfinite(alt) and t_ms is not None

        live_view = (self.mode == SIM_MODE_LIVE
                     and self.live_state == "running")

        if self.live_state == "idle":
            # tracking stopped: only remember the latest raw reading
            if valid:
                self.raw_alt = alt
                self.alt_source = source
            if self.mode == SIM_MODE_LIVE:
                self._live_labels()
            return
        if not valid:
            self.rejected += 1
            if live_view:
                self._live_labels()
            return

        # --- payload time handling (duplicates / restart) ---
        raw_t = t_ms / 1000.0
        if self.prev_raw_t is not None and raw_t < self.prev_raw_t - 2.0:
            if self.status in ("READY", "LANDED"):
                self._reset_live_state()          # payload rebooted = new flight
            else:
                # restarted mid-flight: keep apogee/state, continue the time axis
                self.t_offset = (self.last_x or 0.0) - raw_t + 0.5
                self.win.clear()
        x = raw_t + self.t_offset
        if self.last_x is not None and x <= self.last_x:
            return                                 # duplicate / out-of-order packet

        # --- glitch filter: physically impossible altitude jumps ---
        if self.raw_alt is not None and self.last_x is not None:
            dt = max(x - self.last_x, 0.05)
            if (abs(alt - self.raw_alt) / dt > SIM_MAX_PLAUSIBLE_SPEED_MS
                    and self.glitch_count < SIM_GLITCH_MAX_CONSEC):
                self.glitch_count += 1
                self.rejected += 1
                if live_view:
                    self._live_labels()
                return
        self.glitch_count = 0

        self.prev_raw_t = raw_t
        self.last_x = x
        self.last_packet_wall = time.time()
        self.packets += 1
        self.alt_source = source
        self.raw_alt = alt

        # --- ground reference ---
        if self.baseline is None:
            self.base_samples.append(alt)
            ref = sum(self.base_samples) / len(self.base_samples)
            if len(self.base_samples) >= SIM_BASELINE_SAMPLES:
                self.baseline = ref
        else:
            ref = self.baseline
        rel = alt - ref
        self.cur_alt = rel

        # --- vertical speed from measured altitude ---
        self.win.append((x, rel))
        while self.win and x - self.win[0][0] > 6.0:
            self.win.popleft()
        vz = self._vertical_speed()
        self.vspeed = vz

        # --- flight status from measured altitude + speed ---
        self._update_state(x, rel, vz)
        if (self.vspeed is not None and self.vspeed < 0.0
                and self.max_alt >= 800.0 and rel <= 800.0
                and self._live_sep_started is None):
            # Interpolate the telemetry segment to the exact 800 m crossing,
            # so a packet that jumps from (for example) 820 m to 780 m does
            # not move the separation trigger down to 780 m.
            crossing_x = x
            samples = list(self.win)
            for (t0, a0), (t1, a1) in zip(samples[:-1], samples[1:]):
                if a0 > 800.0 >= a1 and t1 > t0 and a1 < a0:
                    fraction = (800.0 - a0) / (a1 - a0)
                    crossing_x = t0 + fraction * (t1 - t0)
                    break
            crossing_delay = max(0.0, x - crossing_x)
            self._live_sep_started = time.monotonic() - crossing_delay
        if self.status != "READY":
            self.max_alt = max(self.max_alt, rel)
        elif (self.baseline is not None and SIM_USE_RELATIVE_ALTITUDE
              and abs(rel) < SIM_LAUNCH_ALT_M
              and (vz is None or abs(vz) < 0.5)):
            self.baseline += SIM_BASELINE_EMA * rel   # track slow weather drift

        # --- history ---
        self.hx.append(x)
        self.hy.append(rel)

        if self.mode == SIM_MODE_LIVE and self.live_state == "running":
            self._present()

    def _vertical_speed(self):
        if len(self.win) < 2:
            return None
        t1, a1 = self.win[-1]
        ref = None
        for t0, a0 in self.win:                    # oldest sample inside the window
            dt = t1 - t0
            if SIM_SPEED_MIN_DT_S <= dt <= SIM_SPEED_WINDOW_S:
                ref = (t0, a0)
                break
        if ref is None:                            # slow telemetry: newest old-enough sample
            for t0, a0 in reversed(self.win):
                if t1 - t0 >= SIM_SPEED_MIN_DT_S:
                    ref = (t0, a0)
                    break
        if ref is None:
            return None
        return (a1 - ref[1]) / (t1 - ref[0])

    def _update_state(self, x, rel, vz):
        s = self.status
        if s == "READY":
            if (self.baseline is not None and vz is not None
                    and rel >= SIM_LAUNCH_ALT_M and vz >= SIM_LAUNCH_SPEED_MS):
                if self.launch_count == 0:
                    self._launch_cand = x
                self.launch_count += 1
            else:
                self.launch_count = 0
            if self.launch_count >= SIM_LAUNCH_CONFIRM:
                self.status = "ASCENDING"
                self.launch_x = self._launch_cand
                self.descent_count = 0
                self.land_since = None
            return

        if s == "ASCENDING":
            if (vz is not None and vz <= -SIM_DESCENT_SPEED_MS
                    and rel <= self.max_alt - SIM_APOGEE_DROP_M):
                self.descent_count += 1
            else:
                self.descent_count = 0
            if self.descent_count >= SIM_DESCENT_CONFIRM:
                self.status = "DESCENDING"

        if self.status in ("ASCENDING", "DESCENDING"):
            slow = vz is not None and abs(vz) <= SIM_LANDED_SPEED_MS
            if rel <= SIM_LANDED_ALT_M and slow:
                if self.land_since is None:
                    self.land_since = x
                elif x - self.land_since >= SIM_LANDED_HOLD_S:
                    self.status = "LANDED"
                    self.land_x = x
            else:
                self.land_since = None

    # ------------------------------------------------------------
    # PRESENTATION (labels / scene / graph)
    # ------------------------------------------------------------
    def _present(self, graph=True):
        if self.mode == SIM_MODE_LIVE:
            self._present_live()
        else:
            self._present_auto(graph)
        self._update_controls()

    def _update_controls(self):
        st = self.live_state if self.mode == SIM_MODE_LIVE else self.engine.state
        self.btn_start.setEnabled(st in ("idle", "finished"))
        self.btn_pause.setEnabled(st == "running")
        self.btn_resume.setEnabled(st == "paused")
        self.btn_reset.setEnabled(True)
        self.btn_rezero.setEnabled(
            self.mode == SIM_MODE_LIVE and self.live_state != "idle"
            and self.status in ("READY", "LANDED") and self.raw_alt is not None)
        self._apply_param_enable()

    def _set_labels(self, phase, alt, apogee, vz, time_caption, tval,
                    i1, i2, i3, link, link_col):
        col = SIM_PHASE_COLORS.get(phase, "#FFFFFF")
        self.lbl_status.setText(phase)
        if col != self._status_col:
            self._status_col = col
            self.lbl_status.setStyleSheet(
                f"color: {col}; font-size: 18pt; font-weight: bold;")
        self.lbl_alt.setText(f"Altitude: {alt:.1f} m")
        self.lbl_apogee.setText(f"Apogee: {apogee:.1f} m")
        self.lbl_speed.setText("Vertical Speed: -- m/s" if vz is None
                               else f"Vertical Speed: {vz:+.1f} m/s")
        self.lbl_info1.setText(i1)
        self.lbl_info2.setText(i2)
        self.lbl_info3.setText(i3)
        self.lbl_time.setText(f"{time_caption}: {tval:.2f} s")
        self.lbl_link.setText(link)
        if link_col != self._link_col:
            self._link_col = link_col
            self.lbl_link.setStyleSheet(f"color: {link_col}; font-weight: bold;")

    # ---------------- live ----------------
    def _live_status_text(self):
        return "STANDBY" if self.live_state == "idle" else self.status

    def _live_link(self):
        if self.last_packet_wall is None:
            return "Telemetry: waiting", "#888888"
        age = time.time() - self.last_packet_wall
        if age <= LINK_LOST_TIMEOUT_S:
            return "Telemetry: LIVE", "#00FFCC"
        return f"Telemetry: NO SIGNAL ({age:.0f}s)", "#FF3333"

    def _live_labels(self):
        vz = self.vspeed if (self.signal_ok and self.live_state != "idle") else None
        if self.raw_alt is None:
            i1 = f"Sensor altitude ({self.alt_source}): --"
        else:
            i1 = f"Sensor altitude ({self.alt_source}): {self.raw_alt:.2f} m"
        if not SIM_USE_RELATIVE_ALTITUDE:
            i2 = "Ground reference: raw sensor value (0 m)"
        elif self.baseline is None:
            i2 = (f"Ground reference: calibrating "
                  f"({len(self.base_samples)}/{SIM_BASELINE_SAMPLES})")
        else:
            i2 = f"Ground reference: {self.baseline:.2f} m"
        i3 = f"Packets used: {self.packets}  ·  rejected: {self.rejected}"
        link, lcol = self._live_link()
        self._set_labels(self._live_status_text(), self.cur_alt, self.max_alt, vz,
                         "Flight Time", self._live_flight_time(),
                         i1, i2, i3, link, lcol)

    def _present_live(self):
        if self.live_state == "idle":
            note = "Live tracking stopped — press Start"
        elif self.live_state == "paused":
            note = "PAUSED — display frozen, telemetry still recorded"
        elif self.baseline is None:
            note = (f"Calibrating ground level "
                    f"({len(self.base_samples)}/{SIM_BASELINE_SAMPLES})…")
        else:
            note = ""
        streak = (self.status == "ASCENDING" and self.vspeed is not None
                  and self.vspeed > 1.0 and self.signal_ok)
        self.scene.set_signal(self.signal_ok)
        sep = 0.0
        cs_alt = 0.0
        cs_chute = 0.0
        if self._live_sep_started is not None:
            sep_elapsed = max(0.0, time.monotonic() - self._live_sep_started)
            sep = min(1.0, sep_elapsed / 1.8)
            cs_alt = max(0.0, 800.0 - 5.0 * max(0.0, sep_elapsed - 1.0))
            cs_chute = min(1.0, max(0.0, (sep_elapsed - 1.0) / 1.5))
        self.scene.set_state(
            self.cur_alt, self.max_alt, self._live_status_text(),
            self.vspeed, self.packets > 0, note, streak=streak,
            separation=sep, cansat_alt=cs_alt,
            rocket_chute=cs_chute, cansat_chute=cs_chute)
        self.scene.set_trajectory(self.hx, self.hy)
        self.curve.setData(list(self.hx), list(self.hy))
        if self.status != "READY" and self.live_state != "idle":
            self.apogee_line.setPos(self.max_alt)
            self.apogee_line.setVisible(True)
        else:
            self.apogee_line.setVisible(False)
        self._live_labels()

    # ---------------- automatic ----------------
    def _present_auto(self, graph=True):
        e = self.engine
        prof = e.profile if (e.profile is not None and e.state != "idle") \
            else self._preview
        if prof is None:
            return
        fixed = _nice_ceil(max(SIM_MIN_VIEW_M, prof.H * 1.15))
        if self.scene.fixed_view != fixed:
            self.scene.set_fixed_view(fixed)

        if e.state == "idle":
            note = "AUTOMATIC SIMULATION — set parameters and press Start"
        elif e.state == "paused":
            note = f"PAUSED · T+{e.t:.1f} s"
        elif e.state == "finished":
            note = f"SIMULATION COMPLETE · T+{e.t:.1f} s"
        else:
            note = f"AUTOMATIC SIMULATION · T+{e.t:.1f} s"
        self.scene.set_signal(True)
        self.scene.set_state(
            e.alt, e.max_alt, e.phase, e.vel, True, note,
            flame=e.flame, chute=e.chute, separation=e.separation,
            cansat_alt=e.cansat_alt, rocket_chute=e.rocket_chute,
            cansat_chute=e.cansat_chute)
        self.scene.set_trajectory(e.tx, e.ty, span=(0.0, prof.duration),
                                  ghost=prof.ghost)

        if graph:
            self.curve.setData(list(e.tx), list(e.ty))
            if e.max_alt > 0.0:
                self.apogee_line.setPos(e.max_alt)
                self.apogee_line.setVisible(True)
            else:
                self.apogee_line.setVisible(False)

        link_txt, link_col = {
            "idle": ("Simulation: READY", "#888888"),
            "running": ("Simulation: RUNNING", "#00FFCC"),
            "paused": ("Simulation: PAUSED", "#FFD400"),
            "finished": ("Simulation: COMPLETE", "#40C4FF"),
        }[e.state]
        speed_txt = AUTO_SPEEDS[self.cmb_speed.currentIndex()][0]
        self._set_labels(
            e.phase, e.alt, e.max_alt, e.vel if e.state != "idle" else 0.0,
            "Elapsed Time", e.t,
            f"Target apogee: {prof.H:.0f} m  ·  max speed {prof.vb:.0f} m/s",
            f"Descent speed: {prof.vd:.1f} m/s  ·  total {prof.duration:.0f} s",
            f"Playback speed: {speed_txt}  ·  source: internal simulation",
            link_txt, link_col)

    # ------------------------------------------------------------
    # FRAME TIMER (GUI thread, non-blocking)
    # ------------------------------------------------------------
    def _on_frame(self):
        now = time.monotonic()
        dt = min(now - self._last_frame, 0.25)
        self._last_frame = now
        self._frame_n += 1

        if self.mode == SIM_MODE_AUTO and self.engine.state == "running":
            self.engine.advance(dt)
            done = self.engine.state == "finished"
            self._present_auto(graph=(done or self._frame_n % 4 == 0))
            if done:
                self._update_controls()

        if self.scene.advance(dt):
            self.scene.update()

        if self._frame_n % 15 == 0 and self.last_packet_wall is not None:
            age = time.time() - self.last_packet_wall
            ok = age <= LINK_LOST_TIMEOUT_S
            changed = ok != self.signal_ok
            self.signal_ok = ok
            if self.mode == SIM_MODE_LIVE:
                self.scene.set_signal(ok)
                self._live_labels()
                if changed:
                    self._update_controls()


# ============================================================
# SERIAL READER THREAD
# ============================================================

class SerialReaderThread(QThread):
    """Owns the serial port.  Runs in a worker thread and touches NO widget.

    Every value it produces is plain data (``str`` / ``dict``) emitted through
    Qt signals; the GUI thread converts that data into widget updates inside
    ``GroundStationGUI.handle_telemetry_packet``.  This is the only place where
    the port is read, and the only place where decoding happens - the graphs,
    the map, the 2D scene and the 3D scene all consume the same dict that this
    thread emits, so they can never disagree.

    Decoding is delegated to :class:`zenith.receiver.ReceiverDecoder`, which
    understands every form the ground station can receive:

      * the receiver sketch's human readable report block (firmware unchanged),
      * the optional ``RX,<15 fields>`` echo line (one-line patch supplied),
      * a raw ``@`` frame, when the PC is wired straight to a radio dongle,
      * multiplexed ``{Roc}`` Rocket and ``{Can}`` CanSat 15-field records,
      * the legacy ``CAN,...`` frame of the previous payload generation.
    """

    telemetry_packet_signal = pyqtSignal(dict, int, str)
    raw_console_signal = pyqtSignal(str)
    connection_error_signal = pyqtSignal(str)
    connection_status_signal = pyqtSignal(str)
    monitor_line_signal = pyqtSignal(str)          # one readable line / packet
    decoder_message_signal = pyqtSignal(str, str)  # (level, text)

    def __init__(self, port, baudrate, team_id=None, source_name="ROCKET"):
        super().__init__()
        self.source_name = source_name
        self.port = port
        self.baudrate = baudrate
        self.running = True
        self.ser = None
        self.buffer = bytearray()
        self.bytes_rx = 0
        self.decoder = ReceiverDecoder(team_id=team_id or ZCFG.TEAM_ID,
                                               strict_team_id=(source_name != "CANSAT"))

    # ------------------------------------------------------------------
    def run(self):
        if not SERIAL_LIBRARY_AVAILABLE:
            self.connection_error_signal.emit(
                "pyserial is not installed.\n\n"
                "Install it with:\n    pip install pyserial\n\n"
                f"(import error: {SERIAL_IMPORT_ERROR})")
            return

        try:
            self.raw_console_signal.emit(
                f"[SERIAL] Opening {self.port} @ {self.baudrate} baud...")
            self.ser = serial.Serial(self.port, self.baudrate,
                                     timeout=0.05, write_timeout=0.5)
            time.sleep(0.2)
            self.connection_status_signal.emit(f"CONNECTED: {self.port}")
            self.raw_console_signal.emit(
                f"[SERIAL] Waiting for telemetry ({ZCFG.EXPECTED_FIELDS}-field "
                f"{{Roc}}/{{Can}} records, raw frames, or receiver report blocks) ...")
            self.raw_console_signal.emit(
                "[CRC] Supports CRC-16/CCITT-FALSE suffix '*ABCD' on '@', 'RX,' and tagged records. "
                "Legacy/report frames without CRC are accepted as UNVERIFIED.")

            while self.running and self.ser is not None:
                try:
                    waiting = self.ser.in_waiting
                    if waiting > 0:
                        chunk = self.ser.read(min(waiting, 4096))
                        if not chunk:
                            continue
                        self.bytes_rx += len(chunk)
                        self.buffer.extend(chunk)
                        if len(self.buffer) > 8192:      # runaway-noise guard
                            del self.buffer[:-2048]
                        self.process_buffer()
                    else:
                        self.msleep(5)
                except serial.SerialException as e:
                    self.connection_error_signal.emit(
                        f"Serial communication error: {e}")
                    break
                except Exception as e:
                    self.raw_console_signal.emit(
                        f"[PARSER ERROR] {type(e).__name__}: {e}")
                    self.msleep(10)

        except serial.SerialException as e:
            self.connection_error_signal.emit(
                f"Could not open {self.port}\nReason: {e}")
        except Exception as e:
            self.connection_error_signal.emit(
                f"Unexpected serial error\n{type(e).__name__}: {e}")
        finally:
            try:
                if self.ser is not None and self.ser.is_open:
                    self.ser.close()
            except Exception:
                pass
            self.ser = None
            self.connection_status_signal.emit("DISCONNECTED")
            self.raw_console_signal.emit(
                f"[SERIAL] Reader thread stopped ({self.bytes_rx} bytes read).")

    # ------------------------------------------------------------------
    def process_buffer(self):
        """Hand every complete line to the decoder and to the monitor."""
        while self.running:
            idx = self.buffer.find(b"\n")
            if idx == -1:
                return
            raw = bytes(self.buffer[:idx])
            del self.buffer[:idx + 1]
            self.parse_ascii_line(raw, len(raw) + 1)

    def parse_ascii_line(self, raw_bytes, packet_size):
        line = raw_bytes.decode("utf-8", errors="ignore")
        text = line.strip()
        if not text:
            return

        # 1) everything that arrives is mirrored into the Serial Monitor ...
        self.raw_console_signal.emit(f"[RX] {text}")

        # 2) ... and fed to the decoder, which validates it exactly like the
        #    receiver sketch does.  Messages (rejections, packet-loss warnings,
        #    receiver notices) are forwarded to the monitor as well.
        try:
            samples, messages = self.decoder.feed(text + "\n")
        except Exception as e:                       # never kill the link
            self.raw_console_signal.emit(
                f"[PARSER ERROR] {type(e).__name__}: {e}")
            return

        for level, msg in messages:
            self.decoder_message_signal.emit(level, msg)

        for pkt in samples:
            pkt["_wall"] = time.time()
            pkt["_bytes"] = packet_size
            tagged_source = pkt.get("_source")
            if tagged_source in (SRC_CANSAT_TAG, "legacy-can"):
                avionics_source = "CANSAT"
            elif tagged_source == SRC_ROCKET_TAG:
                avionics_source = "ROCKET"
            elif self.source_name in ("ROCKET", "CANSAT"):
                # Backward-compatible routing for the old two-link setup and
                # for untagged receiver report/raw frames.
                avionics_source = self.source_name
            else:
                avionics_source = "ROCKET"
            self.telemetry_packet_signal.emit(pkt, packet_size, avionics_source)
            try:
                self.monitor_line_signal.emit(
                    f"[{avionics_source}] " + ZPROTO.format_monitor_line(pkt))
            except Exception:
                pass

    # ------------------------------------------------------------------
    def send(self, text):
        """Write raw text to the port (used by the HIL loop-back self test)."""
        try:
            if self.ser is not None and self.ser.is_open:
                self.ser.write(text.encode("utf-8", errors="replace"))
                self.ser.flush()
                return True
        except Exception as e:
            self.raw_console_signal.emit(f"[TX ERROR] {e}")
        return False

    def stop(self):
        self.running = False
        try:
            if self.ser is not None and self.ser.is_open:
                self.ser.close()
        except Exception:
            pass
        self.wait(2000)


# ============================================================
# TAB 4 — STL-BASED INTERACTIVE 3D ROCKET SIMULATION
# ============================================================

class Rocket3DSimulationTab(QWidget):
    """
    Tab 4 only: STL rocket + STL CanSat separation scene.
    The telemetry path is unchanged; this widget only consumes already-parsed
    altitude packets from GroundStationGUI.
    """

    FRAME_MS = 33
    ROCKET_DEFAULT = "full body(1).stl"
    CANSAT_DEFAULT = "cansat.stl"
    ALTITUDE_TO_MODEL_UNITS = 1000.0  # STL geometry is millimetres
    # UPDATED: raise the bay and enlarge its vertical aperture.
    BAY_BOTTOM_MM = 700.0
    BAY_TOP_MM = 950.0
    BAY_CENTER_MM = (BAY_BOTTOM_MM + BAY_TOP_MM) / 2.0
    # Oversized mid-body doors overlap the rectangular bay aperture to hide
    # shell gaps at the outer edges when closed.
    DOOR_HALF_WIDTH_MM = 83.5  # narrow enough to stay within the rocket silhouette while overlapping the 78 mm opening
    BAY_OPENING_HALF_WIDTH_MM = 78.0
    EJECTION_DURATION_S = 1.8
    EJECTION_DISTANCE_MM = 1170.0  # 50% farther than the current 780 mm distance
    CANSAT_DESCENT_MS = 12.0  # retained for compatibility with earlier descent logic
    CANSAT_VERTICAL_OFFSET_M = 1.0  # keep CanSat within 1 m vertically of the rocket

    def __init__(self, parent=None):
        super().__init__(parent)
        base_dir = os.path.dirname(os.path.abspath(__file__))
        self.stl_path = os.path.join(base_dir, self.ROCKET_DEFAULT)
        self.cansat_path = os.path.join(base_dir, self.CANSAT_DEFAULT)

        self.mesh_items = []
        self.mesh_components = []
        self.cansat_item = None
        self.cansat_mesh = None
        self.door_items = []
        self.door_closed_vertices = []
        # NEW: independent canopy meshes and suspension-line items for each vehicle.
        self.parachute_items = {"rocket": None, "cansat": None}
        self.parachute_line_items = {"rocket": None, "cansat": None}
        self.ground_item = None
        self.model_center = np.zeros(3, dtype=float) if STL_3D_AVAILABLE else None
        self.rocket_bottom_mm = 0.0
        self.rocket_fire_items = []
        self.live_ascending = False

        self.current_altitude = 0.0
        self.max_altitude = 0.0
        self.mode = "Live Sensor Data"
        self.auto_elapsed = 0.0
        self.auto_running = False
        self.auto_paused = False
        self.last_tick = time.monotonic()

        self.previous_live_altitude = None
        self.live_ascending = False
        self.live_descent_confirm = 0
        self.live_descent_armed = False
        self.ejection_triggered = False
        self.separation_elapsed = -1.0
        self.separation_altitude = None
        self.cansat_altitude = 0.0
        self.cansat_x = 0.0
        self.cansat_y = 0.0
        self.rocket_landed = False
        self.cansat_landed = False

        self._build_ui()
        self._load_rocket_model(self.stl_path)
        self._load_cansat_model(self.cansat_path)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._on_frame)
        self.timer.start(self.FRAME_MS)

    def _build_ui(self):
        root = QVBoxLayout(self)
        controls = QHBoxLayout()

        controls.addWidget(QLabel("Mode:"))
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["Live Sensor Data", "Automatic Simulation"])
        self.cmb_mode.currentTextChanged.connect(self._mode_changed)
        controls.addWidget(self.cmb_mode)

        self.btn_load = QPushButton("Load Rocket STL")
        self.btn_load.clicked.connect(self._choose_rocket_stl)
        controls.addWidget(self.btn_load)

        self.btn_load_cansat = QPushButton("Load CanSat STL")
        self.btn_load_cansat.clicked.connect(self._choose_cansat_stl)
        controls.addWidget(self.btn_load_cansat)

        self.btn_start = QPushButton("▶ Start")
        self.btn_start.clicked.connect(self._start_auto)
        controls.addWidget(self.btn_start)
        self.btn_pause = QPushButton("⏸ Pause")
        self.btn_pause.clicked.connect(self._pause_auto)
        controls.addWidget(self.btn_pause)
        self.btn_reset = QPushButton("⟲ Reset")
        self.btn_reset.clicked.connect(self._reset_sim)
        controls.addWidget(self.btn_reset)
        self.chk_track = QCheckBox("Track rocket + CanSat")
        self.chk_track.setChecked(True)
        self.chk_track.setToolTip(
            "Keep both vehicles centred through ascent, ejection, descent, and landing. "
            "Uncheck to keep the camera target fixed for a fully free view.")
        controls.addWidget(self.chk_track)
        controls.addStretch()
        root.addLayout(controls)

        info = QHBoxLayout()
        self.lbl_model = QLabel("Rocket STL: waiting to load")
        self.lbl_model.setStyleSheet("color:#00FFCC;font-weight:bold;")
        self.lbl_alt = QLabel("Altitude: 0.0 m")
        self.lbl_apogee = QLabel("Apogee: 0.0 m")
        self.lbl_phase = QLabel("Phase: READY")
        self.lbl_cansat = QLabel("CanSat: INSIDE")
        for label in (self.lbl_alt, self.lbl_apogee, self.lbl_phase,
                      self.lbl_cansat):
            label.setStyleSheet("color:#00FFCC;font-weight:bold;")
        info.addWidget(self.lbl_model, 2)
        info.addWidget(self.lbl_alt)
        info.addWidget(self.lbl_apogee)
        info.addWidget(self.lbl_phase)
        info.addWidget(self.lbl_cansat)
        root.addLayout(info)

        if STL_3D_AVAILABLE:
            self.view = gl.GLViewWidget()
            # NEW: clear sky-blue background gives strong contrast with the vehicle.
            self.view.setBackgroundColor((105, 185, 235, 255))
            self.view.opts["distance"] = 3300
            self.view.opts["elevation"] = 13
            self.view.opts["azimuth"] = 35
            self.view.opts["center"] = QVector3D(0, 0, 900)
            # Broad, flat green terrain: the surface extends far beyond the
            # camera's normal viewing range so no small rectangular platform edge
            # is visible during orbiting, panning, or zooming.
            ground_mesh = trimesh.creation.box(extents=(200000, 200000, 4))
            ground_mesh.apply_translation((0, 0, -28))
            self.ground_item = self._make_mesh_item(
                ground_mesh, (0.12, 0.52, 0.16, 1.0))
            self.view.addItem(self.ground_item)
            axes = gl.GLAxisItem()
            axes.setSize(350, 350, 1900)
            self.view.addItem(axes)
            root.addWidget(self.view, 1)
            self.lbl_hint = QLabel(
                "Mouse: left-drag rotate · right-drag pan · wheel zoom. "
                "CanSat is housed in the mid-body bay; doors open on the "
                "descending 800 m crossing.")
        else:
            self.view = None
            self.lbl_hint = QLabel(
                "3D view dependencies are missing. Install with:\n"
                "pip install pyqtgraph PyOpenGL trimesh numpy")
            self.lbl_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.lbl_hint.setStyleSheet("color:#FF8A00;font-size:12pt;")
            root.addWidget(self.lbl_hint, 1)

        self.lbl_hint.setStyleSheet("color:#BDBDBD;")
        self.lbl_hint.setWordWrap(True)
        root.addWidget(self.lbl_hint)

    @staticmethod
    def _make_mesh_item(mesh, color):
        vertices = np.asarray(mesh.vertices, dtype=np.float32)
        faces = np.asarray(mesh.faces, dtype=np.uint32)
        md = gl.MeshData(vertexes=vertices, faces=faces)
        return gl.GLMeshItem(meshdata=md, smooth=True, drawFaces=True,
                             drawEdges=False, shader="shaded", color=color)

    def _remove_items(self, items):
        if self.view is not None:
            for item in list(items):
                try:
                    self.view.removeItem(item)
                except Exception:
                    pass
        items.clear()

    def _choose_rocket_stl(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select rocket STL model", self.stl_path,
            "STL files (*.stl);;All files (*)")
        if path:
            self.stl_path = path
            self._load_rocket_model(path)

    def _choose_cansat_stl(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select CanSat STL model", self.cansat_path,
            "STL files (*.stl);;All files (*)")
        if path:
            self.cansat_path = path
            self._load_cansat_model(path)

    def _load_rocket_model(self, path):
        if not STL_3D_AVAILABLE or self.view is None:
            return
        if not os.path.isfile(path):
            self.lbl_model.setText("Rocket STL not found — use Load Rocket STL")
            return
        try:
            loaded = trimesh.load(path, force="mesh")
            if not isinstance(loaded, trimesh.Trimesh) or len(loaded.faces) == 0:
                raise ValueError("No triangular rocket mesh found")

            self._remove_items(self.mesh_items)
            self.mesh_components = loaded.split(only_watertight=False)
            if not self.mesh_components:
                self.mesh_components = [loaded]

            # The provided rocket STL has a continuous cylindrical mid-body.
            # Cut a clean, sharp rectangular aperture in the front-facing
            # mid-body shell. The wider door leaves overlap its side edges.
            for index, component in enumerate(self.mesh_components):
                component = component.copy()
                if index == 0:
                    centers = component.triangles_center
                    z = centers[:, 2]
                    radius = np.hypot(centers[:, 0], centers[:, 1])
                    angle = np.arctan2(centers[:, 1], centers[:, 0])
                    front_delta = np.arctan2(
                        np.sin(angle + math.pi / 2.0),
                        np.cos(angle + math.pi / 2.0))
                    opening_faces = (
                        (z >= self.BAY_BOTTOM_MM) &
                        (z <= self.BAY_TOP_MM) &
                        (np.abs(component.triangles_center[:, 0]) <=
                         self.BAY_OPENING_HALF_WIDTH_MM) &
                        (np.abs(front_delta) <= math.radians(60.0)) &
                        (radius > 65.0)
                    )
                    # Remove triangles that cross the rectangular cut boundary
                    # as well as triangles whose centres lie inside it. This
                    # prevents thin STL slivers from being left behind as
                    # spike/teeth-like structures around the bay opening.
                    cut_margin_mm = 2.5
                    tri_vertices = component.triangles
                    vertex_z = tri_vertices[:, :, 2]
                    vertex_x = np.abs(tri_vertices[:, :, 0])
                    vertex_radius = np.hypot(
                        tri_vertices[:, :, 0], tri_vertices[:, :, 1])
                    vertex_angle = np.arctan2(
                        tri_vertices[:, :, 1], tri_vertices[:, :, 0])
                    vertex_front_delta = np.arctan2(
                        np.sin(vertex_angle + math.pi / 2.0),
                        np.cos(vertex_angle + math.pi / 2.0))
                    vertex_in_opening = (
                        (vertex_z >= self.BAY_BOTTOM_MM - cut_margin_mm) &
                        (vertex_z <= self.BAY_TOP_MM + cut_margin_mm) &
                        (vertex_x <= self.BAY_OPENING_HALF_WIDTH_MM + cut_margin_mm) &
                        (np.abs(vertex_front_delta) <= math.radians(60.0)) &
                        (vertex_radius > 65.0)
                    )
                    boundary_slivers = np.any(vertex_in_opening, axis=1)
                    opening_faces |= boundary_slivers
                    component.update_faces(~opening_faces)
                    component.remove_unreferenced_vertices()
                if len(component.faces) == 0:
                    continue
                item = self._make_mesh_item(component, (0.72, 0.78, 0.84, 1.0))
                self.view.addItem(item)
                self.mesh_items.append(item)

            bounds = loaded.bounds
            ext = bounds[1] - bounds[0]
            center = (bounds[1] + bounds[0]) / 2.0
            self.model_center = center
            self.rocket_bottom_mm = float(bounds[0][2])
            self._create_rocket_fire_effect()
            self.view.opts["center"] = QVector3D(
                float(center[0]), float(center[1]), float(center[2]))
            self.view.opts["distance"] = max(float(max(ext)) * 2.15, 500.0)
            self._create_bay_doors()
            self.view.update()
            self.lbl_model.setText(
                f"Rocket STL: {os.path.basename(path)} | "
                f"X {ext[0]:.1f} · Y {ext[1]:.1f} · Z {ext[2]:.1f} mm")
            self.lbl_hint.setText(
                "Rocket STL loaded. Clean rectangular mid-body bay with "
                "oversized hinged doors covering the outer shell gaps.")
        except Exception as exc:
            self.lbl_model.setText(
                f"Rocket STL load error: {type(exc).__name__}: {exc}")

    def _load_cansat_model(self, path):
        if not STL_3D_AVAILABLE or self.view is None:
            return
        if not os.path.isfile(path):
            self.lbl_cansat.setText("CanSat STL: FILE NOT FOUND")
            return
        try:
            loaded = trimesh.load(path, force="mesh")
            if not isinstance(loaded, trimesh.Trimesh) or len(loaded.faces) == 0:
                raise ValueError("No triangular CanSat mesh found")
            self.cansat_mesh = loaded.copy()
            if self.cansat_item is not None:
                self.view.removeItem(self.cansat_item)
            self.cansat_item = self._make_mesh_item(
                self.cansat_mesh, (0.95, 0.62, 0.18, 1.0))
            self.view.addItem(self.cansat_item)
            ext = self.cansat_mesh.extents
            # Model coordinates are centred on X/Y with its base at Z=0.
            self.lbl_cansat.setText(
                f"CanSat STL: LOADED ({ext[0]:.0f}×{ext[1]:.0f}×{ext[2]:.0f} mm)")
            self._apply_scene_transforms()
        except Exception as exc:
            self.lbl_cansat.setText(
                f"CanSat STL load error: {type(exc).__name__}: {exc}")

    def _create_bay_doors(self):
        self._remove_items(self.door_items)
        self.door_closed_vertices.clear()
        if self.view is None:
            return
        # Two door leaves are curved patches of the rocket's cylindrical
        # shell, rather than flat rectangular plates. A dense X/Z mesh lets
        # the front surface follow the body's radial curvature when closed.
        # The hinge axis sits along each outer vertical edge of the curved leaf.
        shell_radius = 90.5  # slight clearance avoids z-fighting
        bay_height = self.BAY_TOP_MM - self.BAY_BOTTOM_MM
        vertical_overlap = 0.50 * bay_height
        z0 = self.BAY_BOTTOM_MM - vertical_overlap
        z1 = self.BAY_TOP_MM + vertical_overlap
        x_segments = 18
        z_segments = 2
        for side in (-1, 1):
            if side < 0:
                x0, x1 = -self.DOOR_HALF_WIDTH_MM, 0.0
            else:
                x0, x1 = 0.0, self.DOOR_HALF_WIDTH_MM
            xs = np.linspace(x0, x1, x_segments + 1)
            zs = np.linspace(z0, z1, z_segments + 1)
            vertices = []
            for z_value in zs:
                for x_value in xs:
                    # Cylindrical cross-section: every point lies on the same
                    # radius as the rocket body, so the door skin visibly
                    # matches its curvature instead of spanning a flat chord.
                    safe_x = min(abs(float(x_value)), shell_radius - 0.25)
                    y_value = -math.sqrt(max(0.0, shell_radius ** 2 - safe_x ** 2)) - 0.35
                    vertices.append([float(x_value), y_value, float(z_value)])
            vertices = np.asarray(vertices, dtype=np.float32)
            faces = []
            row = x_segments + 1
            for zi in range(z_segments):
                for xi in range(x_segments):
                    a = zi * row + xi
                    b = a + 1
                    c = a + row
                    d = c + 1
                    faces.append([a, b, d])
                    faces.append([a, d, c])
            faces = np.asarray(faces, dtype=np.uint32)
            item = gl.GLMeshItem(
                meshdata=gl.MeshData(vertexes=vertices, faces=faces),
                smooth=True, drawFaces=True, drawEdges=False,
                shader="shaded", color=(0.95, 0.42, 0.12, 1.0))
            self.view.addItem(item)
            self.door_items.append(item)
            self.door_closed_vertices.append((side, vertices.copy(), faces))

    def update_from_packet(self, pkt):
        """Consume the existing telemetry packet; never opens a serial port."""
        if self.mode != "Live Sensor Data":
            return
        value = pkt.get(SIM_ALT_KEY)
        if value is None:
            return
        try:
            if not math.isfinite(float(value)):
                return
        except (TypeError, ValueError):
            return
        try:
            altitude = max(0.0, float(value))
        except (TypeError, ValueError):
            return
        if not math.isfinite(altitude):
            return

        previous = self.previous_live_altitude
        self.current_altitude = altitude
        self.max_altitude = max(self.max_altitude, altitude)
        self.live_ascending = (previous is not None and altitude > previous + 0.02
                               and altitude < 1000.0)

        if previous is not None:
            delta = altitude - previous
            if delta < -0.25:
                self.live_descent_confirm += 1
            elif delta > 0.25:
                self.live_descent_confirm = 0
            if self.live_descent_confirm >= 2 and self.max_altitude > 800.0:
                self.live_descent_armed = True

            # Strict descending crossing: the ascent crossing is ignored.
            if (not self.ejection_triggered and self.live_descent_armed
                    and previous > 800.0 >= altitude):
                self._trigger_ejection(altitude)

        self.previous_live_altitude = altitude
        self._update_readouts(
            "CANSAT SEPARATION" if self.ejection_triggered else
            ("DESCENDING" if self.live_descent_armed else "LIVE TELEMETRY"))

    def _reset_flight_state(self):
        self.current_altitude = 0.0
        self.max_altitude = 0.0
        self.previous_live_altitude = None
        self.live_descent_confirm = 0
        self.live_descent_armed = False
        self.ejection_triggered = False
        self.separation_elapsed = -1.0
        self.separation_altitude = None
        self.cansat_altitude = 0.0
        self.cansat_x = 0.0
        self.cansat_y = 0.0
        self.rocket_landed = False
        self.cansat_landed = False
        self._apply_scene_transforms()

    def _mode_changed(self, mode):
        self.mode = mode
        self.auto_running = False
        self.auto_paused = False
        self.auto_elapsed = 0.0
        self._reset_flight_state()
        self._update_readouts(
            "AUTO READY" if mode == "Automatic Simulation"
            else "WAITING FOR TELEMETRY")

    def _start_auto(self):
        if self.mode != "Automatic Simulation":
            self.cmb_mode.setCurrentText("Automatic Simulation")
        if self.auto_elapsed >= 110.0 or self.ejection_triggered:
            self.auto_elapsed = 0.0
            self._reset_flight_state()
        self.auto_running = True
        self.auto_paused = False
        self.last_tick = time.monotonic()

    def _pause_auto(self):
        if self.mode == "Automatic Simulation":
            self.auto_paused = not self.auto_paused
            self.auto_running = not self.auto_paused

    def _reset_sim(self):
        self.auto_elapsed = 0.0
        self.auto_running = False
        self.auto_paused = False
        self._reset_flight_state()
        self._update_readouts("READY")

    def _automatic_state(self, t):
        # 1 km apogee followed by a 12 m/s descent.
        ignition = 1.0
        apogee_t = 24.0
        descent_start = apogee_t + 1.5
        if t < ignition:
            return 0.0, "LAUNCH"
        if t < apogee_t:
            u = (t - ignition) / (apogee_t - ignition)
            return 1000.0 * (1.0 - (1.0 - u) ** 2), (
                "POWERED ASCENT" if t < 8.0 else "COASTING")
        if t < descent_start:
            return 1000.0, "APOGEE"
        descent_t = t - descent_start
        altitude = max(0.0, 1000.0 - 12.0 * descent_t)
        return altitude, ("DESCENT" if altitude > 0.0 else "LANDED")

    def _trigger_ejection(self, rocket_altitude):
        if self.ejection_triggered:
            return
        self.ejection_triggered = True
        self.separation_elapsed = 0.0
        self.separation_altitude = float(rocket_altitude)
        self.cansat_altitude = float(rocket_altitude) + (
            self.BAY_BOTTOM_MM / self.ALTITUDE_TO_MODEL_UNITS)
        self.cansat_x = 0.0
        self.cansat_y = 0.0

    def _update_separation(self, dt):
        if not self.ejection_triggered:
            return
        self.separation_elapsed += dt
        u = min(1.0, self.separation_elapsed / self.EJECTION_DURATION_S)
        # Smoothstep outward translation through the opened mid-body bay.
        smooth = u * u * (3.0 - 2.0 * u)
        self.cansat_y = -self.EJECTION_DISTANCE_MM * smooth

        # Parallel descent is an AUTOMATIC-SIMULATION behaviour only.
        # In Live Sensor Data mode, use the altitude from the latest received
        # telemetry packet; do not invent an independent CanSat descent profile
        # or add a simulated vertical offset. This project currently receives
        # one flight-altitude value (bmp_alt), so the
        # CanSat follows that received altitude until dedicated CanSat telemetry
        # is available.
        # Once the rocket reaches ground level, bring the CanSat all the way
        # to ground too. Do not leave it hovering at the automatic mode's
        # small vertical-following offset. In live mode, ground contact is
        # driven by the altitude value received from telemetry.
        if self.current_altitude <= 0.0:
            self.cansat_altitude = 0.0
            self.cansat_landed = True
        elif self.mode == "Automatic Simulation":
            self.cansat_altitude = max(
                0.0, self.current_altitude + self.CANSAT_VERTICAL_OFFSET_M)
            self.cansat_landed = False
        else:
            self.cansat_altitude = max(0.0, self.current_altitude)
            self.cansat_landed = self.cansat_altitude <= 0.0

    def _on_frame(self):
        now = time.monotonic()
        dt = min(max(now - self.last_tick, 0.0), 0.1)
        self.last_tick = now

        if self.mode == "Automatic Simulation" and self.auto_running:
            old_alt = self.current_altitude
            self.auto_elapsed += dt
            self.current_altitude, phase = self._automatic_state(
                self.auto_elapsed)
            self.max_altitude = max(self.max_altitude, self.current_altitude)

            # This event can only happen after apogee, on a descending crossing.
            if (not self.ejection_triggered and old_alt > 800.0 >=
                    self.current_altitude and self.auto_elapsed > 25.5):
                self._trigger_ejection(800.0)

            if self.current_altitude <= 0.0 and self.auto_elapsed > 25.5:
                self.rocket_landed = True
                self.auto_running = False
                phase = "LANDED"

            self._update_readouts(
                "CANSAT SEPARATION" if self.ejection_triggered and
                self.separation_elapsed < self.EJECTION_DURATION_S else phase)

        self._update_separation(dt)
        self._apply_scene_transforms()

    def _set_item_translation(self, item, x, y, z):
        item.resetTransform()
        item.translate(float(x), float(y), float(z))

    def _apply_door_animation(self):
        if not self.door_items:
            return
        angle = 0.0
        if self.ejection_triggered and self.separation_elapsed >= 0.0:
            angle = 82.0 * min(1.0, self.separation_elapsed / 0.8)

        rocket_z = self.current_altitude * self.ALTITUDE_TO_MODEL_UNITS
        for item, (side, closed, faces) in zip(
                self.door_items, self.door_closed_vertices):
            pivot_x = -self.DOOR_HALF_WIDTH_MM if side < 0 else self.DOOR_HALF_WIDTH_MM
            # Hinge at the actual curved shell surface, not at y=0; this
            # keeps the door edge physically attached instead of floating.
            pivot_y = -math.sqrt(max(0.0, 90.5 ** 2 - pivot_x ** 2))
            theta = math.radians(-angle if side < 0 else angle)
            c, s = math.cos(theta), math.sin(theta)
            verts = closed.astype(float).copy()
            dx = verts[:, 0] - pivot_x
            dy = verts[:, 1] - pivot_y
            verts[:, 0] = pivot_x + dx * c - dy * s
            verts[:, 1] = pivot_y + dx * s + dy * c
            verts[:, 2] += rocket_z
            item.setMeshData(meshdata=gl.MeshData(
                vertexes=verts.astype(np.float32), faces=faces))

    def _apply_scene_transforms(self):
        if self.view is None:
            return
        rocket_z = self.current_altitude * self.ALTITUDE_TO_MODEL_UNITS
        for item in self.mesh_items:
            self._set_item_translation(item, 0.0, 0.0, rocket_z)

        # Before ejection the actual CanSat STL is placed inside the rocket bay.
        if self.cansat_item is not None:
            if not self.ejection_triggered:
                self._set_item_translation(
                    self.cansat_item, 0.0, 0.0,
                    rocket_z + self.BAY_BOTTOM_MM)
            else:
                if self.separation_elapsed <= self.EJECTION_DURATION_S:
                    cansat_z = rocket_z + self.BAY_BOTTOM_MM
                else:
                    cansat_z = self.cansat_altitude * self.ALTITUDE_TO_MODEL_UNITS
                self._set_item_translation(
                    self.cansat_item, self.cansat_x, self.cansat_y, cansat_z)

        self._apply_door_animation()
        self._update_rocket_fire_effect(rocket_z)
        # NEW: parachutes deploy on the exact same frame as CanSat ejection.
        # The rocket canopy attaches to the rocket's upper body; the second
        # canopy attaches to the CanSat. Suspension lines are refreshed each frame.
        self._update_parachute_visuals(rocket_z)

        # Auto-track the rocket and CanSat throughout the entire flight. The
        # camera orientation and user zoom remain untouched, so orbiting and
        # zooming still work; uncheck the control to freeze the camera target.
        self._update_camera_tracking(rocket_z)
        self.view.update()

    def _update_camera_tracking(self, rocket_z):
        if self.view is None or not hasattr(self, "chk_track"):
            return
        if not self.chk_track.isChecked():
            return

        if self.cansat_item is None or not self.ejection_triggered:
            cansat_x, cansat_y = 0.0, 0.0
            cansat_z = rocket_z + self.BAY_CENTER_MM
        elif self.separation_elapsed <= self.EJECTION_DURATION_S:
            cansat_x, cansat_y = self.cansat_x, self.cansat_y
            cansat_z = rocket_z + self.BAY_CENTER_MM
        else:
            cansat_x, cansat_y = self.cansat_x, self.cansat_y
            cansat_z = self.cansat_altitude * self.ALTITUDE_TO_MODEL_UNITS

        # Centre between both craft, with a small upward bias to keep the
        # deployed canopies in frame. Keep the current distance and angles so
        # the camera continues to feel manually controllable.
        center_x = (0.0 + cansat_x) / 2.0
        center_y = (0.0 + cansat_y) / 2.0
        center_z = (rocket_z + cansat_z) / 2.0 + 350.0
        self.view.opts["center"] = QVector3D(
            float(center_x), float(center_y), float(center_z))

    def _create_rocket_fire_effect(self):
        """Create layered 3D exhaust flames anchored to the rocket's nozzle."""
        if self.view is None or not STL_3D_AVAILABLE:
            return
        self._remove_items(self.rocket_fire_items)
        # A cone's tip is normally above its base; flip it so the tip points down.
        for radius, height, color in (
                (105.0, 620.0, (1.0, 0.20, 0.025, 1.0)),
                (62.0, 430.0, (1.0, 0.78, 0.08, 1.0)),
                (28.0, 270.0, (1.0, 0.98, 0.70, 1.0))):
            mesh = trimesh.creation.cone(radius=radius, height=height, sections=20)
            flip = trimesh.transformations.rotation_matrix(math.pi, [1, 0, 0])
            mesh.apply_transform(flip)
            item = self._make_mesh_item(mesh, color)
            item.setVisible(False)
            self.view.addItem(item)
            self.rocket_fire_items.append(item)

    def _update_rocket_fire_effect(self, rocket_z):
        """Show a flickering exhaust while the rocket rises, stopping at 1,000 m."""
        if not self.rocket_fire_items:
            return
        if self.mode == "Automatic Simulation":
            # The automatic flight reaches its 1,000 m apogee at T+24 s.
            active = 1.0 <= self.auto_elapsed < 24.0 and self.current_altitude < 1000.0
        else:
            active = self.live_ascending and self.current_altitude < 1000.0
        for i, item in enumerate(self.rocket_fire_items):
            item.setVisible(active)
            if not active:
                continue
            # Small deterministic flicker gives the exhaust a lively flame shape.
            phase = time.monotonic() * (13.0 + i * 2.5) + i * 1.7
            flicker = 0.88 + 0.12 * math.sin(phase)
            item.resetTransform()
            item.translate(0.0, 0.0, float(rocket_z + self.rocket_bottom_mm))
            item.scale(flicker, flicker, flicker)

    def _make_parachute_canopy(self, radius=150.0, height=95.0, color=(1.0, 0.25, 0.18, 1.0)):
        """NEW: shallow domed canopy mesh (parametric hemisphere) for one chute."""
        rings, segments = 7, 24
        vertices = [[0.0, 0.0, height]]
        for ri in range(1, rings + 1):
            theta = (math.pi / 2.0) * ri / rings
            for j in range(segments):
                phi = 2.0 * math.pi * j / segments
                vertices.append([radius * math.sin(theta) * math.cos(phi),
                                 radius * math.sin(theta) * math.sin(phi),
                                 height * math.cos(theta)])
        faces = []
        for j in range(segments):
            faces.append([0, 1 + j, 1 + (j + 1) % segments])
        for ri in range(rings - 1):
            a0 = 1 + ri * segments
            b0 = a0 + segments
            for j in range(segments):
                jn = (j + 1) % segments
                faces.extend([[a0 + j, b0 + j, b0 + jn],
                              [a0 + j, b0 + jn, a0 + jn]])
        mesh = trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=False)
        return self._make_mesh_item(mesh, color)

    def _update_parachute_visuals(self, rocket_z):
        """NEW: animate two separate canopies + eight suspension lines each."""
        if self.view is None:
            return
        deployed = self.ejection_triggered
        # Before deployment, hide the canopy and lines without removing objects.
        for key in ("rocket", "cansat"):
            canopy = self.parachute_items.get(key)
            lines = self.parachute_line_items.get(key)
            if canopy is None:
                # Large canopies: 3x the previous radius (9x projected area),
                # giving both vehicles clearly visible parachutes in the 3D scene.
                canopy = self._make_parachute_canopy(
                    radius=525.0 if key == "rocket" else 315.0,
                    height=330.0 if key == "rocket" else 210.0,
                    color=(1.0, 0.28, 0.12, 1.0) if key == "rocket" else (1.0, 0.78, 0.12, 1.0))
                self.view.addItem(canopy)
                self.parachute_items[key] = canopy
            if lines is None:
                lines = gl.GLLinePlotItem(pos=np.zeros((2, 3), dtype=np.float32),
                                          color=(0.98, 0.98, 0.92, 1.0), width=2, antialias=True, mode="lines")
                self.view.addItem(lines)
                self.parachute_line_items[key] = lines
            # Hide each canopy and its suspension lines as soon as its vehicle
            # has landed, so the vehicle visibly rests on the ground without
            # parachute geometry floating above it.
            landed = self.rocket_landed if key == "rocket" else self.cansat_landed
            # The rocket chute may open at separation, but the CanSat chute must
            # remain packed/hidden until the CanSat has fully cleared the bay.
            # A short 0.25 s delay after the ejection animation prevents the
            # canopy from appearing inside or attached to the rocket.
            if key == "cansat":
                chute_deployed = (
                    deployed and
                    self.separation_elapsed >= self.EJECTION_DURATION_S + 0.25
                )
            else:
                chute_deployed = deployed
            visible = chute_deployed and not landed
            canopy.setVisible(visible)
            lines.setVisible(visible)
            if not visible:
                continue
            if key == "rocket":
                anchor = np.array([0.0, 0.0, rocket_z + self.BAY_TOP_MM + 180.0])
                canopy_center = anchor + np.array([0.0, 0.0, 1080.0])  # 50% longer than the previous 720 mm line length
                radius, height = 525.0, 330.0
            else:
                if self.separation_elapsed <= self.EJECTION_DURATION_S:
                    can_z = rocket_z + self.BAY_BOTTOM_MM
                    can_x, can_y = self.cansat_x, self.cansat_y
                else:
                    can_z = self.cansat_altitude * self.ALTITUDE_TO_MODEL_UNITS
                    can_x, can_y = self.cansat_x, self.cansat_y
                anchor = np.array([can_x, can_y, can_z + 100.0])
                canopy_center = anchor + np.array([0.0, 0.0, 690.0])  # 50% longer than the previous 460 mm line length
                radius, height = 315.0, 210.0
            canopy.resetTransform()
            canopy.translate(float(canopy_center[0]), float(canopy_center[1]), float(canopy_center[2]))
            # Eight evenly-spaced line pairs connect canopy rim securely to its craft.
            line_points = []
            for j in range(8):
                phi = 2.0 * math.pi * j / 8.0
                rim = canopy_center + np.array([radius * math.cos(phi), radius * math.sin(phi), 0.0])
                line_points.extend([rim, anchor])
            lines.setData(pos=np.asarray(line_points, dtype=np.float32), mode="lines")

    def _update_readouts(self, phase):
        self.lbl_alt.setText(f"Altitude: {self.current_altitude:.1f} m")
        self.lbl_apogee.setText(f"Apogee: {self.max_altitude:.1f} m")
        self.lbl_phase.setText(f"Phase: {phase}")
        if self.ejection_triggered:
            if self.cansat_landed:
                status = "CanSat: LANDED"
            elif self.separation_elapsed < self.EJECTION_DURATION_S:
                status = "CanSat: EJECTING"
            elif self.separation_elapsed < self.EJECTION_DURATION_S + 0.25:
                status = "CanSat: CLEAR OF ROCKET"
            else:
                status = "CanSat: PARACHUTE DEPLOYED / DESCENT"
        else:
            status = "CanSat: INSIDE"
        self.lbl_cansat.setText(status)


# ============================================================
# GROUND STATION GUI
# ============================================================

class LogoBannerLabel(QLabel):
    """NEW: centre banner of the first dashboard's logo header.
    It fills all the free space between the two side logos (white backdrop that
    matches the banner artwork) and re-scales the banner on every resize so it
    is always as large as fits, with the original aspect ratio (never stretched)."""

    def __init__(self, b64_data, height_px, parent=None):
        super().__init__(parent)
        self._src = QPixmap()
        try:
            self._src.loadFromData(base64.b64decode(b64_data))
        except Exception:
            self._src = QPixmap()
        self.setFixedHeight(height_px)
        self.setMinimumWidth(1)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setStyleSheet("background-color: #FFFFFF;")

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._src.isNull():
            return
        dpr = self.devicePixelRatioF()
        w = max(1, int(self.width() * dpr))
        h = max(1, int(self.height() * dpr))
        pm = self._src.scaled(w, h, Qt.AspectRatioMode.KeepAspectRatio,
                              Qt.TransformationMode.SmoothTransformation)
        pm.setDevicePixelRatio(dpr)
        self.setPixmap(pm)


class ComponentStatusTab(QWidget):
    """Live component readings inferred from the Rocket/CanSat telemetry.

    These indicators mean that valid, recent fields are arriving; they are not
    substitutes for hardware self-test flags, which the current packet omits.
    """

    STATUS_COLORS = {
        "CONNECTED": "#00FFCC",
        "ONLINE": "#00FFCC",
        "REPORTING": "#00FFCC",
        "FIX": "#00FFCC",
        "CONNECTING": "#FFFF00",
        "WAITING": "#888888",
        "N/R": "#888888",
        "PARTIAL": "#FF8A00",
        "SEARCHING": "#FF8A00",
        "NO FIX": "#FF8A00",
        "NO DATA": "#FF8A00",
        "STALE": "#FF3333",
        "LOW": "#FF3333",
        "DISCONNECTED": "#FF3333",
        "ERROR": "#FF3333",
    }

    SOURCES = ("ROCKET", "CANSAT")

    def __init__(self, parent=None):
        super().__init__(parent)
        self._last_seen = {source: None for source in self.SOURCES}
        self._latest = {source: None for source in self.SOURCES}
        self._source_cards = {}

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)

        intro = QLabel(
            "Live status for the shared Teensy telemetry link and the sensors "
            "reported by each avionics stream.")
        intro.setWordWrap(True)
        root.addWidget(intro)

        link_box = QGroupBox("SHARED TEENSY USB LINK")
        link_layout = QHBoxLayout(link_box)
        self.shared_link_status = QLabel("DISCONNECTED")
        self.shared_link_status.setMinimumWidth(120)
        self.shared_link_detail = QLabel(
            "Select the Teensy COM port and connect to begin.")
        self.shared_link_detail.setWordWrap(True)
        link_layout.addWidget(self.shared_link_status)
        link_layout.addWidget(self.shared_link_detail, 1)
        root.addWidget(link_box)

        vehicles = QHBoxLayout()
        vehicles.setSpacing(10)
        component_names = (
            ("flight", "Avionics / flight computer"),
            ("barometer", "BMP390L barometer"),
            ("imu", "BNO085 IMU"),
            ("gnss", "GNSS receiver"),
            ("power", "INA219 power monitor"),
            ("radio", "E22 LoRa diagnostics"),
        )
        for source, title in (("ROCKET", "ROCKET AVIONICS"),
                              ("CANSAT", "CANSAT AVIONICS")):
            group = QGroupBox(title)
            grid = QGridLayout(group)
            grid.addWidget(QLabel("COMPONENT"), 0, 0)
            grid.addWidget(QLabel("STATUS"), 0, 1)
            grid.addWidget(QLabel("LATEST READING"), 0, 2)
            stream_status = QLabel("WAITING")
            stream_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
            stream_status.setMinimumWidth(92)
            stream_detail = QLabel("No packets received yet.")
            stream_detail.setWordWrap(True)
            grid.addWidget(QLabel("Telemetry stream"), 1, 0)
            grid.addWidget(stream_status, 1, 1)
            grid.addWidget(stream_detail, 1, 2)
            rows = {}
            for row_index, (key, name) in enumerate(component_names, start=2):
                name_label = QLabel(name)
                status_label = QLabel("WAITING")
                status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                status_label.setMinimumWidth(92)
                detail_label = QLabel("Waiting for the first packet.")
                detail_label.setWordWrap(True)
                grid.addWidget(name_label, row_index, 0)
                grid.addWidget(status_label, row_index, 1)
                grid.addWidget(detail_label, row_index, 2)
                rows[key] = (status_label, detail_label)
            grid.setColumnStretch(0, 1)
            grid.setColumnStretch(1, 0)
            grid.setColumnStretch(2, 3)
            self._source_cards[source] = {
                "stream_status": stream_status,
                "stream_detail": stream_detail,
                "rows": rows,
            }
            vehicles.addWidget(group, 1)
        root.addLayout(vehicles, 1)

        note = QLabel(
            "REPORTING means recent valid telemetry is present, not that a "
            "hardware self-test passed. The 15-field packet does not report "
            "RF RSSI/SNR or separate INA219 current/power readings.")
        note.setWordWrap(True)
        root.addWidget(note)
        self.set_shared_link_state(
            "DISCONNECTED", "Select the Teensy COM port and connect to begin.")
        self.refresh_statuses()

    @staticmethod
    def _number(value):
        try:
            number = float(value)
        except (TypeError, ValueError):
            return None
        return number if math.isfinite(number) else None

    @classmethod
    def _format_number(cls, value, digits=2):
        number = cls._number(value)
        return "--" if number is None else f"{number:.{digits}f}"

    def _set_chip(self, label, status):
        label.setText(status)
        color = self.STATUS_COLORS.get(status, "#BDBDBD")
        label.setStyleSheet(f"color: {color}; font-weight: bold;")

    def _set_row(self, source, key, status, detail):
        status_label, detail_label = self._source_cards[source]["rows"][key]
        self._set_chip(status_label, status)
        detail_label.setText(detail)

    def set_shared_link_state(self, state, detail=""):
        raw_state = str(state or "DISCONNECTED")
        normalized = raw_state.upper()
        if normalized.startswith("CONNECTED"):
            chip = "CONNECTED"
        elif normalized.startswith("CONNECTING"):
            chip = "CONNECTING"
        elif "ERROR" in normalized:
            chip = "ERROR"
        else:
            chip = "DISCONNECTED"
        self._set_chip(self.shared_link_status, chip)
        if not detail:
            if chip == "CONNECTED":
                detail = raw_state.partition(":")[2].strip() or "Serial link connected."
            elif chip == "CONNECTING":
                detail = "Opening the shared Teensy serial link."
            elif chip == "ERROR":
                detail = raw_state
            else:
                detail = "The shared Teensy serial link is disconnected."
        self.shared_link_detail.setText(detail)

    def reset(self):
        """Clear the per-stream readings when a fresh serial session starts."""
        self._last_seen = {source: None for source in self.SOURCES}
        self._latest = {source: None for source in self.SOURCES}
        self.refresh_statuses()

    def update_from_packet(self, source, packet):
        source = str(source or "").upper()
        if source not in self.SOURCES:
            return
        self._latest[source] = dict(packet)
        self._last_seen[source] = time.time()
        self._render_source(source)

    def refresh_statuses(self):
        now = time.time()
        for source in self.SOURCES:
            self._render_source(source, now)

    def _render_source(self, source, now=None):
        if now is None:
            now = time.time()
        card = self._source_cards[source]
        packet = self._latest[source]
        last_seen = self._last_seen[source]
        if packet is None or last_seen is None:
            self._set_chip(card["stream_status"], "WAITING")
            card["stream_detail"].setText(
                f"No {source.lower()} packets received yet.")
            for key in ("flight", "barometer", "imu", "gnss", "power"):
                self._set_row(source, key, "WAITING", "Waiting for telemetry.")
            self._set_row(
                source, "radio", "N/R",
                "RF diagnostics are not included in the telemetry packet.")
            return

        age = max(0.0, now - last_seen)
        fresh = age <= ZCFG.LINK_LOST_TIMEOUT_S
        stream_status = "ONLINE" if fresh else "STALE"
        packet_count = packet.get("packet_count", "--")
        team_id = packet.get("team_id") or "--"
        flight_state = packet.get("flight_state") or "--"
        card["stream_status"].setText(stream_status)
        self._set_chip(card["stream_status"], stream_status)
        card["stream_detail"].setText(
            f"Team ID: {team_id} · packet {packet_count} · "
            f"flight state: {flight_state} · last packet {age:.1f}s ago")

        self._set_row(
            source, "flight", stream_status,
            f"Team ID {team_id} · packet {packet_count} · state {flight_state}")

        barometer_keys = ("bmp_alt", "bmp_press", "bmp_temp")
        barometer_values = [self._number(packet.get(key))
                            for key in barometer_keys]
        valid_barometer = sum(value is not None for value in barometer_values)
        if not fresh:
            barometer_status = "STALE"
        elif valid_barometer == len(barometer_keys):
            barometer_status = "REPORTING"
        elif valid_barometer:
            barometer_status = "PARTIAL"
        else:
            barometer_status = "NO DATA"
        barometer_detail = (
            f"Altitude {self._format_number(packet.get('bmp_alt'))} m · "
            f"pressure {self._format_number(packet.get('bmp_press'))} hPa · "
            f"temperature {self._format_number(packet.get('bmp_temp'))} °C")
        self._set_row(source, "barometer", barometer_status, barometer_detail)

        imu_keys = ("ax", "ay", "az", "gx", "gy", "gz")
        imu_values = [self._number(packet.get(key)) for key in imu_keys]
        valid_imu = sum(value is not None for value in imu_values)
        if not fresh:
            imu_status = "STALE"
        elif valid_imu == len(imu_keys):
            imu_status = "REPORTING"
        elif valid_imu:
            imu_status = "PARTIAL"
        else:
            imu_status = "NO DATA"
        accel = ", ".join(self._format_number(packet.get(key))
                           for key in ("ax", "ay", "az"))
        gyro = ", ".join(self._format_number(packet.get(key))
                         for key in ("gx", "gy", "gz"))
        self._set_row(
            source, "imu", imu_status,
            f"Accel [{accel}] m/s² · gyro [{gyro}] °/s")

        latitude = self._number(packet.get("gnss_latitude"))
        longitude = self._number(packet.get("gnss_longitude"))
        satellites = self._number(packet.get("gnss_sats"))
        gnss_time = str(packet.get("gnss_time") or "--")
        has_fix = (latitude is not None and longitude is not None and
                   not (abs(latitude) < 1e-9 and abs(longitude) < 1e-9))
        if not fresh:
            gnss_status = "STALE"
        elif has_fix:
            gnss_status = "FIX"
        elif satellites is not None and satellites > 0:
            gnss_status = "SEARCHING"
        else:
            gnss_status = "NO FIX"
        if has_fix:
            gnss_detail = (
                f"Fix {latitude:.6f}, {longitude:.6f} · "
                f"{self._format_number(satellites, 0)} satellites · {gnss_time}")
        else:
            gnss_detail = (
                f"No valid coordinates · "
                f"{self._format_number(satellites, 0)} satellites · {gnss_time}")
        self._set_row(source, "gnss", gnss_status, gnss_detail)

        bus_voltage = self._number(packet.get("vbus"))
        if not fresh:
            power_status = "STALE"
        elif bus_voltage is None:
            power_status = "NO DATA"
        elif bus_voltage < LOW_VOLTAGE_WARN:
            power_status = "LOW"
        else:
            power_status = "REPORTING"
        self._set_row(
            source, "power", power_status,
            f"Bus voltage {self._format_number(bus_voltage)} V "
            f"(warning below {LOW_VOLTAGE_WARN:.1f} V) · "
            "current/power channels are not in the 15-field packet")
        self._set_row(
            source, "radio", "N/R",
            "E22 RSSI/SNR and radio self-test are not reported in this packet.")


class GroundStationGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("IN-SPACe 2026 — Zenith Orbitron Ground Station")
        self.resize(1500, 950)

        # --- v7.0: ONE shared telemetry store -----------------------------
        # self.hist shares the very same deque objects as the store, so the
        # graphs, the labels, the CSV log, the map and both simulations all
        # read from a single validated source.  There is no second copy.
        self.store = TelemetryStore()
        self.cansat_store = TelemetryStore()
        self.cansat_attitude = AttitudeEstimator()
        self.hist = dict(self.store.history)
        self.hist["t"] = self.store.t

        self.packet_loss = PacketLossTracker()
        self.attitude = AttitudeEstimator()
        self.derived = {"roll": float("nan"),
                        "pitch": float("nan"),
                        "yaw": float("nan")}

        self.packet_count = 0
        self.total_packet_bytes = 0
        self.last_packet_size = 0
        self.last_packet_wall = None
        self.start_wall = time.time()
        self.max_alt = float("-inf")
        self.max_accel = 0.0
        self.auto_scroll = True
        self.hil_frames = None             # set while a HIL self test runs

        # map state
        self.map_marker_lat = None
        self.map_marker_lon = None
        self.map_view = None
        self.map_fullscreen_dialog = None
        self.last_map_render = 0.0

        # CSV log - every column of the channel table is written; a channel the
        # firmware does not transmit is logged as an EMPTY cell (never 0, never
        # "nan"), so a recorded flight can be replayed without inventing data.
        self.csv_filename = f"telemetry_{int(time.time())}.csv"
        self.csv_logger = CsvLogger(self.csv_filename)

        self.thread = None
        self.monitor_panel = None
        self._monitor_restore_sizes = None
        self.init_ui()

        # link watchdog
        from PyQt6.QtCore import QTimer
        self.watchdog = QTimer(self)
        self.watchdog.timeout.connect(self._check_link)
        self.watchdog.start(500)

    # ---------------------------------------------------------
    # UI
    # ---------------------------------------------------------
    def init_ui(self):
        central = QWidget()
        main = QVBoxLayout(central)

        # The original dashboard is placed inside a resizable scroll area so
        # all dashboard controls remain reachable on smaller screens.
        # The dashboard widgets and their behavior are otherwise unchanged.
        dashboard_scroll = QScrollArea()
        dashboard_scroll.setWidgetResizable(True)
        dashboard_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        dashboard_scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        dashboard_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        dashboard_scroll.setWidget(central)

        self.tabs = QTabWidget()
        self.tabs.setStyleSheet(
            "QTabWidget::pane { border: 1px solid #383838; }"
            "QTabBar::tab { background-color: #1B1B1B; border: 1px solid #383838;"
            " padding: 6px 18px; }"
            "QTabBar::tab:selected { background-color: #272727; color: #00FFCC; }"
            "QTabBar::tab:hover { background-color: #272727; }")

        # --- v7.1: the Serial Monitor is taken OUT of the scroll area --------
        # The dashboard keeps scrolling exactly as before, but the monitor now
        # sits in its own panel underneath it.  A splitter separates the two,
        # so the operator can drag the divider to make the monitor as tall as
        # wanted; it starts at CONSOLE_SPLIT_RATIO of the window height.
        self.console_split = QSplitter(Qt.Orientation.Vertical)
        self.console_split.setChildrenCollapsible(True)
        self.console_split.setCollapsible(1, True)
        self.console_split.addWidget(dashboard_scroll)

        dashboard_page = QWidget()
        page_layout = QVBoxLayout(dashboard_page)
        page_layout.setContentsMargins(0, 0, 0, 0)
        page_layout.setSpacing(0)
        page_layout.addWidget(self.console_split)
        self.tabs.addTab(dashboard_page, "Telemetry Dashboard")
        self.setCentralWidget(self.tabs)

        # ---- NEW: logo header (top-left + top-right of the first dashboard) ----
        logo_row = QHBoxLayout()
        logo_row.setContentsMargins(0, 0, 0, 0)
        logo_row.addWidget(self._make_logo_label(LOGO_LEFT_B64),
                           0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        logo_row.addWidget(LogoBannerLabel(LOGO_BANNER_B64, LOGO_HEIGHT_PX), 1)
        logo_row.addWidget(self._make_logo_label(LOGO_RIGHT_B64),
                           0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        main.addLayout(logo_row)

        # ---- top bar ----
        top = QHBoxLayout()
        self.port_selector = QComboBox()
        self.baud_selector = QComboBox()
        self.baud_selector.addItems(BAUD_CHOICES)
        self.baud_selector.setCurrentText(DEFAULT_BAUD)
        btn_refresh = QPushButton("Refresh Ports")
        btn_refresh.clicked.connect(self.refresh_ports)
        self.btn_connect = QPushButton("Connect Teensy")
        self.btn_connect.clicked.connect(self.toggle_connection)
        self.status_label = QLabel("Status: DISCONNECTED")
        self.status_label.setStyleSheet("color: #FF3333; font-weight: bold;")
        self.link_label = QLabel("Rocket stream: --")
        self.link_label.setStyleSheet("color: #888888; font-weight: bold;")

        top.addWidget(QLabel("Teensy COM:"))
        top.addWidget(self.port_selector)
        top.addWidget(QLabel("Baud:"))
        top.addWidget(self.baud_selector)
        top.addWidget(btn_refresh)
        top.addWidget(self.btn_connect)
        top.addWidget(self.status_label)
        top.addWidget(self.link_label)
        # --- v7.0: two tools that verify the link without hardware ----------
        self.btn_replay = QPushButton("Replay Log …")
        self.btn_replay.setToolTip(
            "Play a saved receiver log through the same decoder and the same "
            "graphs / map / simulations as a live link.")
        self.btn_replay.clicked.connect(self._on_replay)
        self.btn_hil = QPushButton("HIL Self-Test")
        self.btn_hil.setToolTip(
            "Hardware-In-The-Loop: sends reference frames into the open port "
            "and checks that they come back decoded. Verification only - the "
            "values it sends are never shown as flight telemetry.")
        self.btn_hil.clicked.connect(self._on_hil)
        top.addWidget(self.btn_replay)
        top.addWidget(self.btn_hil)
        top.addStretch()
        main.addLayout(top)

        # ---- metrics row ----
        metrics = QHBoxLayout()

        def box(title, labels_grid):
            gb = QGroupBox(title)
            g = QGridLayout(gb)
            for lbl, r, c in labels_grid:
                g.addWidget(lbl, r, c)
            return gb

        self.lbl_bmp = QLabel("Alt 0.00 m | 0.00 °C | 0.00 hPa")
        self.lbl_bmp.setStyleSheet("color: #00FFCC; font-weight: bold;")
        self.lbl_max_alt = QLabel("Max Alt: 0.00 m")
        metrics.addWidget(box("BMP390L BAROMETER", [
            (QLabel("BMP390L:"), 0, 0), (self.lbl_bmp, 0, 1),
            (self.lbl_max_alt, 1, 0)]))

        self.lbl_accel = QLabel("Accel: X 0.00 | Y 0.00 | Z 0.00 m/s²")
        self.lbl_gyro = QLabel("Gyro: X 0.00 | Y 0.00 | Z 0.00 °/s")
        self.lbl_euler = QLabel("Roll +0.0° | Pitch +0.0° | Yaw +0.0°")
        self.lbl_accel_mag = QLabel("|a|: 0.00 m/s² (max 0.00)")
        metrics.addWidget(box("BNO085 IMU  (roll/pitch/yaw derived, not transmitted)", [
            (self.lbl_accel, 0, 0), (self.lbl_gyro, 1, 0),
            (self.lbl_euler, 2, 0), (self.lbl_accel_mag, 3, 0)]))

        self.lbl_vbus = QLabel("Bus: 0.00 V")
        self.lbl_vbus.setStyleSheet(
            "color: #B388FF; font-size: 13pt; font-weight: bold;")
        self.lbl_cur = QLabel("Current: -- mA (not transmitted)")
        self.lbl_pwr = QLabel("Power: -- mW (not transmitted)")
        metrics.addWidget(box("INA219 POWER  (only bus voltage is transmitted)", [
            (self.lbl_vbus, 0, 0), (self.lbl_cur, 1, 0),
            (self.lbl_pwr, 2, 0)]))

        self.lbl_packet_count = QLabel("Packets: 0")
        self.lbl_packet_rate = QLabel("Rate: 0.00 Hz")
        self.lbl_last_packet = QLabel("Last Packet: --")
        self.lbl_time = QLabel("Flight Time: 0.00 s")
        self.lbl_packet_size = QLabel("Last Size: 0 B")
        self.lbl_avg_size = QLabel("Average Size: 0.0 B")
        metrics.addWidget(box("LoRa TELEMETRY LINK", [
            (self.lbl_packet_count, 0, 0), (self.lbl_packet_rate, 0, 1),
            (self.lbl_last_packet, 1, 0), (self.lbl_time, 1, 1),
            (self.lbl_packet_size, 2, 0), (self.lbl_avg_size, 2, 1)]))
        main.addLayout(metrics)

        # ---- sidebar + graph grid ----
        pg.setConfigOption("background", "#121212")
        pg.setConfigOption("foreground", "#FFFFFF")

        row = QHBoxLayout()

        side = QWidget()
        side.setMaximumWidth(300)
        side_l = QVBoxLayout(side)
        side_l.setSpacing(6)

        gb_att = QGroupBox("FLIGHT ATTITUDE INDICATOR")
        l_att = QVBoxLayout(gb_att)
        self.attitude_indicator = AttitudeIndicator()
        self.attitude_indicator.setFixedHeight(190)
        l_att.addWidget(self.attitude_indicator)
        side_l.addWidget(gb_att)

        gb_map = QGroupBox("PAYLOAD LOCATION")
        l_map = QVBoxLayout(gb_map)
        map_widget = self._build_map_widget()
        map_widget.setFixedHeight(190)
        l_map.addWidget(map_widget)
        side_l.addWidget(gb_map)
        side_l.addStretch()
        row.addWidget(side)

        graphs = QWidget()
        grid = QGridLayout(graphs)
        grid.setSpacing(6)
        grid.setContentsMargins(0, 0, 0, 0)

        # Each telemetry heading gets two independent, same-sized plots:
        # Rocket Avionics and CanSat Avionics.  Four columns x four rows keeps
        # each plot close to the original dashboard tile dimensions.
        self.plots = {}
        self.curves = {}       # plot id -> [(key, curve)]
        self.plot_notes = {}
        self.plot_note_text = {}
        self.plot_sources = {}
        self.plot_source_colors = {"ROCKET": "#00D6A5", "CANSAT": "#FF9B45"}
        for n, (pid, title, ylabel, units, series) in enumerate(PLOT_SPECS):
            for source_index, source_name in enumerate(("ROCKET", "CANSAT")):
                plot_id = f"{pid}_{source_name.lower()}"
                source_title = f"{title} — {source_name.title()} Avionics"
                pw = pg.PlotWidget(title=source_title)
                pw.setLabel("left", ylabel, units=units)
                pw.setLabel("bottom", "Flight Time", units="s")
                pw.showGrid(x=True, y=True, alpha=0.25)
                pw.setBackground("#000000")
                pw.setMinimumHeight(150)
                pw.getPlotItem().getAxis("left").setWidth(70)
                if len(series) > 1:
                    pw.addLegend()
                pw.setXRange(0, 10, padding=0)
                pw.setYRange(0, 10, padding=0)
                self.plots[plot_id] = pw
                self.curves[plot_id] = []
                self.plot_sources[plot_id] = source_name
                source_color = self.plot_source_colors[source_name]
                for key, original_color, name in series:
                    # Keep every trace in a source-specific colour family.
                    # Axis/legend labels still identify individual IMU axes.
                    pen = pg.mkPen(color=source_color, width=2)
                    curve = pw.plot(pen=pen, name=name)
                    self.curves[plot_id].append((key, curve))
                note_text = ""
                if any(k in DERIVED_KEYS for k, _c, _n in series):
                    note_text = DERIVED_TEXT
                elif all(k in CHANNELS_NOT_TRANSMITTED for k, _c, _n in series):
                    note_text = NOT_TRANSMITTED_TEXT
                note = pg.TextItem(note_text, color="#FF8A00", anchor=(0.5, 0.5))
                note.setVisible(bool(note_text))
                pw.addItem(note)
                self.plot_notes[plot_id] = note
                self.plot_note_text[plot_id] = note_text
                gb = QGroupBox(source_title.upper())
                QVBoxLayout(gb).addWidget(pw)
                grid.addWidget(gb, n * 2 + source_index if False else
                               (n // 4) * 2 + source_index, n % 4)
        for i in range(4):
            grid.setColumnStretch(i, 1)
        for i in range(4):
            grid.setRowStretch(i, 1)
        row.addWidget(graphs, 1)
        main.addLayout(row, 1)

        # ---- console (Serial Monitor) ----
        # v7.0: the only layout change in the whole dashboard - the monitor is
        # taller so a full receiver report block is readable, and it has an
        # explicit auto-scroll switch.  Everything else is untouched.
        # ---- Serial Monitor ----
        # v7.1: a large, always-visible panel below the scrolling dashboard.
        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.console.setMinimumHeight(ZCFG.CONSOLE_MIN_HEIGHT_PX)
        self.console.setMaximumHeight(ZCFG.CONSOLE_MAX_HEIGHT_PX)
        self.console.document().setMaximumBlockCount(ZCFG.CONSOLE_MAX_BLOCKS)
        self.console.setStyleSheet(
            "background-color:#000000; color:#00FF00;"
            "font-family:Consolas; font-size:10pt;")

        console_tools = QHBoxLayout()
        self.chk_autoscroll = QCheckBox("Auto-scroll Serial Monitor")
        self.chk_autoscroll.setChecked(True)
        self.chk_autoscroll.stateChanged.connect(
            lambda _s: setattr(self, "auto_scroll",
                               self.chk_autoscroll.isChecked()))
        self.btn_clear_console = QPushButton("Clear Monitor")
        self.btn_clear_console.clicked.connect(self.console.clear)
        console_tools.addWidget(self.chk_autoscroll)
        console_tools.addWidget(self.btn_clear_console)
        self.btn_console_min = QPushButton("Minimize")
        self.btn_console_max = QPushButton("Maximize")
        self.btn_console_restore = QPushButton("Restore")
        self.btn_console_min.clicked.connect(self.minimize_serial_monitor)
        self.btn_console_max.clicked.connect(self.maximize_serial_monitor)
        self.btn_console_restore.clicked.connect(self.restore_serial_monitor)
        console_tools.addWidget(self.btn_console_min)
        console_tools.addWidget(self.btn_console_max)
        console_tools.addWidget(self.btn_console_restore)
        console_tools.addStretch()

        monitor_panel = QWidget()
        self.monitor_panel = monitor_panel
        monitor_layout = QVBoxLayout(monitor_panel)
        monitor_layout.setContentsMargins(0, 0, 0, 0)
        monitor_layout.setSpacing(4)
        monitor_layout.addLayout(console_tools)
        monitor_layout.addWidget(self.console, 1)
        self.console_split.addWidget(monitor_panel)

        # default split: the dashboard keeps the larger share, the monitor
        # starts at CONSOLE_SPLIT_RATIO and can be dragged from there.
        self.console_split.setStretchFactor(0, ZCFG.DASHBOARD_STRETCH)
        self.console_split.setStretchFactor(1, ZCFG.CONSOLE_STRETCH)
        total = max(600, self.height())
        monitor_px = int(total * ZCFG.CONSOLE_SPLIT_RATIO)
        self.console_split.setSizes([total - monitor_px, monitor_px])

        self._log(f"[SYSTEM] {VERSION}")
        self._log("[SYSTEM] Rocket TX frame: '@' + 15 CSV fields + '\\n'")
        self._log("[SYSTEM]   TEAM_ID,ms,count,alt_m,press_hPa,temp_C,volt_V,"
                  "gnssTime,lat,lon,gnssAlt_m,sats,ax;ay;az,gx;gy;gz,state")
        self._log("[SYSTEM] Accepted: receiver report block | RX,<15 fields> | "
                  "raw '@' frame | legacy CAN,20/22 fields")
        self._log("[SYSTEM] Not transmitted by this firmware: "
                  + ", ".join(c.name for c in ZCFG.missing_channels()))
        self._log(f"[SYSTEM] Logging to {self.csv_filename}")
        self._log("[SYSTEM] Select the Teensy COM port and press Connect Teensy.")
        self._place_plot_notes()
        self._init_extra_tabs()   # NEW: adds tab 2 (Live Map) + tab 3 (Simulation)
        self.refresh_ports()

    # ---------------------------------------------------------
    # NEW — LOGO HELPER
    # ---------------------------------------------------------
    def _make_logo_label(self, b64_data):
        """QLabel showing an embedded (base64 PNG) logo scaled to LOGO_HEIGHT_PX
        with its aspect ratio preserved. If decoding ever fails the label is
        simply blank (same size), so the application still runs."""
        lbl = QLabel()
        lbl.setFixedHeight(LOGO_HEIGHT_PX)
        lbl.setMinimumWidth(1)
        lbl.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pm = QPixmap()
        try:
            pm.loadFromData(base64.b64decode(b64_data))
        except Exception:
            pm = QPixmap()
        if not pm.isNull():
            dpr = self.devicePixelRatioF()
            target = int(LOGO_HEIGHT_PX * dpr)
            # Scale the complete logo to the larger header height without
            # stretching or distorting its original aspect ratio.
            pm = pm.scaled(target, target,
                           Qt.AspectRatioMode.KeepAspectRatio,
                           Qt.TransformationMode.SmoothTransformation)
            pm.setDevicePixelRatio(dpr)
            lbl.setPixmap(pm)
            lbl.setFixedSize(max(1, int(pm.width() / dpr)), LOGO_HEIGHT_PX)
        return lbl

    # ---------------------------------------------------------
    # NEW — EXTRA TABS
    # ---------------------------------------------------------
    def _init_extra_tabs(self):
        self.map_tab = LiveMapTab()                 # Existing map tab
        self.sim_tab = RocketSimulationTab()        # Existing 2D simulation tab
        self.sim3d_tab = Rocket3DSimulationTab()     # Existing 3D view
        self.component_status_tab = ComponentStatusTab()
        self.tabs.addTab(self.map_tab, "Live Map")
        self.tabs.addTab(self.sim_tab, "2D Flight Simulation")
        self.tabs.addTab(self.sim3d_tab, "3D Rocket Simulation")
        # Append the new tab so the order and behavior of existing tabs stay intact.
        self.tabs.addTab(self.component_status_tab, "Component Status")
        self._log(
            "[SYSTEM] Existing tabs initialized; Component Status tab added "
            "for live Rocket and CanSat telemetry.")

    def _feed_new_tabs(self, pkt):
        """Forward Rocket telemetry to the map, simulations, and status tab."""
        try:
            self.component_status_tab.update_from_packet("ROCKET", pkt)
        except Exception as e:
            self._log(f"[STATUS TAB ERROR] {type(e).__name__}: {e}")
        try:
            self.map_tab.update_from_packet(pkt)
        except Exception as e:
            self._log(f"[MAP TAB ERROR] {type(e).__name__}: {e}")
        try:
            self.sim_tab.update_from_packet(pkt)
        except Exception as e:
            self._log(f"[SIM TAB ERROR] {type(e).__name__}: {e}")
        try:
            self.sim3d_tab.update_from_packet(pkt)
        except Exception as e:
            self._log(f"[3D SIM TAB ERROR] {type(e).__name__}: {e}")

    # ---------------------------------------------------------
    # MAP
    # ---------------------------------------------------------
    def _build_map_widget(self):
        container = QWidget()
        stack = QStackedLayout(container)
        stack.setStackingMode(QStackedLayout.StackingMode.StackAll)
        stack.setContentsMargins(0, 0, 0, 0)

        if MAP_SUPPORT_AVAILABLE:
            self.map_view = QWebEngineView()
            self._render_map(self.map_view)
            stack.addWidget(self.map_view)
        else:
            fb = QLabel("Map unavailable —\ninstall with:\n"
                        "pip install folium PyQt6-WebEngine")
            fb.setAlignment(Qt.AlignmentFlag.AlignCenter)
            fb.setStyleSheet("color: #FF8A00;")
            stack.addWidget(fb)

        overlay = ClickableMapOverlay()
        overlay.clicked.connect(self._open_map_fullscreen)
        stack.addWidget(overlay)
        return container

    def _build_folium_html(self):
        lat = self.map_marker_lat
        lon = self.map_marker_lon
        fmap = folium.Map(
            location=[lat if lat is not None else MAP_DEFAULT_LAT,
                      lon if lon is not None else MAP_DEFAULT_LON],
            zoom_start=15, tiles="OpenStreetMap")
        if lat is not None:
            folium.Marker(
                [lat, lon], tooltip="Payload location",
                icon=folium.Icon(color="red", icon="rocket", prefix="fa")
            ).add_to(fmap)
        return fmap.get_root().render()

    def _render_map(self, view):
        view.setHtml(self._build_folium_html())

    def _open_map_fullscreen(self):
        if not MAP_SUPPORT_AVAILABLE:
            QMessageBox.information(
                self, "Map Unavailable",
                "pip install folium PyQt6-WebEngine")
            return
        if self.map_marker_lat is None:
            QMessageBox.information(
                self, "GPS Location Unavailable",
                "The locator appears once valid latitude/longitude "
                "arrive in the telemetry.")
            return
        d = self.map_fullscreen_dialog
        if d is not None and d.isVisible():
            d.raise_()
            d.activateWindow()
            return
        self.map_fullscreen_dialog = MapFullscreenDialog(
            self._build_folium_html(), parent=self)
        self.map_fullscreen_dialog.finished.connect(
            lambda _=None: setattr(self, "map_fullscreen_dialog", None))

    def _update_map_location(self, lat, lon):
        if not MAP_SUPPORT_AVAILABLE:
            return
        self.map_marker_lat, self.map_marker_lon = lat, lon
        now = time.time()
        if now - self.last_map_render < MAP_REFRESH_S:
            return
        self.last_map_render = now
        if self.map_view is not None:
            self._render_map(self.map_view)
        d = self.map_fullscreen_dialog
        if d is not None and d.isVisible():
            d.view.setHtml(self._build_folium_html())

    # ---------------------------------------------------------
    # PORTS / CONNECTION
    # ---------------------------------------------------------
    def refresh_ports(self):
        current = self.port_selector.currentText()
        self.port_selector.clear()
        # v7.0: port enumeration must never be able to crash the dashboard
        ports, descriptions = [], {}
        try:
            if SERIAL_LIBRARY_AVAILABLE:
                for p in serial.tools.list_ports.comports():
                    ports.append(p.device)
                    descriptions[p.device] = p.description or "Unknown device"
        except Exception as e:
            self._log(f"[PORT] port enumeration failed: {e}", "#FF8A00")
        if not ports:                      # fallback scan (e.g. odd udev setups)
            ports = available_ports()
            descriptions = {d: "found by device scan" for d in ports}
        if not ports:
            self.port_selector.addItem("NO SERIAL PORTS FOUND")
            self._log("[PORT] No serial ports detected.", "#FF8A00")
            return
        for device in ports:
            self.port_selector.addItem(device)
        i = self.port_selector.findText(current)
        if i >= 0:
            self.port_selector.setCurrentIndex(i)
        self._log("[PORT] Available serial ports:", "#9E9E9E")
        for device in ports:
            self._log(f"    {device} — "
                      f"{descriptions.get(device, 'Unknown device')}", "#9E9E9E")

    def toggle_connection(self):
        if self.thread is not None and self.thread.isRunning():
            self._log("[SERIAL] Disconnecting...")
            self.thread.stop()
            self.thread = None
            self._set_status("DISCONNECTED", "#FF3333")
            self.component_status_tab.set_shared_link_state(
                "DISCONNECTED", "The shared Teensy serial link was disconnected.")
            self.btn_connect.setText("Connect Teensy")
            return

        port = self.port_selector.currentText()
        if not port or port == "NO SERIAL PORTS FOUND":
            QMessageBox.warning(self, "No Serial Port",
                                "No valid serial port is selected.")
            return
        baud = int(self.baud_selector.currentText())
        # reset stats + history
        self.packet_count = 0
        self.total_packet_bytes = 0
        self.last_packet_size = 0
        self.last_packet_wall = None
        self.start_wall = time.time()
        self.max_alt = float("-inf")
        self.max_accel = 0.0
        for d in self.hist.values():
            d.clear()
        for plot_id, lst in self.curves.items():
            if plot_id.endswith(("_rocket", "_cansat")):
                for _, curve in lst:
                    curve.setData([], [])
        self.attitude_indicator.set_attitude(0, 0, 0)

        # --- v7.0: reset the shared store and the derived estimators -------
        self.store.clear()
        self.cansat_store.clear()
        self.packet_loss.reset()
        self.attitude.reset()
        self.cansat_attitude.reset()
        self.derived = {"roll": float("nan"),
                        "pitch": float("nan"),
                        "yaw": float("nan")}
        self.component_status_tab.reset()
        self.component_status_tab.set_shared_link_state(
            "CONNECTING", f"Opening {port} @ {baud} baud.")
        for pid, note in self.plot_notes.items():
            if (pid.endswith(("_rocket", "_cansat")) and note is not None
                    and self.plot_note_text.get(pid)):
                note.setVisible(True)
        self._set_status(f"CONNECTING ({port})", "#FFFF00")

        self._log(f"[SERIAL] Connecting to {port} @ {baud} baud ...")
        self.thread = SerialReaderThread(port, baud, source_name="AUTO")
        self.thread.telemetry_packet_signal.connect(self.handle_telemetry_packet)
        self.thread.raw_console_signal.connect(
            lambda text: self._log("[TEENSY] " + text, "#9E9E9E"))
        self.thread.monitor_line_signal.connect(
            lambda text: self._log(text, "#FF9B45" if text.startswith("[CANSAT]") else "#00FF00"))
        self.thread.decoder_message_signal.connect(
            lambda level, text: self._log(
                text, {"error": "#FF3333", "warn": "#FF8A00"}.get(level, "#9E9E9E")))
        self.thread.connection_error_signal.connect(self.handle_connection_error)
        self.thread.connection_status_signal.connect(self.handle_connection_status)
        self.thread.start()

        self.btn_connect.setText("Disconnect Teensy")
        self._set_status(f"CONNECTING ({port})", "#FFFF00")

    def _set_status(self, text, color):
        self.status_label.setText(f"Status: {text}")
        self.status_label.setStyleSheet(f"color: {color}; font-weight: bold;")

    def handle_connection_status(self, status):
        self._log(f"[STATUS] {status}")
        detail = (f"{self.port_selector.currentText()} @ "
                  f"{self.baud_selector.currentText()} baud"
                  if status.startswith("CONNECTED") else "")
        self.component_status_tab.set_shared_link_state(status, detail)
        if status.startswith("CONNECTED"):
            self._set_status(status, "#00FFCC")
        elif status == "DISCONNECTED":
            self._set_status("DISCONNECTED", "#FF3333")
            self.btn_connect.setText("Connect Teensy")

    def handle_connection_error(self, message):
        self._log(f"[ERROR] {message}")
        self.component_status_tab.set_shared_link_state("ERROR", message)
        self._set_status("SERIAL ERROR", "#FF3333")
        self.btn_connect.setText("Connect Teensy")
        QMessageBox.critical(self, "Serial Connection Error", message)

    def _check_link(self):
        if hasattr(self, "component_status_tab"):
            self.component_status_tab.refresh_statuses()
        if self.last_packet_wall is None:
            return
        age = time.time() - self.last_packet_wall
        if age > LINK_LOST_TIMEOUT_S:
            self.link_label.setText(f"Rocket stream: NO SIGNAL ({age:.0f}s)")
            self.link_label.setStyleSheet("color: #FF3333; font-weight: bold;")
        else:
            self.link_label.setText("Rocket stream: OK")
            self.link_label.setStyleSheet("color: #00FFCC; font-weight: bold;")

    # ---------------------------------------------------------
    # PLOT HELPER
    # ---------------------------------------------------------
    @staticmethod
    def _finite(values):
        """NaN-safe filter: a channel that was not transmitted must not be able
        to destroy the axis range of a graph that does have data."""
        out = []
        for v in values:
            try:
                f = float(v)
            except (TypeError, ValueError):
                continue
            if math.isfinite(f):
                out.append(f)
        return out

    @staticmethod
    def _autoscale(plot, x, series_list):
        xs = GroundStationGUI._finite(x)
        if len(xs) == 1:
            plot.setXRange(xs[0] - 5, xs[0] + 5, padding=0)
        elif len(xs) >= 2:
            xmin, xmax = min(xs), max(xs)
            if xmax <= xmin:
                xmax = xmin + 1
            pad = max((xmax - xmin) * 0.05, 0.5)
            plot.setXRange(xmin - pad, xmax + pad, padding=0)

        ys = GroundStationGUI._finite(v for s in series_list for v in s)
        if ys:
            lo, hi = min(ys), max(ys)
            if hi - lo < 1.0:
                c = (lo + hi) / 2
                lo, hi = c - 1.0, c + 1.0
            else:
                pad = (hi - lo) * 0.15
                lo, hi = lo - pad, hi + pad
            plot.setYRange(lo, hi, padding=0)

    # ---------------------------------------------------------
    # TELEMETRY HANDLER
    # ---------------------------------------------------------
    # ---------------------------------------------------------
    # SERIAL MONITOR HELPER (auto-scroll)
    # ---------------------------------------------------------
    def _log(self, text, color=None):
        """Append one line to the Serial Monitor and keep the newest visible.

        Implemented with insertHtml/insertPlainText (instead of
        QTextEdit.append) so the append point is always the end of the
        document and the scroll position is explicitly controlled by the
        "Auto-scroll Serial Monitor" switch.
        """
        try:
            cursor = self.console.textCursor()
            cursor.movePosition(cursor.MoveOperation.End)
            self.console.setTextCursor(cursor)
            if color:
                safe = (str(text).replace("&", "&amp;")
                        .replace("<", "&lt;").replace(">", "&gt;"))
                # white-space:pre keeps the column alignment of the receiver's
                # report block intact in the monitor.
                self.console.insertHtml(
                    f'<span style="color:{color}; white-space:pre">{safe}'
                    f'</span><br>')
            else:
                self.console.insertPlainText(str(text) + "\n")
            if getattr(self, "auto_scroll", True):
                sb = self.console.verticalScrollBar()
                sb.setValue(sb.maximum())
        except Exception:
            pass

    # ---------------------------------------------------------
    # TELEMETRY HANDLER  (runs on the GUI thread, from a queued signal)
    # ---------------------------------------------------------
    @staticmethod
    def _fmt(value, digits=2, suffix=""):
        """Render a channel, or '--' when the firmware did not transmit it."""
        try:
            f = float(value)
        except (TypeError, ValueError):
            return "--"
        if not math.isfinite(f):
            return "--"
        return f"{f:.{digits}f}{suffix}"

    def handle_telemetry_packet(self, pkt, packet_size, source=None):
        """The single place where a validated packet enters the GUI.

        Order of operations: route to the source store -> derived attitude ->
        graphs -> numeric readouts -> CSV -> Serial Monitor -> tabs. Every
        widget update happens here, on the GUI thread; the worker thread only
        emits the dict.
        """
        try:
            if source is None:
                source = ("CANSAT" if pkt.get("_source") in
                          (SRC_CANSAT_TAG, "legacy-can") else "ROCKET")
            source = str(source or "ROCKET").upper()
            if source == "CANSAT":
                self._handle_cansat_packet(pkt, packet_size)
                return
            # --- 1. rocket shared store ----------------------------------
            self.store.push(pkt)

            # --- 2. packet-loss bookkeeping (port of checkPacketLoss()) ---
            try:
                count = int(pkt.get("packet_count", 0))
            except (TypeError, ValueError):
                count = 0
            for _level, msg in self.packet_loss.update(count):
                self._log(msg, "#FF8A00")

            # --- 3. attitude derived from real accelerometer / gyro -------
            roll, pitch, yaw = self.attitude.update(pkt)
            if all(math.isfinite(v) for v in (roll, pitch, yaw)):
                pkt = dict(pkt)                 # do not mutate the stored one
                pkt["roll"], pkt["pitch"], pkt["yaw"] = roll, pitch, yaw
                self.derived = {"roll": roll, "pitch": pitch, "yaw": yaw}
                self.store.latest["roll"] = roll
                self.store.latest["pitch"] = pitch
                self.store.latest["yaw"] = yaw
                # store.push() already appended one NaN sample per channel for
                # this packet; overwrite that slot so every series keeps the
                # same length as the time axis (no second copy, no drift).
                for key, value in (("roll", roll), ("pitch", pitch), ("yaw", yaw)):
                    if self.hist[key]:
                        self.hist[key][-1] = value
                    else:
                        self.hist[key].append(value)
                self.attitude_indicator.set_attitude(pitch, roll, yaw)

            # --- 4. flight time axis --------------------------------------
            t_ms = pkt.get("time_ms")
            t = float(t_ms) / 1000.0 if self._finite([t_ms]) else float("nan")

            # --- 5. graphs: every channel goes to its own tile ------------
            self._refresh_source_plots("ROCKET")

            # --- 6. numeric readouts (NaN -> "--") ------------------------
            self.lbl_bmp.setText(
                f"Alt {self._fmt(pkt.get('bmp_alt'))} m | "
                f"{self._fmt(pkt.get('bmp_temp'))} °C | "
                f"{self._fmt(pkt.get('bmp_press'))} hPa")
            if self._finite([pkt.get("bmp_alt")]):
                self.max_alt = max(
                    self.max_alt if math.isfinite(self.max_alt) else float("-inf"),
                    float(pkt["bmp_alt"])
                )
            self.lbl_max_alt.setText(
                f"Max Alt: {self._fmt(self.max_alt) if math.isfinite(self.max_alt) else '0.00'} m")

            self.lbl_accel.setText(
                f"Accel: X {self._fmt(pkt.get('ax'))} | "
                f"Y {self._fmt(pkt.get('ay'))} | "
                f"Z {self._fmt(pkt.get('az'))} m/s²")
            self.lbl_gyro.setText(
                f"Gyro: X {self._fmt(pkt.get('gx'))} | "
                f"Y {self._fmt(pkt.get('gy'))} | "
                f"Z {self._fmt(pkt.get('gz'))} °/s")
            self.lbl_euler.setText(
                f"Roll {self._fmt(pkt.get('roll'), 1)}°* | "
                f"Pitch {self._fmt(pkt.get('pitch'), 1)}°* | "
                f"Yaw {self._fmt(pkt.get('yaw'), 1)}°*  (derived)")
            if self._finite([pkt.get("accel_mag")]):
                self.max_accel = max(self.max_accel, float(pkt["accel_mag"]))
            self.lbl_accel_mag.setText(
                f"|a|: {self._fmt(pkt.get('accel_mag'))} m/s² "
                f"(max {self._fmt(self.max_accel)})")

            vbus = pkt.get("vbus")
            low = self._finite([vbus]) and float(vbus) < LOW_VOLTAGE_WARN
            self.lbl_vbus.setText(
                f"Bus: {self._fmt(vbus)} V" + ("  ⚠ LOW" if low else ""))
            self.lbl_vbus.setStyleSheet(
                f"color: {'#FF3333' if low else '#B388FF'};"
                "font-size: 13pt; font-weight: bold;")
            self.lbl_cur.setText(
                f"Current: {self._fmt(pkt.get('cur'), 1)} mA")
            self.lbl_pwr.setText(
                f"Power: {self._fmt(pkt.get('pwr'), 1)} mW")

            # --- 7. link statistics ---------------------------------------
            self.packet_count = self.store.packet_count
            self.last_packet_wall = time.time()
            self.last_packet_size = packet_size
            self.total_packet_bytes += packet_size
            avg = (self.total_packet_bytes / self.packet_count
                   if self.packet_count else 0.0)
            elapsed = time.time() - self.start_wall
            rate = self.store.rate_hz()
            state = pkt.get("flight_state") or "--"
            color = FLIGHT_STATE_COLORS.get(state, "#888888")

            self.lbl_packet_count.setText(f"Packets: {self.packet_count}")
            self.lbl_packet_rate.setText(f"Rate: {rate:.2f} Hz")
            self.lbl_last_packet.setText(
                f"Last Packet: {time.strftime('%H:%M:%S')}")
            self.lbl_time.setText(
                f"Flight Time: {self._fmt(t) if math.isfinite(t) else '0.00'} s")
            self.lbl_packet_size.setText(f"Last Size: {packet_size} B")
            self.lbl_avg_size.setText(f"Average Size: {avg:.1f} B")
            self.status_label.setText(f"Status: CONNECTED — {state}")
            self.status_label.setStyleSheet(
                f"color: {color}; font-weight: bold;")

            # --- 8. map marker (only for a real GNSS fix) ------------------
            if "latitude" in pkt and "longitude" in pkt:
                self._update_map_location(pkt["latitude"], pkt["longitude"])

            # --- 9. CSV ----------------------------------------------------
            self.csv_logger.write(pkt)

            # --- 10. Serial Monitor ----------------------------------------
            self._log("[ROCKET] " + ZPROTO.format_monitor_line(pkt), "#00FF00")

            # --- 11. the same dict drives the map and both simulations -----
            self._feed_new_tabs(pkt)

        except Exception as e:
            self._log(f"[TELEMETRY UI ERROR] {type(e).__name__}: {e}", "#FF3333")

    def _refresh_source_plots(self, source):
        """Refresh only the graphs belonging to the selected avionics stream."""
        store = self.store if source == "ROCKET" else self.cansat_store
        suffix = "rocket" if source == "ROCKET" else "cansat"
        for pid, lst in self.curves.items():
            if not pid.endswith("_" + suffix):
                continue
            x = store.times()
            for key, curve in lst:
                series = store.series(key)
                if len(series) < len(x):
                    series = [float("nan")] * (len(x) - len(series)) + series
                curve.setData(x, series)
            self._autoscale(self.plots[pid], x,
                            [store.series(k) for k, _curve in lst])
            note = self.plot_notes.get(pid)
            if note is not None and self.plot_note_text.get(pid):
                has_data = any(self._finite(store.series(k)) for k, _curve in lst)
                note.setVisible(not has_data)
        self._place_plot_notes()

    def _handle_cansat_packet(self, pkt, packet_size):
        """Keep CanSat telemetry isolated from rocket state and simulations."""
        self.cansat_store.push(pkt)
        roll, pitch, yaw = self.cansat_attitude.update(pkt)
        if all(math.isfinite(v) for v in (roll, pitch, yaw)):
            pkt = dict(pkt)
            pkt.update({"roll": roll, "pitch": pitch, "yaw": yaw})
            self.cansat_store.latest.update(
                {"roll": roll, "pitch": pitch, "yaw": yaw})
            for key, value in (("roll", roll), ("pitch", pitch), ("yaw", yaw)):
                history = self.cansat_store.history.get(key)
                if history:
                    history[-1] = value
        self._refresh_source_plots("CANSAT")
        try:
            self.component_status_tab.update_from_packet("CANSAT", pkt)
        except Exception as e:
            self._log(f"[STATUS TAB ERROR] {type(e).__name__}: {e}")
        self._log("[CANSAT] " + ZPROTO.format_monitor_line(pkt), "#FF9B45")
        if self.csv_logger:
            # Source column already identifies the incoming stream.
            pkt = dict(pkt)
            pkt["_source"] = "cansat-" + str(pkt.get("_source", "serial"))
            self.csv_logger.write(pkt)

    def minimize_serial_monitor(self):
        sizes = self.console_split.sizes()
        if sizes[1] > 0:
            self._monitor_restore_sizes = sizes
        self.console_split.setSizes([max(1, sum(sizes)), 0])

    def maximize_serial_monitor(self):
        current = self.console_split.sizes()
        if current[0] > 0 and current[1] > 0:
            self._monitor_restore_sizes = current
        total = max(600, sum(current))
        self.console_split.setSizes([0, total])

    def restore_serial_monitor(self):
        if self._monitor_restore_sizes:
            self.console_split.setSizes(self._monitor_restore_sizes)
        else:
            total = max(600, sum(self.console_split.sizes()))
            self.console_split.setSizes([int(total * 0.65), int(total * 0.35)])

    # ---------------------------------------------------------
    # PLOT NOTICES
    # ---------------------------------------------------------
    def _place_plot_notes(self):
        """Keep the "not transmitted" caption centred in its tile."""
        for pid, note in self.plot_notes.items():
            if not note.isVisible() or not self.plot_note_text.get(pid):
                continue
            try:
                (xmin, xmax), (ymin, ymax) = (
                    self.plots[pid].getViewBox().viewRange())
                note.setPos((xmin + xmax) / 2.0, (ymin + ymax) / 2.0)
            except Exception:
                pass

    # ---------------------------------------------------------
    # TOOLS: replay a log / hardware-in-the-loop self test
    # ---------------------------------------------------------
    def _on_replay(self):
        """Replay a saved receiver log through the *same* decoder."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Open receiver log", "",
            "Logs and CSV (*.log *.txt *.csv);;All files (*)")
        if not path:
            return
        if self.thread is not None and self.thread.isRunning():
            QMessageBox.information(
                self, "Replay", "Disconnect the serial link before replaying.")
            return
        # (flat build) ReplayWorker is defined above
        self.decoder_replay = ReceiverDecoder()
        self.replay_worker = ReplayWorker(path, self.decoder_replay,
                                          speed=5.0)
        self.replay_worker.line_received.connect(
            lambda line: self._log(f"[RX] {line.rstrip()}", "#9E9E9E"))
        self.replay_worker.sample_decoded.connect(
            lambda pkt: self.handle_telemetry_packet(pkt, len(str(pkt))))
        self.replay_worker.message.connect(
            lambda level, text: self._log(
                text, "#FF8A00" if level == "warn" else "#9E9E9E"))
        self.replay_worker.start()

    def _on_hil(self):
        """Hardware-In-The-Loop self test.

        Pushes reference frames into the *open* port (PC -> RX Teensy USB ->
        this decoder).  It only verifies the plumbing; the frames are tagged
        ``_source='hil'`` and are never mistaken for flight telemetry.
        """
        if self.thread is None or not self.thread.isRunning():
            QMessageBox.information(
                self, "HIL Self-Test",
                "Connect to the receiver first - the self test sends frames "
                "into the open port and waits for them to come back.")
            return
        # (flat build) reference_frames is defined above
        frames = reference_frames(5, 1.0)
        self.hil_frames = {"sent": len(frames), "ok": 0,
                           "pending": list(frames)}
        for frame in frames:
            self.thread.send(frame)
        self._log(f"[HIL] sent {len(frames)} reference frames; "
                  f"waiting for the decoder ...", "#FFD400")

    # ---------------------------------------------------------
    def closeEvent(self, event):
        # Stop the worker thread first (it owns the port), then flush the log.
        for reader_name in ("thread",):
            reader = getattr(self, reader_name, None)
            if reader is not None and reader.isRunning():
                reader.stop()
                reader.wait(2000)
                setattr(self, reader_name, None)
        worker = getattr(self, "replay_worker", None)
        if worker is not None and worker.isRunning():
            worker.stop()
            worker.wait(2000)
        try:
            self.csv_logger.close()
        except Exception:
            pass
        event.accept()


# ============================================================
# EMBEDDED LOGO IMAGES (base64 PNG) — first dashboard only
# LEFT : Zenith Orbitron    CENTRE: Dr. M.G.R. Educational and Research Institute    RIGHT: existing right logo
# ============================================================

LOGO_LEFT_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAIAAADTED8xAAEAAElEQVR42uz9d3hc1bU+AK+19z5lqkZdsiT3Xim2sek9kEIooaTc"
    "FHLTy02jJuSGFEL6TUIKCWmUhJJAciGhGNPBBmNjG1fZsqzepekz55y99/r+ODOSLEuybEhuvt/3zaOHR8gzZ87Zba31rne9C2ee"
    "fw0AICIQAYH/Iiz8glj4jaj4b6NeeNj7j/blX9b/FiLyfxn+3yleBMd74zHckn8Dw7cx5gFH3+qY+z/CnYy64Jj/HX2T/leP/4CA"
    "COPfwNiL0NhbOnwqJ5+CMY9T+DtO+DiHjFJxAMc81+SzP+ado/9Y/CwC+L8QFNfoOEON6K9gRCzcBhGDwqgOPyYBAAOEwkoTI7dO"
    "8P9//f9fo5bnhFtuwpNo4j38L71xosKdT+HNbCrXmspTHdWTjxyxozbraGtz+NUmOcDozRiy4fmb6Iv8Wz3mR57Kg0w+DW/kS49q"
    "Zgt/xHEeeXL7POaCR9w5ow3+RPM+9eU+4sCMbOGR+xx+FgQY/UYBhb2CRzDl/l0Whgb9X0bMKxUs0NRv238zEQECK37hmPWHNM5H"
    "JrizcQZmjBcxfK6N+cuw+SzcDx0yJYVRo/GsP03pOJxkHRxhxEaOiaP3AA+986I3hGMGhIhGzyzSIaMx6VeMP92FdTZyACMQjRn8"
    "8UbedzH9ey6urpF7Jv8/44744f7qlHxm/ysYiMI1j2QtcNSM43g3cnQuNx36O45/zQk/MpXvpbH2vDBSNM4n8dCb+Td5HduNTLjf"
    "Jng0POy4wDfv3tC/Mh46KTjmDaOOJA2IBL4ppgnu7011lsRoGwGTRFqj7uCo7NQY32Zs/HSo/zN1d/ONB9xjjPXwv052YB/TP8Eb"
    "XseTOGYTDfhIFMjY5O7WRM7M5EMxlUEY7VhONBFjPzUqZB85s451ACdbqIUrE/unTuREM3ds3t4RvcB/i9BxPGTjjW+Gf58H/NcZ"
    "wH/qUxP5VkWMmbYxiOQx4I/jTv/hhuXw3ye/2ug7nGSRHT5kY756igt09Dl6eOR3+PF8OIQ6OqoejcRNxZgcfmQe1UZ64xZ1cnfg"
    "qLyAid457mC+QYDhGK4gxl2px+ZXHNVUjZ6kcW3lRFtxDGR0xHueBNWZyv9OtGkPX/FHnOnDjTABIiCRQkSiQ94/udvwRqZ/3Cu/"
    "WQ7YMTsF/wKv8lhg0H+Bk/D/jL2eCuo36j2IyEl7+UwCmaEVTXHo3lzX8WjX2b+Vt/mmjAEbM3NYfI375GOCp9Hg9LhA9eHvOfxf"
    "D//gIbnY8c7XN+VsGMGPJ8HCj/58Gr6m1nocf6yQqiQNSIowvqsOD+YyfSgYkX7jp8m4HuARH/DwSR/3U0fMRRwOuk9l3I4q7fNm"
    "n8WaTb7uDx+jyRMowxc5fGWPe3Ec9RrzLZP4PFNxXqcIWw2v16NN4oxZEIePyeixGnlDIZ8AtsX7W7add8Ksm6/7RLL5VcG4/49T"
    "zzwe80IZ9tyOyqGafApGY2hjspz/56b4kPE/bNf9H7hA/7KB+Jc5aWO+S2t9pPeDJx3b67366vft2r/v3BOn97ftM0wbtP7/wTH/"
    "P9knBXt8tBvgiDbuaA+wcY/Mox2R0WbE/zhjbPQ5NC4W/sZX/+Qn4oTXIS0su2f/7qvecdqaNafe/6d7jz9+uZFrkSQRGcMJ3Yxx"
    "rfQYCzPalk5io45o6ifxr8ac8TBB0mAqK+FordD4Ph4WfiYa+YldD/ZvZwHe+GFweDzz73dOcjcvQ9h1xbve0dLc2tPd23SgZdWS"
    "GfHOfYYh6J8zmEe7zqYe0B/t+fLv9mJTh8bGXVXHtsjG9fWPbVccFVfxiG+e3K2ffHymZDpIG5bV27Ltsres8ZgYSg5YgeCT69ad"
    "smqhircAaDXKC5pKJIOHvsaMySTjPBHRbRIPfnSAd7hHMOaG3xTE9k3xaSfGXSZ2gaZo3Cca8anf2dSTBsfwzGOin8lhn2PAjsaJ"
    "ehEINaBG0Aga/V9IAWkAjaAVMq2kle++4pJ37X59V2VFuZRed0+PEPbx82uH+tuBGwAaQCNp8j9FCgvkMARABoCEh6fwx0bbU9vh"
    "xzbsh7tAh++QMX7Rkb/rUE9mont44w7CKCwH/PH8/7/elBCZgIhryTQw4MgE46ZgYWFGWTAqghFuB0EI2zaHug6cuWZFIBRKJ9OW"
    "Gchl0wDw3PMbzz3zpKGDjUEA1B7jHK2QCESMYBQDJWgHmCE4BwIlQRNKZN4R2YNTPHf+D3H9f0FWYVwweiQEhmJBzDFcd3TQCUef"
    "Tzlaj/Pw2ToqNsGbe4oMP0bhd2TIGGOcuGBAoKTy8l4+5WXTucyQ6yRkPqvdTEBoIEr3t3zw5nuffea5yqqqvJM3TYtz/tQzz15y"
    "2UVVdu/BDb8WZliRUMA1s7kVMoMhI1hiB2N2IGqaIWYYgFxprZWnlSStCrjSoWzPyRfW8KxNboQPj2snCiiPeFL864OxAsrJ2Lhu"
    "pG+bNJD4J5yFx3gUvSlP+MZHbYJbKrDTmUYA0oyAMcFNJkwCkm7aSQ9kE/35ZK/Kpbh2DZTRkFEZC5TXlpTGyqsq5i1cMPf+B/+2"
    "4aVX6upr1649+cc//vnXvvaVvv4eIUQoFEkm401N+y8458zf/eHO0mmBr3z5S309PamheDyZ7u0fSiQH+vob4+1uf157KMgMG+Hy"
    "SEl1IFImAhGGXEkplQIlgRQhp5ESC0T4t0/c4pu5Ko72ImIizuokPLZJvMA3Ahsf8abHjeTelNU/SehGRADEgAgYogCbc8651Llc"
    "PDHU5Ax2quwgQ688ZCypq6ieV1lXd3xDQ0NZWWlFRUVZWVkwFGJcKKW0ptt+9QdEvOySy3t7+rq7O5YsWfrals2klWmZAGzd+uc+"
    "+MH3/eHuP/X1Dkml3/r2i0gR50wpCYBOPh+PDw3097W2th9sbWtt72pr39rbnM4pgeHyQKwmFK0SwVLGA4KkUlIrQJCAmkCMXmLH"
    "TPr6ZxyLvsfv1+mOqgo4unU8RUbmeFl5AABxxFrpyZf4m7v+JuLoj8kx/1Pt5qgBIZ+6wLjBDAtBublUqq8n3XdQZTpKTD13Rt3S"
    "sxcuWjC/vr6+qromEAw60tFaAQIp4Ewg40ppTTIWi913331NjY2AcPm73vXoo/8IhULl5RXxRJwIEMAw7de2bLn66vfPnjNvf+Ou"
    "v/31sfPOOS+dSrqu67qu53mIGAiGZs4pnbdoBWiJSJlcpq+n58C+ffsa9+xrbj94cGdfyiOrJFA+K1I53Q6FgVmekuBJIEIAZOxw"
    "AOMYeKaTeDVjKLTjrsIj+lE4wRE5hg48UcnK4WWWk2MzAv5dX34+9V/oOyIUqve0j4+hMIQhQHmZZH+iY6+b6Aqy/Kzp1cedt+T4"
    "4y5ftGhRbe00xlgymUpnMp6UXirFhTAMEwCybiaTHkqmUt3dPX19/UNDQy9teAkAZs+du+K44775rW/V1dUhQiKeUEoqpQxDZDPZ"
    "vXsbzzjj9P2NuzZv3nrNtdeVxkrKSssikUhFRXlFRUVJSUlUCAGeAsjm8lKq0tLy1WuqzzrrfMZZMpM82Ly/cU/j1m17d+77R79D"
    "RqQuXDk7VFrDDOFICZ4HpIlxHPGLEOD/8TKDI64fMVEY+ibaymO71NEy+N/g3XJQBKCBKS4MYQuQqXjnYNteGW+vKTHOPW7RqlVn"
    "L1q0qGFGfSgcyeeVVlprktLVWhHpVDLR2ta2b9+Bzs6Ojs7O7u7uofhQLpsdWWBMIMJlF1+SSide27rlE5/4JAD09/crpaGYS9r0"
    "yuarP3z1b+/4dTab+Mff/zH6oQPBQCQSLSuN1dXWNjRMr29oaKivrayqikRMzYBxFgpFFixcduLKNe99H3V1du7dt/e1rds3bX6t"
    "pSnOQtWl9ctC0WpE8DxHgUYgRlqigcfECYWJ5WEmKZ8YpyakWAk+5tIwXvnHGBsyuUsy2kpMGtdpAUdTkTDRF0/y9/+THT/FbVCs"
    "CCciUpwZhmEyI5eO9+zfkh/YXxNlb1mx5LxzL1914gnRWHk6k8nlc0qD47gI3HWdgwc7t27dunXbtv3793d0dqSTqTHXZ5xzwW3T"
    "YMLK5JXMJd761re++uqrg4NDs2fPBoBEIiGEQE9xzpGJ7a+/HrCtumk17R1dgUA4GAo6jiulKzXkHJ3L9vX2dO/Zs8e/uGmaVVVV"
    "M2fOnDdn7tIli2fOnBUtiQCRJIqVV542re78C8/LpHO7X9+xbv1zG155sWWvCpTPjNUuMEIxRa70FGq/HuHYvdYjjvbUz77RZUN+"
    "JeeYpM2Y7XREz3yqQfD/kzj9kYJjHzXUvpePTFgBSys33tmY7NwVYc7apXPf9omPrz3ltFhVuZd3M6l0JptlDAO23dHVsWnTq6+8"
    "/Orexn2dnZ1KeqOuykzTsP1XwIpEwpFIhDPDNkRze3+iua+mJrRixYrrr79WKVVbWyuldBzHsq1MNs85F8JMJxN79+45/vgT2rue"
    "IzM6vb4qWhJRUkmt8rlsJpNJZzJ5N+/k83nHdV2vvb29vb39hRdeAIBQScmcmTNWn3ji6pNWz5u/IBwJ5TNZcmDJkhOXrVjV19+z"
    "/bVXn3l+w6btT2QoVFK3MFwxg6HhunkiYHiIH/gvcz/+SQDj4XV5R9gAUw8xR5uVceGgSc6Jf/Y4Tr1sH8GHgBVnQcPkKhvvOrDR"
    "69+3aHb9+e9/21lnnVU/fYbrSc/z3ExOCOE6+a3bX9+w4eXXtmxvam70HLd4IWHZdjAYKAmXBEJB0zSRARFpBZ5UeQeT+bzjpvJK"
    "SYiCck4//bxgMPjiixtisVhdXV0ul3M9D5EVaQwaAF7fvuP00099+O8vQKRyV0fa7ssaqAWibZoGD5SXhkzTYAw96XhuPpdz05ls"
    "JpfNOblMIrF92/bt27bf8dvfVVVXrVi+7OS1a9ectLZ2WiCVTGupV64++cxzzutqb3vu+efXPf3cvg0vBqoXV8xYBGbEc1wADwEI"
    "OdKbsAfGXR4T4fETndlHDNPH8ncKqa3RlMLJ7xIAmfhnb+7J1ab+TwyERA8N28ZILtXRvnObkWs+c83xl97wjWXLV+SzGQLI5/MB"
    "286kU6+8svHZZ555aePGro7OkTPDNCLhcHl5aWlJqWlbCKA9lci5/Vknn1U5DzwypObEBHIThdCMLLSB8m9961tb29oOHjw4Z86c"
    "ioqKbDbnOI5v8Tnz5Q9hz97GD33g/aGSYF5pHax2tELtgVToaAKJ2jXQs7gOWcy2zFAkVF1WYRjM8WTOcQfiA0PxeC7j9Pb0rlu3"
    "ft269bHyypNOPP60009bvnx5MBTMZXOhSOyyK6686qp3bX711Xvu/9vmTfea5fMqZh9vmNG86wK5CIzeJIrkMR9/x0qrZoBHbTrE"
    "RCf3MdzE4WHH0SaJ/3mlqMUJIcaNgGHlBrvaDrwUxqErzjzl8quumb9ocT7rZlMpS6AGtnPnznXr1j39zNOdw+seDcsySkujFZXl"
    "ZaXlhjBdxxmMp9p6+lNZnVe25gyNkDYsCFqIJlIetUsApBXTSrtpYdJpp5328suvuK5bXl5uGEZvb28mk0EEIkLGOOfIeFPTASfv"
    "Lpg7bcveIRELgVaAHAzhR8qE6IB2lE56GnIOk3kTdMCkkAUVZcGFC+ZnsvlsJptIJofiQ9lsNj7Q9/gTTzz+xBN1dQ1nnXX6eeee"
    "s2DBfMaMbC6/Zu1Zp552zrbXtjz4t/998sW/stD08rmrhBmVbk6TngjiPCpHZZIAYOqh2phw9lDAFGGUZusIj4jGSiAd7rmM4wJN"
    "dGCPW6A4ldX/xj2/SUSKpuSwFXTFGKFDhIIZwg5mhzq7Gl8qs3MfuuScd11yWWXdtFQymxgciEZL4p7z9yce/9+H/75j167iCFt2"
    "QESjofLSsmhJCQqeTjr7Dw4kcyorueYWigoWMIgzhgBADDSQh+QBARFDIiQJnHvZ+KL582fOnPmTn/wUEUtLSw3DGBoachyHMUak"
    "iDQiMsZdJ9fe0XHCcUu3bHkYS6cpJGACqCjOS8QIAQwQjAyLAFwiV8qhbL49mTPbMkGhSyN2ZWVVTXVlJpOJxxOJVCqTyXZ0tN19"
    "9z1/uve+1atXX3rxRWtPXiNJDvQl62fMuunL11+xr/H++x966qWHKFxfNXclExHPzXNSvlHSwGAKEj1Hu8qPIX4dvcC0f0vDYofF"
    "X9CP72iyFNM/MQj+t/J2fL05DYooaNrCy/W3vbq+HAc+fuWF77z40lhZeSaTyWaydsDYu+fAX//283VPPjXY31MYF0OUl5VOq62N"
    "REsyOTeezO1vTSRd8DAERhkETMZQgIZimWNRC7CQ2yQg8lUftGLcUJmB09ae73py06ZNQohYLMYYU4WXBiDSahj32Ltv//Kly0A/"
    "wIA0Q0DQjAMAaV2caQJQSAQIBIQCmQgABD3QceUlE177QNoSMhY0y8vrptfzTDbT09s9OBj3PLnhpZc2vPTS7Fkzzz///PPPP6+m"
    "pmookaqprb/xy9e/p3H37+6579mNfwlULyibeaIES3p5BMZA/5smC/CwzNlYDbqpoUDjqrVN3S2ZYg3XMcf1R0W+P+TOAQhA2Kbw"
    "8l07NkGq6UPvPOs/PvjhaEXdUE9HOpUqjZVuf33nXXfdtf6pp1zXAWAo7HDIbqifVlNVQwS9Q6mdTQOJnFbCRqOUQjYiA9JIHmiu"
    "GSvQaX1GGgARMFYcCiIC0sgZApBz1hmnN+1vam5utiwrHA53d3cnEgnODSFMIuZDpgyZBtizZ9d5Z55lRWzpOWhaVNTK9HfIqNnh"
    "AISF/VBMbAmDGCoLszqfzeZ6UsmAQeVRu376rOnTaWgo3tvbl8mkDzQf/OXtv7rvvgcuuOD8K664oqG+IT6YLCmd9pXrbrp019bf"
    "3333po0PlM48Llo3P+ciSg8Y/xcgNpOnpIb5l8dQRDZJICr+3zr4EYAhEIDWoBgP2oL6Dm7LdL72ttNXffjD10yftyAxOOgkB6Ml"
    "sc2bX7333vuefvo5rSUA55yVRCMNDQ1VVdWOZAc6412DOQcsNMshYgEqIs1AkdYEQMABeSHA8ekFHKm4DomISBc2IOfkedwwVq1a"
    "+dSzz6fTadu2KyoqPM/r6uqigreKo32MAweaw5FQfXV500CWWwEkQmCF6g3GCACR+UuOtO8G+HA+giLUhKAAgIRAEdEQSZFKJTId"
    "A4nSIFSVlywoL0vGh3p6epKp9FA8/qd77/vfh/9+wfnnvetdl9TU1vXH+xtmz/ned7/z8ksv3P67Px14ZW/1gpPNSI3nZBG0QgNH"
    "KfT/n0CcU0B2xnecJtoD4tDQ4VgW/Ruh6Ixp7vBG9h4RAErkRMSADNuM5hPN+3euXzG76rM/vPWktSuHBuKpwaFoOPz6jtfv+N1v"
    "n37qKdIEAMK0G2oq66bXE7MH4vlXd/enHFRWBMNlAhX5uGahrQIOJ46IFOriyDIUAqKGMZj2CDgUNgAHIGQoE4kZ02pnzp6z6fs/"
    "cF23pKTEtm2tdTqdTqdTSrmMFeqYCTQA7+7qzrjphfNnNz29h5VXk+sC4/6y9rnttkBbGCnH0/6k+qUIgmsGBEh+rQwVlioDzuwS"
    "Bdjv5gbb0rZwKiL2gnkLtXJbO7sHB+OZTPovDz30j8cevfDCC9591VXlFeWJZHL5CSf9eMUJf3/4r/fc//BAcNa0hadIsJiTB4YE"
    "RxZBOxYJ+Anec3gmeGJkhSaPwke7NsP/xI55s46R/ThiJmHq9mvytx1e+lT8hRiA1ozxQFBg184nM/se/+qnP/iH39+5aMmirq7u"
    "aGksnkrc/I2b3/+BDzz15HoiEoZR39Bw6ilrFixe1peALY39ezvlECvR0VJmCSSHtIZilT3nfMwjFL4XUYMOGHzxrOmjvOVCMMCB"
    "IDWwdMk8LsSOHTtt27YsS2udSqVyuRwAuK7HGEeGnHMAQMZcz+kfGFi4cBE4KaZHprZIZNNBy5heUw5KFZhnCEQkgKEmAGCcIRvR"
    "mCFgyj9mzDCFqrK8smUIXz84FM/i/Fmzly9ZUFlVwwwrl3MefPCvH/7Pj97x6zuUUojk5Nz3XvWh3/78x6fPtVs3/CmX6GThqAYG"
    "R1/0eDj2f0QNoklW4OGzP/mXTn5xMcX7nojBN5XWEv8KAgQQgdYgLNvODzQf2PXMGSctuu5Ld02f2dDX1xMIBIGzX/zyF3f+4a5k"
    "IuGTFOqm1c6eO88QwZb23pbBARdC3C5lNhEhKZ8wRqNKX7T0PGFaPnmz6OVrQuSIRJjKy5d27kXOD7FIfjMemVp10vGJRLKjoyMQ"
    "CASDQSnlwMBAOp1uampKJBJaa9M0tVKMcSJNAAebDy5atAhQklSaiECPaO0zlsx5u1q6iXMgQIZISKRLLCtFmFOKEY4ugtKAhb5A"
    "oAA0cMHDZXnQ+4ZSbf0dNbHArJmzZjTUtrR2DA4OJZOp3/3+D+vWrfvgBz94wQVvyXnZcKz0a9/45hlPr7/jN3d3dzXVLVzralNJ"
    "j6P2Wyj9fzujjh1zbnUipaGJ5LDHeD7+DxIgARvVbeHwgu4pLH+lQTFuGqboen291/L817/86f/5nx8HI+FEMllRXbNu/VMfeP8H"
    "b/vJbclEAjmvqa465ZSTFi1a2tmXf2F76/5B5dmlPBgkZD5x2G/SMGLilKoIGsfPnUaO44+Yf1eMESELmszQBJ6rimcjEQFjjGkO"
    "ABoAnOXHHd/a1pZIxIUQlmVVVpYfbG56+qn13/72Lb/97W+rqqv7+vs4I8Mo4Kk7Xt/dUF8bjJrSyxECIwRgiIwhJwVaAwGSVkSK"
    "tAIUWurqWMgUliZUiITg2ysiQtBACkihHzwAEiEjLuyoF6huTRk7D/QlEnLunHnLli8sKy1FJto7Or/5rVu+8MUvdXR0RqMlvb19"
    "a04+5Y5f/fTC48taNtzvpfuFZeuRvioTluRP7gJM0m5nknk/fGn5i2fMz+SXGn0PPDbnZDgcTZrYsRu/m9phGe/JpWdHZODfWBbQ"
    "BzpRoQhEvHRn28YHzlhR/9Mf/WD58hN6e3tisZK2tvavfOUrv7r9V4l4ApDFYtFVJxw/c/rsjp6h15r6+xxbB8vQsEBr0qrQnsSH"
    "kxmOGUVP6XTeQ8YLMQAy5EITzqmK5LOZnAJExnCkZ05hmJSn0z1fv/mmffv333fvvaZpzp07NxqJPPvsMzff/LVzzj6nrbXtvHPP"
    "3bN7d/PB5pKSWC6f11oFAsG3vvWCxx9/IpEXaNkIbHSXGMbQp/H5jp8wMGLjBy87P5PP9vYNAiIBO3wUR2vvFSYQDbAi2rAH0u7A"
    "wGDADsyZUx8KBtLZrFKyo73jH48+KqVctXKlIbjnyfMvuLChtmTj4/fFE+lYzVyPGJHiIMdkjt+gJPURr1AsQx29Bo4104ww2QYY"
    "I1c47m4+vDL4iGWjOKq5Dk58NkxSOTHyftSI3AhFBva9mG957rovfOzzn/tCznW08iLRknvuuef6667bu7cRGJqmuXDhohNWLE9k"
    "9eY9vZ0pVIFyJgwiDUA+mjkcF/n8nJHHQXQ0pbIOCgHDWVKtGANO8pLTV3T39Q9lNSLDkb5aftTMZD5dYcuv/fdXH3/yieeefS4S"
    "icSH4ozhL395+5w5c7q7uvbtafRc953vvGgoPrR161bGhVbKMI23XviWV155pbM3w0NR0niok4nDRhcIgpZx6vLFN/7XhxChqfFA"
    "MptXIHzTMxGiTQwJOAFDUASAhiV5YCjupZLZ6opYQ8M0IshkMq7rbt68eePLGxfMnzdnzpye7u7Zs2eddfYpB7Zv3LFlY9m06cwI"
    "kxzR9R2zGI4q8T91GP2NbICx6xOBl849ZbgbxyTGYsziG1cIf+och2KIeHRYwehOl77+CJm2wXXLpofmlro//fH31p58ald3T3l5"
    "eVtb63XXX3///fe7nmKM102rXnnCiYFg2ZZdLY3dWc8uZXYIABAUB43IADhqWcCFfTIVEQxrChBxX0ZYE8KIo1NiW6esmPW16z+J"
    "HFpaBlLp3MhRSKRBcyZ0vH/uzOrPfOZTd915V3Nz08DAwMknr/39738TCgXT6SQAO9Dc7LiuJn3eeefncrlt27YyxjzXffvb39HS"
    "2rpn90EWrSStsMAVGoZdCYpT5oHZuL+1rbPrb48+tb+9j7jh5wdGgxPFgNhP6nIT0CKlGAdwCz26kDHTzpHo6R10svmG+mlVlWWZ"
    "TNr1ZH9f3yMPPxJPJE884USlFDB+8UVvC4rsM48+Ytgxs7RSeh4vtN06OubLRG1Sj1AyVux1h6NO7cnLaw/3q7E4oDw255Rh1sAR"
    "N9NRbdkjukDH3IwIiQiIB0M6NdS64Y/vecfa737/B3YgmIwnKioq/vdvf7vmmuuaDxxAxsPhyMrjV8yYOW9/S9/25sEMi7JAmACA"
    "VMFTYf5mAuRccKZJ+Q782BkqlJiPSvcydDW1tLRnkrlHn9vS2htXpEa5HpoADcbUQMfatSuuvOLyn//8F1u3br3kkovvvvvuXDbr"
    "unkuBClqa2v3vyCZTK5etbq7q+tAc7OU8rzzzsvlsq9s2MrLqkGPWRNjDggFhsgk80OpvMvN4ah0HF/U95yUrIpFptdW9fT3A+f+"
    "xZgPpjIGZjTlUH9/vy34vFkzOGepdEZpveP11zds2LBk8aJ5c+ek0pnTTz/rhKWznvr7n5JD2Vj1dE8RFnvhvXEs5BgWxhHP7on+"
    "yEtmn1ywI3RkCHKSPTpFfLPwCyuaEcBjuRSRFYwkWnekGh/+9n9/6RMf+/RAf7dlWcD4zV//5u233+66ErloqK9fufLEnIev7uzo"
    "zgoIlZIwR5a0TyFB5IwjaDXUq/rauRVEIwCgCxgOG/aFhg9gNtwIUSMnNIcGMm2DKUd5UOwPXRglzQUnNdj6lgvPuPAtF15zzXXH"
    "HbfinnvuVloDkU+FIA1dXd1KFRLJAwMDhmFo0u3t7atWrwrZ5tPPbeKxKtDkT8zhsrtExAA0SKXBkagRCDj5FJDxok8iIiTXk0PJ"
    "jMRCtTAAEDAChoxp4MhN4vZA3E2n0tNqy6ZV1aTTac/zBgYGnli3LlZScsopp/T299dUlZ9x6kmvv/LMgX27S+tmS0AcT3FoEg2i"
    "cYXBYeJDfaKzfNzI84hlwf638tLZJyMCFtYkHi1B7xjSezjK0kzU4nMsmwoRiRCIEWnkZijY/vqT1dT8q5/9bO2pp3V2dVZVVW/d"
    "tvXTn/nsKy+/jNywLfv45ctnzJq+u6l7R3taWjG0wpq0IMWIEBQDIGEKzsHJy64DmB869+TFn/zou1/Z+EJec+QBIBrOzh7WrxzQ"
    "3wdEQORI11MeALHR5ERABGQIKt7y7qsunz171l//+rf77/tTe3t7rKRECFHAlzR0dXW5rut/yjTNXbt2LV22tKuzMxKJ1E9veGLd"
    "syxaqQ/RHh9DiABE4R9fmoCwYISwuMVHrRjQgAZDAi619hTRSKSP5K+AQrkwETI0Q3nF+nv7Lc4WLZitmU4m0lrT88+/0NbWvnrN"
    "asdRSvMLLzwn0X1gw0svxGpmommD9IpYwlEHAJPXvo4biMLRUErHfgQREHhs9slH69K8Cf2nJkaBJowcEBUgcGEa1Pzyw2curfj1"
    "r35RWl6WSMSrqqvvvPvu6667YaB/EBhWV5SdtHqlAuPVHd290sBACRECKERgyAkYMc4NQ+ZTurupxMxdfsnZX//Kly699JLlxy0J"
    "mPjMI4/ZFXVSKmR+eDBM8mHDfLWR9YegiulsKkA0rLgBNDLU8baPfuRqw7ROO/WUQMCODw1NmzaNqKCppRS1t7V7njdsVzs7O4fi"
    "Q2edfbZtB6pqqh99fB3Z5TRcNFPEqYjAJ5D6yBMC8ykaOBzKF97MRtY4EhErDZhKgyJ9yJsLHBIGo8wjgUYh0Iz2JbOZdHbRzFnl"
    "FbG+gUEi3LNn99NPPbNgwfzaabX9A4kLzjunqoQ98ciDgWgVD1dp6TE8crvZqauhvXH2zTgangCAoImOZQPAkfrSTZ2xgVPLBCOQ"
    "AmQGNzDX9MKD77vwhB/88HuuqxDRMIybbvrv22//le/IL5o/77jly/e3DWw/OOia05htkpL+uuRImjgg07mk6mueWWV86qPvu/kr"
    "16xZc2Jf/1DzwYP7m/ZdcP65r23d0nqwk4djWit/A4zTuWz0IAyvxUOlyf136VTvf7zvypUrVykpW1oOxmKx8vJyP4rVWgNBS0tr"
    "LpdljAEB57yzqzORSADAqlWrSamnn34qjxEUZtHQF8aMMcYYaq0L4cjw3mCIh7JfoNCTBhnjoNSC+grP87KuHANq+87eKE8JADgw"
    "1KDRCGVc1t3ZW14WnD17ZiqZyjtuIjH05JNPlpaWrlq9cmBo6LgVyxfMqVn3t4fICgWj5dL1jtx5emoS7ce8f46Io0CBKvKmsdBw"
    "qu2T8aivSwTcENyNt7705y9+9OIbv/a19t4B0zZz+fx//udH/vLgg5ybXPATjl/RMGPmhu0H9/Z4GKoBQ6JUDFhxUhEZ8OzAvHL5"
    "vW987q/3/f6id769tb1367ZdyWTaQAQS+w90fPOrN3JnELQCZMPMLwKtSWmtgRSS9p1dGol3xzsIEEkrbhq1tbWWaXV1dfHiq9gt"
    "hqRSnuf6/ZT8MhTTNC3LGhwcaG1rCwZDkVAAZN4nwxUKAhCRceXmVTbLuKWBE/jUI/JzwsMA0SFnJGlPg85kaytLpJLkESAbPvDH"
    "sFqGd69vx5iWzLaykbItTfH2joEVK45rqK9DRCX1j370ozt+/avSsrLOnsTy5at/8t3r7IFXB1q2iYBNmhjBv584/cSZ4MN7BB2N"
    "RvSUNkBB/ne03Z10H3MkhqiBMytAmb7WDX+9+bqPffIzn+rp6q6Mle7bv+9dl1/xyqZXUdiRSOiUk082guHntx3sccIiFAUkBppw"
    "2BkATcg5eIPd77vyoksue9fWbTu3b92ey6WDwbBhGoqhZZhtrS2R8rKP/ueVsm2nYYe1nyUgApKopUDFuIlcqFxaZQYZeIRIQAxx"
    "WIS1eO4iMK6VF7bNsrJyJ5cDpQHAMIwxB4H2X6QVaQ0kDIMxJoSRTiWD4UgoHAaZ99MUWhNpybSEXOb4edVvOW0F5DOC+8XEhT0A"
    "oEGr0XyZ4lSy+ljwjJOXfPWaj139rrPn1YYDpknMKBqTEUNXBE8ZIjEEAIO4AA1IAqO1TUOwfXfbzJkzlyyZzzgT3Ljrrnu++Y1v"
    "hUNmPDFUXlX9yx/dUoPd/U2brGBYEvcLnd+ga324/vubiC+xib5sivLZxyDwO/J+OoSCehhUigBMAheWodI9fVsf//G3vnDZVVe1"
    "tbU3NDQ899xz73vP+1tbWoFhTUXs5LUn98flpt0DObOK2YHisCOMQnAQSGkCs+SVza93d3V7nmdZFmNMa805N4QBCAHb3rB528c+"
    "8sElC6d5iV7OGSiHMymMEBG68UG3vdHr3jW7ND8j4mB6CLgg5KOyMzia50pSRiLhcCTsOE4BO2VMj7wIEX2bwBiHIuXdf1s+n+eM"
    "BYNB0HrYmSHiGg3NMZFy+gaTxFATA+CAo6aj6KKNRn40AOPMtm1hWsGSMsMIMWJExdNrVJOLw8o/RlxW0oqFq/shvHl3hx0uW7x8"
    "EXLgXKxb98T111/PGGNMBIPBn3z/5gazv7tpoxm2NeFReTiTt1Wfuu7B1PMPTJP+92x8yQAUoWGZMt7Wv+Oxn/7wKxe8/aLuju7a"
    "mpo/3XvvJz/5yWQ6h8jnzJm54vgTGg907erIQLAGkWvS/qIskD1AD1dzaKUhVLJjdxNDMAyDMcbZSJ9MIQQXgmu3o6f3W7d8nQYP"
    "Cs60dLy+Nq/99ZDbsXZZ5ec+cfHvfvqN/73/7qv/491eMi44EySHGQpI2qdlF8QulQqFQoFAwHFcJZUPd45uIElaCyGEEJwzIUQB"
    "GyWNiK7rMsai0SiMKgRBRgB5ssSBnqEtu1rBsgvYKx2J+UjUOph+/KnNX/7mz2+78+FdbX051wX0EEAX7+dwhuY4PRBknluBfKB6"
    "+76E44lly5fZpoWI27Ztu+aLX0zEExJEIuN87aZr5gT7ene/YARCPmEbj2l1/iuWGTIGDMe0WDr6m9DFn0kN0DBdaSQbN/bJfQeW"
    "+WlLy84PtfXvfvr2H918xhlndHX3VldX3v6r33zlyzdp4ozx5cuXzZ23aPOu9v19CoJRxVyGwP0aEQDOuXackxZPn1FZQV5hgnnI"
    "aO/o7e3tLi2LMUYGZxwISfsrAZFHIpGDB1vmzJv9/vdd5Ox7dlrQufSCVT+69Ut/vvPnt37rq2eceWYm7x1o65Bagmbgex5EgEhK"
    "nTB3WoAbWiOQZkgg80HbsO2AVFJp5XkekX+sFn8YEShkhAigCAlIawKJTEmVB1LRSASUHAHuAJAQJTFh8ICNSvl1AoAMkfs/AKzI"
    "5ytYHQCGwATjIhrpGswYRMzihITFcqhDumYg+U04AMfrAMJQa9AolF2xtz09kHROOP7EsvJyZPxAc/OnP/PZ/U1Ntm0rYD/+3rcX"
    "V8quvS9YQVsRsfHatEzUIHWiPl+jTccb78vk17L+2wlj+SCfx7gwhRdvG9rx+K9+/M1Vp5ze19tdVV31ox/9zy9/ebswTNKwasWK"
    "SGVow2tNSVXGIrYi6csEDMd/Sik0jC2NHUpzMBBAAyAXpitp9979Z5x+cjKZ8ENSrTUgAfikfLKtwOZXX/v4Rz584rLFx5+4kgvR"
    "09vT2dOTTCScvIeApmEUEoeMFTq+AxBju/Z3uooB88CXnJFeSTTKOXfyju/eGMZYOe7hOdWkGWMMGREy5H7KKxCwRreOpAIDuVBH"
    "hoVKxUM00IeZAodCVaS0JqSDvb1O3vEZEuPXTxEwLPLLDzuR/bCWAWouMVzbMhD3vP4lSxbv2L1jsHeov3/g2muv/frXv75k6VLP"
    "y3//lps++8UvNx/YUjpnjcok/92D4KMlIb+RyGOigNtPMAGAEByyvQM71/3kB1876eQ1vT2d5VWVt9z67V/+8nZhBADgpDUnBkpK"
    "XnitM6VjwgoguYwhAh87Y4iO0pI8IKVJMwJNDKzQhlc2hwK2J5UaccgLcnxEoAmTidSevU2z5y/evXvXSxs3tbW153M50zRDoZAQ"
    "QmlNhQAGR5pSIktrlKCGufugKRQKAYDrOgyZ7+343zU8LJxzPwz1tyIgkEatUXCTc8E5B63H0hnGYgcj/jFjjEgXAaNRRywikGbE"
    "HEdJjcXQCw93r5E0Z8zTXErUyEcfvSO5JIYIAlCxULQ7ae3e37No/sKamhoASCaTN954Y+OevXYwkkhnv/X1G6bxnvj+jYYdnGKf"
    "Mpi41y9MoPIwpin1VKl4UOwUOfoPU/TMpt7YbHyxbCq4ycNUCCIE4AUPQZjopto2P/b9b1xzymmnd3b3VVVWfetb3/7D7+7khiEE"
    "nX7qSQxDG3a0u0YZ2kECz7+kBtAatNLgS9f6gAYVEVBgGkhJheGKLdt3OK5rCK619l1zzpgPznuedB2PMZFMJA4eaCRSoYAwDAFA"
    "nucRaA1SawmogRRpomK7rkLaCRmCQYQEDJQXDIUAQBNxwTlnhiEMQwjkoEFJnc3m8vm863paawKwLCsYCGqtEMmTrtSeJQwAd9Qq"
    "94V0OQA/dAMQgCZk0nUABIHSWhbdSSLSRBqJQCulJJEG0kQKoHDaU6G4WXPwOHAnnpiuWpeHU8JNkqsZGoQAjIAV6D4qnwECIEWk"
    "eDDa71h7mwcWzJ9XV18HyDK53DXXXrN9xw4mrJyrv/HVa0tlZ6Jjl2nZqEeKjI6hoGwMt2/cznRTz9LSuBbgX/qi0XtXAUoAACYY"
    "c9o2/fVr1370/AsuHOjrraqsuPXW79z5+z9wQxicn3LKKY62X9nVIc0o40yT0sg0MNKaoeYcGeeq0PqJAEBpX08EC7g2kBGMdvYO"
    "dHb1RMNRz3NHWJ/+ulBSSkmgTdPghqGBUYEd7WsTyEwmk8lmTMsseD6kik+BDBELvqlfg+UGgjYASE/6YE86nWptbYkPxZOJVHIo"
    "kc/lA8FgKBQK2DZDlsvlcrmcVpIxdF3HdV3TMEFLKKS4kLGJ4GYiAgO8xTMqBdMjmf4RaIqItJ9BLmwYIgQ9TDDhoACRuKXT/V9+"
    "9/IXf3rVYxd3P3pZrt4aIi/PSYLW6KvGg1oxZ5oASRoQUJEUwdiQa+/Y2zlr1qy6adWgdS6Xv+GGG9paW0wrYFqB733jBmNoV6a/"
    "WdvRQhHzPy1DcLT7agT8wkk7TI1Lw5hS4cJR3DcCMGGoppf++qWPXPn+d1/Z2dFZU1Pzs5/97He/+z03hGEYp552at4RL+/slaFy"
    "zU3PF7JERCCDI+Tjsmu36m8WHAEZEBQTnGxU1gIAObps8+ZtpbFYLpvzV3/BYmgNCEIwxtDH6AFAcK6UymQySqny8orjjjt+0cKF"
    "+ZwDwgL0j1IAIH91FoUeCEABKc7Z8PmVy+eTyUQgYIdCoXA4VFZeWltba5omARFAIGAHAgEuuGXbUiqtCl9dyLONOuxgmAR/6DSZ"
    "DM5es9TGHCo5Wh+n4BT58FTRg2IICMRAIYImkh4piSqZuXRB/Js3XGXa0VzWO70+9/VTHEr3SzA5gPBTIoDJdHYEyGAoQUOgZEgG"
    "9+zrrp85s6amRmudSCRu+spN8aFBQBaIhG7+8meyLRsh082F0EdI/0ywUkc1P58iNH842W5MtDlivt/cSOCoMwMACASa2wG7eevj"
    "H7jo1A9/5GMtbR3V1dW/uuM3t/3sF8KwTGGcceqabJ5e3dsFgRJiXBMvVoQpLkxvsLuSZf5850/fc/EZ8uBmofOMM60kgK8UQgwI"
    "gRhycrIqP9A70B+KRjVo5AwYak1KSq0lAjEG/jmuFOSy+Xw+H41Gly5detJJq6OR0PZtWz7/uc//5LZfm7ES6UkfciImPNeV0iPG"
    "fB8DiAB0IGADgFKKITLC+vrpFZXVPgJLGogUIiipXcfLZXOMMdMwPc8l0ul0SikNnBe90xGjqRGkdpTny/X4Byowhjktbrvn0aTL"
    "iZlU9Jm4JgDTP+k4aY7ksy6Ux2VSekmH55OVIrewNLe2Ir4gNHDJXDt5x+e9p35qh+zuPm9JeaYhnCtjOS+v3TwJItK6uTuuiBVN"
    "DCFqDZoFo4MysKe5d+bc2TXVVch5b1/vl2+83vW8TF7Wz5j95c9/pG/HY6BcxILIxZtiB95gq0mBNM6NHB21cwKa61Fch7TSLBAO"
    "tu1Zf9bCaddd98WO7raqqqp777//u9/5LnKGSGecfrLjsU27uiBY6iuiMV8AR5EwLbd3/4LpJX/47a/z+dyXvvBfxy9bdNPXv+da"
    "VWZpredpYooINQrTFE5/u+n03fTVGy659KK9u/cGQiHw87hSa+3jMEikpefmcrlAMDR//tzyitKuru7H/vHoU08/u7uxVebTAAIC"
    "pUZIkNIcGSDXTv64hbMSyczBjh4QvjnjQFRSEtVa5fN5ImLItCalNDDUUmvSMu+5jlMwSwwQ0bRMraT0KGCbWmkmhI/9+BFgAbiR"
    "ujISKo2E9nf0guBUjMUBNA9ElPQAFAACaQJUDAydI0YamOdw8CSQjAVwbmV+ZoVqiOiSgAGgh1LeQMpLpby8sEkn84IbRJx7eRkk"
    "4m+vTdWV5DZ0R59pU8KIoBHU4CATSmtE5MQISJHGYCSZh6bmvvmzZ0ny+vsHW1vbv3rTV2+55ZbEUPL4lSd+/AMX/eKPTzeccL7r"
    "+SfMyPoYV/vkcGD0cL3RqeTUJjnKxeQf1lpPogcxdenqI6QHSJt2YLBtxzTe+42bfzMwEC8rLXv22We/8fVvMMERce3aVY7iL+7o"
    "ksFKzkADIWgEpUgETCvXvX/1itrf//aXjfvbe7o6LNteddKaP915+7Vf/sa+5sZg/fys0gy0wbTTuvvE5dO/efP3yspKt23Z5lf2"
    "KqUOqegHkFKVREuWLl3CDdz40st//suDr7y6GZQCMMAIsUjYMgOeJzQayDiQ8uOHgf7efE4hY8QIdeHMNk0DkRFJraVlWbZtA4Aw"
    "zUiJnc85qXQCgWzLQmS5XE5KKT0PAIQwPM/TWvuOkI8NjPA8CTiBYIU1DqNWhtZyGMxAAMZAAXPyJijJRW5eibNiGi2o4hHLTeT1"
    "gX7+/H5oScKgayiHA4+B9u7Z4b5zMa9LZDOgQ9GS7z/J2jKBOw/iQg7vW55563R2ywu5DFjaEIdo4WhAAFKaW5GBjN7X0rNwwfyd"
    "zp5kMr1z587v3HrrTTd9dXBg8OKL3tlysOPRzc9MX3ZePuf4Ml9jsJ3D98DhAMwkzcjGXYETHceIR+oTfMy9eI8G95dC2G66y+3Y"
    "9INf/EALbnK+f//+66673ufkn3Di8Xaw7KXXmrUZAwbKL+sDAmLCDOTadp53+uLbfvbjXbv29Pf1B4NBRGhs3FdZXf3HO2//znd+"
    "+OeHnrIa5nq5tJvo+uKnr/7gh967d9++g691WIGAojzJQgTMEIEgnU6XlZUdt2JFOp1+8MGH7nvggd7ubgAENICLUChYUVYejpQ4"
    "yuxOuHnDKs6VIsNq600CY2BYzO8RjwwIBOeIqEn7mWbGmOCis6trYKBfKZXNZlrbOjgzDNMIBUOMYS6Xk1L5J7rWWhXqWorQpyZA"
    "TQbvTqe64yk0bShkP/xViEgCQAnUgNxzuXLzgNmFMXHazOz8eoGa9nSoR3d4+/sx6YSBMRAGmCYX0mQSUGoRfLJVXnwPv3yxWYL0"
    "VIu4c49rhEII7h4v/JVn+r94Ov7y7c4HH80oHiD0CijisCYe05JQhEr60spqG1q6fNnm17Y5uexLGzb87ve//eQnPtHZ3fORj36g"
    "7b9vOdC8s2zmUtfJHjPePrme51G4QJMwrSdpg/OmdL4AAEaoODByu3c88f2vfX7ajBnpdDoP6nNf+GIimUJuHLdscW1N3XObD+R4"
    "FIXAgvIhEDFugNvVePHbTvrurV/ftHmLkjISDXmeBMBgMDA0NJBOJ7/81RuWLF329Vt+WF1d+dN7bp+/YOGLL20g0HbQktJFQGSF"
    "MqtsJltSUrJixYpsJvXT237ylwf/mk2nATkACmHW1U+bPmOOaYV6BtIdg9mEhySiDBBBEwrQCkgy0/IdDwBQhYQGAjEAEMJGrhSQ"
    "1joSLbnjG9/8/ve/PzwIgUAwl8/+901fPv30MwBJE0ilAbltWcIQAFTInUNBAwuUZMxAC7UPECFHkFojABNcSsm8jACVn1WWOXNB"
    "7rhaAcA2dfHbn9cHEpbWNnANJuMBQuBEHEiRVhK5ZohKcjP0XBs+1yQBCYRgoZhHBGRww6Oy0h+8NLjlavaBpbnbt6MZFpqAiFRh"
    "wSABAoIk4qGytvhA0E6tWDJ/y7ZdgPz++x+YMWPG2WeflUylrv3iZz5//S2ZoRIrWq89B7n/WDiJERiHz3w0uPzh8rXDcYM44tF+"
    "VBU3Uw9cisR6ZZvhplf/9okrzzvr7PM6OztisdjnPv+5loMtwHDWzOnT5zRs3NKUgDDaJmhkRbeRc+EOdV1w+sLbfnLrPx5/xuA8"
    "EAgQUSGzS9pPOW3csPHss05ZsGhebXUV5+LFF1+0LIuxQmtaqZRhGETkuu6SJUsikchdd935hzvvyqTTXJgAYAXMZUuXNdRNT+ew"
    "sbW/I94vicAwmMFA65EMwEh+HkdJc4/8E2N8WKjHc53TTz89k8kQUVlZ2SuvvLJ+/fqAZZeXV/r8vCJHBU3TKkqYjCmR00VR6oI+"
    "hWbImVZZch0dCCXeupCdMRtDhrO9FX/9itw5aBOPghniYU+QBGkoVKR9hXHtk+GUkiACoD0ixYMmhKsJEBC1koh+iT1DRoDhvx/I"
    "XDY3d/tWpiFCmggZINNuHsxAkZeBqD2M1uzv6lnKacHC2a+/vksI46c/vW16w/S6huncFF/9woc+9/Xba5a/DVmQaYUg5ZvE+D98"
    "jY17ZBcG9k0Uxz2mj2ketHv2bT5rWeV/fuzTnZ2dtbW1P/zhD1968SUmeGlpyZIlC7dv7+3JWDwUQIk+Zju8JgwrtO9Ax8Hm9rJo"
    "1FNKKY0FLgRw5BpIax0Kh7fvbKytqeno7E2lU4FAwPM8n7fmRziDg4MNDQ0LFy5c99jj3/3e9/v6erkZAGCC8zPPOHfO3EVN7f1P"
    "v3YgnnLBtLlhM+6DPIDIio0YfAESNlKKNXKcjRBbOed+xiCbzZx33rnnn3++ZVmvv/76Aw88YBjmjTfeUFNTnUgkGGNCCM65/5FR"
    "GZtDeeK+bD9KAYSIngvayc+L5S891Vgzw2wZyP3tdffZFkvqCNjIQ4YBpCGtPAOQE9dEHAq3KX3e+Kz68vbeXB4MRFJ+tTQRI80Q"
    "i/LUBepHd9arsDyDSU8XZFBR5ufNqG4fyGTzEhkCouaC6zyFw7s64stnV86cOfNgc4ty1He++73/+dGPpZOZNXfJR6962+33rp++"
    "6m1ZF8T/HRuTTZRvmxwefYMgKUNkoLlh5uN9gXz7Ddd9MZXOTKub9thjj/3ud79jQgQDwTWrTmpvH2qJezwUI6UI9CiIF4k0RKJN"
    "bfEbbvrG0mULpNbIBAEBFmTEtVRaKiVVKGT39HanM0nDEH7HaSLSWkkpXdc98cQThRAf/9jHrrn22r7BOAAoN3fqqad+5rP/ZZdM"
    "+9OjL61/eVdcWxguQcPQIH2JNZ/pwEkCY0R+looVkqXACDlpRFIFNAZAkfaUVNKfZx0fHFJSbnh547nnnrtv375Pf+YTy49blkwm"
    "ldZKa8YEYwKAK0/6kiVcaS4V+NllQELiWgVYzkAu08xLJE+pTXz7wvx1Z5GXU9f82fvcX+31nVU6XCliAg1Tkc4jeMCBMy58egNH"
    "BGSkgREAoA7als+0I2SIPjZIowT7ilA18VCQc9JEEgmIGAEBUiAYMJAhMQROgKSRAIgLL1DS2NJdVzWtqrIaANvb237y05+Eg8HO"
    "rp63XviWU5bWdDe9ZtqGJv2mr+wjt9Ol/6NMsJ9kUsi50L27X7jhsx8IhyIEuq219Vvf+hYicqDVK1cOpdztbWkIV2jSh7C9ii/p"
    "eYG6mc8/u+nOPz44f96CRCIBRVmSEaqh1loryzIMg/tWnDHknGcy2UAgcO655z799NNXXnHlxg0bjUAYlLtw4fz/vum/Fy058Q9/"
    "febvz+9M8VJeUomMF0UWDknEKiaYk/C3AYwj/lUgtgKAD+/4kJpSKhgMtrS0vP/97+/t7f30pz518to1PT3dwjBGhBsAPM/L5XJF"
    "hiwpUqQlASFqE13PDOayhkoOXDgv+dv34EfX4Ev73Y//hf3wFXM/RKxYhNuMwFMaALXfNI4ASgPe6kUzlYfIiJHmBUOFCsT2pg4H"
    "gHFZTNMWffpRYIUGDkIcX656c1wqzoZBPBHYtvdg1tUhSwgkJB+u5UDATTvFw03tvUsWLQwGg0KYzz33zIN//WtJLNrT1/fxj30g"
    "5La7g52M2/9KgdFD6gEmecfkBWKTMFonNx3+jBrBYMeOZ684f9npZ50xEE9xRjfccEM8HieixUuWW3Z4y74eCpYjKQQNWJA8xlFs"
    "Rw7gKWZOX/zdW3/S0d7eML3OdT2lCtweNoroX0QSARAY45lMZvbs2fPmz/+vz372Gzd/nQsOANrNf+wjV3/8Y//1yPrXfv3Hx/py"
    "No9WMgCtfKWFsUaPcaYdfdUFp86dUadlob+L1rpYTDjirwOA9PvBKwUAhmF0dnW9+93v2d+4733/8b7TTj+96cABx3G11pZlCSGk"
    "lJ7nuq7jeq6SEgAJGTEE8EzIMuRuJhxIDL1rfvbP72HvWiR/92LqA3fRw43TVKRUhEMc0SNQmg7poIKIQImM2rJrPzFNoDiQIOAE"
    "AEyjwYwA0wqAEQocGbFD9Jw1QdRMrJlmbOgyAAyGBW1eIsVMmzxn4YyakIGo1bBoKGjFAiVdOdbZ07d48WKtNWP8nj/e09Laalgm"
    "8cBH3/e2vsbnDK6JcKJl9qZgRKPLvEavRjb6HybRpZj8X4/aBTKtdPfBGjv5yY9/bGAoMa2u4Te/+f3WrVsRed20+lmzZry6uyvP"
    "YowjQ8WKBd+EOKqcsqBFpritwtVf+MK1VeWlhmF4nqep0D0KGTtUqkkjUiadOumk1Urqyy65dP2T6+1w1M07S5Ys/vH/fB+Nyi/d"
    "fNvmve28soFxDjLPQLEROSAGxIcbUREBM8VTm/d29MfRp5EW/z6Kt1wMuUghaa09Kb1ItOzXd/x62/ZtAPCnP/7pqquuuu7aGz/z"
    "6c8daGq2TFsr0kprqaUrXdfzlAJgyIEzzlnQSZOXGHjrjI5fXuacOcf5/nP6ww+Zz3dXsvISEZGMtNKaiFPB9UKAUUXuRB6IjNQE"
    "ErS2TbFgVrVSLvjlED6SX0DltR/4jkrVMwM55Nwz6lWpUA/sNyAQ1prIb7RMhJqQ47bGAynH9cVWCFETakBSmgfLGrtzitjcOTNI"
    "Uy6fv+1nPwdkg4Px409cddaaRV2NG23bBNIE9KaEwodLsY/DJ52iPPo/g6+kQSX3vfStWz9HPBA24ZWXX/7d7+5EwQKmceKJK/a3"
    "dPenyYjYRJKQF/TMfM7KoUlrIq2VNkqqDra9ftNXv/nNb968bdtWH9hRBY7zKDhL67zjnHnmGS+88OKnP/1ppTXjZj6d/MhH/+OM"
    "s95+22//vHHjblZWyxiRdH3JYa1974Y050AE5CFxGJH3gs7BrC+lqCftzs3Az/5rpWQ+l165cuV73/tehsxxnVQqRURKqrLSslw2"
    "Jz3JELSSgFRU+ifgQmYIPHXR7OSFC8WA6/7oeb21pwTsiFXqSQ1ak0ZOvMBvKdL9D8m2AGNImnzVRICshMb2bmIIpP2HVYgIBIXa"
    "YiyWFSGgh8pSAg1S15yYe3yP3DFQboRNUC6SS0DATACQRH4npSIGgAWlLNBECIHYvtae4xZOHxpK9w0M7NvX+Oe/PPjuKy6LJ9Lv"
    "f/9/bLvmptxQB0YbhJfSzIB/ZjH9cLlIoYPWETPMk/Q0nqQP5oS4p9ZWMNyydd1Vbztp1cqTuwd6LcP41re+5fvHJ55w3GDK3dmW"
    "Y6EyrSRjvmYjFFUUxslLIKLnKbNh6eOPr1u6aP5Fl17StH+/aZq+v+Fj/MiYklIpdfrpp//+97///ve/b5g2KRWNhr5y4ze5ZX/m"
    "hu8PpZmomiaVh1QIo/1jnwiQoXYyfk3VcNFbgX/Pcdgm4DDNHvwwHXx6aXEBomEYiDgw0HfpJZe8+93vAQDHcZ5//nkAMA2zs6PD"
    "cRxPegQSGTMMFgwGDMME0JSTx8eGPnOqQGb+5kX1QmclBNCMWky6UqJinIEcfbiNA/8x9J0xQF/YXyspvSIBY5glWJBRKSpvFTOO"
    "jDNykqn3zk4sjGauvtehnK0srl0CALQt7vfjIF9epQAEF9cZ+LRENMy0DBxsG5w3f37i1U1Swt/++uDa1SdMb5gpDPPD73vn9371"
    "t4aV9QqM4aF74yrTk3B2hkvsxNHumzeU9NWam0a8t3VGKH31f36wu3+oqqri1lu/e/BgMyCbN3dOaWnt01taIFCqARloAlRaC2EA"
    "aE0SQTAqZJr8whG/DpMJQ0snGK1csnRpIh4HAKmkT0HzgwEtJQKedupp3/nOrXfffXcgGMxls3PnLfz2N27esHnHD2//PYTLjIip"
    "ZZ5zTvrQs5Ohzqbfdtaq5vb+3U2daJlFtBsQkMAA5QISEiMU4GsTAhENi2oVaYnFOCIaLXn8iXXPPfecECKbzXZ3dwshgOics8+u"
    "rKrUWjmOa1m2ECwQCBiGAGBRGLjqOPPBXYOP7ApDsJ6XEfPyWioPDUYuEgErBN3FqdIAAMwA7VIhnCWSGphAjqAlECF4DPzyxwLJ"
    "DkFjQSeVuDCU53mJIQAHSCnQ06tKP/K2Zfui0SVn83Drwd6+jtmLF+aycldjc86VAAxCIcMOKQ1Iihe0NEYVshExO9YVHygrcefM"
    "mb17917tyl/96te33PLt+ODgytWrT96wddv+jbF5p5OTRCAN7F8iqYJi3NZL42pqT7F58kQvH+oywRg88OL1138ImWnb6oWXNjzw"
    "wJ+Z4MFgYO68Oa83tqakxQNIpDQQaWII3lAXEDNiVUyg1ESKI0gipf1qa60NzDk9+27/5ffnzZvz+o5dgYCtpPJJBIhISiPiaaed"
    "+pWv3PTnPz8QDEWymdSpJ6+56cb//u2f/nbf/z7NKxtQu1orYgbSMId+VMAkjH3N7fGMQ8I/E5H8zhNODkSUIyqmOClfUdDHfgB1"
    "QfaxUKjF/Tp3rXU4Urp927Yf/OAHY8Zn2bIl1TVVnCMBagLBhWH4SreQNSNffSzrWNWi1Cad0ZJp9MMbpXztNxo1QQgEHDXpbBLt"
    "CIBE1NqT8+qrM3nZNZgAhn77ykMPONKgAAxhmCSzXldzICjWnLQoGjVXHr90zeq1s2fNyeUze3btOSG564NXvX3V6hPT2Vx//8CG"
    "lzY+/tijHoide/b3d7RDSY0RLlNa++fTcBtBJARACsYOtPctW1BTWVk20D+wt3Hfgw89dOmllw4OJd/77iu2ffUWL7UQrRCRZsN9"
    "L9/A8T8JoWgY0xPjAv8TReI4Vm4Sp54JJtJGMNi7d+u5q+aetPbkZDIdDAT+50c/UkohZ0sWLx4YzLYMeSxQ4pOEtQZumHrg4NIZ"
    "pbHS2IbN2z0ZhEilWRJEYFohMqVBWIzlDm77ype/cNzyxZs2vxYOh6SUuvhEWmtS+vTTT7/pppv+/OcHQuFoJp085/zzP/fJT/74"
    "Z7//x0u7RPVMJRUSDne+GBv6a42G1dg2CJwhYyN4rPTm1VV2x92sy9FzZ9VWKM87MJBmhkFAIyoDRVx2uNUpgA5HwkKIX//6jvPO"
    "O/eFF16Ix+OktWHwbDZrGKZpmn4KTCmltQIgD21VIgRpcD0t/Do+BFB+whgOc021VNPKglddeM5P7npEGhYiolLTaysGE6munn6w"
    "LTgs08+AGDO4QLevJWDRf37ksndccHZPb09tXd3KVau1lnv37t2w8eXNm7ZddvE7Lzj37GQm+/rrryJSIGiec+7ZH/nox1977bWn"
    "1z/5l4ef3NvcDLFa07KVdH20vaA7pIkhS5Pd0p2YO3dOIj6kNP7lL39ZuXJleXl5SWnsikve8tsHXphxwttynjRAER4ZGfU17SZy"
    "wieiVIyIveIbywRPmRFECMAZl9kMy+392NVfT6acaDTyhzvv2r+vCRBqa2si0bJXdrSDXc609Nn5CMTcbIg5v/jJraVl5S0tLc8+"
    "v+HJp1/Yumev9jiUVItgzLTsXMuOy6+69N1XXbb+mefC0VLSyo/BfGQmn8+fc9ZZt3z7lgceeCAYCmfSycsufdeHP/rhW374mxde"
    "ajKqqrV0GCKhKIA3h3Vq8nskMYMhMD2qRQVDCARMkXQ0aBCiYzABhMDYGP6sP0TSb4iNfkIg72cG+vp6Dx482N3dnclkKirK/biF"
    "ADjnQhhaK8fJu64HQFyDQlLAsNh0aYTPgoVK6EMzLZDMuY+/vBM4J62VJhYIrN+4E7iJgSBqj0ZrJvvLiBvgpN14+7suOvu/v3JD"
    "SUn0kUceWbZs+coTTuju6dm7p7G1ed9A78AHPvDe0046IZGMH2jt9Ml3WslNm7es3fn6ihXL8k6+blrt+qef37hlV2fHQatmloe8"
    "UNTv9/cjwkBJ9+BAXSmfM2ve7sY9SuXvvvvu66+/PhFPXHDu6c88s2Goe0+gdpHyJJvC8f+GtSGIwdRkSidqnzEFCS0GqDWBsO2u"
    "vRuufMsZNXXThcE7unruvvsexoVlGYsXL97fPphSNidDcdSAoIVhmF5n843Xfi4SjT7/0sZ8znvrBW+5/bYf3H/H/3z86nfOKwfZ"
    "tcfZv2nBnLKvf/W6jZu2WJatPUeNKgVOJ1Nnn3nWr++44+677rYDkWwm/f7/eM9nPvPZH/z0Dy9sahSVVZ50CRgiRwAiJFCERMSo"
    "kMwZeV4f8vOVZgsV59zcvr8r4Th+EiwjIatHHwqMEQJoXjBE4ClAMAAYEWitAODaa6899dRTP/e5z335y1/euOFl07D9el3GhFJa"
    "K8o7Lg476MiQ+fIpftm7AmC+CEpBdochDt8eYylH7djb6qFAZIicFLGAzQwfCBqO2n3eApnClMmhEj14zx0/uv9Pd+cy6Xvuvvvs"
    "M888Yfnynq7OA/v3HWxt3tPU3DCj4dS1q1OZXDyRGejvEwYTwjAMsywW6WhrLSuNhUOhwXhixXHLvvetGz9+9WVe/0FwUlxw36H3"
    "FYEBkaxIY9tAZW1tJBpGxM2bN7/66qvhklDWgcsuvSDR/jpH0OwIwopj8M1J2AkTuycEoMdR6ZgKtejoIl9AFMHMUGetGb/88ksH"
    "E6nKyrJbb701k84AY/PnLXFcs60/j6FSSQQMtSJumG68e+VJCy695PwXX3k1WhJLpZIDgwOGYcXKYu9//5X/8R/vbm5sevzJ9Vdc"
    "ecWBA81aKdMwhnFPxlgqlVqzZs2jjz764//5se/3X3HZFR/5yH/eetvv1r/UKMqrpJsHPEREn5OvDVTIexVrFWjEkzl0RIRtF74O"
    "WYGbxoZrL0eXYI4c2AWJaa0B4Dvf+fbSpcu2bt2Wz+erq6oSiUQwGPRVApTWyvMKHk6RhVBIhtCEXi8dorRH3LaG+wmQ30RzGJCC"
    "YrCgNbdMd6BzXn3oL3/867IlS59ct/6lDc9fculldXX1iUSir68/EU/09vYiwrnnnJ3P5xHZwMCAkpKQCEhrHQyGBgYGHccpLS2t"
    "b2h4fceOrdtfv/H6a049ee3nr/1qX9I1YjWeRwwLyTVhBpPpfFd/fNasWa9vfx0R77333uXLlyeTqUULF6+YV9PUtjMyY5l08uyw"
    "5Td5N4mJCKRjIoHiX2jCksipp9+m1vqYBQQONb387svfzoPhcCT60gsvPLluHSJGo5FZM2Y37u9WohSIMyChGSpE7bFc+43XfGrX"
    "3ibtKVCSCxEMBi3LTCaTO1/ftX/vgWhZ+Wc/+2nBRXtHp0+i9BVKhBC5XG7JkiVNTU3XXnttIBjJZlLnnHfuxz714V/99s9/f3yT"
    "KC9TnhTIAM1i+hYIoKKkLGDayFghsTWq6oIXBTTHpBVHT8OwfnpR9wRGcFg/X6pUsSE2CCFmzJixfPny+vr6WbNmIWO+IJz/Nl83"
    "lzOGE5t4rRUVmvmN7LXRIod+gdth62ZYJYWISAjDG+haMTv65D/+smDhgmefe3bLa5vXrDl5wfz5rutks1mtdS6fS6VSq1evrqmu"
    "VlKmUqlEIs4FR0ClVCqVisVitm3lcrlYSUlFRcXsWbNcz733vj+dcuopP7j15gWVljfQbQox3GFWgsZArK0zHQxGq6oqAaClpeWx"
    "xx6LlkSyWfdtF56d790rlIP4TyRH+FIZI1SIQ7TBRomkHpFmPYV0neKGMdh7cE6VffY55/b19TvZzC9/+WvfbC9dvKi7P9GbAzRN"
    "IIWgFUluCNm1571XvnXunIUd7Z2hUJgXJ1JrxQACVkgwPtDf99prW9pbDwZse7jJCiJ6nldRUWEHA5/81KeEYeey6RXHH/fFz31m"
    "3boX7/7rM7ysVnkSEYEx5jPYiAiJMrn6CjPAUefzmqRCBYUtwDk3Rg4PZMQYMU44Do/QDwAQUIMGrQE0IQGABkLOCugRE9lsVkr5"
    "3ve+t6Fh+gc+8IGrr776U5/6VDwRtwOWJ12lPL+/JAAJwXynf4zSLQJVRuxowFCKQI/4XQCs2NibHVZJSD5qTAAIyIhQCJlOza2K"
    "PPTn+xrqZ76+fUdHZ1c4GDj91JMzqaT0vKGhIcdxBgeHTMM4YcUKN5cBwK7ubik9H6f3tRxd1x0cHEJEw+CRcChgmwHLaj7Yur+p"
    "qbau9rOfunp+dcAb6hVcoJ8i14SgHWZ39gzOmz9XmAYif/jhhxPxBIFetnT5GavndR/Ybhs2kPSFK462694YvH/cHt1YqJl7w3m1"
    "SW+OFHDBId669X1XXKwV2Za1fv2Tu3fvQmTlFZWhSPne1l4MBICkHyQRoM4nKsrtz37yM43795WWltCouG/46FVaCi4CgZBh2bpI"
    "e/OPT6XU4sWLP/+5zyfiSdK6vm7al6+/prml+2d3PoyxWj1M4fIdCoYMwCa2bP60H3ztMx+96tzp5UFDKyQGaIx5zOKBOr6A6yiF"
    "TRrxSIaHHoBx5Jznstk1a9bccMP1N9544w03XP+e97zn4osvvuyyS8vKywiIcUaj3RjOCrE5HsJLI6JIpMQ2LNAaj3KCGChGCpAz"
    "5QV1/J47fz5r9uzmA02DAwN79uxeu3YtaQVEHe1tuVy+t7e3r7e3vLy8vKzUdZxsNjc4OFRkQxVUgX3ytud5UkrOGefcb/q9Y8f2"
    "+YsWSaQbr/9UuZVV2TgIQ4MAIA2a23bnkMNEcHp9AxHF4/HHHnusrLxManj/Ve/iyf1eLk1gcgL2z1QLFVN3ckZ35pk8BzxK/5m4"
    "aQ+17zluVmTtqacNDAwKwe+9915/Gc2bO7ulrS8hTRYSWNRANoThdrZ8/qbPcG739PVUxEr9DpbDYY7vVGitSfsFSSMxDGMsnU6v"
    "Xr36F7/4xaZXXjEtmwg/8clPC8P64a9+m9JhxjhoiciK2X4/f4TEMJuXza1dnd1DHjFiDIiI5HBLmOJ/tS5AkMO++eHEQRom4Byy"
    "ChkKzn337MQTTzjvvPMQOQBs2LCxr6+XSA8ODkgpiUhKqbXynRTXdYsuO8GoHowojAOdvcAQLe67QgAj+deiwKT276z4vKOMMjDB"
    "hdd54Cvf+MLqNasS/X0d7Z379u0Lh8JLlyxNpeKu6/X3D3Au4vF4JptdedJqRKa1zqRTpDXn3J+UrOP4FdXBYFApJaUUQpimaQcC"
    "mqCnu5cRzZ+3oLWl5ev/fc3nvvQ1CESIChrCGrk2YvsPds2eVtXa1iE9Z/369W9/x9tKSsrLq2rPOfW4xzZvrV28xnUmZCwfMWo9"
    "1GPUh0cRdHhN09Q3wxG8f2TIFCIKppIdu6+8/J1KqWhJ9LkXnj948CARn1ZXZQVDB3szaJdo5RdgIPj0m2jlH++5e9OmF6fVN6Ry"
    "eV/DZriEBYti/FoprTRpIl3wPTzPmz5j5sGDrb/85S8N23Kd/Pvec+WK5ct/decjTa39IhAE5Rb1sRgRamJ+b0+HdFPXwI/ueOgv"
    "6zd2DWWl/3e/3L0gbYzDFhOJkPwqeyxQZw5tlTCs3TNsARhjw3ZDEzEmvve977/jHW9/17vedfPNN//gBz9Yt+5Jxng+7yhFAEwp"
    "8st/pOsVGqnRoVCG1pxxAYxJwmFiIBVE4MAfFJ+mVvSmRmmnM+SWTAwet2zGJz72YdfNd/cPeNLr6u465dRTgTM7GMzmc3nXSaSS"
    "jucGgoG58+ZrZOFoqQS0gkHDsl0pPekODg1ksulcPm9ZFudCazBNKxSOBINBIZgn3eYD+6fX13V2dIVDwSsuvdDt3M95gdKlCYQV"
    "7I07mbysr5sGgJlM5m9/ezgWKxlKpM47/1yR71SOHBOlHhUH+XDv6PA9wN50JdAiukwEiGZ4sLt55bzKVatWZ7MZxvCBBx5ARM5p"
    "3vy5Hd0pl4WRCVZslkcESno8UrGzFz537Vc2bdgwf85MIJJSUVG/bVjzsMC50qSL4aMmqK2d9rWvfQ2ReXlnzdq1l195xabXdqx/"
    "YZsoiSnl+Tl5DaQYI9BAkhXEGRFN0ZvMKWRocH+NAGPFfL6/axhjBcEtUqoiaK2cNxPyeVaAaHBMR7NDB4T5lkFpHYlEHnror9dd"
    "d/0jj/z9L3/5y/r1Tz733HM///nP9+zZa5qWVtovnkTGEAv5Xhqvf60mrQ9JaBXydv5WAEZM+PUzUNRIHFW6iYpyg1/8zEcj0Ug6"
    "lYrHB4FhIBhcs3aNYdrpTKZvYCASjRJAKpOpqKpauHBRKp3Z8Mqm5198aU/jvv7BwUAoFA6HBwYHNZGUMhSJ+GOlNCEyYXB/K+7b"
    "v48xjMVCr7zy8gXnn1tVHVaZuG/60O+7Y4Q6+tI10+pM0+bcWP/kU4179zhOrrKicvWyOUPt+w3D1ofagDdXP128QdBzwrbGQIqE"
    "hTrV+fqln7lSehgKhZ96en1L80EAqJ1WI3iotXeAB6qINBZbuSEiaaW05uUzZD56y7d/2tZ04GOf+Fhnd398aCAYDI7+Uh/u4IJJ"
    "rZCxVDI5b8HCP/7xj7t37xSGFYlEPvrhq+NJ57f3P+aZUR9O8R0pBpqjp9A/IotlhxoGEhmp9KgagiIDqtBEl0Zzy/rT2cHGfWQZ"
    "hJqxUTpIRX+kWL8AxaqAgmqiYRgvvPACIt55553Lli3bvHnztm3bfvKTnzQ1Na1Zs4aKJDDGmNbkFWpl0deOnqC2dZzh59oEL0dG"
    "QBdbYY+aGlSZocVLZr7joos8J++rozY3Ny9cuHDHjh3fvuWWXTt3ZjLZQMCeM3fO8uXLgoHArbfeevfdd3d1deVzOU/K8rLymtqa"
    "VatWzps7LxxC6cmy0jKf6JFOpzOZjOe6ftuRwcHBSCQSi8UMw+7r7f3wB6789rd/Zc6IeVIzxogUWIH+dL5BQn1DfVNTk8pnH3/8"
    "8fe///2ZTP7sM0/d8NO7Qc7T6NctTEZTmGJV+uHvYcdQTjY1nAmEENm+lmUzS09cc0oyk5XSu+eePyIiF2zerLmtHUMOmMAP07tj"
    "nLiBXk7zgN2w4q4/P/HZ//o8glddXZXL56DYU8jzPKWV75UwzqVUJbGSTDr9q1/dLuyA9Jz3vfc/Fsyb+7d/PNHWMWAEQqALGBwh"
    "GkCr5s/mhBoKVZQ+WdhTpGF0AeyoNAoWHY2iV6NAuNoE4IwAkfltGwsjOhIjwHAjDK2klpK0BtKBgE1ECxbMr6+vM02joqIcAGzb"
    "Fpz77tyws6S08pMRYxI9k0w2AhBpC/NXvuPMAHNHihmGc5/coET/xReeVVJa2tR04OGHH3ntta3pdHrr1q0XXnjhQw891NvXn887"
    "vX19//vwI3/734e3bHntxhtvHBwcDIfDpWVlkWhUmKK1tfW3v/3dr++4Q2syDLOqqioSiQYCASllJpNxHNeHibTWpmVFItHS0tJd"
    "u3cvWjBn+swqL5P2Ne18hgAZ4daugZrqCiE4In/uuecGBgaAaOacufMaSlJdTUIYpCfT/3kj4nDsqFz/wz2qMYVXozcAN/hQ5963"
    "nX8WMB6w+bPPPneg6QAgVldXBQLB1v40C8RGT63fNKIg8M8EkXaVNhqWbWnq+/gnP9O4v2nmzJnZXEapgvKzn/TypEdErussXLjo"
    "t7/5XTaTlp63aPHSc889a/uefY+sf5lFokqmsNDsi4DIJdi8d5+HoA95LkK/4wXC8M/IgvN1NEkjFKnuPoWeM2IckAESgdYIhafw"
    "a22hoOuDBKDJdfOe57iu4yvyKiU9z/WLvwBAeVJ6UitFhbAVOBdMGAAaQfsZueGyqUlPHkDGPeRPvbTJKRDS2HAlpy+ZgeRdcO65"
    "P/zBD8846+xPfPJTn/2vz/3tb3979dVX4/H4tLo6LjgwMC2rpKRECGMonigtLTVNk4ikVoZpaCI7YE+bNq2jo+OOO+7wPN3Z2fXI"
    "I3/fsGGj4ziVlZWI6DiuUjqXy7mua1qWJplIJQ+2dJxz5kmU6ONcaNKMONPEhd2f9Dyp6+tqCHgymXzmmWcCtsGBv+OC81Jdezmx"
    "4Qq1w5trvBEf/lB59Ckz7CavOivk2ISRSwzVhHMrTzghlUoj4kMPPeQXXMyaNaelJ5UnEzjSqAZNvkNfgDx9DwfR86RRMSfOa665"
    "9qb7//xAfUO967o+9Maw0G8rk8mUlpY2Nx949NG/G2ZQMLji8osNS/zpofWZDCIThwA1mhRilpj2vfkjnRw4KqYtyjTAIYVmSMrL"
    "kpIkGLJiocWo/owFn82HX4oNCRhjZWVlNTXTysvLQ6GQzxWVUhYamnK/SUUBv9ekoXBSTKhaMHIKEmkiF3hXPOvhWK8Jkel8dsbc"
    "GeufWn/NddcGg4GqqqpYLNbU1BSNRsPhMBTISMJxHMaYD+8Mg2xKqeFBkFLGYjGl1IEDTZdffvlHPvKRj3/8Yx/96Edvu+02z/NC"
    "oZDj5NPptP8RHx1qa2tbsWK54B74pZ4MNCKBJh7o6MvV1DYIjoj4zDPPZLIZV3orjjtxRoWVGmhmBoM3T1N6NJbzTymKJwLT4MnO"
    "/WeddpwdLDFNc/v27Tt37SSC0tLSQCDS0pNCO1psbDhqkbFis3V/yTLBGErXY8FyMCL5fD4UieoiroKskOhxHKe+vv6Xv7xdaeW5"
    "2bVr1560etWexoMbtzSykjI9Qs0vusCEnAQDNvXzwz/wfeB1rMfhOgsaautiJeCqQ7+Igc+CAtCahq2NaVqBQEBr/e1vf/t73/vu"
    "unXrHnnk71RoTA+maXLG/JpjIu153ij4yO8iMEwtPQRzG8XsRyQFJIFzvz34WJkzpSpKSx5/7NFwSZnfmCMSiQSDQSIyDMOfFM/z"
    "/HYeoVAom836cbmvqVHYAAScc6XU7NmzpZRKqcrKymAw6DjOU0899bOf/cx13VAoJKX0POl5Hufctu1sNldVVTmzoUpl0sCYRiAE"
    "DZpZod6Eh8woLyslwp6ens2btwSDAQA4ffWSwa5GLjiB/mdUirEpp7QmCw/G5I8R0fU82+s666zzspk0Y+yRRx7xV86C2XMGE7m0"
    "EsgRtfYl9Yf75vqcLixg/IwBICPgTHtOMCg+9P73t7e2Cs6Hk/yMsVwuV11T3d7V8dTTT3NDGKbxlrdcoAj//uQGF2xkxJhAZhT6"
    "gRR9NoKxxWWETDOuATWNJ+7r5bkiJJ+kyjWy4iFMjHHBkYFG4EUeqkDGURsAUkpVQKoQARjnRjab+9SnPrV48aLf//7Oa6+97rbb"
    "fv7iiy/NnTvnlFNPTiTjRJIhEClDcACSnuPTCZExKjyywEITL0bANCEgIzfPlFdMFPjhNkOCQuPgohQNoPA1q5OZXMP0BuEbBK0D"
    "gYBvf/ydCUCum7cskzFWVFICAPA8L2gHGKBgfmdLhogzZ85saWkxDMNxHCklIpaXlyul77vvAc6NmpppnifzedfzlGEYUnpa07y5"
    "08lJMzRAKyANyIChB6xvKF1XV4OMAPCpZ57RWqXT6eNWn1RCccp6xMfhRhwhDTUeeDpmob5pFmAkDCcShpns3r9sXt20+ulC8K6u"
    "zo0bNwJiKBwqKats6U6BYdMoKZhhR8jP6I74RUgIaAqhBjrOPevUQCg0NDTkgyHFtkbkOE5DQ8Of/nQvEClPrjlpzeIli3fsaXl5"
    "2wERDBE5hZzvobDVuF1Bx6/hBADXXbNkbknQUKRG4/3FI93e2TbUHs+hYSBgoVkdQ0ZugUVaxJv9jqiO48yYMeMf//j7448/9uij"
    "f7/11lu++c1vfP7z/+U7G67r+i2IOGNEWhEBSEayqCDNCMCPNIp8YK5zzttOXjq/tkS7ctwypjEdhMxAoHF/T/2M2SevXZnL54dT"
    "KFrrSCTiR66GYQjBORdElM1m/TJr0zT9qk7/QQCgtLQ0GAzG43HDMFQhekGtdTAYTCaTTz755PLlyysqKogok8n41mBwcHDG9HrQ"
    "ksEoWV8EtOyu/mQwFI2WRJEZe/c0NjY2aq0rq2pWLJoV795rCpMKGmT4JjamYDBB36WJzMK4qoljC2WYyA+1nrxycTyejJZEXnrp"
    "xVwuB0QzZtRnHTWQBiZMvxa7aNxHQEZVUBbxYX0NGkBJ0KnLL3lbc2sL4wWWi5TSV7aqqqrq7e179O//4IYQ3HjH299umOLFja9l"
    "XYWMAQnSOKzP49+kzOV8b/tQD6fQgWj4WQo+AwAaRmN7byav/PrZovHxSRlaK08YHI0AAjLkCJw0AjLyMmOr74TwF1BPT4+Ucv78"
    "edOnT49Go+XlZSXREhpl1gDAdV3pOoAcgMjLs6IMj0YAhsSGWSGaWcbLu1raB3PM4IeatUMiRZ+MzIThJrNnTod38Bfn1FejsPw+"
    "UX7WubS0zNelCwQCvrGMRCL+0vfTvb7L5DMOPc+rrZ3W2dk5zEEcPXRKqerq6j/84Q9f/vKXe3p6/F5pRDqRSMSiUdCKwWgHmEAY"
    "GQ9TqVzdtGm+tXn++edty8o7zhknr3ITLUyz4YBq3ED0aFXbRlQhDgeVxxVoh/GE/w/dMwgAIISTTlYFnfkLFyXiAwaH9U89409/"
    "TVXN/vZBMH1jxjRppoF8zRuNgMQYMsYZ+GoIoDWhIdRQ57JF8+cvWLDp1c0B2x7RvCLKZrMLFiy4974HXMcBxOVLl0yvm97Z1fPS"
    "1n1ohzVJnz1fiBkASQDls6cev7Czv7+5M4kG95uw06Q10ITYn8wzRMYEsUIPYPJrgjljftk9Z+QnVQouYF6n2ocrNnwxa3/LlZWV"
    "33bbz3/4ox+5ruM4rmmanLOTTz7liiuuYNwwLVtprT0PAZRUICUiUj4OVoxAaHCBcYYCAAg1EoBWBNSbyvszowkZMvALEH1wFjRX"
    "WgNHQ2oNOu98eCX76imB37y8vztcdtKK5Qc6DuZy5Kl+z8sHAraUijFuGBYA+DvWN7aIKIQgUozxQoDGsLa2evv27X5RpmkKIvTZ"
    "HLlcbvHixYFA4L777gMAyzLf+c53zpkzt6enR2uKRMKApIAXIisCRojAwIz2DmZnz6zgxkHpwMubNl1y6aUcxey582pLWTI9GAyU"
    "KO1NEglMmJUat1EdAIwrjz6VIslJ4l9TGN1d289dOjccjWWz2ddee62p6QAgq6isQB7oTQ4yM0IFwB0ANObikB8SzHScPKiCcgFo"
    "n2TAwTQh23LRx76STmdI+V2MSGnFsMCqN03jscceB8ME5Z122qlSy02bdw0OpUVJhV9POBrm9ImQ2k+T4mQGlIpNIwuGUrBiXOsD"
    "7cDIDTCW4yYwMYKVAmm/dWomITODAJhJZ3xcBRCUlETEuMhks6lU6qyzzopEIo7jHDhwYP369XPmzLnooosaG4WPunDONWEqmSYi"
    "chJM5kSgHPwcr5+oQKali9wADQgKGQKNCJSOPA4BIWeMy3zWkrn/OTd79crgp59wf70uuGjJ/lml5emEjMYMk9fmck4gEM5mc9Fo"
    "RAjhY1au6/pMW8uyhoWk/AO+tDSGCIODA4FAABGEEIhMCCOXyzLGli9f/sgjj8RiJZZlOk7+wQcffNe7LvetRDAUAFBUTFDQMHtJ"
    "GP1pt15iRVlpd3d+oK+/cW/j8qXLAWD5ogVPbN8fnbtG5r03nqMavR/EGJbbcKXZ1DtwHEq4RU6k0gdPXv0+TToQsF96aQNpCcin"
    "TavrH8rklcmKWiy+jDDL9t7xs1srq2qSif58Lud5UkvleV42k4mns3nX8Zz8W9/+lr1795mWWSjSBSQix3Hr6uq2bt3acrAJDKth"
    "xoxly47POelNm/eCZfv0uUPuE4gUcTPw0tY9YBhoGjAaDivmWccs/YIPPXwJKHTzFqSPnz9nc3OHlBoZ1z4rkzECbgqdT/RUlcfm"
    "LFzc3HwAAEzLwkxGSpnP57XyOGeI+POf/3zhwoXPPvvsE0888Z3vfMdxHN/0Syk554ZhSILBRKKmZtrAQB+6SRGu9qQfrntE0iRd"
    "WxnpjjsOGqR8BXXy7R0W7tPf78CB3FR6bln29gud6WF93n32c00VRqXqGxyoj2SamjqEcObMmh0ORRhjnutoHfKrfDjnpmkSacaY"
    "39ZpOHZyXXfevHm9vb1SSj/pK4TPBeLJpHf88ce3trYODg6Gw0EpPc6FaZpbtmxZsmSJHbCzmTRIF8gbdoGGpVk8ERhKZGurKnt6"
    "eojUy6+8fPyK47LZ/InHn/DUi7+XJEc3Szsq73/cA12PdoEOgUSmgI4fnohGJBRWKjlYG8X58xbmtSKtX3ttCwDaAStWWrqzaQCM"
    "oK8TAAhccDk4eOLSBcuWLnl16/bKsopAoEQIwVmB9YmInAnDNDvau/O5HOdcSYnIkKEmItDT6qb9/g93AgB4zqqVKyORUGtHa2Nr"
    "P9ghpXyNfgRkVNQcY8g0AQuGiABBEyLqMR4QIkMC5lPeELmv8eN3CCUgJAaAAkFjeOO+bi0s5MB9NgdpDYTcZLkenek+/9Ir5sxf"
    "dP+f/gjgt8kApVU2m/E8x9cT/PvfH3n11VcPHDiwY8cOpRQSZNKZTDozHEq6rhsfGjznnLOffvrJ7sGuQKTOZTbz/TpkXKuSWFl3"
    "ohsBobBjkRhwn20MipMJTCqNbiZ72ZL8befLVzrstXep/qxhRZUEPpQOCSFKa0sSObOxdTAv5drVx1mhUCAUNEzLcbIA5DiuUmAY"
    "hmVZWms/LYGMGYaoqq7a/OqWUCgspTQM0zQtKZXWuqqqqqGhYf369aFQSGsyTYMIGGP9/f2lpaVlsbKDzf0AhCQIVUHn2AenAcCw"
    "B1O56TPLggE7k8lt3fr6wOCAbZvTZ9TXlJuDQ0N2JEbaG9XtD4++Qv2QZfymyqMTcMGTAy0nL13EzYCp3J07d3Z39wDw8vJSSTiU"
    "kSzgV0kTEXAGMp9664VXxodS6VSSF0sQSflkZzVMpWSMCVbwDYAVqipKSqJKqRdeehEAuRAL5s8Vgrd1JXOOEmGhPY9GmGyMSPva"
    "JD4sX+CmDae0is8gBPdcVxgBYgggEdiIXJ9/UiH32TrImEYA7d+SrxihJaFAkgMHALz3vO/9D/7lL6l0WimliZRSUnqe5+piMuFL"
    "X7pmeAAXLFiwcuXKocFBz3OJSEoVCAQsyxwaGiDSa04+5cE//4VS3axkus/0QeQKxLZ97cywgGTxEB1ukEoIQeSul9Zhkf/6hbmP"
    "Hce/+4JxywbhQcAIMs9FxqUklnS92XWlm5vQqoy2dB5cPtASC4dymbxtmbFYLJ/NOY6Ty+VKSiKWZXmep7X06yCjJVHPc/N5JxyO"
    "Dg0NmqblK39lMum1a9c2Njb6IQQRCWE6jlNRUTV//rydu3adeeaZvf2DwG1ErjSwQuKzIH+GXCTzypVQWhrLZJ1kYmjf/v2rV6/i"
    "VmDJkrmPvrI/XLradYgh0JuUEzgyDDpGYHDCRCmCJkBSlO5YsXR5MpvinG/ZssWn91RXVfUPZVwSzGetAxAy5TqGqdacdOJQPFMS"
    "KfG7SPj5F8MQtm3btm1ZlmVZhlEE8hnz9caUVFWVVdu2b0vF4wAwc9asisrKTDbz2vZ2sAMIxJkY9l5G8Y0Ih5u7+wadITAGfm6A"
    "CQHqxPkzAgZo0kCoAYgh8EL5OQAjROQMGAMGCMQYQ2TIDRQGcEuYIVulnUTn0mVLZ0yf/sc//pExls/ngch1XSLynWD/+2+55ZsP"
    "PfTQCSecIIS4+kNXB4NBx3GLncMpEokYhuG63vPPP79s2fJwJJwfajVVDrhAJoAJbVhGMAjFQgk2wkBiApRgOS8pTp6WffZ97qWz"
    "ncvu1zc/H5LBUmEZEgIATCkENA70ZmfXRApzJ2KmHnBzuYPtide27mncc0AIKxAIau1Fo1HLsn0BL4bM87yK8opkKsUZE4LblmVb"
    "NmMs72Smz2gg8rq7uyKRiA8oAYBpmmeccXpHR8fLGzeuW/dYc2sXWKXAFQNGhywhZIxJNPuS+dLSUn+F79ixwxR2Jps5bvEyyraj"
    "8gg5TqwaNHVq0JvfKJtxkU0nKoI0c9ZM13NTqeSrmzf7DYvKSkv7hnIgLCLtR7/IhEwn5k6vrqooTyQStmUTFOq5tPYbvWsAUFpL"
    "pfyOKD4G6u9J13XLysuee+55/1mWLV0ajUbbOrp2NLVjIEhajVRjMUQuiHHfCSrS64cdHoaMFaJbBAJKplJSFzp8ESDjAhkf0YlA"
    "f/Uzhpwxg3EOXBBjHBkCBk1GqW4i9YUvfHHdunU+NTIej/tAuw+FCWH4fvMpp5xy8cUXf/KTn0TEO37za9d1AgHLMARjzD8H4vEh"
    "KWVbW9vAwMCaNau0G2dOyjBDxAUiV8AUIvgEbfAdQwQOFoe8stysd8Mp/U+9T7Wl2Zq7Io81R6wQB/I0EmOKMYaMMUv0xg2O+WhY"
    "k5SEtiKzoqIMQ9UiVj2Ykq0tbYJlw5Gw57kIFAoGTcPUoLRSpaWxnu4e0zIBwLDsUCTgnwSzZtZvfW2baVr+KSaEyOfz5513XmNj"
    "49BQ3LLswaFEY3MbBKNKa6DDJH0IgBt9iUw4EjFMAQC7d+/OZFNK5hvqZlZGeDYVZ9x4E0kL7PC8CUzaYvLw7VWAjAiEYaQG2+fP"
    "qI+UxQKW0dLS0trWBsDLYxFJmMhqNITy9QmQCSYgNbhm1fGpZDaXSSgpgaCwAYAAQWntKalJK6086fn+ne88+OGB43gvb9wEyBkX"
    "ixYuMC2zpz+dyqcFICm/7oT5jVtKg5aJHBgQMCpWw4Bmfvct8hUCmWBIEsS+npSrOAICZ2BwKXMaFQjBBGfC4FwAMkAGyJEbwC0S"
    "BnBOwLQw0U1ne/bMX7j0bRe+9a677jJNM5FIDA4Ocr+nBAEREkFZWcWsWbMQeXd3d1lZ2Qc+8AGlVHvHwXAkiAwYEwCoFPX09GZz"
    "eQDY+PLLb33bO00r4CTaLQRmCM7QQCaAMzRBmCAMYIyhbTCezdP8ssRjl6evWel95gnjsgfNbhUTUcsDhgqRDAAgDsg5GkxRsDvh"
    "1ZVAQJhM6N4MKwl4pBG4heG6ivIoS+3avb9/0/Z9L77y2quvbunr6wuXlFRX1wLj2VQ2FAw6uZzneMA4Ih2/dHZ3S8vQUEppn9Sn"
    "pXRPPfXUloMte/Y2IoNT1q62zEBbW78wudYe4GiwEQFQE6FgyUyeMbMsFgXE7t6epuZmk5tWJLhwbn1qsNvgQhM7orc/SUKgmOEh"
    "As0mB4mmogU0nDFFAJnoWrp4vlIYDoV379lNSgHq8rKygYGsq8WISAEQkgTyTlm7urWtXSrpZyJH7zHfFIyOy5VSPqNTKRUKhdrb"
    "2zs72gFZZVVlVXU1KN7ZMwTAGBAVtwrjXDvu0lnTOGlEc1hMChgCR+DFASIiZIRcA+NCEBAxQM6Zp1fMnl5mWUgM/SU36odxg3HB"
    "OUeO0mTMNuVgm/JyX7rmi1u2bHn99ddjsZjrurlcTgjhRxz5fD4ej3/gP977wvPPzGioy2ZSQ4N9a9esuvlrN9XV1fkMHFZU1+rr"
    "7fVcB4W1Y9vrs6bPOOPMM710D6TaDcEYCoGW4AGDWcBN4lww4ZF0cvjpJYOb35cLmLDmbvHrbVEKxZhlaRDITWJCo1/RzxUwBA4B"
    "62CPUT/NTCWV5mIwlTMFB0DGAqTNgM0xmyUWhUitClSmdKi5M/769gM1FWHylCbI5LJaUTAgpEPBoKiI8WTCm1ZfFwwGPc9NplIr"
    "V67inO/esztWWrJ42eJp9Q1PrH8eQ9VKAZIcgzv75XcMuQQrk/XKKyoAiJTevXuXbdueJ5csWuQm27HQhfzoWlkfvsL9XM6bSYVw"
    "PSeAufnz5uRyecdxt259DQAM04zFYoPxPHB7xMIAuZlk/fTaVStP6OvvU0p70htd6jW8GXwQ3b9jKaXruT6YWFlZuX//Pq0VaD2j"
    "oSEcjkipD7b1gJ9jLirCKqVOXTH32zd+5J1nnRAyeQHwBf/RfdERn34pCBmhbwoY+L3jURC3kumc1KgZI8aAc+CcGyY3TGYYfk0i"
    "YxbnQWEaAZXL9TTWTat+58UX/fL2XwyX7+TzeQT0Y3o/BuAIwq/9cR2SUjqOm88LYRSzy+TnnlzPBQBhGPl8duOGDVdccRmQcgaa"
    "GWoUJpg22oLMADM55yKfxzkh9Y8LB75zWvzrGwLn3B9pdGvMmA1MEyhARkwgF8hN4IKQAzJSjFmiJyFKLDsYAeA8mTUCtgFMEjBQ"
    "nmDeYFb5XGzgNgTLRNnsZI4xZ//GjS/sbOrYtrNpT3Nnc2tbfGhg4czSHY2DXYlMX1+vk/U4N048/oQZM2c2NTWbprV44cJs2r37"
    "nn/kAjO1HSYg1IKKdZ6HVFQTgLCHEpmSaAkTAgB27NyplcrlcjMa6oM86+XzwHCUUsKESP9UIgE2LsFhIvMxRl6iWGPq87yMXLqv"
    "riJUUlbu5LPtHZ379jUBQEk4wgUMZiQaTGu/EQgDFBwc7eaeePKp+oa6mTMbggGLtKOkpzyli9UPo5V2fKqJ7z0rpQKBwK5du/2b"
    "mj1zhmlZ2XSmvTcBwvbQj1yF/9PS1b/+mY3b9zY5qqDQzJAhMK1JSaWBcYXoeMxXOkcfAC+SyQzePOiktcENE4WBzAAhQAgQJgob"
    "Ddswg8IIGIwzM0gDbTIf/+jHPtnV1vbc8y9GS0pdqQAgm84IvxKWyE8wSQJPk0Zm2AHDtrlpCdPi3ABgUhYayXiel3dcAFBaAYr7"
    "HvzrogULFy5anE922cqzS8qYzW1hBGwgLaRknzp+cOO7B6IleNqDc763pZrCZUbQksiQmb70HSIR54xx5jkcNCIAkwiUkzqVMaZV"
    "MCCe9gIW83k+DNALWTztmcAMYhxAIEPpYW1VNBamA50ZESph4WoWq0mlS0qCGSfd/dyLrx/sHGjpTTU29XNKlYe8X/3uwW3b9lTX"
    "TEvEh158ebdZt1gLA0gyVqgAH15FrCDyy4mAcUzmpGGYwWAImGhr6+js6vI8LxKLTSuL5DN9QpgMGR3pmJ9kGxTwcZqyBTjCZiJi"
    "jDlD3XNm1GsCLnh7W2sumwOAyhIzn3XyGkd6SiESMWZF+3LGNdd940vX3Hj//Q8MDQ2WlVdHoiXIisz4UXIjfoOtEZkewwCiPXv2"
    "AHBgWFVdIz03kUolc54wDV8MsFCfzrBtMPuL+9bt6Yi7UhUqWYqqJYiAWlbF7FNWzATPZcJE5IAIjCEzuDA553YgaJi2EJYwLC4M"
    "xgVyIQyb2wEMBFgwxMM2hGNRNFMd24NB+0MfuvrnP/95KpVyXdcfgXw+b1kWY0yT9jew/2iWZeXyecdxhWEUywS06zr+BggGg4XW"
    "cQTcsg42Ne7evecjH7maSMmBtiBntmm6wVhCRZaU6Kff3vTt05Lf21167v/O3eKWlZSEGAsQCmQcuIHcQC6Ic+BIMrNyyezSoAFK"
    "KwKtAARr6U/PqDBRY4ayxCkUlH5tZ8gK5D0GjAMVWUaOs2C6PtCNgCFCoYExza0Yu2B17bqX+zBSJ0pKiVVNn1Gyen7pw882KhRn"
    "veWcWNR+4bV9vGq6qyWge0jvGTqcv0DAecZVoFQsEgbS2XSq5WALF5xxY+6shmy8WzABh8jgHZPPMlFBzOHEiTE5spGadMThIiQE"
    "gFx89szpRFQai7UcbPa5AzUxK5/JEzeAaLi6G1ErZDpSbjYsb03Z9z745Odv+Pq3vnXrK5s2mbZZVzdNCOE67rDOjx711Vpr2w4o"
    "pTo6OgCZbdulZeVIeiiecl1d1BKkAtxOhMzoTLrADdQKAIfXX+GEMMx4XjV2DJEZ0IDAOXLBhMkMkxsmNywuTGFY3DAZN5gwuWEZ"
    "dtC0bW6a3DBM2w4GQrHKmoAa8LJDV737vQBw//33x2KxVCrluh4A5HM5vzAAi9/ut8orLSt94P7777nnnlhJyfAf/Ty0n1sdkeEl"
    "AoC77rr7nLPOqplWl+zcpZyEDFaU2OZNJww9dtF+1zFO/9vC726fCRHbDobyRtiwwsKwuWEwYTBuABMcGWpAZje196c9JGEBIiMB"
    "AaNlgMIWBC2p8gKISgIhf+tZBss5vlIk99l0wHMzyviOJgnBEk2m4KZMyQuOC27fn+1LRITFZJ7HzOQFJ8Ue25JxZOjcc09S0n3y"
    "hd28bK4mQyBDEIfou+DhGs4EyF1CJ5crCYX8dhCtba3hUAiBNdRWyXQ/EukJiJtHWyA2vjbo4Yy3celERWVt1Ixc5drMmztvNueC"
    "c75v3wEAsIQ9u9x8sdkFEfRJrz7x328+q4lpAB4uY5ESUs7WpsGt235XXhE6+aQTTzz++MraGqUUaVKy2H1WFxrO2cFA30B/PJEE"
    "gNJYLFYaC1hmfzwDCBp8qgRioRcKApIGDUjIgUAjIuNM+ssROCLkCDJpDwUnAMYFY5wxjowBFygMZByQcUTGUBiMMS6EwbhBCKTJ"
    "4BYY4WjYam96hQnjs//1uXvuuTufz5eFwvGhOGOoNKQyacMylNYCWFFNzeOcDfYP/eMfjx1obu7u6Q2FQq6T94vg/BSSryAEfpMZ"
    "rZGbL7zw3IGDbZe/65Kf/uQ2b6j1zBPqvjxz9xzs/d6W8tsOLnQDkYqqnOfltOZaSZQSFILimpQGr6AEgIpA9WclMp/EJwCJA2Yl"
    "y+ahMoyZtJnMekETFVnAueCQcxVwpvweMxIqSxEUdidtI8gUknKs+hrZUG7+8pGMiEaVBlu57zx32lObh7oHc285Z21+aPC5TU2s"
    "coEGCaxQ8McOReKpmJDUBaTZ50YGHNeZVyka9wtPyebmZgJyHFk7Y5oFz3kyD4dumzFr9XAYc+LuVW8cSkVCxt1csixqlpeXA0A8"
    "Hm8+eBAAKgI8bOJARqMwfSHLIpmkYH98VEgT08wySmsD9YuHqOzh9Zu/9s0f3Xff/aWxqPKk36fIh4AQUSoZCoXaOjq0kkC6sqLC"
    "5wj1DsSh2NrIT3QNA+QFlbYCdikAGTKOzAfyBRNCmBZnXAiLGZZhhYQZQjPAzAA3bBEImqGQFQ6FSmLBUJltl9h2LBKrjpbXltRW"
    "l9ZVLzluVjV1DrXtecv5b5neUP/HP/6xurrayTuKQAgDAOKJuBCCsaLuJ4BfevLyy69wLqqqqjZveY0VEnyIxaA/EAj47KACOC64"
    "1nT/n+6+8rJL7HAptb/6nZr1gHDB1jN/mjojUNNQUWoZkTIrVm1GolYkaoTCRiBkBqJmIGzYQW7ZYFgoTBAGtyzGBTIGTFBBsMjo"
    "ycgZ1SZIIyVZebSgaMwAslKCL4PFOOTd5TND7XGhmKFZgFMQvOw7ThJPbPGkUY5MkOtcdk54x578/oOJt561KjHY9+xrTbyyXoME"
    "Jv1lLg7t/DIOD9eXCGFmJp1fVB0qDQUBsLOzI5VMSemWV1WXl1j5dIL5ZfVvlizK4TtpIj30w3eSJi2Y7Sb766tjpmF7Sjc3t8aH"
    "BgGM2WWmlnLItdFiGhSQ3+sRR/FRmQYGqH2lVY84BsutWJXb16kUVFZUdHX2hqyA1BqKUg1KqZKSkqGhQf/GS0tjpCGX8/oHh4Bz"
    "nxNQYExoAkQtFRoCC4Rk7vNOkHMGnIAh54gcfDFNLpAJ5MKwLC4EE5ybJjOE1JqYsEPBSMAORkINNRVzppVVlYbrKsLTY0ZlJHDp"
    "278LoL/0hc8+8vDD+/btq6+vz+TzyIVGBgDZbI6NqqP1vbhIJLLp1U2nnnrKE+vW7dm9+/jjVhiC+UgRIiopASCXz0OxakRJFYlG"
    "161bd911N7z1bRf+9b4/Pp5eef77bvzS2SyfTHT0Jg8MJnY0D7W3tWTyBhLZQVKup1xHKyldU0sXuKeVVJ5LykOQQP7dMSIAk7UO"
    "eosWCjByA2mcWSEAFQBj2nWkX1cGGgXnzoxS+39fddG0AcHLOKctwniCN3Z4ooK8uPP21SUdnfHNu1Nvf8eZne2tW/Z0svLpWkrG"
    "UBP3W3LLnMss4/9D23/HSXpddcL4OefeJ1Suzt0zPTlJMxrlaMuWnJADxjhiG5PZJbO8GPi9hGWXsLCEXTJLMCwYbLw2zgEvDliW"
    "ldPMaHIOnUPlqifce895/3iqeno0kixj/+YzH3vUPdPV/dQN53zPN6yXYayFq2ULwwETCGi13JUcmvFKsNTqtJrNer0xOTGSy5em"
    "J4cPLtVy5THnDFxlVXh1YsD6O+Hq1atf+IJ4seM0orRd33bbNlQqHwQXLlzISrRdk/lexBYCQgVi19h/ax7iWavqMs04KRRBcWxB"
    "jNmyeYunfdIq4y0TkABnpBpP6drKavbalUpFKc3A9U4M2s80lpBtKQJgd+30yGy917FASITUz4YmBNKESnmaUCMqIg1aKd/TXuB5"
    "OfB8UaR8XSqVypXiro2V/dun9mwe2zyUn6qEeY2e5q51goXPf/JThx576LZb73jJ3S95wxvemM/n09SkqRHqm9lEUaSIeN2IPlOX"
    "Hzp46K1vf9snP/Wp5eXlhfmFjRs3iCA7AURBZJFet7ce4Cjk8wsLC5/6zGff9bbv/Nj/+eAfffrhG39I3zgJk3s2ar0tis1cM3r6"
    "7OLxS7VT862zFxcXVxpRlOQkFZe3cZSmqUtjVtpZyzYWJGDHZFFAk230AgYeqsBCy+zbqIAw8wGLjQIKkGK2PDkaoOOVLniBdjbO"
    "F+JbtuX/9l8bXrVqavDyG9gkra88Eb3xLffOnT/71IklGt0k1inEzCMJEMGZG6/ZdHJmJUrsWvu5ln84mMlkpGJsJUFq0q1j/uFL"
    "KjVmaWlp69ZprdTW6Y1PnJsjQvtcXIhv1MdfP0va8mJNP69c/8JOc7J161bHLlDBmTNnss9sGfEOLauMMZ+FDsqgIsG+WzwP4jgz"
    "JkLWUBPEvfGR4cRaaw37nrWmb5kGgAK+7y8tLmWvPTw8TETOJSYRILVm6cPCCgkEbrxm5+oTx9om1VoBZnU4ECpUCkmRp7X2NXkQ"
    "eEp5gc6T51Ggy9Xq+OTI/h2jt++cumayND0cBp4XRyZxthu15xNeqfcurXYD5f/hH/4Js/vlX/mlgwcOHjxwYMOGDd1uzNaR3z/1"
    "262W53lKqSykPsN/5ubmZmZm0iRl5uXl5dXV2sYNGxVpFmBhJPR8r9+uEyELADvnyuXS37//7z7wjx/Yt2/vkUOPf/lfPrf/Ja86"
    "cLa5aayU1yhKvfKm7d9+02YrdHGl/cyFlcdOzD5zdmFuqdlrt/M25biXJqmxLNZ3SSLOgKTinAJrLS507e4N8ujpqFwuBEHPCig/"
    "TF2HlEee5chdv0GfnUOAALTljv3228MHjrVbUgGTvPQ6nCjmPvKlc+94x5tOnz7/1PEVb3QTMyOBy7BlYAYipdnZtTDL9eapl8k5"
    "iFmXyE51U9k/Xf7MU0sAcPbs2TvvvN06u2lqg40OirjnU8Zc3bK+wK7QL7DKny8276q6iKxJAoomJkbT1BLGFy6cB4BCoCcK6tIZ"
    "Bq1BjIgjWpMfXOFYvw5Nyv6fgdOJ8bHUmMu86KyKQCSlgiBoNpvZ46pWq4QYpWmSJoBBxtMEQAFmQB0U/umLj6EfkCIkhcoTBFKK"
    "lIekUeswDL0gRM9XXj4I/YmJ6r7tG27cNnL91pHdk5XRYhgbjuK41U2eWVxZjW3B10nP1tq9ThxHVq2eferQY1/dvm3b61//2h/8"
    "wR9AxA0bNhw5fCwDfbNnVqvXM2IMCGdDjDD0jxx5zDmntQqCIE3TpeWlXq+XC0NrTeaNpZTKnHHX0DdrbbFYOHvm7JGjR3/oh374"
    "Z3/2Zz//zx+Y2rF/odadX1geHq0KqA3N7sRQTphLvnrtDZvfdueO1Xb89Jm5+w9ffPDowsXZFW43AzHIQdrr2jQV6zMZ5hQ0nq3F"
    "N0wncNRDwnzIrZ6zAil74BmxWql0ugr/fDahsGQSvWPSlf3kqfMeBP7uiWTnBu8Dn7/41re96eSJkwdOzauRbc7aDKofGJciADCo"
    "Q6cX0VOAl5dan8q6vosFyoylFtq9l23XCtkJXLhwwZo0jk11pOpB4qx9vsiMbwjH19+CHph01GuMlr1KpWJYup3O/Nw8AE5V/HLe"
    "m+kxKIXinkeBhQCE4KBPNXMszKCVTyMjwya12bonUkTkrCWlAt8XkU6nk52OYRhmJoSm7yPRd50kIkHlSHmlKjOT9pX2FZEhQlS+"
    "H2AY5rSPfqBy4YZNm27cPXnHrpFbto1uHi6TotVOtNiKjl9YmanVYyZnwBiTL+bqbZmdr682miAWhP7tk//H2PS9P/ezp06d/PjH"
    "P7F79y4ArDcaSumslgGATqdDRCY1WveNjEjR0aPH/MCPkySXzwHA7MxsrV4Lc7k11yPf8/obIHNW7KNnGIbhP33wg+973/t+//d+"
    "7/EHvnzzqx7buv8mQLu81FjtxMdstHGsGqWuOjw8XMqlcTxaKt5+zbZvv/2axVrjq8+c/8xj5544dmlxtSFMoZ8662zSi2KFHs43"
    "27dsAi/0ozQp+NDuWWvZsiKlOYq3juse6Xq35w0H2G294Xr30ceMUH662LpzW/XDX5p5w7e/9sTRY4fPt9TIJudShcJIDER9CVHW"
    "A1sKvMtKZRABIhA2hrTPlxPaAEGAvLlmOhpgKfQakVtZWep2uyJUHaqWC5QmkR/mJSsZvyXeoM9nN/ksgOk5ljDptFefGq3m8+U4"
    "jedXlzvdLgDuGAnQ85uJpYCz7nedGUkmcHYZG4mFAZBQZb857XC6GuTzvU478weU7O8gCAgRWWt7vV7GkigWi04cobKkARUD908U"
    "pZEUEhFq5XsUhp4XIHPeU+T7Epa0F5ar+b07N73ili2v2Lt5ohIqxHaUnlzszayszK/WurFjRjEcar/ZbXYjZ4EDTzUarVanG/hh"
    "0mmfefJrE+MT3/2e7/259743iuKpqakjR44RomMLA0PCXtRDQK20iMssdKxz5y+cF4BavZY1S3ML87V6vTo0lGEgWukwCK2xMAjA"
    "yxoba93Q0NBXvvKVSxcvvft73/P7v/N7//rxj9ybqyqlxQKSHh0qCmDK7sLFmWSoWCjmHzux8tixc7umR6fHq3ft3fKam7Yu1qOv"
    "Hr74uUdPHTg13+tF2hRVq5GijaJ8ynbzVLgaq6ES1lpWkRKllPacM/u2q9OzKXiBabbv20cX62Z2yZ+akJffUPnc1xbue8PLjhw+"
    "d+p826+OG8dEKED9SKc1wyJmWTvpEQVRgwhTMaQbr7/2wSePkk8OMi1SxtdSsy3ZMORPj+QaM3Gj2YiSdKhaKZdK49XiTK8W5MvA"
    "9mq3oCv03F+vudXPWvfro4Fe2ApuDcciQtvrbNw3kYUoXrx4MaP+bh3O1bq2Z0nlgEWQaM0xDQeBjCiAgFqHImh6HajPgOmOjA3d"
    "9trXb9ux5dCBw5kHQeaEvM4jOSMLYYYepkm6FklLpEEQUIHS2dQW0ddBqHO5wCNWoaN8mA+3bBt51c1b7r12evtEpZlIs500u8ly"
    "Ozl5aXml0SF0gQeNWu/S3LLy1PjEWGIsWKiWPLbOOYgMkpJTj32p123+ws+/t9vpfOQjH9m7d2+v16vVVrXnQWLWDqZOt2OdJUJj"
    "++ryZrM5v7AwMjISxXEGjDabjU6nk8Gj3W43e9pxnGRvAMJ6AjeKyF/+5V/+wi/+8l/+2Z/PHX+K60ve6KbIWZLEOr8Xh+12mvO9"
    "2mqjF9limE+Mabba5+dXY8tjo/nJ4aE3vuyGt75s38Gz859/9Ni/PHLhUk+0b9QYLif+psnGctuGOdGASgGQcqSDnNtayX356QhV"
    "WC209230/vTzWB4OXn9L/l8fPnv3q+4+eujCqbmWHq6aVHCQapOtIV6nYrzKwxQRJUrdwRNnQBMI0DqaPypcjZXnw65ROjyDvV7c"
    "abXGx8cAcbhaPjtXo4mdbNfZKl81yHqBcqivgAX5ZkugfkiEiYaGKu1WR3l47uzZ7FOby95yMxUs4UBNu7aCGYCQSCmxxnRa0K6B"
    "JBunhl721pff8/K7du+5ziPv9OmzzrHOvMKBxFlrbWYrYm0mFiNm7nZ7pUrZJ620hn62BRFppTzUvpBHXhAW8l5YTAn8fHD9jqnv"
    "fNl1d1+7MefRQjv96onViwvNfF4pcfONZGZpFQVTk66u1OfnVou54M7br6uUPAEV94znIThXbyycODsDSefkVz5TLJZ+9Md+7I//"
    "6A+iKNq2bduBA08FQZCmbv0b3ev2kjhxjrPyRmvd7rYa9Uar1VkjzGWWUkmaDoQ6ZIyJ4xhwkNAx+HLW2tHR0U9/+lM/+wvvffd7"
    "vvsv/+KvDj/+8K67qnO1einvewoVKuUF7biH7E6eudBoxVs2bzZD+cnR8sXl5pm5+MzFi4dOLW6erOzZNPyeb3/J6152/RefvPC5"
    "rzxx7sylU936SyaiTiMqlLVScWI06MBZvmYMZ+txL8mDdL/9tvy/Hk4s8ZvuDB86tnjbHXcfeOb82blEV6rWCWmNaLMjvB/Guh71"
    "hnWxwQOrSsPY6KXZ4Jsyw1wAEVEKmz0/6rrNFR+AhN3s7OzWbVs7nU65UuILK9Kvn19MTteLKIG+7gTguS8UERZA6VaGRlKb5r38"
    "8soKABDqqSH9xCwAas5CGaQfAyAiSNbFsa0vgepdu2vrS25/3V233zw1OaW01+32Tp061Wo2iSgIAlkLnHDAzMakzlnP85Tys++r"
    "242S1OSLQRCGkGilkEWj9sgPiJTvBX6+YFRZ5b17btry9pfsvnXHxkbXnVloW0Dfz1sHU8PB0urS+fm2UEDWLS/Xlhot3/P2XbO5"
    "UAh73R6YcGFlsdZoLS2vtho1T+nJTRtrh4+YpPNTP/nzWsP73//+a6+9dn5+vl5vFgolhDQze8owz26vl5pUEbnUIIuntO+FURSv"
    "ri57SonrE3601mmSZMMyz/OMMamJgTBTUEPfoBozl55arfb3f/M33//9P/CBD/zTgQe/aMob29aFQX5lpeX5sHnz1K4tG0cqG0eG"
    "R48cP3bg6SMH/GDf7ukdWzdglMQMTnCuFp++eLLVSz0Nu7ZN/OKPvfXQkfMf/8KjLmoHaj6EfLlUNhoB8+DSnZO5UwspOH3zDmTk"
    "wyeT179ueO5i77rr9j166NLFBaZK3gogKgYLRACEIpDZ4SGIKARUZJhlbUsDrNnAAioaNACSAcYASMjWqUaUbhr2AQjArSytMIO1"
    "bmJswiUzgsCZZdg3SGrOCofMqEZ/3d75hZ3XkRCFNdhKqcTMRKrRaAJAIaCJodzSqR7glbamIoCEndqGvHnLj7zlrjtu3LxlaxrH"
    "C/NLJ06dMWmaORGEuVBYRIQUAUIWv5NNwYwxRCoMgwHMIsziaeX7PlkCpZQKted7ni9ezglhWHnlXdvedc/erdVKreeeONtQipCo"
    "1ektr84bYzzfn6/LA08dHy6XR8uFdrvVWFmZGBu+NDOzXG+HQcAs3W5i0ihNO7fs37tj81YH5qGnvwgAr3jFvfd/5f52u33NNdcc"
    "OnQol8sBXNntE8ZxbK0NgiA75n3f11ozuzVa3sAz1M+M7tYgoOzGWCsfsoMzowxVq0Of/vSnf+AHf3jfvusefeQRTDulsCgo3aiT"
    "NpKl1fqRExc2Dg1tmBrbPLlxaaF9eu686S51akv7rtvrF/Pzyyt+WHAMzvFSvXdhoTlSDoaHh+971St4MTz6pQvWSmmoyMQAxYJe"
    "HA7xCzXIl829+yt/9pnll99ZynWS0pYNDx5YmKmBLgeOB/7TqMimDAhaQd9DCQiYHVtA0B6xkYEGY92SgOc07QGkmZZsrvQtsVqt"
    "tgikxoyNjRKnIPwtmwS/sJjgalT1clgDIrPzwHkKHXMcR6srKwBQ8lXJp+VIwWXuQ3bridaeaSy/491v++H/+EOPPvzwk08+mabG"
    "z3wFfH/N/XxNGrKmSyYiAIqiXua00f8BtOf7fpwkSilUWvm+8vNhWHCCBtQdN2x51xtu2TM1fHqmdX+9Wy5qNMlqvXfq0mKn3R4a"
    "HpocH42MOXPmUiUfiI07HQ7zuenJsbGR6sHDx1vdpOvHQughVcuFsaHJ1NgLM3OxjVdqqwDQ7XZMmgZBUK/XB2xnXDeMFCDqdjtR"
    "L8o+qLXWWmU/V68XZYPhvj2B1hnfOzvjEdGkhrTHl4X7awHXmAFKUdQjJABJ0jjMDweFYi+OlNICSAKnz144fubcli3Tfhh4pOrN"
    "zuHj54uFyu2336g9ffzU6U4v2bFjy8RIYbnWXaq3ZpfOdCJbyfnXXLt9edY5wCheBZHtk24pSXsrpTffp752qrN7c/HayXwNC/c/"
    "urrQAVUoiLi+FwUwGLd1tBqxLNRa4uksiZCcG8p7YT6cr8d9g+ustyHqw9yZRc7gD/0ZAREofa4Ot+8iQA1il5eXkzRx1pVKJSVO"
    "bJrRXl4A738BDls2f3pRCTHP6qmv6JsR2SYaAT0AwTiO2502AAwXqIDpUk+AUBjX7fmspFeJNWcvnF9aqRUKed/vx0dnkMia9+2a"
    "AGC9p6cIOmdzOR+ARdg5k/f91FkfnUIVFivWy/dE3Xr9lu999XXbt216+vTq33/xbLnkbRgPT56snZtrLLdijpPRkaHZhfqhw6ei"
    "bsfzQ2bTarWiOA3DXKDx2NGjqQPth2k3tS4dHSrlguL583NDI1U94nFq1+u40zTtdrtrNKe1DZA5/ceRSdM0CEPyvChNXEZ2cJym"
    "ibU2O/1IaWZOkiRbB5kPwDr71IF58LqIYqU9z/OzOqLZ6CS656eWCQiJWXJhbmxrtVZbOXP+PJEGRkHdis3Xnjxw7OzZUi6/bdOG"
    "0clKa6Xj8rlCmMvlkk4vChSt9rxpKufxwvDQhtaKgJKd0/mDZ8rTW5rEweKqfserSvOt6v2PLC3FBVUy7NzA3RMFBDQs9xInAooG"
    "uTjo4vS6G/bu2bHhr//pXzBfAE7XwEDF7JEySMJ2kITLfXE/AwAtdXi87JcCbMdQa9RNkopIsVgIfRGbitIonGXdvnBS/NW5zl+n"
    "CX6RLiuImNqkmA/CMERFvXYr6vUAYKJMpYCbCQH5iHbA3bt880RRmm0f56yIsOvnfymlspfOlr4xZu1ny3ZCdsqWSkUAEXbNZkPA"
    "Kg+HCkWbcCxqz/Smd75h//XbpmaX2//3sUvztWZrdXnhUuvQQeMgjOJUnBFjj8zP9XpRXzmZBcCIIFK321lqt9nawA+KhbznqXw+"
    "nBwe1loFSpB0o7GqJdPXg1IKRJxzvV5vjd9xmamLSKiy4i1fyANCp9uNkwQRdeaEj0SkMheq7OfNfmW53wMvOlmz58hshJVSAzYh"
    "KkUAWClVxffYGJtZYJBaWl7BkerWzZuU9k6dPut7oZfLAUqj0V1YXAWgA4eO3bB/79zy6sapDZPj4w5c1OkiQ6cnK1oP+71abY4L"
    "W7bvr1SDzkzb+/abqidPL77nZZMzjdxnH43rtuSX2bIScsjYr2oQkKRtLPTzkkEQhFnncw8fOPLIwWcgX3Js1ypxSJOJsWEvCM7P"
    "LqDnZQ8wwxL7LvmEqx2bD/PDOWrHEPW6zpogCAlFKwDn4JsWyH/9HuAFZ2mCQCaJy3mvmCtFIlEcZW7aw6FW4HrOQw/X+e5c3jhJ"
    "bIwRa5zv9+kx2dxnTfyVFbvZglg7azN5AABMTEwCAIibn5uLYpPP69HxsWKUvOFVN9/7shs7zeQjj5yLDHGnsTAzWyjo3Tu21Gqt"
    "Q8+c6EQ2CDxnjIiEvpckkbVWBhiqABDK+HBFIeVy+UKxEMW9XM4vhAE7a5PYGGtBfC8knQMAIu3AZN/zenxv7ZEhoTOm3e54npfP"
    "5wqFAhG1222tdbFYXEuPzO66UqkUhmEul6tWq8aYfjsxAFLWpE1rugjnHDsH5KeMYoykBkhlGa8KoVZv1Gr1jRumbrnppmeeOcpp"
    "7ECsYY3EgIbx4See8T21NL9cKZXGxobaURIbRgrPOLt9NCc9/vKlmk4WLiC99KZhbZfvu3vXbBs+/KiJPF/54liIHDonyH0CDwgI"
    "ExJQ35Qyg0EtCGgtggAWkft+rMyo9UKjLgCoNQ9ycnEQtSnAQLLaIxIphwoAo7jHIkppT2PgBbE1XpCHgWX38yq/XoDpg9/8JBjB"
    "2STIe0CKnGu2mtYxAJR9ciknzFdqN/tpuwAozESYWhNKnwqaBS6sHfxZFZSZYa2VQ1nyQC+KRsfGspdfXF7uRoad2bJ59J0vvblY"
    "LHzsC4co0JUwqC+vnDl7ySe4+caXL8zOnT57rhfFvW7SakR531c6yDJEEZGFURjEIVKYC4WdFwa12urp0ye3b9+WHxk6P3vp3Jlz"
    "vhcGHjq2pVx+DdbLzAzXyhTEy8yWLO4AhLvdTrVSmZtbOHDg0Mc//olOp91stjzPQwQRm80KPvGJT4yPj+Vy+cwRaLCjZA1CyODR"
    "dXHcEEWRdQ4Aozg2TsBY8jxP6yxCgZWK4+TRJ54aHxuf2DDVaDTaSwvOYVCqIDgR9skFzqYsy6u9Wn01yOUjYwONLQI3HFTDlu26"
    "6VxvdjG+ac/w9dMlvWHr//4XG+WbXmAxjh0xMAF4JEaYEfo1PAACCUhG4BWCbAQqhIPI78tlBdm+0AYROHN0xMv2pgJEjcgy22oO"
    "ATBNDYh4niaEQs7vGauI2OELeGR9/UHYv0MSiesdWBHY2VyhyARgoJMRGAFKIcZODKtnGdVnIkdAtCZRJK5v9Cr9O2+gB1+79LM/"
    "Z1W1cw6JSFG726kOVTPBfL3VZnFRYgpB/uSZC6kKXJK2LzXOdpsApIAKofdvX7x/ZbXuh3ljjOu1xysFw66X9LIksix3BdkCiHOu"
    "0WxYxxop9L2xifF6s7m4vJwkaZjL5fMFNL0waaeqGifd7HRmljXvMJcpuTJdywALV8r/vd/7vbnZ2eMnT2zZsuWd73xnZsPvnPN9"
    "TdhnO6+srKysrCCg9vSJEyeGhoZQabc2QLpqNKm1DsOQEIEZ2DB7bBkhZceGLj/znB806rVOu9WNon27t87PL6/2YqXAphGKyZWK"
    "gfJNbJxgp922NkkFOkmymHPXj6mqnSuNqqF88aWTjUNLwZHe9A+9+4Yjh4988ZETJi8eRGBiMCJMbJO1qAsCdACSqY3YAl7ewnJl"
    "JlXfu0MA0IkxqDzsP4+BAytSZFEQsw1gHcdxbJ1TiJ4GYJOZdz8r7uTr1u2D0YqIrKNDv8igyfUyyGwMzMy5XGitcU4yM2QArIaU"
    "gDinkfiKEih7aU/HaQIsmlSfC8vOWbcW5305jSurfQfoR1YdLS8tjYyMZMT+dqulNXgqSDpm8fwZb3TaRlHU6ykEAel1O+16zxij"
    "yOu0mzZNwMbLtSRx7Ic5xJRd34ELETNoUislziE7rcJ2ux0GQS6XKwR5Jza1SRTbVltPq4VJr7EIoNW6EC7KIJlBgPEA/2XBS7ML"
    "3W5XRDzfD3NhHEeOXeapn4lmEBGVT5mgU1yj0Wg0GiJEWcTLlUq/7DlkuUOe7wM4McZJzFYQFChAHNhIAmhgTpKhiYmd27fcedft"
    "zzxz9NK5i77nK99rtBqe5xdKxUpqZi9ejDsdYCdgXRzP1Br3bTOetLd54zdfrx84A1+sT+WKtQPHjr/x2+6445Zd7//4Vy4t+0FY"
    "tp1VawkQ2CKAJSRx3M8kYewbkWXP5CqH/YFzGSG7kepQu9NLed3gTBBQYlBOXN5X2fi/2+kODVkd+IHvmW4CcDk+8sV7gw4KLZRv"
    "vgQSAULI5XLOOkBM0kzEhJWAeiwiitYNARCpv9wVxXGEIjZNk4j675YgInpaA10+J/pUiMERm6VI1Ov17du3F0qlbi/q9nrdVlSu"
    "lgKdUlKbnXUFX48ODwvz8vJK1OuC2IxIl6Zdx9YKpUC+1mmSkEDmwIUAQn0YDlA8ReIYnM0VcklqlpeWwFry/DZoSKN37ez+7K32"
    "tz5nDwIoIhykWlB/9/br9oz5wcLCbmR01NN6duZS1Okk3V7g60B7SdxLTSrCivqJgDygfZaLRVIqSrpAHrEDZBHgdW4xa/rsbEZo"
    "rfFzBUFgGrgriBhrENAioPaW682lWs3E9uyFS1GnpcRVx8aqwyORcSu1poDL5fMuTVyckh9gYeRcM4ZmfXfZ3LNBvf+RxS/X9kxs"
    "rRbKxdpy60OfevS+e2787z//Ax/57MOfe/AoFUe8qJmmzEDECbBkpwBkIYR9Dx/OqG/r8bH1jlKZuyvSZcOCPmFY2KCyzHm/nxfR"
    "iyJA8DyvVCpy2wHKN6kL0y8QD/MCBkMCSFkaAwDaxKMcOxGwWQAogAxVqJO67BAYCEGzmJbsz8oyjk5uyBfKnqdjY5wzJFZAGeuc"
    "MwCScehxoJHNegMRIUGbmlwQbJyaPHnqbBrHFy+cv7a0D0mNBHip4fxcuLq83IvSKOo56wCsR5TGCTvHANrP2jcmIbZWwFl2Qugp"
    "7XvKI+WHge95JFBv1ltzyyAWBI0lA94bNq3+2K3ORvqX/iX50vEEAFLn1spWEckcjlEAARSAAaVtxODanVUEqwm9QtEqUoo6qak3"
    "4nrHNlrGsThWgAzIHhITep6XilLaA3IE5MQI40Cl2MfElFIDsEhZZhSngFDYWUYBdtYkCQCQHyqlkCTqdi6cPjG1YdMlmybd7tzs"
    "/MLCImitlU/KQdLpNlZNt+UFnperXoqSk7zvpfuaf/nFM/9W3zmxpZi0GotJUs7nmd2Dj59cWem+6fUv3bVn+m8+9JUaUBDGutc0"
    "BsRZtFYYgIDFZvmyGbwJQoOjkJ/ttIC4WK+jUjDIwQQQJgbSzJA4VeinREJqE98jT6sgCEAEQCFYgRfrEb3+s1l6ov66ZIfnjI25"
    "TOdGHBhaMYuYtB+opr0sIJEEOHP8GgB5IMAqFx49fvxP//B/eloH+WK+EORyuVy+kC/kFSlgyLK0oiha75x6+R4QIaI9e3afPHkS"
    "BM+ePbvn2n2pMeNDOX8lXl7qddstz/cHtDkXp6mvtA6Cdq8bEAyPjGyYmFxeXTl75ow4Iwi5YmFkaNjXXhrF3W4nAScMrW7LB4wS"
    "5Tqd/Rvw5+9NpoP0bx9KPni2yMF0Qa90AZj7qNRgRiED9EMYSbv0lh2Tj5+4qLxQedqyOJeurCyXi6UbtpS8cUMXvvTyzfG+wng7"
    "wrlGNN/otRIHICl4xqbj1fymavDYmQXUgUiKVzFWPM93zgGwMxaS1DmCNSAF+++0QmGbOiOkdCdOe+fPCoJ1RiliNgpcqLzu/Llh"
    "3Xzba+69Zs+uU6dOnztzMlGT88HGT33l7FOXisPX7mg2GkGuoK3lXCDAly6cWa7XL9Zq99x2za/9zNvf96EvHjq3EpZC6K6aNBYh"
    "QAN9+ENA+MqZ99qBe6UkRuu1+MvLk0SF1pF1sPaBLDwhY1dfnWP0DfmZZ73zN1ACPVcatqzp2zOjd+dsn8mncOCBxWttCvQ54AJe"
    "sNyhf/jw/wVngR0o8TwdBH4Y+sViWC2VhoaGlFIvf/nLs+RNa22WTrWGCLXb7b179336058BokuXLlorlnlyuJA2ZrsUELBLk77F"
    "InA+l1dIK7Xa2Njozm1b2NiF2YuLKytBoPNBnpmNuOWlJV95mjQwM1sB1iidFTMxFP/yW+T6cfw/D3f/4ZjXURNeQQXKMfkAgECe"
    "9q5sTzkbLKRxdMOGwo0bw4dPapMke6aKb3rbzjuuGSncec/EzltaB/My83Tc6+R2VEtUUWyJ0xjUueX00VO9+2fV43Mcpe627ZOn"
    "F1frHZcpxZ1ziJK5HllrF5cWkyQBEJcalyRaFGSGSAhZiJjWmkCIMJ8vtKPEmKTXbWtf+36QpKmzqUnF2caWknnHm9988623v+lN"
    "b/r93/sfK43VreXw5KnjzSgZrUBj7rBf3ZymceCRTdNOBxBg4cIZm0TGyL5dU7/0U2/98Cfv/+hXjgalIdVrJ9CTlPuhChnAkMmU"
    "LmfByGUTuOef1yKgoBjBxKzVlv3BaGqy3JpvgUuuXj8nu5r48IK7qj+EFhClSGstFgaUJqWJE6MA12gdly1xCJGZsDjtlVU/KBNA"
    "nInSXidOVjoGZueAz0PauOP2W4eGhjqdTjYdy7pG55xSul5v7N17rdKeE5xfWFhempnaMJUbCqeK6uhy3fdDJJU1tYQYd3ssrDXZ"
    "bmfu/JnV2kq7E01MTKXG1hvNPkFDeUY5VqjEdlMXtSLPc//PPe4tN5TuP5284x8bS71irlgueGysZNHRAMBiEYkFWdAxrHW/wqw9"
    "eustE5860gEpjqv6f3115fjR5LNfPf7oR35lrmvajZpxCgCVGGDnKRwu5fZPhLvGvHu2Bd9/Z+l1f3nxxAo/NV9/623b//qLZ7V2"
    "VtjPNOyDtybqRf3LmI24FESDksSJZedp1NozNs3S9NqtNosQief7qUmty5RGqAGi+TN3vOvVK/XG7j3XPPjQwydOHF2cm82H2y9e"
    "mCkUcrunN54+c/7cwuHCjju6DnrLi4VCcWhkpFTILc6cr5QKpwJ/YbX5hlfeOT4x/rcf+YIOqgKeYQA2ziXAAogKSYmkwDKQvxNa"
    "BARRGQgq/UBwvoJnwIDo+ulJg1pfGJwVAhZ2wIYR/h2RYfCshJhvic10dqdcfj0GYAdgQcLnaFMQRNBZN/jZUVTA+VAJAzOI0YrN"
    "3Pmz5y9u2rzVOef7njH2shMR4erq6vbt2zdNT5+/cMEJz8xe2rZ9KwLumB46dH5Waw/ZISFCxkpkduxpXSgWer1Wq90sFsu11eUk"
    "tUEuF/iBsdb2ogTaCr3U5SCtf+e16qdfE86u8I9+oHWkDpgrewVKIFEpCaAIqywAOFOwrZtPaa0T0zPW/cSrp/O+fuJSElTCY2fr"
    "H7y//JmjeGCRoDdTyvs//pM/fdedd/zBH/3x6bMnFxYWXaSacXp6KQbAD0yU3nljeKkR6Xz10ROrb7pu76uuG//S4fNlFOWFwmaN"
    "0hiGgVKULShnrUkTz/dR+yhiUpOJBhWqbGSG64xZ2VixRlABYKGSr5TKaZru2rnjb/7m31brjaHqEAp0Oh0W/spXv7r3mj3XB3yx"
    "cTG36fp2u95q1qxJhoeHquXy8sK8M2ZeB2fOXHrX6+/8rZ9+2+/+78+vtL1AU9JpAnA2F9GQbhirnF2qZ30tADjyABTYHniauJ9P"
    "AFc0mZlrHGjkcICNZlBbljdDhN+kM1z/MV6JJzzH9PdZ7opXBg7jgMY0MJ1dR/HzNIJYlOe0K1ICBKQFlaACUkAKkLLDwIFnnWKd"
    "P3HyVGammf3rtQAvz/Oste12+/rrb8jg53PnzjJzs9HcsXWokgtdFpXuLJvU2VSsYZsWw1wvjhdXV/Jh2Ou2k7jneyrwdK/bjntt"
    "Bx3ncmnD3lBp/8P3VH/yZfS7nzXf8w9wJPbDfI6QHAuwBTEgnBlwwbp8q7Xuigjb7d5kmd5268ifPtIMhiZGR0Y7ufHf/Ozx6++6"
    "7Ud/8LsBOCxW9l23/4677tLKTyLrjACAEwtgfusdt+0aK/+P/3sR82OVcp78wocfPv3Dr9hU8LwoNhoFia5mevWtI4HTNBaTeiAE"
    "KI6tMdYmzEbEsjNsU7YpsgWxzqQeiW3MbBkrdTrdTqf7a7/2a4888ujc7Gyn08nn88NDQxmD9cknny6U82O4Ei2dDn2NCN1uq91s"
    "FHN5ElhaWFxcnJ+dW/jQJ76y2u796k+9aed01Xo5VSiADjJTupjU+ZUmokZQiDrz5i4q3ljNaWZBAuH1YEwWhcggwOgBewjiZJ3r"
    "SUZllvUy8udjAb2wURyuT899ThvRZ32JK3JncTD/JpV5OztrBymFHKU2UAioZR0VdM3rMwvZRAJUJIhOgEWAHQgCEhIKEpQrZy/M"
    "GpPm8qVsXJrVUWtz4oWlhRtu3A8Anh9euDC7tLgc9+KhUn7XdNV02tbEzhpmtklijUHh1drK6upKPldwVpx1iOJM3G4vCzsfyPV0"
    "IV39z6+jP/2+0mNnet/2F/z50xwWwQM0zoBzwIzOoQiJUwhZXzbIjSMEQHGiKI0Sa80vvmn7xw+0z9ewWPSt8IbRaj5frJsgF+ot"
    "k+XX3LENk5WnHr//1Xfv/8HX7fuReza+8/bpN984smMkVwyMUlyp5DZOVcgvlCrVp86b1U7nF968rxd1e93W2puZjUT6wiBBZx04"
    "AUFrnXOMApkHBlvL1pIIggg7dtZZw6lBZrMy85JrJv7DD7x77969f/qnf3LnnXfm8/lrrrlmbGwsYzdlE+4wn19p9vZdt70xe5ST"
    "KPS0Up4DNbe8srRSi4zxULwkmluqf/hzDx85dPyX/+N33nTNFkO+XxwG8sVTrEKrAiACBEEWQmDne2psdEIsK+D17TDiGvmVGRwK"
    "a3LxWqijUgJCiOyk7zYC8gJL/1mRp1fvh2+iBMLLmzCJ4wzLD/0+iytKISzQs8qzy6mjeLWwDAQQiPriMSaVLzVmZxYXF0vlkXa7"
    "g6IyQXBGl0DElZXla665dmx8crXWbLc6x4+d2Hfd3iRK9m6bfOLIOfaKji1AH3/o64NB4k60ZqjkGHMkkUSuy2+6Hn7pDZsOXmq8"
    "/c8uLjSGVNnzwRhLnDH52AKi0hoEhA1A35oYCYUZ0SE6T4siuNRo371vZO/2sV/++LmhybLnUkFI05SVunjwyR/Yuae5d+rIuflf"
    "+aXf6CVJoTKsKHatVpzayeH8a7aXbxhK/mylrfwCWEegUNHIpg2///nZj/6nff/4QOHsUjyVL2agykA1Qn32gYD0UTICYpUV30Qi"
    "4Jglm7ERiJOMikLibHPhbW/+4acOHLzv277N9/0DBw4+88wzaZpOT08zcxCGzVZTRMIg2DS9sTI0antpbXm5PDRUKg9HidmyZfP5"
    "8+dajYavcNOGjafPn1cAh87WW+nB7//Ouwraf+Dp07pS5K6IMUKZM7gAYGYlWI9s7cQ55WsRluc+nkGAA4XFYj7iRtYV53I5EfA9"
    "L9PW4L8DuXk+Z7gXSaW40nmrX5FnBEYRKZVL2Q3gHOU0kUQshYz5/Zy+jettrPswQcbOBCQQx3T6zOnbbxtPUht6ak0Qw8ye50W9"
    "FJFuv/22z37mM6j8I0cOX7v32qjX3jBaGSt5K6nF7MQBlfUczoowA2f+RKIIGThqyJaK+c3vyW0ZDn7lk3NfOIwUjhXzkrokpTxJ"
    "hjGLAlSkUADZWWdEkGDAKe97MSKh32v1NMb/7+uv/52Pn+/mhzYEOTBtYlHspidG5+eWf+V9M1PDwfe9fv/2V/7E+NhIKT9mxdW7"
    "6eLcmUuf/5//9sj5X//s+eWOTEzlnQUfrVIQBsHcXPgnX5r/9bfseNefPdPutAuFIoAopZTKEsXRcZYdm4nLkPv+AVns8oBjnHkG"
    "Z1Ajkes0t2zbgEgg8u53v7vRaJw7d5aIkiQJguCZZ54pFgqe7znnTGqnNowePHAMw1FQ0Ol0g2JVE87PXBwfHVleWmo2WwzoKV2v"
    "1UfHJ46cW15Zqn/f2+8OQvm/Xz2aK3hpt+GEWTIfUAJ2Gf8H/JDB9R/gGgtobckxglDgmSAXRDbT2mAQhACilLbG0poJyIvGMK9K"
    "dflmmuCB8omUn6SdTMpfLGYbABIDgScEzgoS8MATDtbXzM/W41/uS4DBsKCqjD740KM333KrZWZgZuFBiBgRkVLzC/Mvecldn/3M"
    "p4nUpUszS0tLYyPVMHA3XrvlC4+dVrm81gKCxrKzjMxCCoFBwFM6jQRM6z++3PuxV1Q+/kTzB/+xbijwqiE4E4vPoslayXi+Msil"
    "YUYQESeCMFDqkEJSOR/zqeusNDu//B2bZpY7XzzmhqbzNqn55IfaeUS5wBvfs3F5uVGt8o9923b4tu8Am4BDQAt+AHRrpL/wmccu"
    "nkkLu7eUU3E98UICJ86kaWV46O8fuvSuG3e86cbxTx5YzIU5Ut6AGHJ5CWDWDYtjKzTgaPTZ9f2F1TcNU0q7OHrprXcdO3Z0ZWXl"
    "j//4j51zfX4e4ZEjR+Ik7kXR0tLS2Njo8NCIOHfk+Fld2sXCALK6vDQyOqIIrYkr5eLS8mqURNMbNor2Tp04vmf3rplW+oFPPPzt"
    "r7x9qJD/588/qvNF7Lux275fsXMCTgYWKH1TNLiirxVAYAoVmiRt9iyAECjtaQGwznSiHqmJ5zy3v6GBwDdjjtsP5iSdb3d77Cw7"
    "Cfww+9Ry24Q+e1plcmAQhj5pXET4Wb11X+6RJZIiZFas5GLXXNm9Y3cpn88mCdZZJ7xmLQiAiwuL05s2bpzewjZh5meeeUaImt3W"
    "dbs3VELFlpPUpCYRccJOEAmcltRnTJvpTZP1f/2P6g175T3vq//6Z7QtVnUutFasIKMVEEGHKCiMIgJsxXJ2dg2kmJkBHaAg9PxQ"
    "ltqdXePeG2+a+vXPd8OxYZZuoMK8j0FAfgDijMVk59TQttFCo+OSyERxmsbdXuKSyCbdTt3KNRuru8cKIMZZ1iQ5D3NKQJwhUylV"
    "fv0zyz/z6qki+a24pX2QLEKqv24Gd2k/HCqLGWRmFnHMjjO4WTiLT0MRgXTD1OTjjz+2srL8tQfuf+973/u1B7929OjRCxcurNRW"
    "jbOZJnPm4kypVHz6qYOREWbLaRL6WrGtzc+5KAKbakIlDKmpra4MlQuEbn5+JtTq3Erz4198/M7bdn/3d74MMKcqZeUFpD2gfsga"
    "DuKy1vsli6wNgiULHi17CoxrdBwAa+35QQCIjlxknPIDYcEXsfrXG/o/i4lE6xGMF4iEed4+gEUp1Y0TBgBwxVJBEwFwPaaKJwEx"
    "APcd+9doHleiSv1XYQF2yA6cJY+g23YrZ3/8x979/d/7nnOnLgU6yHq+Z5H+kiSp1ep33HG7iNNecOb0mTiJU2O1Vrfu28y9JqFi"
    "t0ahcYEYY8Ik7f6/r47+/m3qkwd6b/prd2Qll6sgsDh264PIn12qrQN5cZ1sVVgrR13HSSv+zbds+9uvLs41A8x5AMoJWgFAKeWD"
    "QoBDWidsfGVzQYHIeiCKAq0UkUKRPHJALrUmr7EUqIIHnrakLIr1Wel88cEz7SNL8S981/ZeE8Qa5UmWUA99AHGNag5rYMNa4JT0"
    "U3eQmQWJO/Xd2yc2bdn40rtf/uM/8VMvu+cVv/qrv/pd73jH/v372fHs7OziwmIcxwhASjUbjaGhEfTzQATASa9bzPkaYHVx4dKZ"
    "02nUGxoeRsJup7M8Nzc5NtZsNY4fO6KcuTC/+ncfffS6fVvf/aabRQp+eYT8HGZW99njJYLMMxfWa8EGpTUKAA/nAcC2YgsAnu/l"
    "cjkBYCdRbJXys5V1tfft8xF8ntUTf0vs0QWVTowTAGeN73mepwFgtecKnuSVrLvU1qBTXO/+ssZ6J2EA0Yrswrkxf/n3fvOXb7v1"
    "tseeetJpEXCOOau01+/mMMydPn36+uuvD3NFAGm3myeOnyzk851m/cZrto5U8pwYpRAzxBt01DT7h5uf+359/Ri+4S/TP3us6heK"
    "OsAENfIV2uwXvkbX0E8EBA068Gcu1t/5kon88PD7HpT8UNGlZAUtC4lUwrDk6aG8X/Y0oJRCT6mAXSJsAPsOBezYJykFRCTFQOWU"
    "eOgUYKDz7NA66UTkVcZ/7V9br79t8ubN/vJK7IfFjGkIa7jgs6O2nuMUBACllVu5+P3vekunE587fxEAz549f+bs2cNHDlcqlfte"
    "e9/tt9/urG02m34Q5Av5zVs2K6XEYXZWmzSJuh0BZ9EZsRcvnkvjeGJiwg/DdtSdnbmkjJHUzp0/K0m33Y3+4eMPTW/Y+tZ7b4xT"
    "5+fyqDSsc3FCUkJK1p0sV6RcCFdDFuGuBQAoFPK5MGeN7bQ7cWQ9L1ifJffvs0mkZ1lifaPllLBTXi5JXByZbpx4np+RcBbaKSo9"
    "nENgdJlFJAyypvsGzf2iB4VRHAMIKSXOzBy56/qNv/s7v+UF/sGDB8LA9xQ6Z/pQAYIgOGHLzqTWGtdp94qlwh2332pNpIPcE08e"
    "aDfbACRi77pxt5gYyPcUOuu41/vFe+Wv31H+P0/H7/5gdImrfolSkX6kMBKCWg/XPmvoMdh2wBkJXeWyZ+l7aAwP5dIff8PWX//w"
    "Kc5XU/SVMcKEikDRSqPX6UYkljSL4LDP7ISTWEAJsQATuNS0AWAkJF+rnA++rwSl3UtakWg/AIUgjvzCcrf4Bx8/+6vv2GnSqNXp"
    "iTgABvBEJDOD5zV8bm2unzFSsB9CKiycpIWR4X37dt9///2veMU9udC3JllaXmo0m6fPnn744Ufqq7W91+4dHxvL7Cc2btx46Mhx"
    "8gMWm5m79aJuHPfYGiIkBY36UqfdEUaTJEkUxbFNOk0XddIoBtdrt7v//NkHd+zd8eqXXmec07mCaBJFoD1RHqDngdLCKECAgOD6"
    "fEJRDOB4ZwVaBho9CwCVcin0fUI0cZwaB54n4uTKKuY5bQ7xql/wrQrKFhHtBZ3E9jptFi6VypVKBQAWOww6nC44YEZ4DtPFgZ+R"
    "FXDAogE56dilUz/yg2/9mf/nPx0/duLCxYthGDLzmlg28xVcu9/T1BhjgiBYWly877X3+X6OkFr12sFDhxCx1W7v2bVly2QFo9W0"
    "C7uK8afe427ZoN78/t7fPeX5lVHyPTdg6X2DpwhmAGQfRnDU6bV/4217vnJw4fHz5BWLwobIKTGd2F1q0UpCga80GMscEk8UQOKu"
    "S1PtBQREwohsu6vG8cYRv+BpD8QnynkeC/ZSGxtmFlTCkuRLpQ881ktS90N3j83MLjO7rE6AK+mQz1IvrYumZUXItYVX3nNXs9UG"
    "lL3XXru0tGSM6Xa6vtbAkgvDRqNx7ty5iYlJIsrlwkaztdqIda6cnUF9zQb29UqkCFFM0mHTtUkUR71yqRD4nrDrNhtRpxPFPfK9"
    "z3/xay+5/bbbb7zOifJzZVIBkBIkcFzQvH1qHC0LDWJ7EUiQEYB566i33MVO7ACgOjxCpJRSvSiKDaPSL3IY/AKJkd+CEkhpLxXl"
    "jMnn86VSeXh4BABWY4gZNhVTyEj2IFc1G9lORxYiTdy4NC6rv/Vf3nvrHXc8+OBDcRx5WmfQizHGGLuWEpnJ5NeM9rXWyyvLlWr1"
    "jjvuTOOuDsJDBw+2Wm0B16ov3XTdLpt6370v+eh3yReOxW/7kJ1Pil4pZ1mArQDB81iAXT2mGBwd/W+9z9MmqnfTa0ZxzyT9zmda"
    "amTKpSmIY+0rTyGQNWas5PkkkUMnUArURBE57lprETUAITOzdd2aOJgcCvMKNQixy3nKCnRjExmOjdFaeVqxYl2Z+JWPzb/7pVt2"
    "jvqJEdB5AI2DBuWKE+5ZLpfCKE4RQtx+5Utu/epXH9i3by8Rra6uxnGMzqZWGYOFQiETLp8+fXrz5s3VauVrX3uQimNWNAquzWm1"
    "Up7vZ3K6JI177bqSlJ0B4eWlxTDMFwuFpNey3UbRAzDR/MLiP/3zp2/dv2/35o3MnvYLQJoQQFHP4oWFZdCEAsiD+hhJSEDcZMHM"
    "tTnrdYeqwywsIvV6w4rCLHjuRTvDPWeBQy8C68FnWaRc0WEIkCKWXBR3i6WyUliplAGgFdvVXjpdBrA2W2WC68NVGYABGRm0KNdY"
    "2jrq/5df/f+xyFNPHfQ8P/MGzEgs1tp+G+fYpiaLnnbOaU/5gUYCrbyTJ07ee+892tMAHEXp0weOEMD52WXlOu//vsoP3RJ93z+7"
    "P3m8QpWKptgMZEfy4sSf2V4TwbULgxFYEQAmCDqk975u0+98+nxXj6EKMhTegbKMmqSgLdukFxsjFIDzicoeOlHiTMoxcsKgbRw7"
    "G4uTXMEPNAoSIjdbXU8FY8NldlYjETgSC5L6oX9q2fvgQzPvfcueJErCIATKQtdArrKuyThmIJz9r6AySTS5dXJ0fOjwkcPXXHPt"
    "ysqyieJ2N1oxdNd458duNp0kRRLHHPXiVrs5XBmqNwHCsoBl4rVC3VoHwgTAaYoCABRFqTjLnBoXLS3PO3Zj4+O9Xq+5vNheXvQE"
    "5ucWvvzVr732ta/cMD5qAFFrRA2kDGGCipUHkEWfZkFyzEKgZaoYnF3tu2QPDVcBOAi8VqcBXgiEKBrx6wM2z6IyDHhrICLf1A2w"
    "VksJBUsrKwpJhLMSKE35YhO2VDW4RJ53VoGCzkkiCqI0dcyrtVq1XMzQfmNMmqbryEWQWUKkaZoZT2RiLAAmoqWl5SAMXvmKV9kk"
    "1oF34tSx4+dm9wzHP73ladNdfseHc0+vlnTVY2cs6Axjlhc3QXlucAwAQQFIu8lvui64sNT51+MFv1RhcEAKiRCytHkOlIp7hp14"
    "gCSoyZVCSnVeFHF3FZxFZGNjVJopLGn0fOWjE7GxxUbkoiQtByqngIQ1ga+V5dQfHf/7B2sBxvs3uHav93UN0mRNu6eU1Jfue/XL"
    "FxYXc7nc2OjI2XNnV1rd5Xrz27eld0x2K6qbNOupdUmaAPDExESaOghKSAqAAQT7ijPI9NPADI7ZpMLie34uCME5RBBwqytL7Waj"
    "UCguLS4uzs03Gk0/zM2v1B558qnXvublQ/mAUQP5iESZijqj0a47aa3ooYA3FPWZpW72Q4yPjwFIGAartRp6BYRvwS96kaDn85GC"
    "svNRhYXF5VVEMMZMTm3I/sXpuuwcUaCc4wzVWhMEXZEMzgK6ODY/s/jkE49Nb9oUxTFcMRiWtfD0bKijtM5ME5IkSZI0A/vCILhw"
    "/vzdL39ZtToENrFJdI079fPXzH3qfOG/PVSYmirnc+hSh32drsA6r7UXlhE9lxsAgGSAnfaluXTo3/70K7Ea2uBcxlLJsoWgX9Cy"
    "qZa8nE85JdapXE4NlfweegxgGgsghGKjqMOA7OVzJjGpJaJc4Oc8SlOTppYokzc7AmYBcchMtjz9Ox8+ZRbP59CBUAYt9nfm2nuU"
    "yfW5b7iUZccipK95+UuefvrAXXfeCcKXZmfOXbgwpeov2xlcnJXFTui5Xq3esTYNc+GePbuPnToFfm5gab5GwVhfGgoIuzRJ4x4L"
    "h7kcOyfOAtuV5cV2vT41MQVKRUnUadajTvPQ008eO3nsDa+5N1AKtQ8qY0PS2hhYBn4q4HhDzuQVn1pNAUAprFarmYfk0tKqDiog"
    "DOhezAJ+DnO4AU5G8PUM0F9gV2Sopjinc5XllRrb2Fi3YcNUdvOemOtsGpJcAJmhE7MVtiK81g9IZn2EikVjddO/ffURYGucyd7F"
    "tYV+OVwaEQF8rT2lEcAYE/WiNHXiLKJXb3dMN33L299hHf7Gd+z8rl3wQx+pfXZmrFpUO7eUbtk5AYkBQgBBzlSa2e/1tQNnd4Nk"
    "b3R/q1z+PfjmEUAJONCFeOaBX/yDTzX0dqUSQYvIWqNGUeIIhEhI6TgxWomvnAWXUxgqMuSZOOrVVwERxCXdNju2XjEnxjrbSi0C"
    "FnNYDjlQZG0qLD4RCLN1wghsVKFwopH/w7/8h6GgnWHRKADCzxWXnn0akIhb9b37diPy7Nz8rbfePjM712x12q3V+Xr3k8+0t22C"
    "PFARMOp02fH27Vs95S8tNVWYE3FIRKgGHEheXz+KALNF6Dt6eEozs3NWKWi3Gs3ayujoMCFL2ra9NsfRkWPH55aW7r3rdjROe7nM"
    "ODlLJ8cBLImIYHm6Ihbs2VUHwOVSuVwuOQcivFxv6kJZrAgSP8/M62r65nMu729FTCo7P19ZbXTjbsdaNzExkc8VANzp+biYU5vy"
    "DNzHdDNh93rfqMwbg9no8ujFmdXjx09UKuU4irTWWukMc0jTNEkSY0zWFVhj0zTNiPgCyA4iIWs7uYDPzVzauHHDh370uh0Vfvv7"
    "Z794YC4fz2+enjKWpqcre7eXpdMj9ARTYCdyeQOs/90fSAJnCb1X/YXB8WFB59Qf/NlHP3Y0pWrBgGIkJkawCgXFKXAEgCKEpJUm"
    "rYRcNUAxDp3z0Uq3DRpRKUk65FKX2tBThZxOjEXnygU1XtU+QeiTR1nYsSgUUMxaGJiGp99//8yBZ87rXN4Jg+Pna2qy7DVNCnr1"
    "t3zHa8+ePz8yPKqU1+50K+Wy9ry25O4/nvzCV4N/fqZmmFGR9rydu3YePXqSVRGym1sQGPCyVdGVkx0i5yw7Z5JEHFPGoGKnFHba"
    "zfriQiH0S6UCOwuCLkmePnhQab131640SUn7iH0vmcs7GAmsu25D0AVvoZECcLU6VC6XAKgXRbVWHORLwk6AQPAbN3Qb/BhZD7DG"
    "Gn0xN8izdxKCsAR+vt5J252YmavV6vDwMICcXHEidN2IAQsDLz+67Kp7ZVnlgDA/+pUHHq5WqhnHWNhZa63r54qu+chmI3pjjAAo"
    "QgBU1nhoY6kSdF5R/z+FYvl7P7ZSN5zz3akzZ13ChdCr1Zau3TF+zfQId7t98XVfcXG1zpNBBFnwBSE2BKucOtX0qTIBBEqRIlFi"
    "R3IqIBFhRYAiPqUbRzwPnWPylTda9kwvhrTn2Z6X1IREPN/rLfsmkbTrhTpH6WrEpL28rybyik2MAEpc4ClNQOACjYECnwQ8Touj"
    "S0koQZAxRdaIVgNGMV1u0gBcGg2PD02MDn/oQx/pdjs/93Pv/exnPnPi2LFCGI5WKzmPsFN/+GL9YsQEUq1Wy6XKiTMXVWnIycDl"
    "fM3XaiBdX4+si4gziTgrLkUWDxU4cc6SxnarUV9cBIFioSQivW43ieInDzw9tWFyw8Q4A5DnC65dr9kXZ+B0/4jMtKidOACYnJoK"
    "c3lC6LTb7cgFQUEgzdJAnxPeuYK6//xjrm/BDQDC2g8iq2u1mlbk+/7E5AQAXGqmtVa8dxTBOAQk0HilLHr9fzCLqoyeOn3pwrnz"
    "5XIlTW1iXBTFJjEIEgZBPp8vFPKFfD4Ic85liAw40QzCHjaxOEVL/2HLya/M5t93actb3vhacKlT+XYnevKJJ9LUgdPNevu6PeNT"
    "Q4H0OMuqJGGSlLJgWshIeyCCwryG960/8NaOVASxlJPqFhrZwegrdBpdoCzE3V2bp4ZCCpE1IjtbyelySKlJrAPDOFIgcMw2xU7N"
    "T9ugNQCp5pJ2EcVNcWaiqho9rndNJ0o3j+Y2j+WNSTKPNUWoQEJxIZsQwAMMtOcN71TlMUJHCnDATc3INBmNL+PVKCJu1W+74ZqD"
    "B5+a3rw5CILbb79948aNIHDyxMmjR46lzigv8P18HCfOpls2b15cWIwih35usJb4eQ1IZHA9Cgg7dk7YIrACYGetTQnF2nRxfs6Y"
    "2POUQkzjqF6vHTt+7NabbyoUSqIUZPPggcSRBVDznmE4fKmeVesbN24UQc/TiwtzRgKlQxgosL9ZRdgL3xcvoKkZwPmMCJYKy8tL"
    "nucxy6ZNGzNC6JllvmEUQRwgIiOKADsUwXVbQQCECJCZNORGHnzwoVK5kJgUgLQfVIaGCqWqMWb20sXHH3/8Ix/92L9+4QuFUh4V"
    "AXooPS1JGueuCy6+a8PpL50uPhpPdhsr+/fufcUrXplG7SBfmJuffebIkSAXWHb15tJt+zePl5SkmSefZIpe50gYABRxdhL1lQ5Z"
    "O5BttgEgigiiETSK05oJPbQKUREigPL9h5482Gw3c54jSj1KxcRpKglTYrmV8BClosAjhKgJpg2ixKTUaYjrqsa87fQ2jpZ8rZbb"
    "6YWVuJNStVpME4OkHDsE9jSVCv7UaBnBBMRIyMohgAJLiIQu44BmpS0KZ7eZCCATQnrD/j2PPPrIho0bwzC8/vrrp6en3/zmN7/l"
    "LW/59je+YXp689z8AiIohDAIt0xvPnHiHOaqTpCYQHAQaCVXoyIifaadXIblJU1jQCYUAhC2IJYIOu1GGrVzPoFL015ncXVpYWH+"
    "1r17nTWk/fUkK2YYCtKNJThwMclW+fj4eBqngnzm7DnKjQgCgELBf7cvEK6J4l+gD/66WUuAfUEb5coX51de7vvW2G3btmcb46lZ"
    "+6b9YY66CVcIYgF9GUyA9TMaASRh9sqjh0+evmdpvlAI5ucXGitLS0vLcwtLq/VWnAKggiAP3dlt207v2nNN3G4TdpfT0m3Fc28s"
    "zf3vExPPmEregwTooYcffv3r77s4c/HMmfN+Pn/65MlCobBx06ZurxWn9Vuu2/jY4dnVXgJKucTm0Xiesk66EQIFXkD26mfq3MCg"
    "zQEyZm0lOwQmYS2gQAiEPPH9IO+hMc6laTHQFvRqKynm/HbEYqPxnHbgSAyzA9eVtMcAKmlCOsImTVM3lNMxS8tAynThUC1lCv3Q"
    "Q2YkJ0iI4myaiKfQZUG5AgLKMQgCoQJgEuCsf+877lhAZTu1nds2EOGpU6eLpUo+l/+Lv/iLrVu3njp16u67785M5l76kruWFhdP"
    "neldd+1uIjWz1KTyJmZgUIJ9c5/ngMswE0UIEuGVA+m+EFlAAMUxi9Va2TRpJYn2AytO2Bw9fvT2m2/ZMTV99sJ5ReQYABhRwPHO"
    "YZv3vIPzKYDyPZyamkrTuFCsXJpdCvJDfbgIr2IYvLhsvL6pAXyLRPHOOb80Mrt4xqRpHCcTExNhEMRJ8sCs+eGXmk1lczIqK62+"
    "znYUZPQlHPrABz6KSLXVhhMP/Bz4OSxuVV6AiIAK8+MPP/Tkxg0biW3DVF9SOf+q4cU/PDq+gMMlz5jUeAA9Yx986GtvetN3/PVf"
    "/02nG3lBePjw4ZznD4+OtJNIU/26neMHjs0iR7ungx3DoacRhdHKkzO9Z1Y1hnkQC0AAA62quKzmVcBaUTYDAsrI0tYDCDwfxPoM"
    "vtbKRCUfhquhBrfaTpcanDho9KKxgCcLZZcYQivi4qgeJj0m7Xo1TjYy+sJuPLCEnoAICWk0ibS6JiQpF0Lta3Ti0sSl4ukcWqPI"
    "A62jxEm/Ks9UVwovm1QjiEdaue7SPXfevWl6+od+6D/s27c3CHMry8sf/ehHz5w58/jjj7/2ta/dt2/ftm3bHnjggUp1JB/Q0vIK"
    "i9aeQjYC9HXBEuzHP15hIcXMBNg/6QCQnTNMnmaWJGZBBXHCgE88/cT+3XsX5+ejNEsWFAJwjm8e45UEjq1aADc8PDE6NibOsrOL"
    "y41caSczw7diEKCf76R/sZBotveZc/nRpUsHW/VVJr9arY6Ojs7MzhyZjVhyN0x6J09b8ElEZW/U84jZhAGoNLnSXgYBf3gU/UBI"
    "Ze1WFjguLF5YaDf56Scf2X/nq/fgsVeOrvz54dE5UwmViTNox0noh41me25u7u1vf9vf/93fI6CAevypJ2+97ZZSuRxFkXDj+i15"
    "X6uCr8mzTtgZt3Uo90s3Df3Zl5e+dhao5MQohD5BN3MtRITN40MrtQajJjCSSS5RsTBxktOMGk0c33dd9d49FRJmEzvwvnyq8/nD"
    "C4q8ibLnQ2Kt5+kixy3brps0YqBe2siZKEEvkbSokiK5lBBElQPeMaRKPiGqbgzn610OQk+BAw8FEVF5SmkvSVJQyvIAqRWbRZRC"
    "34VbJE5KlfKWLdMf+OAHT58+/b//rlsoFoaGhsql0vX79589d+7jH//4hg0b9u/f7/tevV4f27X5occPUa4qFgEVIDxXZOg6i6v1"
    "HKn1FjiZcS0OLgZhELCGBRQAaw3GdAFN2pPzF85u27b90OEDikBYlChj5NZJ//xir9kzALBhair0vB7jyuLiSjMpTVaE3bM6WLw8"
    "aJIX53P7TWqC1w90RXw/t5TC0vLq5MbpUqGwdfvWmdmZhWZytgav2EQfOY5CFhw9346SgSrIMajSGDAYyTjSfQqFDPj3zqZqZPuB"
    "o2dvmH7sO65p/fmRoYtxOa9MYlXmJCAsLJzL5ebn5zdv3vzOd77zgx/8Jx3kRNSBg4f2X3cdo6a4vaHiN0HXumlTbBx1USiODdjV"
    "1+wZurBUm02LChMRznrirAYgVPV6KzGWFBA4jZCp+QVsgmASv9tpvGF34XX7c3HLkcfOsU/Jm64fBhN/9mh3y5AfBN78kkk7/ubh"
    "tiRdm3aYFcftQMnJJIAEi0UYyeHxOu4ZlrfdNlHy2AtUtViSuH1k3n7sqVqTUWnU5GKmxJooTjWSGyiKQLKYxTU/WiBAZ+JKNf/I"
    "w1976KGHJicnS6VSFEcXL17M4mU3bNiwb9++AwcOnD59evOmzSurtS1bNq7UOro6xvJCKdRf14d5UGZccW5m4k0iYuuUpjSOPC+Y"
    "m7lQLQ+NDA+vLs8qsimrnB/dviX97NMm216bN28RAc9T50/PRhxWg9Ak0fO/+rdCEfZ8A4Xn+5uoiIPyhUszuTAUka07tgKAEXny"
    "kr19MgbVJaNwzRXsub4UEwqhIAojiyAyIDKQIAnigO+OGoFtYdvY8Pdvan1kpnq2OxFiL06sMcb1VeECAkmSeJ534sSJYqnwlre9"
    "xURtIuWcHDp0pLa00I3iE7M1a1yt0X7mzMKZ2fq5xeaR+e6TS7qdxPu25bi+apPIWQa2KA7EMTgW24xiK4qdRTYIDpjFxuyk07Cj"
    "fvfNN5TvuWGs2VE9UYl46BWaJry4HG3dPCa2E6LVitqxaySIpiEsxiQm7mLSJjR1GOmmSol0jc1J9KOv3FbIqeUeWJdDBkv53dPV"
    "99w9NazZ10QKQCyIVQoViBLWKCQOhbPfBP22hMFSGM4vNBYWViYmJqx1cRy1Wi1rred7nufNzc098cQT1Wo1l8udPXf2hhv3X7w0"
    "LyrnSF3pZPg83s7PxRZbR8V7zvOOQZyIdTYlEJvECO7s6WND5bIiBNGcJrtLyXRe/u1ikn0D09PT1rnAp3PnL6rCqCP6euSPF0GM"
    "W1OEvQDx4fkCNp41UxZCYQ4rU8dPngcx7STasXWbJgKwD57tbS7i5mLPGU39JLV+UUiD32sYSz8aJLMCQ8IsbF3651q2tAUDNLXf"
    "f1P+8yfanzhsqp5p9VJrLTsLzjljjbXWOWs5iVPfC55++unR0ZHX3Hdf2muRQuPc/MxMs91s9JKZmcVaowOIoHwQ1+lFZ+aaHeOP"
    "F+imrebOLTIRxGyA0CkRAiBIfe1EOOmZZqfbisE4YbA2kVdt93781Rtu3jLkEzaMfnqm/sVjtU8fXDy+3DOeh0I379g8XiLnKHbM"
    "iGQcCGOacNx2LlVpPJvqZmwZ1JBvbt4+HDnd7TpCmmtFF+p2sUcn51aHiv5wJbdQS2bqUc8gITnHjq0mEGHLjMCaxEPW6FSW0ZgV"
    "5/mR4+cWt27bighxYoaHq/l86Pue1jqXyxWLxeXl5SAIb7rptmq5cmFuFQsjIpwJC1AEBVEI+XkBkkHgSsaxEiTBvk8pgzCCIMg6"
    "sirI4M0UcSIWkaO4XasvlSuj4gQc3zrJkcGDi10ALIThpk3T7JiQLlyYDcqTYhzKc/Eb1mb2ay/5/+8SaG2vWZvmSiMXLjzTajVV"
    "WN0wOT0yOrK4tPzQxUir6ssn/H88Y/3M7u7qfuPKWnJw1NC6Vm7gp4Vo2s3/dGeUtOzvfKVRrJrrdk0mFpEcAbhBvFKfAsMsAIEf"
    "HDpwYNeuXa9+zbd98UtfVn6OnaRJrL0gShwDAjsGUkqBUlHKtUZranx439ahqg93bw8++EhjLlG+IsPKI83OblCt4WHr55Qzcq7e"
    "bUtp70T8HbduaPZsz9jIeodm64tdm6RpqFEHdsOIzlN609biLZuArTQN+AASd8GmmHQ56qJLJe7Nd+3W1DqTfNveiYtpPklaQYAL"
    "LXzi1JIOCr5WnuuqoHjzFm+oaFpNfapmllLP0yTWCiuwFkWpAcaGmdl0FlOHgFonMnT45Pz1e3Ysry4vL69qz8sFIaGK4ziLpl1c"
    "XNy//6ZWq9NtR2p0goUBVXYqXUaVrjxZ1wRZ61Ij1gnG14XjPmdpIgJEmU2EBaRmfXVoaFj7lPb43k14qqaWWwkAbty0ZWxsPE1N"
    "o1a/tNTK7xwWmz6f/fM33AS/OBvQZ7mhrBfmQsZiZXBeWGoaf3m5tmXbiBd423fsXFxavlQ3h5p83y77jycihvzVkk0ceBlf7Ul6"
    "OVu8f82ATXnvaO8/7Azf+KFl7ede9tLbUyENLNAPVM08IxDROWudIyKbsqf1Mwef2btvz2vufenDDz5SHR9htklqkLQDFBGtUQB7"
    "cVou5HqsHz0xB6KcSbdsHN4zlV841WKVI7JF7rxmX/X6DVOSdlSOh/KVCysjf/eV2e3VfCK8mnoC0G7GJ+Y7zYRFbKA1Ak0Op8N5"
    "7WMcaExBN1I15JA6yyBMaQeilk57bHqp5BIMI0cjYXQh0X5Y7XTTrx5fWk7I63adk3KORuru9o3Vat63E+pVyn35VOfhS4a9AIFz"
    "vkpjTp0opTylRICdE+7DDU6YPK9rCo8+c27bZHnn9h29XtTudJIkttYmSSICWnvi3PGTpzFX5EyqN8jtWjMmE1HPIxDtExvX3sTL"
    "YdSDZXl1Plfmzon9btk555qtOqigoOfvmtb/cMgwE4DdtftaRaS0OnvyfDMNNgahMYkAXe0tIt+4WaL+ugKC51TKP+uDIgDIiBry"
    "E2dOn91zzbXOmptuuvHhhx8GUJ8/Hv3wbZWcx1EW4PYcZ3+/KMoSAtfDaQBA0K8mCQQS+4uvpQ+dbp5bhdd+2w0CUKvVfUQ7yKjL"
    "JGPOOWuMc06UQgJrU63V8WeeLgf+HTdee25+secIEay1QioT11trrZW413ugtpQy+sr3fH+5e3F0ZIw0Omadtu+4oVwp4oGLzbJP"
    "e7YPO+GtY/DG2wtRz3v0UveZMwu+Dgq50AppZPLy1jmbJjmFJxc6S0urL5mqrkZuuWcncgGbRHEqNtWmJcKei32/stLhzgi1Entw"
    "pjdTtwx+bCkXaEwjEYqYLizWRzCvlSceMtGrbpq4sDp7qeeMVuC4pCKFNnXY47ylPBMhG2Qn4ABQgJX2RI2fmW8ES+2J4fLI8Kjn"
    "qXa7yczOpkPDu1bqteVmokoTViQrPhEvs18JwAkPbmVaH307uCH6ZQcCAuOzfAuf7eXJgBlI1d8fgkTOJJzSLZNqfAi/fLqZCd53"
    "79rVi6JcoXDyzBlVHBbUAMnVZf5avNDzN8J49S2hr1YMPOskvnobXL3VskEh2zSsjB8/deK17Kxz11+/v1quNFrt/3us+59fXrpl"
    "yn1tATAEFkuirsiOH/wH9cG7genQGg0XEIGMhRunujuHCj/34dmXvvROI7i6uFgIwl6SrH3bMkgadtY657SIQZdl2fqkz88tKT/Y"
    "tHXniVNnkyRSWme7JY7jzGLKOe460Jpiy+0kqjVMrVuzNg+kxofDci53arYTpQK2B6E3UclHzUZgE5VXT19oLLch8NOVToJAjlXI"
    "yZ1bKpPDpdladHSuqdLUxWk7ULNNs480ACruge2RjQkU2FQYLtSiXROehrDetvVmU2kvR3o1TpXSQEAgk8NllfNrjUYinlYyJXak"
    "TEcbdm/Vvnp3caQQxj3TjmHFeo+eaZ9p+agVsMWBBD0zylL5qmF7caVzcanpa/A9pRUKy+zqTGJAF8ecEKJkA67BpBKEGYgyu+bM"
    "361vhY2YJaXIWiPXN6nIgo0HKGH/r1+xNNetuj5FWKHjuPf6HWq1a56e6wK4oaHhHdu2iggSnLowVxza7ayFtQHwOlfz9UczDtbU"
    "OnMAXPfK6/J6n3P0u5YF/424pCA7WyyNXTxzaHlhLixW87nc1u3bDxx4+tASn2/C23fZr10ykFdgWTIK+1W8pf6dSOvMEi+3NFri"
    "7pt3Rv96JB7bd/tQXs/UGkHgx3GclT3P+j4zCy0RIU4BhIhiCz0rrUatnfC111xz4vjxTq+ntB7ETCFiP/LIOhNqnhzOT5arOaKl"
    "dnpqqR16Q7VmvFiLZlaXK9VK69QKJOlkMdg6HoYKdk6NrHaWLAGwdHu9NIkrEyNdL/+5AxeNcxSE11QDdiaWsCOBRYA0ShMTdBsu"
    "NcY40+mAtavG60qe/CDQ3dQGxtrIcafTCfMBChR9f7kZtVptx3Ty0qzy6KX7NoUelLj1it07920IIhYDVpPZW6SpsvexA/XzDUNe"
    "MPBHWStjUAAxVwJEY23qHFgLQOQFOvCZDZAF1AKZKNddUfGjDFy2uJ/DMegRLh+agIOpef+DvCb0vXyYZivYXZGXAeAEFUT3bYq/"
    "cs51YgGAvXv3Dg8N99L28uLC/FJU2jflOKIMPXmeMfCLgWvXPvitskfvf1UdFCNVPnXyxI23vzSJkxtuuOHAgaddaj90oPfWvQVf"
    "dwwXBQIEOwhTuUrFBwjgrty1mY+nVSraOeK+XN9SNOH86qrne2maOmvZuTWBg4BkSDM7l6ap7/vMzqYJEvlB4Cks5IJep/3Ek08S"
    "kXMsxjrr+ncaIiA650bL+Ws2DQ+VvNGiPxz4nTgeu9RoRdTqpcudrpcrskg3Mb1uFPg67HHIVkE6XFQztcgC1BodAbXaTC8+dEjn"
    "CqGPnU7rumquEOZTpg6TgI2jjk0habQSMOzQRF2PsGkDVgXxMHZmodUdLRWBec9Upcs0u9o6N9u8oPxSMeehc37QNTBXj0cq+Rt3"
    "0LHF1nwv0CBzy+0g9HZuKHfavRs2+LFzSxEQImfUboQ+8EYInAIzgIdE2bQLQFjS7PAUtogkg7Ll8shJrhjdr/vQlZyctbcjo+XB"
    "FR7aA91O9k94cPcjIbOVPaV0ejT8ja8uZ1/wxhtvcGK19g8fPphSkfwCp02A525FXkxE5HP0AFf/s+ckV6xT9D43dEoIwi4Y2vD0"
    "kTN3vvTenrXXXbcvnwt7UfqxZxo/eXfljgn42gIGIVvpW3isVxgJCgiKMDoebNJsZqwBhNmO6mg4512c8aNWIwCJ48Q466wFFgQg"
    "IhZ2IogYx1FjZdVYOzw87Gxq0yQIQuX5QRj0klT7uhclJnaECq0M3ocsbIEKoXfd9ulup3E+4eV6txKSc5zz/NTahH3taREEhnon"
    "DhUEQfDoifkgV0qiXuir6bGqUhQ3WpGjWqNFwJ5LU4Op8SaGNCltHNQi0BF3E2NFbJIIxoJ+auIwUK0YDRvHSCCNjinlUCutQJKu"
    "bTQ6cbcLREkaT4xUNErRw05si4Ee8encauvA2Y7n5ayTQONyreeFXrngj5fUfEsAHNgeoIDnAfgCDrJHC8SZokqABPsDVEQCFHaC"
    "LJd7MUeZazeoLAooU2xlboxAVzDHn7VCcBCEy1fBhwOxdcb8EIXMqbvvJt+43sNn2wC2WCxt27a13m6UCsOHj54Mx3aAs8h6fZbA"
    "s8yfn7+JlStBKrxcAj3f1nnhL43PNeQwNi4NTZw9c7zRqAVhYXhkeMe2Xc8cfeb4Mp9u27depx6YQQW9FPMELmM0X/62+hmN/cfO"
    "ANgfaSeEGgTzKFG9Mzuz6mnXZGEhdoZFkPttNCA64TRNV5aXM0Zzs90JPECFhs3SygqzOEBA0Vo7l9kSc3bwo8t0ZxgUC/WIO0av"
    "trpRp8fW+gomR/O5QhEJnTPM0OrFUepM4J2YWbGs0yghpJ6TlU5n18h46HlNm6IDYSNIYcHXYkq5oG7AAbQTBumJoFWBc4mGqG2d"
    "StOCtt2oV+8VVxNGjjrt3pkoHhqqMAaXFptRlGodCEI3ShvNbqkQMstSo3NpbnG8VBgrl5Y7EfieJDZ1vNqJ4na6CTFA8UyrWgxH"
    "hrFrcKWbRMYi+QCZATHQ5ZHWZeVARqTAK1F0JAEHA6shgcFwXkCE7eWPX90iDujZatAFZ1D4+iVEwAjCrDRGb92rHr6YrnYFQHbv"
    "3l0qluIkandr52baxT0TmbM3XGX787yj6H93UPa/4zYRAAbnB8UuVU4eO3bDLbex4xtuu/Hw0Wcc8wee6P7M3dX/4rVbLkfEz54l"
    "CK/lDfRlOiDUJ40ycqRUUDN+z3EZ23NdX6NYYOxXTH0ANBurNBsNQEJFCOAAk1SUIgBkx4JgXRZeytlJ13/jmX3Pr1bLURSnNllu"
    "NaJOmkQ969LUEQvXE+xYY9NI+yrp9dLEIVsSskyps0kqKEKIzsHM8mmbiFJaPAbnRcZCqgpa+Qj1xCYWml2rMNFad504kxDH7CBO"
    "nI9RL5VuzHHsqqE2gohqfnm11sIk9ZECB8DMWqk4FaVsq91KjRWkmUb31h3ezrGhc6ud5XbkWHxkUX474WqA100XfA35nIdIw213"
    "aSVq9LrghdnxQrJmG7GO0JOxvxERVMZPyUgqA74KIgiBWgvH7J8+sNYeXLZayEQJeHnQk/0dtVb6rjXGjJqT5OYRc/0I/u4Xoqw0"
    "uuWWWwChXCo98thDPVuo5spp3CWib2HZ/uwSKDNeflHegOv618tbGbVztlidfuLgqdvvuKXTczdev/+TxUq70/rUocav31N6w1b5"
    "4Gmtc5KCw2xsKJl5roCYywMTYRDXd/cWYACkbieVL57s3DxcOHYsKYU6BVDAmYYoS81IoqTb7QIAKAJBUMpYByYBRCAiRDYGshQC"
    "Uhk3C9gCiB/kRkYqlUqp1YJGs7myvBr1Uq0UEitha6W+2hYB56z2kIgsMylthFxiHQBbBmuduEav159bGB9QiLjq6VYvTQFabTOL"
    "ac96jZ5J4ijqpr2ETL1W0RFrTtM0bD6z2IkbEZCkQwGJcYk4sM45pcgIwni54GuZX41TBNuTxDCSFgBn5MTF5fFKSII2TQSpJ0wW"
    "5ucbnRAmhkqLzV53lcWZwA/KhTBJbTdOwCPIFrU8q2q5XPr3B1pZ5gAOQqkRgYiBINPgDBIb+3+zTx9SgLSuiVvLvMiWvhNkyKT8"
    "IohIgkLIUfrGa/3FXnL/qS6AKxWL1+zZaY0tFsMDTx0Np3awS/D5LU+e8+B/1mfXh65n35L+xn3RXuiXAuuszVenTp56ZrVRr5Sm"
    "wjB37bV7Hnv8sZl6/NUL6Xtuzn/wVGrRE+bsWXqIvseeIg/ygIBIiE4pVDrjACERWSccN0SFDzThO8ZyN27DmuQCTG2WksJkrbPW"
    "pmk6MjpERCyCqJWnnXNKHGbJM1oDgjCnxjCL1opIgbBj1loTgklNLsxp5XW6PU2pcTwosNCyIAEpz4mzDKi1oAagsi8+unxRFwO/"
    "GGAu0Nky8PzAV7x7Mr95dPjQuZXFrh0uecqzRR++bf9I0c60fWJO2a20QfzhEjGFsdla8cNCvuqRl8fXtBPHrhHjidmWAc9G3Xft"
    "HxnJqV/5nMn5EjsJw4IicdahsGE6X4tBaSaNqDL8sptwL4pbiQmDHDuPWZxwRdPGqdEoFaUyAwvIvDYEFAsIixOntc7MTzQREjrH"
    "nupnNisi61yapplJNwqQVsKyZtqXRVqxUGZDIYMYlQypEyTLwIwMYIUdo7XM7CxqcGk+D+/cI/98KOmkDkD27r22VCo55xbm5k/O"
    "tKrXbHDWwr83F3X9PHf9ftcvBkh6YQbIuo+gRUSxWhesV33syWe+43Vbmq3aHbfd/NjjjwHQnz/R+ufvLu0dah7tlMmjwZCQHSMy"
    "I6bZHlUojoCoD+eSUmxTmxqSXoz+3x3uFv0QPASXWs481R0LIyIqXwDQCAgACTphFlIeZfmqLoOn2Thy1ihWSutMbNXppMK2XxQA"
    "WPEdKcdWqA+RZnnKIgIQUv9OEgE2bAUYlDirEsDAWAB2Ir4yTHByoR3SYrngNw120xiVx4JRlDx+BItoPPI+8dW5wzOreV9pRTGr"
    "NHF/9a/HNIHnBYpUlNoYPNF5Z4NC6H3nFswT/s+i13TaR7akGYEVi7PMgspnAfA8FKJMF0Na0I8cJzEqQsAcOjEd45uO0kRGUDA7"
    "p5FIRPXTnsEql7n/oFIaAJkdQUdlwXRILGyNZe6bdStSKFl0lQMASwoAGMj12WZ9K1gGsSBASoCYPQFywK5fgKFGYyJ6zW4zPhR+"
    "6KkeAiLSS+5+aZIkfuA/8ehjvWB8xMvbJEWUr7tWr1Y4vgDG8/Vh0BeQ2KzzyQHOgB1WAGBtUpnc9egTj993z10MdMNNt2zdsuXC"
    "hUv/dio6V+/+wI36579klF+0YJE5BQQrg+HXgPXGAOCAGVhAYkAA5QM7EEOg61EKMg/cF7BfFoYSASCwrMPXcFDoE1xmCyOI7buK"
    "r5nTi4P+5HMt7DqLMcM1sxpBoGwCKsgACUjiEITBYH+W4wiysDN0AAJsgAAgRpDdG0dCZZspzy+v7t1UmR4qPnyy/q+HZgB9EAsI"
    "6JE4ACeACCTQd4LpBUHo0u4911evHU/yCX/HXu/vnkq8AI3LpuQA5GO/aAcBBCQRkCwJBxRS4LKfjQEEwViIExAC50Akgx+zpIc+"
    "jJx5GGdySsqqF+rXNoKA0n9ia2rpTE2dPXxUAAkIZ5E6gArQQUbTz+gSJKBk8PCBgEARK9FCwOb7bg4evJAene8A2OlNm6/fv79e"
    "r1trH3riYGX0TmccAGf8pH7UjEhGWUX5+qv3+XbL198AL4ZfQRlcqXxCTykQcWE4efZYfPDQkTteeg8g3v2yl52/8I8uTf/00ei/"
    "vqzwWw8mDS6TAiYN7AaVz2DyyyyZvI9FuH9QIYkQAniZnyiAB8oNkAf1bGoeM6BamxYCEmYGRC4GYaUCBgFOgUUUXfEoRCBjVcgA"
    "oeV1nHgBhxbXJAwiIIgqACREBnHAIELgFCGTImAScc65UCGAeJ7yWcIwrHXSRts8fHIFw5KHLNY5ZhQizwMtkoXjopdZRxpwoPiH"
    "d6SJyy9R/JM3yIcOqVRAgTAKiBNRQmowcGIexKxlrS2vHQT9h6uynS0Zz+2yMEn1TTKypEvUwk6EhRSSIgFGIPAEM80RwlrqD2T0"
    "XUBEhwSAxCxsMvJW/4QhzVk+GSERogw6TyCHoBFNzNvG03un4Yc+WmdgALnzzjt83x8eGXnm4NNzDdlyzTYrTpNHjIPYAwQB1Q+p"
    "xW+qCX4ees+LkDv09wal4tLuskusTWO0kUs6vqQ57B49fe6ul93bbndvu+22T33mM51m658ea/38ncEP3+D93uMxljzISpf+C2W+"
    "S4BIDgWiuKANg3UmAQBUaj2d43JKK6yxr/Dyx9YIWBl9BUkr3zkX5nzrJIqM9hRKB1kASJECxMw9DTG7MfqaKhz4Fl2W+wlnzgta"
    "KRYk7XfjFJQPziiwWnvALODY2bQb+4UyWxYhJ9JOElBBZATQaycSG0776wdIQwa9e1orpZPEGgesEEEp7XNibx7FW7Z4P/u19MAl"
    "/tIPjr5h19JHj/S8XM4JBWj8gBy4zDYLAZBR1mPtQOufBqzdZ/3M9n4mC5FWntaKojhNXUBKaRcRGnZKoY+CaZqIKolSGSSR8dkz"
    "PLSPW4sIMKJHroe2DYioPFQ+GGsYITcMoLM794p5sHOEYI39wX1ycdV8/kSEKIVC8c477+z1euVy+fyFi3nsLB3+LFAI/hB5OfJz"
    "2g/CXEH84lr8youv27/VijBEAhe2T46rxtTGyWIYlouVSjFXqpRGp6Y8P7+6Wrc2GRqq3n33Sz73mc/14vjvDpifvGfkLw52O6mP"
    "ygrq9WEZApBBAjaO9tyw7a//4o/iqJf1ukqrbMS7ZvhEpLRWAOic7XsAOgeAnu+tXV5sDQtHSbp50+bDR47+9M/8XK+bcuI++Pf/"
    "a/eOXUka9YFwEWZWSmntIRGAWOsUKSRK06QfYk4kjq01ipQADI+M/sR/eu9XvvKQXwzTTu13f//3X3HvPdamyEza/43f/O1PfvLj"
    "Qb4sTpxAJ2HjktiIsMTWISmFQAhp3P3lX/7Ft7/9rcvLCyY1o2MTP/ezv/jVBx4gPySr0A8Bez/1yvL7j8pHHl0EkJ/5vPruW/Of"
    "PNwS0qR85czf/Pkfbdm2LepFAExXCDkQEdiJMSZz2iOibFKeUV2UUiL90EEib2ioevr0me/+nh9WYcn1Orffcf2f/MF/X63VSenh"
    "oeFPffJTv/pff1uPTFuWtUoSkRCR12AeYQHrYfSB9//lyNhEalLt5wDkPd/z/TP1ns4PyXriFwKAQ0STuvECv+c6+Z9fSaIkAeA7"
    "7rijUqk0mw1j7H33ve7bXvHK2dmZ1dpiox11unEnWq2t1nrxpPH2sAL4BrTBL4IM9+LW/GWYiYi6rcbN0/kf+Z53OgmAudOLrLWk"
    "lPY0W4eQBH7e1+r1r3v9/f92f68bfeCR1R9/5fR37fPe92Sky74boMZrdw6DQ2e9oZEnHn/6sUcf+843v2lxeTW70JXqX3qZeZbK"
    "ohKJMt84Zy2yECmllVAffFBC3V60afPIsWMnf/a9v7hQtxDkpb28edPWjRs3dJqNOEnWvDWJiLRai6JhJwOGaf/etZZFpNfrTUxM"
    "fO3Bhx64/wFd3sjiQHBycsPw0JAIK6UA1F/91V+NjI387fve5/l5QdXu2Q44QQqQe2lxqOz17y7hibGRLdObQk+36o2p8bFiqQjg"
    "kQ6A0rTTvXt7Pg2Lv/GFc9t3bpserXzskUdv3LznLTePfvgwBEP53tLqP334n3//d35nNporlsp97BFRKVJKA4hYx9lknRAQ+yah"
    "A4d3ImJm5ziN05Hq0C/+3T/GFoMw71r1QiG/YeO0Y0HEycmxzVu2ATBQNqHEQUQ69v+jPxFAYIcCm7dsy5dKSRwTQq40FAQBcDIY"
    "vAwIaoggQKSdTV57g+5h+MFjK4QchLlXvfrVSqlCoZgJFSif3xwEIxNTWqtiseD7Qajhnz72hQfONfPDVcsOAV9EzfJsMlwG/+rn"
    "bJO/nh/oOuWb41ypeuDk0Usz80GuYpJERHJh6ETa7dbq6urq6moUxbXa6tLyCoL2NF1qyXf94/JQqYyeY+mX/lfENiECKQdCxdFf"
    "+63/+fJ77lWI3SjJyLGKLttH9l2Fs4IF0VqbDettYrO+gFmswOatWz/+iU//xE//lKGqX5iyEiFhkiS9XjeOYhFmK0KaSKWJYUkB"
    "QSmFhP3McgG23D+8CNI0tdbW6/X3/sIvOa+oCIlCUHkBm5qk2+76gS8MqyvLv/XffmNiYuy3/9tv67BACtmRCApRN3G2G9lBc5Gm"
    "phdFGXOJlLJsAAApEBHt9UoTld/4+Byg/cP/8d+v3bf/Va94xe98/tI779xayrW6KavS0Mc/9vE3v/mtN1y3N44j5SnrHCJqIqUY"
    "AVzmpI3ICNniV1ob50yaMrPWWinFzMOjQ//wTx/63Gc+F07uMiwAYtI4TVPrHDP3elGaJnA52ygb5V6hfVkvAs6YyZkqKY6jDH0f"
    "mMGue68RnHOBl57oVd/z0Vaj21VeCIAf+fCHx8bGRkZGisXi2NjY8HC1kM9rrTLio/Z9MeljB04GG+5kJzCoqdZjPmvs4BeKiQeQ"
    "b4UijD2/2KTxrz34xGtf+5o0liiK/uiP/qjRana73f5Yar0EmQggfvjI7I23jm8e6lxoGBV4z/G9oWIRvzo5N3P8D//wD//bf/v1"
    "Wr1BhJTZKyJlnS2BOMfWuSAIEbHVbKNImiZIKP0UUbdl85Y//19//Z//86+p0ogKRowYVA5ROefS1DoUVOT7QSFfQsDUpM5xdrcg"
    "IZCwYxFGRhEhJNJkrQnD8Cd/6qeWF+b0yE7LgooA+pdRkiZOHAky88UL53/+ve+dGJ/4mf/0M+gFpEPH7Ng1Owmm4kSIyAF4npck"
    "Sf91tSIFAwTd00H5gYNLnXbtN3/jV6/bt59t+qd/+sdv/67v/9Cjq6w0ExL5oPO//Tu//+mPf3hoqOLEmdQgoudpIuWsddZFvZ4w"
    "C4j21NDQECnlrE2Ncc6BiNLK94P5+dnf/b3fV8UJx5jZlCtEUkQDcnN2DWZgwgsKcDMNptgsx4QdyCCmYMD6HBgrChAD25FyKY3p"
    "wPkLYsVpNmn69NNPr3+BMAwK+dzw8MiP/Mh/RCRf0QMPPdWA6mi+YqPuNzO4QkT9fAf8C7rBDYbmiIhoTVIcn77/ifvvvO3mXKm6"
    "feOGylD15OlToAgVKuUrpRCsrwOlA1JEAGHga0o2bhheadciq1E/i7PRp0KkVvTYxr/9xw898NBDgB5CFlKqBx6tTokD9FGpNO7k"
    "crn//tu/vWf3nnavHQQ+WyZFY+MTv/Kff+1//a+/9EZ2OPRFhAhBPEFEFLZCgoiUy+d+/Md+9PjJk0qHGfR5GZfNsBGCQcQHodLW"
    "pUePntCFKXYCCoVTcKm4LC5EsWPLrLX2Pe/IkSPf+abvKJeKP/ETPxUZ4/m+Na4dpxBTxpIEAEJPHDvJUrlJDzzcBcUpnbSW73nF"
    "vd/1rnfOz18M/MKdd93xYz/y/X/4R39Cw1sIHYOi8objpy7c9/pvz+dy1qQiQqhQEyqIO53vfc/3vufd72rUV4BgcsPm9//DP/3t"
    "37zPD0IhzdxPD9faq6/WGh1D5SEWCyoAUKg8EXLGIAgwYwb7CIKoNcr9Wm5bf+1kAkcC50yaxs7ZvnXuOmxi3SoSYVVQdtOG4aTX"
    "nBoZcY4Q2YpLY2fSns3AMSRrebXW2LZ958aN08u1ukuTh588kh+9jdOu9Fn1fZflq5kKX9fRSD+n5v/56v7nAIsAxDk/V13l0uFj"
    "R17/hjdq7b3uda97/PHHCbFUruzYtg1FgsBHgtRImlpjnBDV24l1EWpPjOBztTHZD+YowOL00QstcA7Y9mVH2ffADljACyFayuWD"
    "v/2rv9p3zbWr9ZrWOu5Fw+WSX8z/+I/+1Cc++S/hxDUpeMJ9kVJGt0NA59gaI4zMfPTkiVMnTkM4kTVng/zdAXooA7RNBEgBaa+8"
    "xTKKYqD+5IGZU2OyZzU0NJSmaa1WU1ofP3783nvv/eQnP/Hu7/7uleVVv1A21rCwYP8wZRGllCKVGrOmxOi/eUQgMjo6rpVSSjnL"
    "rXpzamoKAbUXWIa+o16xfGa2BpavoCVrgt7S0tKy0jpTHiqlZi5dOnHiBOTG+/OQPkgqoHJeadz1fdbXTkPmzPvcWkBUSpP2CPvW"
    "8UTr9SzZBgBQmjB0kt0YQISqD9/106DhcgOJIEzolpcXUGF5ZBwFAl9rDzQFwqbV7qSpnZ+fT9OEiF7xilemaVqplA8fPDjXpKnN"
    "ldRYIFzvNf6N3gbPcQN8o00wiCBwyrY8dc2jTxx87eveUKvVNk1Pb5zeODsz2+t2U5NGPdtodoxIZHrsEMBjUkII4FArpUie08ai"
    "LysiVKEu5TJfURC3tgVFQGmVzJ++5pqd73vfX4+Pj12cmQkCvxd1xsbGrMB3f9e7H33kSDi+J3XMxNi364Asx0IAmJ211jmx1nBq"
    "AVR/m4HKnPv7fCGQzN40E10CKiDf2DbmQwJECYjYQb9OYOeyzjJN00KhsLKyUiqXz507NzU18bF//tAP/NCPnDl9JiwMOWsz804A"
    "sNZkGQj0LMl5f3qkrHMI4KxjG2fRdAJKkBgBgITAiq8KeQHCTEqBIgKatI0b2tNEiIjO2jiOPU8TBX5l0jorSDhQPbKQFaH+iHAd"
    "wz3L5LQ2jiLnYre6BMZecSIMFLHQH/hKSyV9Aou1/1977x1mV1XuAb/vWrucfqb3lklP6J3QiyAoIKIgCDZAERCuIFawX/XaFVT0"
    "CtilKr2JkFADCSG9l5lkkunl1N3WWu/3x97nTJ9MQlDv933z5OEZZs6csvd613rLr/jY6UmLSc5znpbrchUgoMVJIXkMpaGFNE5V"
    "ZVHDMGzbVkq0tLS0zGjp7x+srCpb/MrScNUcqfwAlgVdkQOtDDcZP5j8vu9IQAQy8NxYae3OPaveWrF89pwFhhF+73ve/etf3+U5"
    "bufuPTX1LYM9A6THSTdRR8Y481MKUoRMoixQhMarRTBfQ0MRUeAg6FtDuwga58zZs/XMs06846c/zGWyu9p2xGOJoYH+mrqa/v7U"
    "xz720S3bOvWqmY4i/2kgSK59hyhF5ANUpCeEdMSpp57WOmsP13UpJUM2smOIgaWSjyQRCGiakXQq89Jry0ErJ1CA3D9pkZARMEIh"
    "vE9dc93nb7nlsMMP3blrd8gwd+3clUwm//bgA9ddd/3Lr7xqxpKeKLJGhATp678HMszAFWrAFTANgCN4nic9IZH8jRgBOCFHEH6l"
    "p0gv3Efug1uRPGKaUkwqTygphPKkEo6rSCmlETAZLFwWKHtiAHAmYFwFgJkA4UPgCWpumXHqKacYoRgEfZ/gAPDVd4PWKiIpisWi"
    "JSXl2WxaCKVARIT0Pd/H7J4Ba54bGDZZcHCRUp4g5QrgXmZmIrGzvc1HWJx00knhcMixvLXrVmxqT1ce1OAJlzEONIpiCVO1g8ap"
    "fAMSHSBlOIMIFDMrFz6/+NWD5s91PDj5lNMeeeSJ7q7uVCo9b36sqszpSnncMJVSNBp/uzcRIwQMtAOQMVIEBMhNJPK6tlx99Sdu"
    "/fLnOvfstmwnFArZTn72vFlLly2/+qrrUzY3qme4QgHnhbOa+VLGQddM+TJCQknZ19t70803miHT37l93AsVMMFSBfZwiIhcG0pn"
    "ZrbO/M73frR48et60hTSCwC9SnlCSFJCyJJweX9/+oqPXPGrO391+unv2rRhXShk5i1L0/U///lPN938uYce+psZLVXoK9wyROZ5"
    "nhBC+PsrMGQMJI3cnZQsIMaJhmnTEIzRR1O0GVNFV2ZlO7bneaqIXCguxECDaRJZEUQphet6pqGlM4OtrY0/+9mPALjGdcYYMl/g"
    "gPz486NFITDOTdO0bddxXCLylITAUpYmkZ8in4aBPq0SgDMuwauvLtV1LZVKIUAiWXL44Ye7jltemnjksZVG2QzFDZDigMD4tUmT"
    "+2lPgglQISiZT1Q1blj91vZdu2Y0zjJD4VNOOeW+++4TUu3Z3dFQXt0z0E1gjoclFW4ejWmGFt/ACB1gAiSm6czJe6mOb3/rtg99"
    "6JL1GzYYho6M5R1r/vwFDz700M2f+xIYlby01PUkBq47w/AARCjM0kkIIYUgAMdxdu/sAAgc4IhIKuX/DzIGRIqkUgREClHTzedf"
    "WPzTn92uldUJCiA4fv6Tzedc12aMK5KRcMQV2pWfuOp73/veBRect23rlng8nkmnhwYHv/Odb9fU1v/ijtvNRDkiMqYDoRDCcVxn"
    "XLexiOOVUjIgITylVOB6NBGHqbAVMh/VQwSO7TiOQxhIZoxX6Rn1PMGEGJAhEUglSWmE2N3da1s2Z0zXdM7941EGcxtFNGxXihrn"
    "Rijk71aIRUONidvoI1yMC+RJYpxkbXm0c/cuKSUBLVq0qKSkxPPEwGDf2q0DiXlHk+ty31FyIoj+Pu3d2gSCLeMwcKPgoiP87YJ6"
    "CUmxYCLHS2e+8OKrcz4xd3Bw6Lhjjn3y8SeyltWxe1ddTVV5ItSbd5mmEw4XWr7hVJBCIo4mrRWH9cJfD1KCbmhuasCEzP/+78+P"
    "Pfa4VStXhcJhy/GEFPPmz//5Hb/4/vf+R0u0gpEQnovImQ+SCVQVAwBPkMeRcj3XEZ7fsQ7FEv5shiGXQgopNK5hcNgzCcrzPCkl"
    "Z9TcVP+Jj31SSKbrJvrC5IUYc1zPsmxFlMxmXemhFtNjVV/84hd27my/6abPbtu2RXiCAW5Yv+Gmz97QUF/35a/c6luC2o7juq4Q"
    "nud6hfqH+zgk//q6nue6LkNme64MiOoMghkiTize4Z9hCmzbcT1BQJZlQwBJw6KEybh9LaDYIREJT3mSdFJIphEz9LAPT0cMSlvl"
    "F8lApBQyjoggHGRMAoESQgkppFQKioIpwzzw0WbuwQ8ZICrPqUqaANDZ1aWUjEVjp5xyUjZnxRPhJ558RZm1mhH2nDwNt3domLYw"
    "vC+PB43ShCpa+5cC0cgnRAICBsA910vWzFq16cnOrl2RULK8vPzEE0946plnPFd2dnc11jT2btmDukGjTsBAUQCC3t+YcUYgrAdA"
    "IMnkzO7eMbul9ic/u6OitHzd+vXhUEi4rhHSmltnfO3Wr953371GSavkYQUeA32EON4IWyukQnIDrud6UghPVldX797TmU6nixod"
    "yNiohjei79AajyZe/OfzL7+yzChvFUIUtrbglkqlPCE9z7Md17/lgke00hm//OUve3q6v/b1r+9sb3McJxyJrFm9+oLz31tbU33l"
    "VVfnbcu2bX++plThPftKI8Geg57rua4DoHlSIPNRmjh58ljkmxMASqEc1xPCU4o41wo7D47svo1obBTBsCClcD0PbRaKxuOJxLp1"
    "K/1mV1ABIFNSFim1wS6mJHBjztzZPd2djDG/yYDj3tnkYg3AlF1fXd/T0+16Lig68YQTGhsbBwZSVmZg+ertyaYzHM9jbJRJ34Sq"
    "c9NcydpYhbaiPElBFQynoQ9c+EYyIyLM5sUvvvKB8z+YtbKnn3b6Cy8scTy3Y09XXV1LRSzc7yjGGJEKWuuFRHtYRWxEHDBiReUB"
    "gzOrc+tJJx3xg+9/r6e7f/vWLYlkSS6Xq6ioKC1LXHfdZ15c8pJZPssjExCBSSwA4wr6Kojgk4AJgBiiDwEQHklJ4VD0tlu/tnbd"
    "WmAhUBJAAbACl2MkpwkBdVBcS9a6SjKmFe0jgxUjhO/fKqVAH6kLoFjILG998MGHOjt7f/yTHw0N9qbTadMw165Zc9BBB99+++1A"
    "IDxPKeV5LiAMt0GxeKyD53mu63GOUqrAnJNGZ4nj84HCRugXNlIKIYT/eFZU+4FRzxA8b0H73FPSU1I6dqKkYukbS6+95lOgh0AI"
    "GCuAWOCCEQCQGQo98vBDUpBC5XlC+plSwUwo2KfZaGsif+zBmBJeeVg3GHV37QECwzBOP/30vOWUlMSfffaVDJRWxUqVO1hYt4po"
    "mONSaKVAEVswhZyzn4UQvW2DjNHDZ5COVVI379W3nj3zpAHivLK66rjjjln84ouu63Z1dTTV1vdt6QLThCl1HRFU4bIKv3lgoLI6"
    "t198yYVf++ot69ZvzmetaMToH+hraZkhhHfZ5R/bsGVXpG6hI4AhImoB5gSDZV9UNwMSBZIqKlL+slOKhFB6KKaZJVqinICjgkBV"
    "s5gSF1JVxRCBExH3qWsygLZDAGpw/UwpWEXIGYICcMgwKme/8sqrH7niit/+9s5IONrRsTsaDW3esnnmzJlz5szZsGG9kj5sj8Zv"
    "aX6SJoQgQiGkkhJATYWCH0F1R0TX9TzXFUo6nrtPN1d40nU8ZOg4WSKBGDJKmoQQ49AQhX0GgaQwMc8QlAKlhOu4YjhgaOINOsgn"
    "EAG4cuurSnt7uy3LBqCjjjqqsqoync2DchcvXVfScCK5OR64NFOhZqMJN/5p8ViKnOAJ1CxwVB02BmUxdjoGMqA8kNAj8QFW9cpr"
    "r5z1nnOz2dxZZ7/7tTfecD13Z8fOo2tqyiJ8wBaoazhaYgZhhGZ6IE2jSClkjAnX6W+76XPXX/Hhy9asXqMIzBB3hVdTW7N+w7ob"
    "brjR8wSwaH7PVgBeoGsUeR4jLw3n8VLQTH/UpIBcz0MiSeQ49kBfj3CGRK8DowxRRiStzB9LKVAETANNlyS0aFRyg0AHIimV5wmf"
    "VK3pGgICcgJOKBmiq0Cvat20bfcHP3jZb35zZ2NT05YtW2OxaE9PTyaTQQAllVIkZGFaFzRGAlUSKUlKIhCO7VIxo8OJD4ERLF9S"
    "QK7nOratGMhAPBAJhhsOo+7vyGk8cs8VVt5ijLm2h366zzhx/zkYERZUDIK0m4pMcaCC6qjlOm5BOtQnsvjlx3D9USjcmfKc8giP"
    "RvUtW7oJgHN++umn5ywrkYi+9vJLKSdcnaxwrQyihqAA2MjkHscWkDgNYU+CkeK4e0W/TVhlj/T58j3npGOVNS5cvPzF404+gRGf"
    "OWvu8YuOX/z8C650O7s6WhsaU5v2kK4XEXlAxensWIE7phkq14dW3+23f+/Y445evvz1SDgKCEKIWCw2Z86cDRs2fOtb34pEo0pJ"
    "VJIxxnUDAKUQiNynsWKw9rVsJv3Vb/zQBlMwVESe63mex/1eh5Tf/MatqVSa64YSwjR0QvRcl5RChggIDBnjACCURwCGESLFGLKv"
    "fOO/+3Me001JJJX0TV0ZY7qmB4O8QmXGgHmCGSX1XUP9H7r0sp/f/vO5s+Zu2rwxFov6EwAkEEJ4nsdwjICqb36kPNcjUJZtDSfS"
    "o6VhR2Xao7ZF8gnBuq4jspH5zriNz7+dwY32MbaMceF5Kph8cZ/mEgzNhgWdoNDKBAISQuTzeSml5zlKqaDRVzDuwFGc+wBIzVCg"
    "shuqa/r6+q18HkAdfvhRzc3NmUzW5OqZl1YlW452PY8xNrLY3Q9a8LC/gU+K379nmSyF8Z3jWaQ8QyUvLXnlgvPPzeYyZ5999ssv"
    "vSyF6OjorKtsqCjVu7MO4yaRn2qPK18UKSRN18VAd2WMfvnbe+rr69at2hiNxImk//lzudzLL78ya9YsKaVwPc401DSOMOw2q+mc"
    "M5/8nresgw466M5f3ZlJp83qahK2z+NWSiEBSMM+xAAATvBJREFUMt7W1hZPlpZXVgEokD5KQvpNQ13X/XyRcQ4EQtqE4Lly7uzZ"
    "Dz/yaF9np1bZrCQBY0AgPaFIGYbBOCNSPqUNiuqmQC4Rj5U6Nrv6qk/94PvfOe2001atWhMyTb/k9utgKACNi7pUiKhIOa6jSLmO"
    "E3Cypi2E7PmdUw5CeJPNZSe4lwg+FBx9C/dCH9p3ARgeXPpzmoCIR4XcSbiu5yPpOGMjqbOT1e1KuOUxI2zApl27kCFj+rnnnus4"
    "biweffHFxb2WWZeoFnYaUNtvW8iJ5wBFlZUJXYXHa0/j5MLsgdwjInr5kubDXn3j2bPedQYq1tTQeMKiRUuWLHFtZ1dnZ2tjS//a"
    "HUoz/WhB4IU0KHDnZaSQM7FnW+uMytt//hNXiDfffCscCqfTGcaGRUWllJlMlgBQBgJBDJnPC1NKMcb9lr8r3dr6hhVvrvjhj37G"
    "kw2e9FASIJCUnusK8vMWSmcz/vBLZyhcx3Nd4JzrIcZGuHlLKaXnm4G37Wz71ne+x6IVSkpEE1iYgHme63qeY9mpoUEf7ADoCxv5"
    "SQUBcqUIzSTn2uc+94UvfemL73vfBSveXKFpHBjmrLzj2DKoPhQFSwelEIODg0OZNOea7VmuPyzDKdYUEQPiwVQ4lU6n81mm8XQ6"
    "48MThkcBYytFvxnhcytVLp+zXcdEdIQQQgFoSEEPlUbBO4PTmxAJGSB3Pc+y8oZuuML1HFdBoUQem60VRkmEKNz6isqOjp2WnQOC"
    "4449prV1xsBgSpH1/CsrKhtPEp5dGFpjUG8AENC+iwRhcRXTSJfIMdoQ07SbnDgYpDAiiV69bsniV9533lkD6dz555+/dOlSz3U7"
    "OnY2tbTUlMd2D+TRCBeUsIq+SQHFF7NdF1xw8h2339HRsbu/v3/Bgvl+g5xrGte0giWi8nU4EFAK4Xke50zXjaL8C0OUStmuPXfO"
    "7Ms+8gnQYiwUEkoxxpmh1Tc25nOWY1mIqOu6bhg+AcD3dpZCImNcM/1RDudcSOk6tpRKKdna2nr9Zz7rCkOLR4V0NaYAVHVVZUND"
    "Qzqdzmaz5WUVjHEAzhiXJAtZNQOAAJOkR8yyhu9+9zs9PV2fuv76vp4eDZkQonVmq67rPp9WFe4C57yhocHzvFAo3NTcsHNn+7B8"
    "6lSDdASgeDw+e/bsWCyGnDU1NUUiEQBVdJAfn2sVevJk6EZ9Q4Nl26FQqLKysn+gf+9bb0AqwtraWjMU1rlmOfmqqqpCmYc09hkK"
    "Cs+eXRkzTZ13dvUgoqZp5513nuOK8tLESy++0O+V1JfUu05GGwftRESYvNUzjbnY3rpAuH8yLAjScZJNhz738tPHHHsE1/SGhoaz"
    "zjrrscceAyW2btvY0jyrqz+llInIRotYACKSkzXIrSqv+O53v2tZtq7rpBQDZJwxxpFjYAhKKlhVCEAglWTMBzEwIiWl8i+OaZq/"
    "v+u3ry9dxspmeAEQlEuiX/zqF9FwzHVszjVDH07ZlfRRuMgY+hYmPmpFCF8IBA3D7Nyze/GS14zyFs8HbyqBoP7wu7uaW2ZZtkVE"
    "Uoienj5uRnwuSuF+YCE/1wSB5GBUzLrrrr+07do9d9YMz5Oapj315JMrVrzJIpHA6kZKFgqtXr36nnvu9jyBiGbIWL58GRqRAh18"
    "giKvMPBWLBR54YXnLctyXBcQNM6WvrYMzYhSVNwJxzKcCIAUhsJr16759Z13WraNgLqhbdq8mRkh33QHRrl/IfkSfQEgmtmW9etf"
    "35lIlAjPI6Qn3Cc79+xGo5TGxw8SAilAjbym6urdHR1CSAA64eQTZrS29g0MKh2eeWlNeeOx0nU5KgIdgaa5IKc2wB7e6FvOumVE"
    "62WY1DDure6beAQjhuHw4JbXT5pnfuDSSzzLQVL/ddNNmWyWlDrsiGMGBp2dfVktHCVVHFH59poEIg/SpfQQgChAdnGs/vAEyReM"
    "wPeOBEgxAM6TFaRHgCFJYkAoM2KoH8ADUADaiOeXxbFuYZY0BqgX2EPopVWCm4QcQTEpSdgqPQigABSAAOAsVslCSYWs6LWqCiLi"
    "Pu0eERAkV5470AXgAZgABCAgnNCiJZL8ZFdxxkV+CHJDADJ4fi2mJauQRwhQ+cpWNGacTwwKJi+ZfnCzBeCkCyyilTYShgEEYCBF"
    "70OZCjdaKSkZSWlnIJ8BkAASgAMLa8lKxTR/BkaANK5poQC48sDLytTACIlvYtESLVwpJpA0VIQMXK82yatKtdWrVhNBJBz+1je/"
    "GY1Gk2XJpx5//P7F2xsOPsOzLUJC5FOs+ZGLtrhcVdFwi4Zv4ohH0gGVRx99GHqeXdJy6CurnjnjtN2JRGksUXLeBRf86fd/AIS2"
    "HZvnzj2kuz/jCeXLUY36Uy0KPKxVJoEHgxMMqsKggTBSu2ds6BaAQxgMmIGhpoAJRYX+n2+uHtWr4oigQPpjgSK5ARkLXoaQ+b9k"
    "BaWFAtWciKTwGCgApoAR42BwrTIWlK6oAFEACkL0rXKHWzO++GyBOghMMp1VNDKGDLgfb4q4IgWo/CgRQDxWweOVpDwgiYwr4EJB"
    "UZ+roE449g4wBECuldT4kQYgkUgCKuXDSMc0ioKFooABY6QYj1aweKVS0u+4Q8FxbC/JNeNgRPXaZKHR5DehmCA+fv/yx9Sasqsr"
    "ajt2bfE3iDNOP720tDSTyfR27Xlm8Vs1M091hGDM988mADywC5WXzDxhpCEXAEyos4J7X/GjvTKBIbrciOYdJ9fVdtzRR/QPDsya"
    "Pef115fmsjnbdspKY/FovHcwx3TTX9WqALSloKPmHwe+fmhhQybwxeACaQLffCTYUoMH+Jw7BPIkKAWSlCIFPrYhkHEBxUAplMAV"
    "IikgKaQQikiBJoEpAkWokIBLRZKUVMB88AkRKB+jQ0QKFGgAPKDDSMFAkVIEXKFGyH2jPwy69T5yxhciKm5FHJADQyRSQvgcKBXE"
    "uD8FZwwIAIXywdkggVEAhFBICiQR8CKGr6gIgRB8L3ycnielVBINhQaRIFLAOGdIMJbXC4QkJAFxVKSUVEwBEiMlJfkdoUDBKXDB"
    "GNUi9+8XBiJz5PuLk0bIACWORviRImBAttVYGeXcbW9rY4iVVZUfueKKfN4qKyv5+98f3pEpi9fNVa4ViBXhXnDDww4xY/q6I6eV"
    "o1czL209AUZIAo+G+g93vKY5EoZRzHYgKeOlFRvXrJzbXFpSVs6Qx+Px5cuWcaZnMunmpoZMJu1IRkwH8grOlgSMiiJtwQ+HNa6A"
    "+d2UADOAhYZg0YVT00gI0pXtlBlOggmT2QkUYUPkLK44MuSKCZ9cjIiMCFAxJZLMTmgypqsod8KaF9dcEOB4Ia5zAl40xCIkf/DD"
    "QVaGRJQLnXlJzEfRMZjM28Q4B00imMwHC6IMFOWASjUnZpArEJAFAyEGCMQBGMk42nHMxVDqzIkyK85kiFMcLCGYz7bxsamBeyYp"
    "TSEJKjNkjHlZ0DhIAg1ZoVEZWJwCA4VKJVg+yd2IJqPcjZJrcJd5ti3CTPNH1QigGAARaCgaY2SSm/WQI2ckUAuRoHI9WxEWDulS"
    "ITBGgX0P+f7OWNQsJ4AAf0sYLEdfsSCg9wQ0J7/ckxTjYmZzxdYtm1zXJUWXXvqhGS0zhet29XTd/+iLVfMWuZL48NgLp8z+aQTI"
    "EkdENsKwXf3YANDGA4dov7TRx3WNfN09JSgUqZnz98efu+Haq/r7+44/7rjXXnll1erVuazs6uxsbapas61bMoZBv9xHQhRLeyqw"
    "NljgNIWggAIVk6Bs9REmPljBF2XFCi3/zVP1E2awMHmkRXQmEbQHN+A3XvTyGjLFh9sJioAxKemn58dOrFekR4U9pBgPh3Agrd+6"
    "WDyzHbgRVugW5GcIgZTC5qj7x0vKa7RBxbguUSidce3lPcZn/wFDrq6jEDgM8maAnpX7wrmhC1r5GXd7uz3GNBnocgJKhVHl3n9F"
    "dF5d3Laszj0OU1p5paFzokjsw3/ILNsT0UKaKvrPAXBgrsdObcz98lw97ZlXPpzbkA5ruiuLInkYNB51MISb/8574qc35sLJsOtk"
    "yWLIWVuW3fxsak1fVDM0SQqDQwfAER87reK6BT3fWKx+8WreTESd1MDpc8J3nZ94rV/71EM5F/xr7C84QvQVKf3zShV8elRA7fZL"
    "akQgXrBEIZ8Jxxkjz2puKR8c6E+nc0A0o6XlqKOOTmUypSWRP9x3r1a1gIwwOO6IMmzvYiXjcSR7Z4QVZNpHhg0GPmg03RZQ8fwd"
    "g+uRnpOonrl59c7lbyw78pijkbEPX375+q/cppTatWtXdXVNXXlsZ18G9VAAi/YRJYHlYJA0S583QkXPVDbM3OXAOAu6SQo4KsdS"
    "Hz89fuWRqbvftLsciJuGJb15MXHDcdqre4y/b3CMkOkqVVRXASJQNCOpmMr/eaXHlNA05SC9p8H+5qnJF9vJUuR7CPkIDf87xviM"
    "iLW1lx7fISIobcKmBF67KLFsV+aO13MqGQahCvJpCKhAqTpNVUeANIc8H6lfoFMQOcxYsj2/vjuUd3FRqSgLyQfXKxM517z+vA5c"
    "VySBhs8hBWiQdeOiuClSTRH1qcP4Dc8R6my8OwtTgog1J92E5v15pVASXSE0YJ9cYHz+qOgVj1nKTBQgvQBAips/fK7z8FLj+6c5"
    "G7v5PzdlZ9bIH5/BhJv5xnOhjGBcD8p5QECJSihg/u7OAu4o+VkhAAtKKR+hRdI/zFEBMdCUmytLsmjYWLO5HRkw4BdffLEUMhqL"
    "bduxZcOubN3hC11H6BP1X8bI306TzTLhD7UpCpoDU2SAEoJKWw55Zsnyoxcdb1v2jBmtp51+2rPPPI3I29t3zJw1u7tv0PVFYdE3"
    "xHCTGumIwCRnQFIRAQc0GJo6R0QNleaj3pjcnQn1eiz4HOgr1svZyUyfYLe9aPalCHQA25xfk333IbK5zAGhSaYCX4FCqDICBmpd"
    "H9z22CBACaAAyu45KfmlU2RIc/ICcRieEDjiOkKA1N9oc37wXKYkEs0LeXg9u/SovIseKD6iOe3b3itAsJTrCIOAj4D9+SAjJNT/"
    "+zkJKguu/NXF0bJS8dWn84AlgASRMNNdpTTGQBEwAh3BcdQZM/G8Od4nHqS5Zd51x8Ptq7wtg1HNkAJ0LKoFgy+J7UrGtqf0Wx4c"
    "AAgDCACYUxGZVS04A6UIRwy1OBeWF/3kg7nHrjB+fa643IZvnJVsiLnvuV/b1MX0KBOKGPmWRyKi0/xKUmQLBVJypVASCCJXKUHK"
    "lSxoPTCmFPcIXeIEEjgBgUayua5qd0e7ZdsAtOjkE4888siunt6orj30t6cSTceQAo0EYLEpN61m/VQAfqAxFUPgDzBcN9D45ift"
    "dawwISpjZDYmpRcuKevqSi5esuTcs87u6+298MLzlr3xRio11N3dVVVd2dpQs3H7IEYNQoHS4IId3cRaSmzQBecaIx5CVa7zqrhW"
    "neTJCIsyaSgnzChcFr3pcXhgdV7nYUWBkwaQcFxL0ysiUVcHbmjKYxiOGJquoXCBSQa6KrJtQBJwBEpnqSlpf//COEov44aZ5Jcc"
    "qe3K67aNaARHPgZNHQAgHbxUHi9cEDn/qJoQ94TSy9lgf1/66S0cTT9dCcbpROA3kZQiTwQuTcOpaoC1Vnrc5Czk5bIax7DGklEt"
    "yzTOSZCniANjwTpVSpFuMOumRdr6PfYf3hAVJfzqI93PH6Nf/aQHTGdKFMki/gAaENysqKxwv3l+UiPJPE6mcWqj9cCWmBCkI8kR"
    "VEmlODO0Hpt/8lH77x+puPdDWY3La56D1zu0UJg5ApAhISEDsPnscvnXy3R0bUuh46Lr6Q5qeWCDltubcftzLOehLdy8bXel+NLd"
    "poMMkJCYtPNN9SXKtbu6OhEhFotf9P73D6UGa2urn3366R0Zs3lGvbAtYiwwVdqH3Ht0SuKTh4rsxUJTESjIKPeiDDdmVD7ZybIX"
    "UAmi7VJF6+FPPf/sMYcdxvRQsqTkkksuufPOXzHOtm3dduSRx/f0pwYtG3UDQEoD/7nNIkIgBiABFSBD5eqY40CGzgwNdFQahBgf"
    "6HNKIBRRpAKzbmAAyJG7njWUF96Q4YUdcEXOA89jwi2im9mI7ZyAlFDCMMxja82U7SS4OKYK1maN6/7h5XXUAaQqet4GfyKkLIni"
    "S+3yf17rDodReppBzk/PK/nwQve7LwuGmhrZhyh22EkG6CAYhvv7YaIAGDKJ4AkpCBSAJEaKFAIWO+gIjJOXcz8wn06rk89s1686"
    "gSHCxiH9g/PU79fKlzvNCHcsiPhdVAIilKAIUAtH5DmtmHWNJFlzy+yH2/WvPpviRkRSIHxewCyRIKWFY6s6c7c+l/n9mfZtr9CD"
    "y3WzPOQKGYhIA6ACDLG1A+K0O/o4cwk0ReAocoWv8a5J0iT4kEepQANgmqYFlH1PxQyvsiyyYcM6vzN28cUfrKqsHBhK9XfvefjJ"
    "lyvmneO5zkii8z7ZVsAIoyOYCCxII4zZ3+4cYK8+ZP5upCnXMKJDybn3/f3x6z91VVdf73HHHfvPfz63ZcuWfN7as7t9RlPl0Pp2"
    "0ELEiACZGUXlz1uURELSQCmJSijNQgSpACQIAhbWmMHRKzSJSZEEBZ4yEsq7sNlbH1WckyvVCU2G4WQEBOLyYzI8SRjVcXsvP++v"
    "rtLAJPf+y8qbI5kduwToceBsnJ4AADMdqaVtr2tIhXNASkbCeoRnDyrXQGj+eh4985EIyCVTagIcG2EB4I+MlHLzlpAEBh8xbiqi"
    "4sBg1tUH64ODg/Nryg6foaFSubxFjvjMIdFX2m0vGkLyqFANEyhQYGjYlY+cenc+78mkZj320eo4eD0WZ1GNRteWChkSoRLIjU19"
    "tueGd6ezqHFFipAzpSiYeSGBQlIdXhJQAhiAAhCBFwjFwPyyAElxREIl0ECyAQBEvqEp0d/Tk0nlAGhGa+uJJ57Q29dfUVF2zz1/"
    "sGIzSsyo6+SJaXhAcW9TyaJMcaxMRg4eT4iZtDxGAGC2k6tomLt85ZMrlr8xc/7CXC536aWX/vd3vsM427Fz+/xopLYs0dE1AFo4"
    "EPtExoABKtB0BYBMASAxGVhUgAaGD/0Xw/oIxCRXyOGBVfa7m81fnIM5Row0T4CJ3qpu/bl2ApP7iH4EgECTQUNGZsjgnqNCjIeS"
    "jk03PJ579broby7hH3/A9TQ+wieXcVKCtKjuIXjnNntnXm0yBYyJiKFy0vzzeg66pgLPS19LLfg2bPJYVBpsmM7qC4769qNBk0uy"
    "UJgbYeAokAiRuN95BQAAHZSbxyuPTpx1kPelp8K/er0vxFzQQyTh8yeW3HgKnrPZe3KLoYcM5cv7kG/woYEBOgPBmBaOpmz9K//I"
    "vnhl6LtDsS8/7/KILiGA6xVpeT66v1QzwnEsMU0ChkpHFMCK/UTFiEsMMVMx4EoRQFHdAChQyQMhPd9vG0AC5EkRuF5Vecwwja1b"
    "N3OOAPzDl17muE7ICG/dtGHpmj1Vh57vOhYg83kv++zU6JuOTQTxHLu8g0FY66LxD5psuU9DL3HSgtpHi7NY9cZl/zzuyIMcoZqb"
    "mnL5/KaNGwExl8nMammuKI2Xxsx4VIubLKIpQxMal55LyAxCv5seDJeCQQPCyHEMA51QoA7tffo/dqhXe70nN3pPb3Ee3SL+ttn4"
    "xTK1PRPjBkoERsXBCANAJNlvsaW7ccuQQahxDQdz8rWdlFXYNogZyZEXh6CBZYoDetugeGyb99hW77nt8Mx2enKL+OUyemmnziIK"
    "lU4jEn0EBM6HcvhKh76q2xRBsQ4TeJ0DpCzxeqe+sZ+I8UD6D0dM+5lXHuWLt4v711A/lecAcyqSo9j6Prm932lLmbszGmesaMtL"
    "TADjmbxcukusGzSBa7qp7cjqyzsp5bC2lPJUYHAx+o4xZMpWcuMALO6Q/S5nXCOk4TcdcLIUFu4IIiv0QAFB46CRa0c1SGgYM3lp"
    "1CyLG+VxszIZq6gs6+zqzKTTpOSpp5563nvfO5jJlkSNO397r1N5mBGKjczApxMAYzLz6a9bAMDmM26ezBZ7PJZo/8gDVMAZMKW0"
    "ULJz8+J3LUx88IMXDw0N6aZx66239nb3IOflpRWxWBhAMtQ0XUdEjsyIhPv7rfbeLIYjGOQVOEbJYvQE2iGhM0bSdcFPBJTfwTch"
    "pOlMKTCJyVF5BREQSkcCSAyFmLIlaAy5ch2QNpohxkLKF0pAJEJGxEhKQmXZAXUYBBADBaDrzORE6HvmEPnyEwyQI5PKssHTIaLz"
    "guMujT7jkYATeg6CtDGEwHQGhIXy15eTNUi5lgUIaJjAXEaMCUa6K1QcXBs4QyNC4PDhJisQAFkSAAwjQsyTKJnShZ0HkCwUUZqO"
    "yoURYyYiXzLVk5JBhkGYMCxBGgyHcVaTVINF/gNTjl1XatRVJR3bkdITUvh0HwJypBwazAk7F4mGvv61ryeTJaUlJQ/+/f5HX+6q"
    "O/hEz7Z97tH0IZhFLejx7Pbh2fBEz0MI2HLm5/a3tTTdesB/E8p3MiJAgw+ufuJLn/lwSVVdCMWbK1f/9Kc/DXbwYr2PgIxxYLqh"
    "z5s3P53ztnel0QgHqHMmgXTf/KfAgPZrM191izHlgsYRDEBZIBApII2IEWOARW+lIroNtcALl4ES/gyEIyCZClxfyL7IUqSAsC8Q"
    "kZADyALd3p9+SgKDuCxI/PohguAb4DBPepyw4EATyM4V0EtESMrvlIAiwbVgAuQPIAKMCDHgDMFTgshjyIlxUJyTQk2hAglIOLIR"
    "iv5bVQigCFFTxAElokClSX8gTlIVi0UqaLwRA5SMSyUZESDy0SzWkbCc4GIqFKCAI5dWtros1lSX3LJ5QzqdQwQp5GjVLQ1IXHvN"
    "NYcccqhU5HnZr/7gnrIF5wbqTTg8uJ16HY5c+tMvkWmEpBIvaV10oAJg6i8WJF6kMV3qsfa1r5524jG9/YO1dbWMMc54NBYFBQEc"
    "JthPlFJqcHCgtbkhEQn3DKSQGwVyUpGHN1J6G8EXLQOTyLfNDvQKArlPBIY0cuQ34qJg4Ajtd4h83BBKGt1JKGAmUSmGoBGQIuZP"
    "FRARGEfGg7ZVobnsM/NZ8JY5IBESDP+WkAgZBk45yEEG5Fk/TWMBlqDwCoCKhApkRTlqOgcGJAiBiCl/5jQKC0OAPibHt+8NPL1I"
    "+c8fZDUjErYiqEQhIRAnRb582ZRLIjhuOIC07ZryaH1d6ZZN61KptM/tDtYA4+FwJJEsqSgvPeHEk95/4UVD/b2JqPmbu/6SN2aZ"
    "pVVKSPS176cXAPu6NRftgYdRTDPedctkeljvUCQQKT2c2L3un5ed2nrSqWf09fXW19VzhgN9vYMDA7bjSMRUOj0wMLBxw8bly5Yx"
    "xnRdO+SQQ/IObmzvUVqYo0bgFWBKNMynYYwpR1o5YBEeCZMMMg0sWkEWEfnjtMAmSBx9jtoYqrWf+SrFiKlMipuczBgoDwCULFgY"
    "Fvd0zrHYaJUyCDz/FVlR0YACHdnip+Caxhn5KGciEjLg+PuHBjLGmPKdIRioXBaI6dGoAImoIbBxvWka3tzHpS3DuW6x56gUAo2/"
    "LEoReR4PGUX4+vDSx8K+DYysdGNVSVVlYvPmDZl0hpRsbmo85ZSTNV0vLy9PJJKhkMkQI9FoPBZzPJGIRZ5/bsk9j7zaeMR5trA0"
    "pVHQD9uf8nc6JwDB8GANEXnpzBOm2PgP+Or3B+QgpFlRv/rV545cOLOqqkYo4TiubdlMM+KJkrKKiuqqquamlpNPOqm/v7+trQ0Z"
    "6+rqqqkqr6ooGxxIK4XIoSg4FhTDjJPnViWNX/3sB5u3bOve3c0jUQjk+QB998+iOQ+OxbFOLM8LwzgUf2P0kxHGmRro/8RHP3DK"
    "iccuXfIqj0ZIuBUl4dJYOBbW4lEeNjGsoeu5CjgimFxWloYjIR4J8bCJiajBAIRQfpNG5rLJqFkSZZEQJiOGEp7jKtRDSAqEUxbh"
    "yXgkGjFiETMWNlE4tpVD3WSoUbr/lv+6ura6cu2K1TweL8qejsfpFsvt8TP+ovQQDvu6YyCkh4igkDGZt8MmzGxq6O3q56apfKNA"
    "xgkYAxkYG5JLTqaxpqQyaW7cuN7KW0rJuXPmfuUrX547f2FleXl1VXUimTRDBqIOgAIgGSvNZ4d++r/3ls0+UXIdSPoWKPslcjgt"
    "kPIYoAMiBifAhKKc0+aVTbc5NfzyiiAUzXWtK3d3nrzoiGhIi8UiXNNDoVA8kQiFI4S6lXeEcBOJ6O9+9/slS5ZwXSOl5sydW1pe"
    "t27TzrQtuBkKVDKBwPf/yQzd/Zsfr1q+tLZlzp/ufWTd5nbSdN0ISeUU7q8aYexZaB0FDJ7hBHEy6bLCHJHIdZpry//5+F8/dNlH"
    "l6/cwRMl5GUe+N0dhy6c73kin88RCIXaeRd/smvIAc9aMKvhwT/dqXPQNF14bjSRuPFz33zgwSeMikp3oOvyS99/2xc+K5TrCmFy"
    "nk7nr7zxK+s3tunRiDvQ9aPvfPH9F57vOXmhkCFLpTPX3vTlFavatHjcG+w+9+xFP/nh908646LevI28yL2ZwBii+LlwFINCTTYD"
    "9WOACECqmXXVl1/87qb6+mcXv3rvA8+YyXgIbEtyDzgjCQxJCk1YMxordQ22bdrgep5Uat68ubfc8nmGAV5XSkGIeSufy6Qt20ml"
    "866bf+PNtTutynj9IcrNQ6F4nbhg3ZuX15g8Z+qlGwhjAWkT8t/fiRNg1AdjTLhOrGrm0FD0r0vayM1xcBi5OkLY5BGDGRr/wHvP"
    "am5t7ekfvPbTny4pLX3k4Yd1w9i0cWNzi3PIgpmbNnf0pfKaaUjm5/7c8LI33XJtY231tkSyqrIMyOXKaayp2rF5Oy8pI0ZE0jf4"
    "oZGsbBx344v16IQXlBTTDJHq+shNV23YsHnZ60u1ihZFkumhr3/nRyVRc6i/59JLLv7c5z77Pz+5s78vpYUjIu+hUlXV1Z+69vpV"
    "K9cYRjQaMXZ1D0FIF7Zl6vjVL37mH88/+4c/P2SG41aq5ze/uv3SC8+59UvfxHgzKFVTU7ure+DqK6/SQlGS4i93/+LKj1725nVf"
    "hxixWPzJRx/73E03XnbJBT/98a94ZbUCUSj6p3lPaHz7u1gMgJDxaNROZxIhmD2z8eprrvuf//52R+fg6nWrbrnx09/78Z1CEDKU"
    "rhtGZ1Zro+NlNqzf5MvKH3XUUddee+1QKl1eEh8YGLz3gUds18tZnuUIR6BihpRIeixRtjBRXe6KnFbo/Oy11T7NVGcvS5cCh6N3"
    "ihE2dR6lEDWSUlC4pCFW1qJIKiKlCKWnPLtfSC83+MPf/u2mT36wdc7sgaHUR674iGEaD9x3P9f0tu07rHx29sy5ZudAR9cgCyWR"
    "kfScqsoyJ5P637vvOfX003/wo19sWLPp/Zdd9KmPfPBvjz/95/uftpTONKDxmtpFOWWgMT8bA68tqNoEIJIjD1345qr1yEpR05UQ"
    "xMKrN+6G9NZTTj/r45+88tvfv+Mb//0zTJQwJXweo5XPvvvM0w+aNz+RKF22ZuOyVY+yWEgJTzc1peRzi5e+/vJKSNRAesfW7Tt0"
    "DQvzYeUJT9i2ZztE3POEAsN2HEAFiIzrBNoby5YtmNMCyp0I/gXjvEH3huoF8lkvIEFk+6trk9d/4Ys33HDdw4+3fPazN3/zu9/9"
    "5m3ffn3Zqz+884+O4shBOvlYCBa2Ng/0923dvoVxLj15yiknX3PNtYODQ2UlyYGB3u/9/G4nPtOI12oxU9NCcc1AxpAzIiLpSc81"
    "GFcI/5Yv9g4l+lNXJ+gP+QClcBw357mWFA4oDxC5GQlFkyW1c0rnnvKDX923fPmbJSXRjo5d7znn3CuvvBKBAKm7u3fdutUNtaUL"
    "ZjVwLys9BzXWPTD0k9t/WV7d+PDjT25Ys6xx1owv33zNf3/nO/3dPeGYqaQjUgNSOH4ZioqYT7xREpREn3xWJFoWZHuZz0ZTivnu"
    "hgoIOaICppsh03UsYAgKURFTHuQG33fRpff+4a5v//cPvnHb18HQSbqgELjBTdNzhREKlZaVVlSWJeIhYDqiAYxxXfcEgRAAHhgI"
    "oOtcY0XvXcSh1GBTU/3v/3jXvX/67YvPP9K2Y+udd/6WhQwlHWQa8JDGdTOkjYZM+uaWfldeAShfpAiVYqSw8MPCZCOwSfb/EUPp"
    "eSKdJdf+1je/csj81lSq++rrb3jg3r+k8va3vvW1F199WSmWznmSlHQylQlj4ayG3Z17tmzbCoDCE+eff97VV1/Z39dfmozv2rn9"
    "Oz+5W6s7rrzpqGi8PBSOc00j5UphCTsn3TxJAYzJANQ8AaBtZEpW/N/Juu3TFzGhQndjUjDcPlHu9/pXE8j3EY0qwQrdbiJFIDxX"
    "8VBZ5cHvvuvPT+cyg6efeUbn7t7TTju9sanx9ttv7+/rz+XzK998Y8H8g448qGX95p3pvM1MUy9t+dODTwKpeFnLbV+4/pe3/2z+"
    "gkN+fc9DYIY0sD7x8Q89/s9XOnuGuK77apuTWYkMnwrjPgXzFRCk2rq9rba6kkQGsBIZquzQ+953zj2/vuO+++57/LGnFxx2mCSx"
    "Y3evBB0QOefxeOzu3/9uxbKVoUhpOB4rrSpLpdIMwXMk4+Zxxx61etUqI1EGdZGW1tb1W9qDaJQqGo2uWr3uwx//ZHVl5UP33tM3"
    "MLh5/WqtpImEA8hJylmzZq7fuBmA40SNv8naXBPeO8aYzNtVZfFDFy38x9NPL1362hc+e/2rS1/9+BWXrF6x+je/+ePZ577rscee"
    "ZEYUlEtuvqkqUV4S3bhx09DgEDJUSl511VVnn312R8fu6srSpW+8dtefnyyb9y6K1UorA3w0PwvHLpvJkrEJoccTTmzHt3D2GhLa"
    "v/S8KRhkTqU4DQiMdJLSdZRmVBz2nj88/kwqlb3owvf3Dw42Nbd85dbbfnHHHdu2biVNf2vlypkzZxy2cMbWtt17eoZkOCY8jaQs"
    "jxgIEE2W3/X7h0KRsJtP3/K5T19x8YWbtrR37uoWRJDPs0RiP0gP6MvmmqH7H/r7z3/wvWRlddqTBBCPR770uc+kswMnnrLo+XPO"
    "lEJms5lzPvDRrkEBAMIT+Vz+rl//xrJspVRlWcl/fe7r9z/wmFFenh8c+sGPf/btr3/xnHNPl66KxmJd3b1/+tN9LJKQSgJjvueo"
    "nbHbrb7rb/rKg3/5/RUfW/7HPz6oldcIy2qd13LYQfNv+/b/QCShlBjDhoVpKzsxzpWUXjpdUVl686eviIT1ufNn3fGDbx988MJ0"
    "OvXHu/949tmnvf7W6sce/SePlEjPMSjf2lxlcNiwcb1j2QAqGo1fd+11hx9+eF9fX2ND7ZNPPvmXx9+sOeR9qJvSTQHHt2nmNYkI"
    "5NtITPzJUXES/Dafd9JlPRGib68iKwHeChRAOGRQ++pnj52Z/NgVl2Q9AUJqmvbnP//5pZde4hqXQlZUVc2YNTs1mGvb1eVhiOuG"
    "cDMgvcsuvvi5F5fag923//S77Tv3hEztZ/f8fXf7ztYZ1ccfc8xDTzznKuCMEaAihchHlwETNAZGEOSYHOq95zc/XvLK67/73cNa"
    "SQTcbF15gmsaICopEUgS7xq0lBYm6ZrgVpfFdY5CSlKkaVrvUDbtADGNoVRWrrqyNGqgEFLTtO7+gZzNeCRGgEw4lYkQ07XO/hRq"
    "urTzNRUlGjf29GVYKCz6ez//uauaGhuuv+FWXllHwvE9wqaYmI5ss5Aif+IOUsr0ULK8bNGxh7+1csPXv3LDNZ/6xPd+fPsjf3t0"
    "9co3f/yTH33ly1/tG0hpiXJgYWFnSiJaQ01pPjvUvnMXAEnhNTY23HTTTeVllX39/XXVFQ/+7e+Pvby57uCzFRokXV9gyfdkgolk"
    "mKeA2Y9vRUxjoY5saKtxUYTDinR44AJg0je3XwEwIko1AGmGtc4tq2qw57qrPhSKJ23LisVjLy558S9//YvruMhAN4yZM2dHwrGd"
    "u7p60zaGo1zTRDYPgt7//rPmz6xvaqhTWui6G74eLzF+/t1bh4YGXGV+4db/IVMjx+PxciAXlIJJ1JQmuHMKwzoyDbO2AN9OVMhR"
    "1SYDzQgDgAJJhOSPugpzadA0xpmva6JzzXVcH9gBpFA3mKZLchghEFNCABDXDSJCBtJ1gBB1E1AAaaUhPWvlBTMRJJIkxicrwMYF"
    "ACmFpAiyAywc+sD5796+cf2ll1968y3f+cQnP1Iakn/+y+9v+cLXbv7C16rq613HS6fTCkgj1VRbXpYItbW39fX1I2OkxEknnXj5"
    "5R9mjCEyXdN/89vfrdop6xacYHkCg50lmEnvRwBMhlI7UAEQQCGKngL7jXibKopw7Ehims/OfDtHAE9QaXXrkCUXP/tEU11ZU1Pz"
    "0GDqiMMPXzBv/pYtm9PpDCno7ekGpZqba8NhPTuYEa7i0QQYuG3blsXPPtU6e8FQavDVJc985vprtm9r+/a3v1lSWrlhY/vChTOO"
    "PHje5pWbyQDkOky/KczAleh6iEwRIDLOdI1pGtODf6jpiJryOWQMmMaZzlHjqHGmG8A4AgawHdKZrqPBmcaZwYkhAfrCET7vE7lG"
    "gRQAoG4CN5nynZTAcl3JWNEPYa8Srn6iH6ibKFEeoo9+7EM9Pf2JkPapqz/huJlnX3pz7doN57/nrPe+5+yXXlu2flNHziPH8ciz"
    "42GY29KgMbV58/pMNktEuqZ95CMfufjii7LZnBkKObbzo5/9els2UTt/ke245ENCimICONWsagJSIeKoNbMP07GRATCZOV8AGeGl"
    "M08syD3tR6hNDz40Qo4FaeLVP0Xk+IZvnudGSqp4rHLx88+ZIn/E4UcMplKxePyERcdls9m29nZEls3lBlOpupqa+upKO5/O5bPA"
    "dORhLVKxrb1j5eo1luVd9fGPPvjQQ3q4ZOnyVcT4LZ+9+q0VqxvrKg85ZP6WtVvR8F3BNEAOpBAVoSLi4zvrBIohFIeWzJdvIeZz"
    "WwpQ/wKEmYgRgfJlUBBI+iOrIiYbiZgqyBuBQiJGRZyBKjrTFjSaJaJvKqUYZ4Gf13hIcwFwOgxIQo2QKcdR2bSy84ah//b2723e"
    "uG7p6ys3rt24bsuOM884eePa1d17el5dsWbjtp3Pv/gaaDopoSmrvrq0qa6yp6dr+/YdUpFSsr6+7otf/OIxxxzd2dlVUVm5ffOm"
    "H93xOzc5p6zlSMfOM5QBfL0ooj5iKY/8Gn9G7bUOHvm5pv6HE6wuHKmTwktnnjgpCOBAtUdx75nP5K9VvGoghaebiZKa+a+vfKtj"
    "+5uHLpijazydtY486uimpsZt27ZZVl4K1d3dg4yaG2siISOfybpCocYyeTdvuSi9vv6Baz59dXl5+bLXljbOqP/if123ffuO8887"
    "6/nFL3b1DDGDIXHlWuRkmRmWyIkUG4FMGfY2HNFfx+KuE6AyqCjjUXhc0ZaimBNi8XkQxiCVxmSNARRtzBQHEBkwAGDIRkqsjt1H"
    "ARiir6lNROjZtaXmpReff9ppp7zx2tKqmrr6usr6+rqVm3b2d/ZnrMxpJx//6iuvCyPW3TmAepicXGmEz5lZa+i0beumgYF+UopI"
    "nnHmGTfeeEMiEc/n7dqq2icefezuh/5ZOvtEo7zFtXM8wM8WhZhpOlUsTk5fnOABuE9Lb3QCPvJgmfGuL4y4rLRP+/3UHkxj+AAw"
    "TsNwvwJMEQPTjPRvX2fmt19+4Zmz5sweSGfKkgnLsv5y771LX3sNkANRNBJqnjEjHIt1dQ929WUIQ6DrBJLyuWgi4nokUumf/OSb"
    "b61cPaOlNp5I3vzZr/KqOlSeyuHBhzTOmzPrvvufMuMxSVwogSzQyp0UYjU9zMheHXsmG/JPE/U19vIiIoGUEiyLRUJc07y+nltu"
    "ub40qgmCF15d+cYbyx958Hf/9V+fDcWr1rd3u7mhuMnTjiJmkOdqQI01yfKSUHdXZ8fu3QREisrLyz582aVHH3NMKpWOxWKeZ931"
    "uz+v3O42HnKWABDS5T6EcPLbixMhEfcVdEPTDIAJClCkYaQdjQXDHYCEZ/xvceJw3J8AQIbApOdGKxtAL12y+AUv13X4QQstAcTg"
    "tJNOrKio2rp1s+PYSkFPb7djW411leUlCc/KW64gpnEz5HhCMZMbZizEHnv86fe+5+zf/uG+vpQDHDlykc5cc81HdrXtCIfN951z"
    "+hsvvZwsTXCmSQrk9jWujXD7IRzVVdunuxh4rjBQNCV2YS+XGkYCO5ChT8cF5bmUz3Fk5YnY8cce3bl7lycZhcI7O3a/591nDg70"
    "zV047+WXXlEkLr/sMiXkyrdWesBtSQoZuPnymNbSUA7gbd26eaB/0Adgn3bayddff31tbUN/32BJMrR165af/+K+Tllbe9AJrmch"
    "CQYIwH2CBkybP7gvLc7Ryc1+nAAjJk8AwEtmLRr/hDTiVfbbhWbcW35bq59GKTSjEq5mJpP1szds3rpq+UuzZtQ01DQODWabmmqO"
    "OeaofC7fvrMdCGzL7u7t1TWtvq4qGQ25+aydzwNjyJAYrFv+Fg+Furt7V2/pACOMUknhcl3ceN2nQIrTTz1+8SvLdmzb/L1v3bZz"
    "Z3fnjh0MbZODk7XQjPguo4QIjJGvdIKj9qUJ/RaCrDfQ7lWckPnSouNqjCnyhLE5NBZkOpEBgbTy5Fmk3OqyxGEHzzdN+vZX/6s8"
    "jvMXLHjj9XU8Zg7t3HnwwQtWvvXGQQfNT2XUs089vXz1mmefXQqmScoj6SXC2sz6ylhY6+zcvWf3bs8VRKqiouLKT3ziggvf77qu"
    "qfFoNPT3h5+499Gl0RnHx6tnubbl+91DcVPYF17iFKXwxKvfNxsYt9mPrwImb8kE/8dLCicAjqqOCyzbaczSpt8hxX3nOE8ay4gK"
    "hEespHZ21ou8/NzzJFIz57YIV2qatmjR8bNmzd61a1cqlSIF6VS6f7A/HtEb66tNw8hn0kJK4KYWi7kKdu/cjWYYiHMGKjN43vnn"
    "hAz+8ssvnXX22d/+n1/NmD/vkg+8939/+5dYFL/6xesv/eBFtutu3bwVUJGTY4xLx0PNYMgZ05FN4NcwPoGhQJoCkDRNuYQaJ08V"
    "BhGTotP8e0FFX2jyO4++DylZGZBg6nj4oXPrKiuaqso/f+M1W7dtXblm60mLjt+xY2vrzJlPPf4PHjbIEx17dn7+5pteefX1J596"
    "0RJqYDDHY0kl7IguG2vKqssT6YGe9rYdubxFSjDGz3zXmVdfeWVDY2Nv31B1eXJPV+fP77x73W6oPuhsZYaU57CRPkj7dZRNr8mD"
    "UxaUtK/nAiKODYBxScvbW7XjQvztV9Ij+pCMgxKea8RLQ1Wz3lq9fv2KV2e11FXX1KTS+YbGhpNOPikejbS173RdWykxMJRKZ3IV"
    "ZaV1VWUaIytvC1cA15gZIikABEMk4lWVVUuWPN8yc1beES89989LL/2gY6WfefyB9130gUQsdvvtdyw6+aSli5ccdui8s089cdOG"
    "NfPnz+/pS0kl1dCgsnKkG4xrvqtMgDsa+6kRQHFEaTlnzaYrDgs9tz7LzfCwQzYiTdAEKO6RyBhTirhmCMdW0ouYujfYddQRB0cM"
    "/r73nH3e2Se+tOTFrOUunNfaPZRJZxyN0aknL0qnBgfT+d07d2rhSDqTefKZ5199bYU04sAUSCuEormurL6mIpdNte3YMTg0KKUE"
    "UAcddPC111572qknZ/I2YywSgsefePae+5+n8kPLZxxqew5TcrS6/X6ugX3ub07UUdnHAEBE5KWtJxTkEXCU9xniFP4z+5694JTa"
    "ptP96GOoPRSkQwIASmtnp0T0xReXuOm+g+fP1cyQY9mHHnzYMcccadtWx64OpZTreX39fbl8tiQZrauoiJqG7bmez23nSIhohNu3"
    "tw/2DRLBm6vWp/P566664m8PP9a2Y+vll33oyWf+cebZ71ry0rKujq4PffA9fUMpLuxPfeJjj//tr2ecfsp/XXtlZWVFd09vNpMh"
    "4ZCVJwLUdSQajSsFhqQUD6P7k3O0DzQ7L3TwnSnJ9YJpRvC5GNMYYwwUKZIAQEqS6zFNU64dC+l2Knf4ofOThlo4e9ZVH3t/Ppc7"
    "btExa9ZsTMZ14MbytTsuOO/sWMR49tmnh1LZGa2t9/7lr4cfcfjKNRvIjChktuVoeoikDGtUX11SX13iOfm2th29vb1SOEBUXl5x"
    "ycUXXX75ZSHTzDluZWlyx6YNd97zx9W7VdW80/Roies6DHGfqFtjvHf3ijSbEKkV/EMYgwUKTPymwSEeobU7qgjGiWwBDkQntMgC"
    "2K8saOzjJ3mTQnhGPB6rmr1+Y/uyZc8n46FZM5ozeQsBTzhh0ZFHHjkwONTZuQeUclynv2/AstKlpeHm6pKwqTm27Tk+ZZGYqWEo"
    "3Ns1kMo53DTWrVu3fvM24eIHPnChzuCkRYuWvbmqY2fHxz/+odbWGScff+zTzy1Zv3b5Ry+/rHdPeyab3t2XVU7mB9+4+fijD+na"
    "09XXO4QaLyo0+KUhZyhy+euONy5uHPJse35t9P4N0ldA8c29ERQjKbMpZecAWcQwmWeVRCMzZrT2de6+4apLb77+qj1de0wOZ568"
    "6JFHH7ntti+gYFzDp5/+x1VXfez115dv3LAtloi0NtQsWHjQmtUbtu1oX7e5fcXyNVqilBSQ8EC6JqfGmsSMxmrp5nfs2NHd0+O5"
    "LoBKJBIXXHDBxz/20dYZLYNDQ6FwSHn5+/963/3PreT1x5c0H+wIQUr6RgEjb88UnfvxLf8pxAhHpkOTDcjGiIMUhPYmxXRO3J9A"
    "GBEAiPvhi7FvKRfgfiz6vQdA8cgSSiqK1zW7WvUrL7++ac2bzY019fV12WwmmSw5+tijGxvqM5lMX28fALie7OsbyKRTiUS8oaYq"
    "GdWUa7m2pyQCMB4ykBFJ0d/dJ7iuheIrVq4+eP685xe/9Pw/F9fPbLn0ovfc9o3vnn76aQ899WJf18D7LzwnWZZ87Ol/bFvffsSx"
    "Rxx71IJnHn/k6o9//LEnnkUzNELtnWsMhAeHVdP3T3Fcy5PIZpZit2O82eZpIV36vHySTDiXfeCCD190LihSwv7SzZ/uaNvywYve"
    "v/KtlRedd+ZPbv95JBZfvX7De9595rPPvVZfX2caxjFHH/LgQ39vaGyc3dw4e+HCJ596NhpPPv/Ksl1dg3t2d4IR4oYpLUsjUR4L"
    "tdRVVJdHHCfT1rajs7vHczwAGY3Gzj333Z/4+EcOPuQgx3EMwzR0/tKSJff85YkdXm31/JN1Lep6Lkfk+8LbnUCWcEKq3SRkyEmG"
    "pBNxuGEvlffYDuxIQsxE4rgTQfknGlJMs1BWxXHgvjiOjZP8nnQcQcgAwcvnDTNWf/DZu7q3/uAX9y46bMa57z5DD4WHhgZnzJx5"
    "zdz5u3d1PPPMM6tXryFSqWwutWVLPBKtqCytq0pWK5bKeoMZ27IdAAANeTSiABSjjq7en/z0TtBDzExEDX7v3x7v7elLDWbatu9q"
    "nDU/EQ//4Md3ZF0NtVBJLFRSUnnG2e9ZsWY9McYYSqUIJYJOQKAkU+rmk81SSnUZoYwIGfmhG44MLd7JdgwKbmiSgJBL4R1+2MFP"
    "Pn7/ipU7zEjisIWz+886w3PSAM6e3v7K2prTTjn51ddW6OFYVUN9X8/Aaxvfst3M3LnzH37k+YMPO+iFF1/qHcr98fcPQDiCugFm"
    "lNy8obOS8khZSdzQeTo92N61J5e1fTOvaCR6wqJF55xzTlV11eBAfy6Ti8Xia1e99fjTz3fYiYo558RCcelYCKQhAo1ljU5BTZys"
    "DBhjzrfXrGksfrvo9BqMFbHA4aSRkOkxuimjoddEoIZPgGlmJvtDmMRxf37gJB8narkikBKeNBLViarWTTu7XlryYn6gs7WpqbSk"
    "1LHdyqraExYdv2DBfM/zerp6lPRc4aVS1tDAoCfyJclwTUUiGTcZCOm4nkegOBGirmmJKIYM5PrAUH718tWaaSx/c+XAULqyquLY"
    "IxYeceghqayzZf2qiy48Z1fbjpqamrv/eH8q76rcEDAgbjKJBirXci8/hH9sgR0OqZ+tjH5nceq8w8pbeaqmvPTva7MmRwGMc65y"
    "2YVzm0497ZRNO3vb9vTOaq4xdf3ghfPuv/+B448/gaFqaWx89bXl1dUVqNTSV1/OCrjvgUf7s+6uzr41K1ZkXI9xHXSTCU8npzSm"
    "tdRX1lWXIbk93R07O9oG+lOu4wHIeDx+6qmnXP7hDx9zzDFKKalUJBJt27H9vnvve/qN7bJ2UUXzEaCUEm6hyxm4k0yB4dnXFTVh"
    "y3gvh8BEw6WRB8h4ENHIWAqSKJx8EDZZHO/X9OqdyaymvqpMkXIFUaSyQSup37R99+tLl7rZ/qamaiMSzaazpaWlxx93/JFHHRMO"
    "h/r7+q18Wkph5a2BgaFsJhU29brqiuqKsmjIYMoVwpKuq6Rv9iWR69xMOAoyOQtNfWCw/6l/vLh9V1fPwNDQYLqlpf6fi1/QOJmG"
    "tm3dqltv/Xx3V3d/d0o3pHDDTXH1/TO0KpV5bqj0tqcGelPkED9jdqg5kduWiaztEHpIEepk5U848ZgVy99cs25dPp9712knPvjQ"
    "34868si1m7cte3Pd+y543z+ef2nN+i1rN2zp2L27dyDdN5TTwiWOlGAwZAjSY0okQ7yuOtZQUxqPaLnM4K5du7p6u/N5WwkJpGpr"
    "a89997svu+ySo448giGXSsVisV27tt3/0CNPvbIpG5lTOudE3Qijm6ZA/3DiVb5X8sr+7WjT0duEUcMh3CuKcVR14bt3zHjXLRPk"
    "Nv5xMTrfGBU6wYGi9sdPGwuWvPsLtdjbH/opt+9+RYqAGNd1XdipofaNUa/rmCNmLVp0XHlZueORzlk0HB7o7Vm6fNkrr722ffuO"
    "gqK7pus8FouWlZYl4nE0wLLU4JA9lMnZnkuogRZmmo6oSAkkAMalbQEA002VHQTDNAxd58yy8scedcSmHbsHB7Oawbx87nsXxD7W"
    "ONjnJd/7gLWzJw1GKQjr9gsiH2jObsgnLrnP63M1Fop46fQHL3rXOWeduXnr1jvuuPOwQw7Zsq1NSCmZMZTKg+cCZ2iGfOFHxrgi"
    "SZ4CJTXuxUyttKQkGY8DyVR2cKC/P5PNKU/4/ROum/PmzD7xpBMOOmhB2Azn855uUCQSa9ux+bnnXl7VljUrZpbWzhOgKTeNqBRy"
    "nEZ3ZfrNHNobKeqAIPOnhUzBEQEwBmpXEEEYHwBFXg/tZwBMb3G/jQCY6A+JFGeaHvbyQ0Oda6NO75ELGk45+biGxhm25aWzjs6A"
    "SHR0dLy54q0VK1f29fYURoWapmnxaLS0tDSRiCMy25WZvJPJ5fO25ykGyIExRGSMKyASinMNEKTyQErOmczmIBTlZkha7tmz6K4z"
    "SYXNWxY79708FElqFaHozr7B2jh78MOlhySGbt9U9+UnMmY8KoQ0ddI5ZjIZYKgcAYbp2w1xM4xcU9JTngMkgVBTMmKyaCJUEouF"
    "dE0KkbPygwMDmWzWEwKUL84MFRWVhxxyyKLjj5/ROsPzvGw2HwqHkLk7tu58+dWlW3bloXx+oraZIUrPG9MD/39pAMCkAVCsMMbx"
    "EliBT0BFVvV+r9op4gcP0BC6+MVBkgKpmbpukpUb7NyIuV0Hzao4/fjD6xtbkIc9zzMMwwwZg0MD69etW/r6svWbNlvZDAAAaACK"
    "6xiNRJOJZCyRCJshUpizRTqXT1uW4yrpO7OghtxApiEoIKGUQs5AAUoV092HPxA5psz+XVviur/1gHS+fHblRS144f1DO/vs8w8v"
    "uee9aJP5qafw8Q3KMJnr30WGAMQ5V4qRIpI2SIlIDFVI1+KxSCQSiRuazqSj7EwmlxpKZXN5z/OK6zcajc2bN+/Y446Z0dISDoeF"
    "EFwzwiEzm8lsWLvmleVvdfRJrWZBsmo2IyWFTcCAkb+/jdevnk4ATEeZZ4r+ypj25f4ppE8nDPwA+PzIxGekdDoUlAdHR/OoAHib"
    "q/ZfGQDFMZNvhcUNnYSV7top+rc3lGknHHXQUUcdHkuWWrbtOvlIJKprRltb+6pVq9asW7t163bbzhfHGYyhrhnRSDwZj8XicS0U"
    "UhJyOTtv5TN523KlgECmgTFOCAaTTlrcdEr0a8cPrRgqu+TPPT1D6sbTSj53eC6bkWvdik8/3N83lP3hRS03H2G91G2e+0cnrxii"
    "BOCKVAD2J9AYmVzFouF4LBoNmzrnpGQ6mxoa6M/mc7bjKlnkIUA4GmltmXH00YfPm39QRXklSS9vZYFxjmxosH/V2g0r1mzsc0qj"
    "VQtC5dVMKU9aQMB9By8f0anggAfAFJ3Df1cATBcOPWEKBP8XvsZwYYPPohQgcN1E4M7gzlTfzgRmDp5VedSRhzfOmBkxDc9z87k8"
    "AMVisb7egZUrV65ataptZ3sqlSpcEc2X6gybejQWj8djyXhS101PKctxs/l8LmulMjnUokJoR1S7D1yoyKDLHpRvbM1//PjEHafI"
    "nOP1eFpdRDy1O37V/b2myf96ReXRFdnvLY388Pl+PV7i2U4spIWj0UgsEjO4rqECKZXM5XL5dNayLcdxXc8BNXwjysvLm5qaFixY"
    "MGfO3IqKcl0zhGLgOaapWV5uw9q1K1at39aZFnp9snaBFk8q4UkpEAAZG7OvTSGcOiFaezKjiZEh4UOYptlkn+zVD9TmuG8BMDIF"
    "GhkA0/fX2I+APrDnAE0oDwscdOQal1Ym29cBmY6qKBx58OzDD12QLK9xPQ+RhXQDARzXyeVzXV1da9as3bxly549nfl8dsQ8mhl6"
    "yNC1cMiMRMORWNQ0QpbrdezOKEf97mK8cJb96edCd73YfvnRlf/7/uTrm93fbZZtffLDh7CLFxp/34Qf+2vXwlrjrx9KRtF9/8P6"
    "ql1WXX15ZSLCOFqWncuks/l8znGF8JTnwYjdJxqNNtQ3zJk7d86c2eXl5dFolHPNdmylKBaNhUNa244dq956a93W3T12yCxvjZc3"
    "oqG7QjIhR3Y1xiyDKSRV9jtNn1RwcvSceOoAOFBr450KgCku039cAAByUh4DAMXIZLqGSHaqL9e3Xbf7mqujC+fNPvywg2vr6jzP"
    "y2SzDHgoZErl2Y49MDjY3ta2ZcvWjt2dnZ2d2Ux6FFZP55pmzJoxS4BxRk3qF6daP11BNz06cNpBNVcdE3r4zcGHtyrP1kHjgOrQ"
    "au+ao+Kr99CvXt354WOrf/NuXNph3viKacYTWzdtyOfzQohR1wFZIpFsbm5uaWlpbqivramuqa3TNJbN5WzH000jEg65trWnY9em"
    "LVs2bN+9u9dV8bpk5cxIvFxKJT2HUCDCRCZx0zoB3qGDGiahy7xTrzi+CN77EhyBmCj2iA5ssv5OFwN7uwnIuKZpXCqZG+px+9tC"
    "Kt1cE5/d2tDcWFNX3xgKxZy84wqXa2CaYcaASA4MDLS3t2/btn379rae7p7BdBqImKYZHONl1UfXmuc2ydueTaX1yFH17K02y3U5"
    "hg3ONUSmgKTtgO0cWo+dXrSnp/8HF5Trhv7X7eGNW3bkLeG5FgAYpllWWlpTUzNjxoyWlpbm5uby8nLP8xzHE1JwjTjXSIGVy/R0"
    "d21va1+3uaNzwFZ6aahiTqS0knMuhCApfGdwDOSAaeqc/m0vvrECDVPsgBMWEm9zAz1gATB8Kr2NABg5XJv+mv6XBsDIOEBkmqZx"
    "XXoin+mx+3eh1VcRxxmNtS1NdS1NDbV19YRg2ZYQtlKSITPNEGO6bTm793QODA488cQTHR0dyLRILF5b35TJOD0DKUITDK4hCMUQ"
    "FEMJgAwlgSFcl0vHjJgtdaWpVKqzq9NAclx5yqmnLJg/r6ysrKyszDRNzrkvXmEYOmOcSHiemxoa2rJ1y4bNOzq6simHQ7g8UlZv"
    "Jqo4BykAlEDwefQ4/eJtCtnw/28FwKg39y8/Af5dXwjEiBQCMcaZwTVGJJ1sNje4x83tMWWutizRVF/WWFveWN9cUVlpmiahAmCc"
    "6Z7n6bre2dn5i1/8on3XTq7zkpLy1taWrq6BPb05aYYYMKaUYsGiQM5NpVzhloZ4U2PFQP/gno4OoTwiuPiDH7zgggss25FS+gko"
    "15hS0nXcgf7+tvb29vaOju5UT1q6LBJOVkXK6nmkBAmU5xJ5EklXAIDE+L+jezGpRM9ky3r65izT3xknNdOeOgD2aZS9r93Pf1fM"
    "7MtLD+s5cKUIUCECahrXEFBKN5/rd4Z6ZH4gponKklBzTVlzQ311TWWyJBqLxzMZy5MKge6+++41a9YYZkjTzabmFs/x2ntTCjSG"
    "mkQ/GwEEANetq0hUlMV3te8YGspIAs7kxz/+sWOPPTaTzSSTCSeby2bznb3dO3ft3rmrs3cwl7LJ0+N6rDaaKDdCUW5EFZESDioB"
    "gekTIvjujUjDQ03aj51yzJa33zdxFIJ/kmr4X7aQDmQAwGh834GKXRjn+/cvriiKg5HC5hm4JiEiZ5xxDgw96ch8zk4PudkeAx2T"
    "e6UhddH7zqlrqMvn7NKSsocefOCRRx9l3ECA5ubmSCy+o6Mn5yIaYUYSpCAv19JUFY+Gtm7aaNtCSq+stPRT11zT2jojb1mJeOwP"
    "f75v645OW2keC4FZZsaqwtGYFooA04GUkkIKETiqvgMl439mAOwfCmHM5+IlrYv2Ssfcq2rFZNnbfpi8TvY5/131dFEPaES7Ewto"
    "JiWVlFKiIt0Ih5PlZmWzXtbIkk1DjvHK4uebqkpmzpxpWfapp55qmObKlSsUyaHUkIayob5OeG7esgCVAd68WQ2g7E0bN3qeVNKb"
    "O2fOLZ+/paGhwRNCCfeXv7xrQzcPt55sVMyPV82KltbokQiiRlKRcKUUwfvEd2T1F89CGEHKm06+PuH9HYNVHvMk45uhUy+Jt8+z"
    "nQANOqEU0XQGIvu3dic6Z0bx+g9s3XNAKM7+aiP/PwgATAFJ5YHngJSgyExUh5JVL77wzxC6hx+2sKunf86s2TNntq5bu9a27axt"
    "O47dUFeNSnJQBy+YlRro27Z1KxFTSpxyyinX3XCDJ0QoHM4M9v7oZ/f0aS3lc46SQjBle8oDKVH6tnRAyA6wjuWEq3acyMJ0LuPU"
    "dusjSTDjJRBhSmLkAdlYJw2AkSvybWKh9/U4K/bQx1zwf00fet+iKCAeFLh5ASmPBVh54ZAeTdbOXLbsrV1b1x958Ny8LasqKo48"
    "8si2traB/n5XeEODAxXlpQ3VlZ1du3a2tysFAHTxxRd/6NIP2VY2Ho2sWPbm7ff8ndUenayZ7doW81V/IBBWGb01H+AAgAPnUff2"
    "f7tXtsD+f4TJTgCYfP48tV7NyO/3L9sef1v3owiZvrzp9I/yfcs+EYFAKl5WN2fj1va33njxiEMX6rqm6fq555zT3dPT3tampEyl"
    "hgZS/amhISlkMpm88cYbTzrp5IHBgarSkieeev6Pf1tSufBdLF4j3FwRPvCv2Q7+vat/wgPhnTjfaDJluClYmNORtdiPg+LA3tTp"
    "lO/TVyncr4chA8VACCFKamcNebj42cdbGypaW5rTWeuYY47lnK1fv54UEYBwxdy5826++aaGhgYiFQnrv/nNH55bubv+sHcjGCAd"
    "GOt9/Z91Hv6f7HEXehu8dOYJ48uUSfsAOMpRFqe3Pg5sEj/F+xyZTb5DQTgd/l6h14iAHBhKz4vFq/Rk7QsvPGdIa87s1lQms2DB"
    "/Nra2g0bNji2c/rpp3/mhusRyNR5Jj34g5/etT0VqV14sisUoCyu/gnp5P/er3fozv7LzjcCCAwypkMdmKAkoEkTp/EGo/9RA4HJ"
    "7EH3eh32KmQLY2G9BEikGNNCnFHn+heOnRl+/4UXZPN2TXXNzvYdmzZuOPvss1PpTElJcs3adXf99RGsPCxavUDZKY2BGmH3+390"
    "tf0nxx7hOxwA70Rf8oA0QN/RABhdZSEwUqhAaRxBCxk9W5bV6n1XXXFJeWUVI0lSZnK50rLSRx958smXNpQtPJPpIXAsYhqxvde4"
    "/8aR4gHvQe9TX/9ABUDgEAPT5yCP7o7tR24w+QuwYcWuYtSNS7doogRsPzgT41sN0ym89nVO6ZutI/laIiQ8UVo9I+Xpry15rrWh"
    "vKq2znWl5zm/+d2fXt+SrT74DAJDCocx39L7nTr6p9Nq/Fd00qaRr0723sZJPOzX/TqAAfD2L8gEtjYTSKxPpYex32ti+t3et9mD"
    "QwDhuZF4pYrXvPDc02UGmiH2o1/9pU82Vc46ynYFBxeQv0PzrMkC4F9cWI/fHN/mBX87ATBskjf1H4xPgSYU0pp+bjBlABRoBsP+"
    "KsMMbcLCqqV/KQhvis1mnyidiKCAaZyjdAZ3rtRAaRWzjWSNsi3Ggt7cf0hivRdD2/2SPBlvivH2E7z9Qxn7a0mbZqxgQQqssB73"
    "cnSOT7jHMhILNs5Fr46JY5dgzG8RhtWT/5UZ8Lg3vPf1MeGNJAIERUIS6smZx5NUjKR0M4xxKIq+/luLy7e/706zDJt+pjrNh+3b"
    "6geC/TDKLmrQ7UO3dfJh0+h52fTq5v+wXsT+ll8MQIIrCXx3Db0oN/h/4v3/h7/W9N+Utq/RTOP4cmPkFyfbTiZrEE1xXaa/xf4r"
    "e2pTyMCMP+umPg9pBMz039WZ2debsh9fSqkDOMEYw6x/O0UnATD4/7/+TWvuP+QEe6c35mLq+B95DVHbv/pjTNY1fv8Yj4A9IBXY"
    "AYCAT/m0+8rInmK2AHvTy5iAoDRtMtTbb1xOMx2fzlt6p2Xepjij9pog7M1xrFADTHjzxqtLT/PF9sPWEyZ3h337mc/IcJ3i6JxQ"
    "mWOa5J4xG8HUSOC3U4yOEf7e13iYTuMF3ja/720ziQ9ArjvNF2V7ffTb2W7/c7Ar/z+I4P/Klf8X3yltmkt/jFroNAcZk0kdjd88"
    "pj5D3ualmaY11fj3M/09bMIPOL5c3ickxdQH6WTqf5PJMe3l8+Le+2xTp0P7l/eOv3QTXvnx30yddPll996yNUKg/wdG0CKOP7/3"
    "+gAAAABJRU5ErkJggg=="
)

LOGO_RIGHT_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAIAAADTED8xAADd5ElEQVR42uxdZXgUVxc+946s78bdSfDg7u7u7sWlSKEUSqFQaCml"
    "SFuc4i7F3b24Bg9xl3WZmXu/HxtC0EILlPIxzz48m7DZnZ058p73GEozUPh0fDr+Xw/86RL8iwellBCJ0k826JMC/D9KP7Ac0mgZ"
    "lkWfVOCTAvzf2X6Whcz07BPH/szK1LMs/EM/QCmVpE/O5JMC/BdEHyglhCiVcPbMyWb1ql88f06pBEJI7msIIZIovpFAMwxydWFk"
    "smedySeV+KQAb/kghEiS9JqvJJIEAAgAIaCUIAQyGWJYRCkBALlcoVSpKVDkfM1jmVWpsLsr6+LCMAwCAIQAI8AYKCXOwAHyvJ5S"
    "yjKQnqFf9vuGmJgEjntK6BkGUUolUSSEAHxShk8K8I+Bu0qFtVoGXmJoEQKgFCgFoBoN1rkwCAEgoBTkcowQxCdmmMwOpZKjFBiG"
    "IZIkCgJ6LNEIqFyBLl26tWL5hp3bDtrsDpYFAJAIkSSi0WCeRyo1ZhgABBQoAMUYyeTk6uXz/Xq1v3r5kkoBlJBcjbJaHXI5cnNl"
    "VSoMgAj5pANPHeynS/CauAUhRCllWXTq1EWLyVS9ZnUiASAghCIEHIdEkQIFihAvR0ABYTh+7LzJaKhRuzZQIpfj69fvjfti6IO7"
    "d7Qurl9NnNqhdX2MMQBIoogeewyVCu/edXBIn+7Zej0C0rF7nx9nzVIo8PgvJ8bHxtSs22Dn1k2Va9Tp278fQojjECDQZ5vd1aro"
    "B3e9Pf3C8xcUJEAYUaA8jxIS0/r16BQUHFqxctXCkcWLFS+m4JHNDgh9uqWfPMAb0TVsjo3mZfDbrBl9e3TI1htZDiRC5HLE8chg"
    "MPMyxPFILqMH9h0ZMWz4jB9+btekbo8OLb+fPInnsSCSCWNHXr7wZ516Daxm45wZ0wx2qlSpAUCQROfHIIQohTXLf/f29du6Y1uz"
    "Vu0O7N4RF5vEM/Dw/t3DB/Ys+nX2nagbUyd8cezIUZ0KpaWlfz5ocJ3KpX/4ad7tqCgPD8/g0BC7HTDGRJLkMjh/9syNK5e2b143"
    "fGCfTi0bdmnX8t79aLmMfgoMPinAG9h+joOsLP20yd+YLWYGSKt2HVu06cjzckmiChl+9Ch+QO/PGteuMqBP30cxcWoOmUzGzWuW"
    "r122aPSEb8tXrrZ2xdK4uFQAKFm63IxfFi5Z8luj5q3jYx8Zsq0KhZJSSqQcD4AQstvpT7/MW/PHvirVqnl5+xJKBcFuFyE9Pc3L"
    "2+ePfQd+mD2fAsTFxTEAUyZOXLdyibeP/5L5cw7u2RleoIBayUkSBQCEsSTBiWNHVGr1nIWrxn4zOTQs/OiBPfPnzuF4BEAQgk9u"
    "4JMCvI4CEIUCThw/tvDXn2Nj4+QMbt6yWdOWbc+ePsmw1CGIX48ZvX3zWq2L++5tmwb16ZmcYS1foZJcIS9Vtvy4MUN79x2gz866"
    "cvG8SoEnTx0fEBjYoVPP7ZvXMwy2Wi0yhQIhJAgizYFAlOdRUmL8pLEjCucvtGndSo1Wy/Oy1HRzQmxM9Vr1grw0PM9jhAMC/O7G"
    "Zu7Ysr5dx54Hjx7qO/Dz5MT4IsVKcSxQSiilLIczshxnThwtUbpc587Nvp4wes6i5Z6ePukZ6XYBEMKUUkLJp/v7SQFeKvmESAhR"
    "BOAQSL7wCA8Pr0njvpg5dyEg8t2EMVMnjuM4HB+bdPbU0baduu8/dGDG3EUXz51avnyFt4+7u4eX4HBIRArJF6FQqu7djeIB5v36"
    "e5vGdTMzsho1b2OxmPVGs0wmYxjGahMoAAVgWTAYbZ/373vx/NkfZvzctn1nq8Wi0WgzUpKMBkNgcBClND72ESDk7e3955lTNqu1"
    "S88+MhYCgoI4mSx/gQIsdmaXiVIO1y5fjIuJLlG6vEMCDOCw2cwWU2BgoJIHURR4HqlUGCEKQNEnBfh05B7oMXuo0zEMixiO0XD4"
    "6qVLJpPxxtWLvy9YIDigZdsO0Q/u3r2TgDFYLObipcrKZahV29ZlK1TetmmNXI4KFi4aE/so0wLhEfl8/Pyibt0y2OimdatKlS67"
    "f98fbTt0NpstWRnpCoWSZVmbzUoBKKUyGXpw7+GD+3cGj/iyY7umNocDIySTybOzsx0Ou69/EEIoPS1FJpN5ePneuHbZ1c3dy8uD"
    "SFJGRjrPy/wDAgUCCCGEgAKcPnUCIbp+5eL2zduMGvnlqKH9KYVmLdsJItVq+fiE1CuXb2OMWA5R+P8Niz8pQM5BCJEkkRCJUMIw"
    "1CHYZ/+8oHn9um2bNj7x5/VKVSsXLVEaITRk1BhXFS5TrqIoCGdPn9Do3BQKVdyjhw4KGItlK1aJiY7W68WikcUS4mIT4xJdNUxI"
    "WL6H9+7YRSSXK0xm09lLV5Yu/JWIQlzMQ4VSKYqi1WJxiqAkgaubm0aj3bJ+1bARX23bvI6XyQXBER39CCGUL6IABUhKTnF1dffx"
    "9TBkZ/EyuaubO2aYk8eOeXh6RuQv5LADQhhjxmKBU8cO+QeFBoaGnz11dM3KlZkZaZOnzy5bvoRE0dJFKxvVrNi0btURQwZbLRaG"
    "oZIkOaMCQqRPCvB/CHeoSoXdXFhXHcMwWCaHJQsWTRo7Qp+dfSfq+ohBA4KDA+YvWckw7PXLlyiCQkWK5MtfYO+OrT7eqsjiJQ8f"
    "2JuV5dDJWKAACESRFCpawmw0JMTHsQBFI0tdv3o5O0vfoUu3O7du1qlcPTU5JaJgkWtXLvIy1j8wiJfJCAWMsd1GQkN9+g4Zcf/u"
    "7fNnT3frM0iuUOj12fFxjxRKpbenh0WEyxfOqTVqVwXy8PZNS0nctnXzLwtWHNm/Kzx/Qa1WKUpAKVUo4M7tu9cuX2zWqt3mbX+E"
    "FygcEBS8efeBHn068zz8sWXnl8MHVqhUvXmrdutXLT129KRCAQoFw7DA8qDVMv9X8fH/dR6AUooRIpQqVejKldt7d+1QqtVt23fM"
    "p3I5dfyIX0Dw4TNnDuw93KdL6y0bt/bp0bZqzbp7d20b9sWYQB9tlWq1t2xYlZpm6t53YJ9Orcd9MbxW3Vo7t24ICQt3d+NDw8Ik"
    "Sbp86VKjupXKV6zYvG0ns0nfsVM7hUKVlBDXukNnQSRARExh+76jPMdZLYARAwB2OwwaMqhd+44arVapYvsNGKTVajp3712tZl2d"
    "i4vdDo2atsQMaxOhWcs2G1YvHzX4s/yFIgXBERwaLpeBySxRSjkGnz931u5wlC1XwUXJVqpSY/7cGfGxCeEhPklJppnfTy5Rqszy"
    "tUstVtiz84+E+Hg5Qlt37J03e4Zao+nUrU/T5o1FkSJAlFJKAX3U8Oj/QgEIIc6U0zPyz3HI4ZCUSubq1dvdO7RMTYwnlK5fuWzd"
    "lq2Dhw9HCCcnJS1fMp9Sum3rxu7d2zZr2Xbb5nWnT5zs1rFp1Rq1li/57eSJEx3aNT576vNlC35Z9ftCDy/v8VOmY0q9vb0XLF9X"
    "oHARvQ2qVKtep351UQSrjbZp15gFMFrBaWUFEVx0GkIhtw6IEiAS9fRyIxLYrcTD01WSwNvLNcDf1WYDSmH02GGCCEYrLVQobMmq"
    "jVcu/lm+as3F836pVLUag4FSwJixOuiubZv8/AOKlyorURoYFEgJvXLpUv2aZQ/u3x8b/UCrc2nesFnJMhUIkfIXyH/xRszwAb0j"
    "i5dMjI8b3KcLw65t0bKBXi/I5RwACA6CMP6kAP/ZoBaBUolttpwAlwKllGKMWRYZDBa5XC7n4MiBAymJ8bMXLJcrFLu2bREJblC7"
    "StSDpBYN6nj7+PQZNGLN7wvOnLteq3a1kNB8i+fNSU1NatikhYur29YNa1q3bvDtd9/Xq98wLjYmsnjJ0mUijRaq1WnatW9id4Dd"
    "DgiBxUwQIISQXi9RSjFmHp8bclKgT1lZhBwO5y+xw0ERQkSidjvFGCMAvV5CCGGMbVZaomThiuUKWxww4+cfRRGMZsAYswzS622E"
    "Qu36Tby8NHYCwWERvEwWHxcNAEcP7fP1D/jiq0mHDuxc9ftCtcalWPHi8+bONpuN30z9KSAwoGio79nTp1u3rq/VcVmZdlEUPL3U"
    "Vgt8rKkz9qOXfkGQom4/KFAgP0aUUsTziFLEc3TxwuVLF85fvnazu8ZPlCSlUl2uQqVCET7NmjdkWUAAy5f+npmRduTcVSDS6qXz"
    "Vy9fumDez+0695g6YczF82cji5ceO3GaSqmwORCltEGj6iyAXQKLmSKMJAmysyWEMUaIUkAIAwAFyBX9PGeIXnTa6KknCGGE8r4D"
    "pQAIWSzERAjGGKGcjwBAogQqpXz1xj9sdofgoMCh/AUKchz/4N4dCpCWnKjSaLt3bl6vccOoW3fsVmOwj0alUgMhIwb2mjlv6eZd"
    "uzQ6D0LRovkrls6fI0nikJFjO3dtb7MShPHHpwbM6LETP1rkI0kaDd64cVvP9s1KlC5XNDJUEGlycnpcfJK/n3uW3rZ43iyzxdqs"
    "aYMso33DmuXhBQqVLB1pMDhuXL+TlJ6VkZ517NDeMuUr3btz68De3bduXC9cqnK79s09/cLadexasXKFChVLFI0saLcBQshqlSw2"
    "IgqQixYQxu8aPTtdAXISn0/FNoAxkvEsIYhSUKlUVWvWCQyOKFA4/9WrUXt3bHkUl/b9pAlRt24MHj4i6s694qUrRkVFnT9z/PKF"
    "8wM//yIywn/ydz9PGT8qskQph92+84/NDZu29fTS2e0igxFQ6qyM+khM5EfWE+yscsm5PZRyPCSnpLZv1lgidPv+w94e2m6du9+J"
    "urHz4LFAb82XY6f8NuuH9dsPVK9evlaVqqIgbNt/NNBT0bZdt5vXr67cuL1fj45RN66xHNd/yEhPb48KFasWL1GE4wAQWC0gCoQC"
    "MBh/gFeQQk5xkbOGSakESkEQaFJy+vjRI08dOxQYHDp+0rcBAaENalb69oeZ3bp37N6p++5tGxev3hQQFNqwerlO3XsvnD9r+97j"
    "3do1X7N1X+3a5QgBhwgMBozAydx+8gAfXLDLsjl2FyFACAkOEuyjKV6h9rIFv6SmpLdo1gB49fJFv3GcombNKvkKRu7dtePc6RPd"
    "enb39A5cPG9uSlKiq7v7nl27DNlZgz4fVbNOPYRQ05btBg//vEbVsh5eXnY7tduJw0YpvMD0fkCG7WlwZbcTQaCEYFdXVeNmLZu1"
    "atfzs4FlikdkZFtWL1uUnZlZonjRqDv37965NWTkuDk/Tn1w97Y+O9tgssY8iom6eX3w8NEynpv/68KvR4/eu3O3l09wWHiAmFPA"
    "8d9Wg4/HA0iSpNUyKSlmpVIhl2GHQAFAJkcnj5+7euXy/l3bLl84O3fR6i7tG3Xr0W/39q2bdh+pUaHIgt83ft6v+6QfZo8e/tmk"
    "qbN++u4bSZIIkQaN+HLCpK8pxSo5EACjCSRJwggjnFOG/5+82c66bgwyGRIEcDhEpZqZO/O3mdMmEookSfj62+/rNGxap1KJfoNH"
    "qlTyZYsXPrx/u23H7r+vWhodk9GlbTOWQSnJiZJIVm3eUap0UYcNABD5LyOij0EBCKEIUa0Wnzt3/cvhQ0qXLT952neCiGUyFBOT"
    "2KJBLUN2Vsky5W7duKZzcd2x75BdEOtVq1i8RKm1mzcRihrVqpGQELd1z+GihYO3bT98/uypsPCIlq3b8jzjcBCgxJlcRYA+GrBI"
    "KUE5/ovyMvTnuauXL5zNX7BokwaVV6/b0a9nx407DjaqU+HqneRd2zaWr1S5apVSGZl2k9kaEegyZ97yMUP7zVm8ulf31olpdqVS"
    "xjLgZKs+QaB/5V6CQoE4GVq6cMWY4YPv373l6u5dt2EThsFyBXPr5v2l8+cOGDZq8aJf3H3CNq9fmZCQ3K9XR8y7LPjlJ7WLj7+/"
    "z84//oiNeWQwmOo3bJi/QFi9utVLlCwqSliSAGOEEEYIw8eVG0UoFyIhUaShYT5VKpUJCAkSCDUY7Vs3rIl+eP/QkRPzZs+YOPUn"
    "f3+fz3r0+ebLkYcO7I1JSDt+aD+hMO6bSQix3Tu1T0tLK1OuNMsylPwnrxH7H5d+yjAQG5s066cft6xdyXLc0FHjho8erZDzHAeS"
    "BL5+fjoXl/T0NMKynbu2jIt99MOkcb/XbzhwQI/DB/ZOHjfip6nfBIWELli+zsvLWxCRwyECBUCIwRjgI59WQmlOqGA2ExMhTrK1"
    "bNliX4ybuGT+L/fv3mnYtLlchkYPG3b04N7hY762WW1rVixKSoibNX9FeJD78FHfnDiyLykxbsv61UNHjWvdtpHJRBjM/LeyZv9t"
    "CCRJkk7HzJm1ZMLogaH58n8zbWaz5nUZDEnJ5r27drRs3UanYYcNGblxzfINOw7VrFo8NkHfunFdk9m0Y/9BlUY5ecLkB3dv9R/y"
    "RcvmtawC2GyPiyLp/1f3OHoqlKUKBUpI1AuCUCjM49KNRw2ql2/Wuv2ShXPOXr7fsUX9StVqr165cPma7UM+61KmfBUvb5+L58/+"
    "uuj3ejXL2wBEAWxWilAOXKQ0J+34SQHelQdAiDIsHTlk+NaNq2bPX9atY7NTF258982EA3u2T/hu5ldjh96+n9iyYR2VSr1q87aQ"
    "EN92zdscObCrbuPWq9avYhhw9oSYzQQhcN6n/89uwbw6QAjheex8kpqa2a55w8z0tJp1ap8/96ckSQeOnsrMSm9at3ZgSOiqjVt0"
    "Lu4mkxEjWLdmrUGf3bhZy2LFIqxWihAiBDACuQKs1k8e4N3pAKEyGTKYTJ1atXr44Hbv/oM3rlkdff9O1dr1x46fUKxESYUCHzp4"
    "qnfnNh4engUKF7l6+UKz1h0LFS7Ysk1bBDng/omJov+nk0OedgJPhlzI5ejihesH9/5x+dK1/bu3LV2zpXWbJvVq1o179GDT7sOF"
    "CoQgDAf2Hx0xqH9aWgqi1NPbd+majaVKFbVYJJ5n7HZ648b1YsWLfbDhwX8+CMYICSLRamUVq1TfvWPH/p3beZms+2cDfpg5Ozw8"
    "iEiIUChcMKhU+apXL1++cO50lZp1ZsyeVa5spCAwCD3N5dP/37k5zygAenyIIgQEeDesUz1/ZGmJoF59+44f89We7VtmL1xWvXpZ"
    "QuDggRM9O7QOCw9fsXZjyXIVN61d4eXlU7t2FZtNkimYiePHjxs5uFrtBqGhPg4H+QCZov+SB3gqy/vkVgEASKKkc2GOHbvYu3Nr"
    "X7+ArXuO6LScJIEkiZO+/gYh9P2MKSYTTU5K8vL24TgkCIRhmOeDwk+i/6LLTiSJyuUML4cH91JaNqrZok2HydMm2CwkOSWteb1a"
    "Gp129aZtBUK89h4+17JBzRlzF/Tt19Vih/Ffjvtt1tSRY6eM/moUUO7DbD75zyiAs6QZYxAECTuLzJ6+eZIkueiYFcs3DR/Qs2mr"
    "DguXL7oT9eCbr8Ye2bfD0ydg3bZ9RYuEEQKiCIS8pAPwI/UA6C9+fs3rTwEoz+OExHSNRqVSyJQqPGXi9F9nfb/2j311apY1mMFg"
    "MB4/drRKlYo+3h5jRo9bv2LRqPFTRw/vk2UCiXygTPJ/gwaVJKJSYbsDbDaHuztvtYIgUIyfuqIMw2Trpa7d28Q8ipk59WuO429d"
    "v3LtyvmqNep/M/W7QoVCbVaS691fJilO8oL+W2L6ARPpGCMAJAg0wN9DFIFSsFjg9InDwSH5qlUvG5dkdNjtfv4e7Ts0FUT4YuTY"
    "xb/OCAoJT4iP2brzUK26tSX7B1o79B/wAE6u88L5Gz/9MC09NblW3Ya9+w9wc1VZrc/qgJMU4ng8tP/gtSsW6HRuHbp/NmbcWDc3"
    "ldlIEc6dvfmqyVDoeQWg70LYX/y7D/lmOIuuHwNRYDnUo2PnQ/t2tGrf9db1K2qty4ZtW1iWHzNi9PKFs9t07lWydOlffvpeEKUd"
    "+49E5A+1Wsnjmm0ghHwglVQfugcghLi6MIcPnR02oE9SQqy7p/f0KV8fP3pw4e/LvX28HI6ca+qcBcIwDCVACf122g9GQ3ateg36"
    "9O1itYLRIOUifkKITIYxRm9gkd6LArzW57xj/UCvPj0Kdjt1RmGEEAahMV9PMpkM+3dvDwwO6dO3HyfjxwwfvXzh7FHjp345bpSa"
    "g5NHj545cZiQ3L4GoDRnAqQggCD8+9MoPmgPQCmVyeDk8VMjBvdPSU5s36XnsGEDt+/Y992EL9t06vnzLzMddsCYoRR4HmQyMJud"
    "vYWUZRGhIOPBZiUUciwNpRSAKhQ4NjbVbrdh9MHV9uQ4n5fM6fl3ZYVSihkmJMRPECgh4JziqFCAxUJjHj0KCg7S6ZihA0f9vmD2"
    "19/N/OLLIRRg8oTpP3//zeivp4z+aqTFTDDGztHwKjU+ePBMcEhIcKCvQ/iXi4g+XAWglHIcSklJa92kQezDux26fzZn3kxJAI6D"
    "BrUbJSfGHzp1UaPhzGaR41BiYtr+vbs7d+splyFByCGL8rYCU0opJS5aZsWKTT//MMUhkA+puI3mgdpPoNqHBX4AiYLYtVf/kaOH"
    "2GxUFAFjRAhlMGI5kMvgmwnTf5g8ZvIPv4wcPYgQ+H7KzB8mfdl7wOffz/xBFCilTuxEtBpm2dJ1nw/s3aXngJ9/mWE2kX83T/zh"
    "QiCEkChQHx+PCVOmjx7W7+KfZ44f+7Ne9XK/r9p2N+pGvoiCUVFR+cLD3d2VahZ2Xbowcmjvm9euzpgzAwEDCEOe9BYhFGOqUjOz"
    "Zi2c8d1EAMbfT/YBUj4IgdXMiwaKPkjC0A7Wn6dPSktJ/vb7yTIG220EM5hQarMRANyiZYuQkJAu3dsBwPdTZn4/acxnA4dP+2m6"
    "KFBCEKWUwVSuZGb8+NuU8aOq1qw3eNhgh/3fryH9oCGQc6mEToOPn7jUp0t7jFHXXp+tXLooKytDqVTb7TYfP/8Klao2aNysYpWK"
    "vy9axnGo/8C+DgGhPBJEJMLxGGOYOvm7Rb/Mksm1o0d5tWqls9vpB2NqESCgBBRqWP99vkPrTEot5J1PheDfntRDKQKsh6xoJioj"
    "O61h4zYz5v6sVavMlpzgilKQyYDnwWyWvvv2u7kzJn82cPj3P00XBSoRpzPHCMO3E76d++O3rTr0mDl3totOZTb/++7uQ1QAJ8+A"
    "H89nEkXRxYW9dvX+gF7dom5e8fULGDxirH+A17mzF44f3n//zh2jUV+rXuPf12zwcOONpqeCW0kiCgW2WG3jx4zZsHqVm7vbxG+8"
    "27fRWa30Q0pKOsNKUKrRsvHhO343qnVAJEAfEjNKgTLAGmjmA+5WSlZipUp1Zi/8zd/PM5dgIIQAJQyLR30+XC7jp//8o8NBJeeg"
    "Ljm2ORxfjvxi5eLfevQfPnPOdCKBzUYxpgj+5YbSD0sBnEid5xmMweGgzuZuJxOq0TDRjxJHDBp07tTRid/PHjawmwMgLcMedfP6"
    "of37K1evWb16BauFMOyT/K4oShoNk5ySNWrIwAN79oeEef4w1bt2LXV2NvnAyhNzFQCvnJhv1zKjSgeP1yD9NXf0ZgQR+utfv4wF"
    "duqAjVqi+ah4fXTBAqXmLJgfWTQ8W//ED7AMAAZKAQhIhBKJqDRMWlrW5wMG7d255fMx46dNGX8/NnlQ3/7tOnbu071tmkHCiPkX"
    "RfADqgWiFBgGKZQ4NSXLaLRodUqeR6JAnWjeZpM8PHX1GjW+c/v+3J+mGCxQoUo1pYINCvarXadqYFCg3Y4w80SuncURd+7GDOzd"
    "/cSRU8WKef8617dSRXVWlsSyCCF49gHwgl++jwfCOIfhkcnRtSNud684ZHKgebigx91br36b1zte8ueQ5/HidwYAQASIDMl0xIMq"
    "SHTynYO79xeMLFOogL/FKjmnsxDitGJAKKIUXHT4UUxSny6dTx0/NOn7md+MG3H4+J+9u3a7eO4kw3Jad6/gkGBK6b+I8PCHY/sZ"
    "hgoOx7fffNeyUe0mtat0at3qwoWrMjnFCDk5fouZaNSahcuWdO8zaO5PU4b275+ammG1SlnZos1G8kIaSZJ0LsyZM1d6d27355nL"
    "1Wv4LlroVyxSkZUlOne9POXanY/Hq73eRUXQm7wzykt5InhPkwmflvec5896KYQQIBFEDth8YtFQVURaVmK/7h03b9nvqmOIJFFK"
    "Ue62MyAyGZw8dbFD86Y3r135bcnKL4b3X7xic4eWTa1mQ9+BQzLSUzu0aLZp/UaVEkn/3kTeD0gBZHI0bcq3c3+cYjYagkLz3b93"
    "1+GQeB6bLTa1GhMiOVkdjLn5C2cPGz3+3OmTGZl6XsZgjHOjXufudVcds3PHof7dOt67Hduiuf/Ceb5BgZzRSJ5Ifx65f5m8vkXR"
    "f+U752Sl0QvhCEJPy+hTxvyfA68875V3UeVjV/DcZzk7RAkQBChUKhzKF3CIlhEDey1cuFqnY5wY9skNlaEL5y5kpKev3rKja8cW"
    "X46bMqRPlwqVq6/fvm/unBmdenxmNulvXL3i3Gnwb4VkH0QMQCnleRQfn9qqcU2H3T5j7qK6DWomJ2blC3bduOXArB+/G//tlLp1"
    "qwgOuHHz3ujPB/cfMrRx08bJyZl+vm72PFQapRQo0WqZpUvWTf1mjNFIunT2mjLJmwLY7TS3+jP3Hv0lTP6Hd+VpWX9qiMizJa0I"
    "KAGlBq+YEL5zuUGtQ88EwS+U91eu+vqLmSV/Q4HyflwOUUGZFCbuIYmyWm2DPx8zcsxwhyMnRZBD4hGakZnG8tyoIUN3b9s4aPiX"
    "Y8Z/5aXlD526Orh3Z0miy9dvKVo0v93uHFT8LwTEH4oHQAhEURTsQkBgcINGNR1WEhDoeuL0lSkTRkddu9SjXcsff/gFqKSSc1aL"
    "6dtxYzMysgP83Wy2JyXmhFCMQalmfvzhlwljPrfa8JBBvtO+8xYlcDheX/qf/BdC/xTV5HkHmucJfdMw9SVnQl9E1VDn7iMnEH9c"
    "9URf8xa8NHB44jGeOiUJST4kKAIi1Wr1rBlTRg0dRYHIeCRJxHmJCKXhwV6H9x85fnjfj3MXfzd9oquWX7VhR9fWjRFmF61cU7FU"
    "AVFCmEEqFQb0L2S72Q9D+pHDQUNC/QoXLXbx/JnLl26XKVPQahM3rV9/++bV3gM+NxmN074Zcyfq5q8Lfl2/bXdcbLy7m4vF8lSi"
    "VyZDoiR+NXrS8kXz1GrdV2O9u3d1tVgIpfCk3+uvpf+lhzO8c8asAMAwCGMEQJ3zoXJW0z0G0C+SavqM/rzGzUav4G5etBGeUgAG"
    "sRzmJCpKlFBKKNDHze9PvQ+Fp0LPV1OuzhWxTz9FCFGgIILgSf1YiXvoGrVuzeLMrKyf5s52c1WbzdQ5tTHLSFu0alm6bNnChQMd"
    "Ivz44+xpk76qWLn6nAULC4cHrFizfeFvs4xGQ7deAz4b0Ftw0Pecof8gWCAEQAmVy5FPQMjGtauvXrpQtVZ9P09tZMmKgaEF+g0c"
    "1LhZq53bNt+8drlStXqFCwd5eXk5HIDzVHeyDBhMhlHDPl+/coW7h/v30/w6ddAZjeRF5pO+jtg96RKjORGhQoF1Oh4hZyU22O0k"
    "W28zm0ChYCilLi6cRsMzDEiS0/QCQq92I+gpeI8AKHAydPWI272rdl6O8g7mfx6uPA1+cuw8izkO8wZ71iPDXUmSOMRxmOdZGUYY"
    "ADn9AaAncv80xPoLnjXPOTz1BAEiSFRSjYpoiFq6ceviudPnipcq4+XlJkmAHrsVLy9dVrZ52MCh8+f82LPv4EUrlgd4aZeu3Dqs"
    "X/eiJUq6urovXTCnQOFSxYtF2B0SQui97SXAH4L0AwLMYLOZVK9R7tsffr56+ULnVi127z/h46MaPqhbkLcqMTHBZrVodS4urm52"
    "O7VaJafEQM5KdopZGDty9PaN60NCvRf85t+qhS4rS8qlF19oMv9S+p0z+xkGEQKEwK1bptFjoubMTXB15aKjbT16JXw+ku3eK+PB"
    "Q4tGwy1akjxx0q3du9ONRuJUGOdf5RIseULMl1j0N0mW5HlKCKUM5mSMXG/LvJR5Ojs4vdbQBh513JO8Ym6Jl69nnE8wxJrtRkyx"
    "nFFwWIYRdlpvkgcdPXNxXgaBnnvi/DJYBIcLePgKwRpX7YWzJy5duCqTIfJ46wGlYLNKMpmc57nx337//cwfjx85bnRIR/bvcjjs"
    "Hbr0+OmXxSzH79+9Q5QkSZQwRjyP3k+H3r8JgXJQKgL8uHTHaJB69O7k6uYy/ovhnVs2btGmQ8269ZUq+bqVqxPiYhs0axuWz99h"
    "pwxmnqFWGISatWx17NA+i8VBKXE4JPSypq/Xk35KQaHAokiNJuLvx2/enDb1R9Ky7cjde3eWKZMOACrXSutWzxs6fPLVq9tcdHj5"
    "ak3DJr2/n7mlf++MHt39UlMFnY5BQC1W8vR9/HtWLTe9/bTwA2UxxyAmw5Ia53joUkDXq8uA1m06+vlorXZIz9DfunX1/p27Vy9c"
    "iL79ID7xkZjlcEHuWs5FJVPLOAUAJZRIVHoGDr0CAuXBQk+dHgbGCuZkNkafkTVs9IRuPdoYjU+aThECCgyLYebcua4KWLh0/bAB"
    "vTbtOpwvfyFJEk8fP+ofEKhUqWvWqafmGNaNMRiIXm9ycdFK754d/ddYIEqBZUEmB0rAbHamURAAEEI0Wnz3btwvP/+8ffN6o0GP"
    "MaaUFC9VfvaCRQXzh1qt9PnRS5QSVy2e9v3sHyZNKlzUZ8OaIJ0OieLzHoD+pfQTCkBBJsOJibaJk+ITksiKZaGJCcZZ8wpt2rB0"
    "+/5LC2d3LVIg04YHzp7x9dotJ7ev6+btSV38vpw4rt/QkVOKha9v1SakQ4c7fn7QvZtf0SJK54fm6tXLWCBCQKXBKyaE71puUOWw"
    "QOgVToB5LPqxjoduhd3adOvYqnV7bw+12QoOh8RgzLBIIQeMwCGC3ui4c+fG/XsPLv955sHN++mxafZ0m5pq3RQerkoPRLAEYt6S"
    "o1eALueTxz/m/IQovs/efGS4U69B6/m/L5QchNBnp8NTACpJChXq2bnX+bMnzl29GxV1s1WDGpEly67dvCMpMc4vwG/Lpq36rPSz"
    "p07eunFj7KSprVs3t9slhmE/Ng9AJKJzwYcOntuwdsWQ4aMii4babGCzSxhjjLFBT8JCA3/+ZWa/QYOvXb2WGB/v6+9fq05tD3et"
    "1UJfOHgMAdKbpMFDB125+OfeHft//EkxY7qP0Si9EY50SqFcjhkG3b9v7fVZfLe+k5UKRfeeowf05UyG+zcfZtarW+rC2T77d28a"
    "Pb4SAFSuUuqPjdUuXIubO7ixTXBYLGZRJKO/uFeiwucRBUIGDB67bDGUKKG2WonDQRjm7cBaRDEGnGVJjxei3Yu6D+g+pEXLtl7u"
    "apMFsvQSxthpekWRGgyEAmCEFTK+YvlSVSuU6tq1rd4gRT+8k5yScvPa5YM79928filAExqEwhDFb+qfKAUKlAU2CccmOmJCgvJP"
    "nPodpuAgKCdCo0/oWISAAHAMjixWYufWdfN/nUuIaDYZQ8MiVCq2dGS+/ccuTxw7HAj1CwgcOXZs3Xq1EEIaDWuxfFwQyFnon5pq"
    "mjLhy5vXLp05cbR5m/Z9+g8IDfI0WUAQJIZhbDbCsrh40bDSRcNsAAjAagWL5dkeyLzCK4lIrmbGTph86/qVDRvTq1RStmqpzdZL"
    "DINewcY8a4NVTFSUydWVLRKpDgjA4RHhjeuUUmnUM6aMLFoswt1dxyH44qvh/YYMN2Sn/XktWsZzM39dihlw0WI5gsjIQj98v6B2"
    "/a5Tvxt4/5Fhx0ZFocKKpCTBZpfCQhUGg/iGCkBf2NFuQeYMJpkvyPfrMqhVm/aebs+K/hMc//hHSaJGI5EkieM4Dy3jU6Lw1Sj5"
    "9YuXfAMC8hXNf+3ERSFTkHFy+iQkoK+ZecDAWMCcgB9RkX45cWposFd2tpRTkUWfYn+BAsbYYqW9+n52/97tOTOmcJysU4/+U3+c"
    "jhn826JVv8z8UalQZmdlRpYs179PV6MNMrJM165erVS5Mn5nEcG/AIEopQCSzW4bO2rk/l1/uLi4OhwOXibr3W9gt959PFwVegNR"
    "KunyZRsP7N0xauy4/AUKEIki9Nf2k0iSqwuzcNHqr0YMK1DAa+3qQDdXRhTp0/CDvhj5EKpWs1eu6IcMN2i1bLcuEs+iletClq5Z"
    "4+amyM6moiidO3Pk9Klzj+7fEgQJEGJZVhAkhIiMZwOCI8qWK1utZt2MjGw3N52XOzt7zvqM+O86dvAcPDSNEDRpgku5clqHg75s"
    "JVJuIiwPBHo2ZkCAbchy3nIsslyppSvX+LmqMkzgcAgsxz7uenvCK+QhcAlQUCixkoO0bPHgvr17d20zm8zFS5VWq7UFI4vP+WaK"
    "8oFWqVBRSl6YensJ/gFCCQPMfebmQ/3tjp0+++mXHwz6J92nLxNZjgOJQPSDhyzLFC0UfO5i1KSvxh4/vK92g0YDPx955uSpug0a"
    "lytXODFJ36FFk3t3o3YeOFGseCGr9Z20zvwLHgAh0GhYLajnLV7w84xCv/08vXDRYt6+/j9P/37lsqWff/Fls5ZtlSyDMBzat1ul"
    "0sxbNM9qe63OCcwweqPUuWunYwf37Ny275fflFMnexsMOVkwlGNF0PNJWUIAMyguzj7k85SvJi8PCfWbOf3n6Du7PHyQXKFITzev"
    "Wbny4N497p6epUqXatR4jJeXu0Kl4ThOkiSzyZCekXXp/Kk9O3csW7KwRq3aHTp3k2GX7Iz4o0cS/rzoPnLcQrVaPbB3p3lzcbly"
    "apuNPnsfX7s3GSFkshgjS5cqEF64R4dOXXv2adWuqVLFGQwEATzp+neynkAJIQxmNFrMANy+G7d9y9bzZ055+vhUrFITEJw8euDo"
    "gX2jJk5lOfYFoW0ulfsSQSaUsMBlofRkR1xgQL6ho0Y67DRPTcpLIy1BoAigYKEwhGHGzN9mT5+mc3WZs2hF63Zt3JSoQe1Kew+e"
    "bdGoxZivJzdv0y5/gUKFi0Q4HPCOGsfY9y/9mEGrVmwKCg4rXab4hLGflypdZuSgfqIoTfph1skjB4b07bV88aKho8b269WhQsUq"
    "GDOUvgFuIATxHPp89IQLf57btDmjeRNt2bIKk4k8pwOQNzBlGHBx4WU8W6gge/Xy1dZNKi5YOuvs6c9KlC5y+OCBOTN+KhJZdNK0"
    "H4qVKCjDYJNAEp15MQAAd3dNaJh/lYpFRYCb1x8sX7KoW/u2ffr3H/P1aBd3r1p16pQpGrBh25lCBVG5cjqVCtntwjNZsJeHuk8H"
    "8QAIkCSKXm4+M2dN277zwKL58//YvKHvoEE1a1SwCWB5zCUQQgAozzMaBWOyw8F9x/7YtCk1OblY6bLtuvaKe3R/87qVN69dBgCe"
    "5xUKJXl8ifNCLgqAnks35HGhFAGSQExkoi1Gy5gBQ8NCvLJywc9foDokEQlhdPzo+cnjRgeH5vt93bZyxUIsFA4cv/Drzz/t27W9"
    "aLESRBLHjR5yLzYrNVXv6ury/H7B/x4EIoSo1Xjdmq0jBvZy9/AKiwivUKl663ZtMM+PGTI4JvrBxB/muOgUUyZ8feHc6Rp16s9f"
    "+ruHh85kejn0f3mE/d23P8yY+mPjxgEL5/uJwktrrSgFjoWsbLJxU1LpUsqwMGX/gQ9rNvx6yNAePMd8PW7y+bPnxk2aWK1KGasA"
    "FgtxguPnltLl7I1TKLCShz8vXv9m7PiChQv+POsHhwgPo5OHD+g0+RuHTIYOHtL37BGAMc1dDPxkoRlBSg3KC4GexiGUUspiPtkY"
    "717bbeGKZXI5FgTYuG7L2pXLg4MDBwz7vHjRcJMVHHZJpWYULDxK0G/bsuH4kUNKlapy1aruHj4X/jy3f9f2uJhohVKpUCgQQjar"
    "dex3M3asWCe/rVQq1IS+dHrhMyjIaf7TcdI167miRUuv3byV5ThCc5qY/hKvOzP3CYnJXdu2DgoOWbx8+YN7d+f99tuW9Wvc3D3H"
    "jJ9YKLLk/Nk/8nL5kf17PLz9fpo7v1Spojbb20dB7Ps1/0iU4E7UDZVabTJmP3pwPyUpedXvi8LCwytUqSEIwuDeHYaPGb/z4IEN"
    "6zYcO3QIY8ZmJfgNu+YQRlYr6fnZgH27th86+GjXbnWbVjq9njDMC3WSqtXsvAXJ+44Uu3ydtVruG01iZkaqgmN69BjgEKT127cq"
    "FVx6loScg+lemSW12ajZTIqViNy4448Rg4a1bd15zYZVV6/cSEu5unCxZ2pGIYPJ32q7O3K4r9lCXu9r0Tx8y5OPwxgbsiXMMF27"
    "tmrSvPnyJQtHDBxYpkLF/kM+9w9wvXD2+paN6+7duV2gUMFOXbo4RHH/nr1HD+w1m4wqtcbdw4MQQp7MKnnT+C2HdpNATEKxkkR6"
    "9Rvs4iLL1ksMg19fEhx2GhDgs3Lj1qxM/Y/fT1s8/1eWYUeMGT9g6BC1ihvcf9jWDau0Otf6TVoMHvF5vtBwh+OdjFl/70EwpbwM"
    "nb9wdcHcn08dOxwUHFK+Sk2b1XL5/JmkxASr1Wy1WBq3aDt1xk/+fm5WK0ji38kdSZLk6sIsXbpu9JAh5cp5r14ZwLKYkGf9AKXA"
    "cSglxdGybfzv6w+WLxZw5Xb6wwd3GzSq9NWocenpmYuWzbNaqcPx1CBRQqQcrJDnX4SfkE2SRDgWqdVo6ICRgiTOmT979ox5Lq7+"
    "Xbo1M5qF6mUrzpsrr1LJxWSWMP4rD/A4ZnFOrHN6AI867otWLnd2lIuixLKMTg2xCenz5sy9fu2au7u70WioUatO8VIlbt+6vmPL"
    "H5cunAdKNFotxpgQ8kSIEXLY7V9NnbF9+et6gLzmPw0nXbOeLVWy0qpNm3PnbL92xh0QgCiJni7soqUbRg3+rGe/gcO/GBXg5756"
    "zebpU6ZkZ6WHhITdunFt4arNbZvXSjdI+Ons59s63nstEEKSSMPCfJq0aBFRqOiVixcP79vlFxDYb+jIpi3bqNQqq9V26MAunc6j"
    "avWKVgv5e+tGEEKiSAsULHjuzPFzZx8EBanKlVNYrfT5N8MY8TLGbBZWLjvm7pevRMn8JQoGrli15cjBA8vWrHTYqSiiXMNGCEUI"
    "abVYLsc8j2UyLJNjhQI70UiuTcUYSQQcAmnSrMGq31dkphtHj/isROkCVrv4+cBRpSIfdO7oLYrkMcR/LHIUcTKctxboBVE+YkwO"
    "gypc3bRlC2elDUKYUrBYJbVK3bxRTYOVXrv056TvZ1y7cumXmT9u3bA+IyNdrVbL5PLn5+EhhCRJqlq73p2rN5h0jud4CvSVWbCn"
    "IoJYfFdvzR419psypf8mRcNgbBdpWL7wVu079ene9uz5K727dl/469yikcWnz/6tdfuuFatWb9SoLsUgiu+qZuffSIQh5FxI0axZ"
    "3dp1av+xedOs6T/02rGlbaduQ0aO/vLrb44fO1miREmHHf3tZTsIIVEgLi5ct94D/jzbe8PG7ObNNRyLnhmLyzBgsdCMTFuPbhoP"
    "t4cDezabs3h7yZJFF/06e86CJSyDbFaam0YgElEosSTB6hWbb1y7otXpACEikazMjCLFSrbr2F4pw2YzcWoLxogQJEkwdcasPl3b"
    "16xTx8fXc0CfvkXynRs9OjQmxuLhIeN5eMNmQOeWR8rxfI4s0pxQnmEYhyBZJNDpdEWKlfzlp+mrly3xCwjIRTsvz32/oG/gmSQA"
    "fbpeiFKCgc1G6Wm2pMKFitetV99soXnKct8szUEJkstlpYrlmzln6XffjA2PCF+4fFWT5i1clZgChIUHLVuyPD4+bsy4cUARegej"
    "8f6dYjhnD5deT4DgLl3b7T12cvyU7w/t21O1dJEZU79r2KiOj7e73fGP6gExxiYzrd+oftkKpS9czDx4yKxS4bySQAgoFHjj5sxe"
    "n5mHjpKdOBNYonTFkiWKzP9lbqVqNUsXDzcapby2X6nC8fHJnVq3Prx/t4en96a1K5cvmndgz44ixUqeO3mkQ8sWd+9EazXYWQrv"
    "PAGzRSoQ7t2gSfMlC37DDB/78Made7R77+wuPbL2H8jUaBhJymW4nmgCfWU8QCllWYZhECVPvRIhhBlGkiSbzYoxdnN35zhectam"
    "/pUYopwrTZ8J63OcxnP5EwSQiVOsNmvTlm09PeTCPxv8Twg12sipE0czs1Pbd+3TrWMrGY8vXLs3bvzkisWKjh0x6PrVy9nZWQiR"
    "dzEa8l9QAPTEAGMKkK2XFHLF0KF9D5053/OzQYlJyVaLTRD/cY+c0wlo+XadeoiisGWr/nkCnlJ07pz+y0nzNmzfO+WnTb8t3YgQ"
    "/vPM6S49epvteWw/pXIZJCSk9u7SoWmLFktXLrHbbb7+QVOmz6IU2W3WuQvmd+/du2/3zlFRD1UqnGtxGQYbrbRjt143rl3RZ+vn"
    "LlnXqc+a2fP2TPt52boNJr2esCx+M5NJqYyTJ8bFmc0Cy75oxO9jWX5N0YecViSHYBdZlnuFO8olgZx1b2lisreXf8OmLWyOPPkH"
    "+jflgWPxkOGj+g/6om79WkfOXPqsR+/Gtar9vnB+mQoV123fs3bz5hB/N4bB76JE+n0rgCRJ0tM1fgzDSBLN0kturtrvfpzy26JF"
    "PC9/I+7/5XQQtlqhboNGhYvkP30q+/wFm0qFnZ0rj2882Ox4/aqV2/84rFTxHq7ciROn3NzdCxUOtNpycjoUAANFCL4c/nmnbr3r"
    "N2xQp3r92Ef3J3w3tU37Jt/+8OONa5ca1qkXWSJy6Mgvx44c7hCkXNrK2egTFKDLX6jI/t27KpXM36JRGbOd7Ni202IBfbbEvCG1"
    "LYLoow54ePj+5G/Gq1SYPNVLThGA4HBQQt9I+ohA5O5KMViIS40VLA78SpEgzglZTKbeklWpas18YT5vgZpE2GqFEiWLzftl+o3r"
    "tzo2b3rq2OGe/QbuOnxi1crFTetVNZns8xeuvn37vkxG8wbx/0EFoKDVMVoX5hk9dv5otxOziUgiPFPF+U9YV7td8vfVNG3ZKivb"
    "tG2H/pkIjxCyeEFo5zant6/r165ZA6OVXjp3snS5ikze5m6JqNT4wP6jlEiNm7fq1LZtv8GDly6dX6JEZHaWVLlKuUUL5owc81Wf"
    "zl3LV6ri5e29bfMOnQblKjmlhEG0WLHid25HWQQy/acFIwY0LRi08Y/NIZ6erPDCBAV94ZWjLMsRO32Qdqd5r7Z3b99ZsmiNuwsr"
    "itIzcILjuNeMK5zbv+12u87Vbeq6n7rM6soVZK2S+bkzoHmDYAJSFk1nMFuvYROGyZsf+Ec3SxRJmkGcP2eWw25duWnXD999Xbxo"
    "2IWr98eO/65BjYpD+3U/fGAfzyMElGXQS6OaD1kBKKUcT1ev2Lhh7XYi2R8jWmAYYFjkomNkPEaA4a2OQUYIiRKt36i5t4/b0aOG"
    "+HiR53MIFozBYCDHjqdfu24VJZmri1bGo+Tk5PCI8NyB0gBAgfAYDuzd2apDl99mz2javGWXdk2TMwWrlTAsYzaTpAyhZeManbr3"
    "nPPT9w0aNzt5/LAo5W0ZwXYJ5ctfODEhzmBB61cvk+Hbag2zd2+63kAZ5jVyRkARxjziUlNTTF76vosGfLfw25lzfvt94a9/Xryj"
    "1TK5UUcOrcFxryP6GGOT0UgIUWu0VrM5yD+0Tec2HmW9bsIlgQpAUd4oIPcOMsDYkCXTkRYQGFquQgWb/a1VKFAKCiVbr1FTlVqz"
    "bfP6+Yt+79yxR+PaVZfMn1u4aOTuIye69+5rNgMgRhCJRoPflht4fywQAuB4tG71igtnTnpt31e5cmmzmSgUXFpa9sgh/UuULtul"
    "ew8PD3dRfJsDUxHGFjMtXCSiQqVKu3fsPXPW0rG9LssuAiAXF2bV6qS1m/w7d+vSqWJYmbLFbTZqtli1WheR5FUhbBPBYrEC0EcP"
    "H3477ccsK2EY5vGMFox5lG4i7Tt17d+rM8vVNRoNJjNlmJw7hBCSRPAPCDCbjEDJj3N+uXIpKjop4+DefQ5Hevv2PgaD8HS9aq4X"
    "yPklizmL0ZSJMir1rfjZqH5Bfj6ZWWL+CL/ho78eO3zwuj+2yeVyZ1+yMwR4tWQ4T9tsMjEMLlOhUrmKVf88fcxht/384/Sjhw40"
    "atK4Zaf2Fxde8nb1FSXyfBSAAJuw3mTTNyzX0s9HZzRJmGFeHbm/riVG2GYlI74YLIjizGkTBIcUFBLau/+gDp27FC8U8jBR/1m3"
    "jjoXl/S0lPT0jLHfTKpbr47geAsxwXtSAEKIUonOnblIieTj66fVuWp4hlKGEGK1mgmRFsydWaV6LT8/d+FtD4wnlMh4XLt+w+1b"
    "dx07bmndSutsa8KY0WqlQoUjBwxoZ6fAIMjMFIkocjxHyTPvADKZPDHukUqjcff0EkV42uohQkCu4HRal+SUVAZjQp6q3aAUeJ7D"
    "GBFJql2ldO0qpQHAZCZ37i7gOL8Xo58nfTNYb8vwruLzxddjSpcpZrNAll5iOTYzW2rXtsGFC2fHjxk7b9HsLL2YwyKhV9kCBGA2"
    "mRBGpctXLFuxitVsPnvqeGJCvM7F1W43zV24oFThsJk/LRBF6UWpgBx3pKeZCDMVq1THzNPVzm9BSChG1MPdrXS5yl2692zaspWX"
    "lk3VOzZs3bN4/vxzp44oleqIQoU7dO4S4B8giW8nImbfvehLCBAAxRhdvXLjzq2bVqulW9umXXv1adaydf6CoYXz+2/ctvH27fiA"
    "gACb7e0X/SGEHAIqX7FqYJDP2XPZCQke3t6M3U4dDik83HXp8h2tml2QyZW+/gUmTvteplBYTKa8ZVeUEjmH5TLOYLRKouiw2xQK"
    "Wd6KulxSFRBKTYrX6VxVKuzcFP3Y6ILeYKIUsTx74MTVXdu3Prx7y2R40L2Lm8MuveImUqAMxQncI17Bi3aRSsDLQRCcc/JwtlGa"
    "MOnrjq3azft1+eBB3VMzHQDMy0UfmU1GhKB0hUqVqtSw2+3nz5x6FP1Aq3Vt1KxF246dihQKcUYTRqsRKHkJXMYi2PVSlqurR6ky"
    "5ezC2yRlKACDGbMF2nbo3KlbNzclnLoQNW3dqj07tsfFRBctXqJMhWrnz5z4fPSEVo2rGR1gt/8XIBClVK1mAIEogCTB4EHdW7dr"
    "s3v7H9u2bJo1fdq82TOr1arTonXH8hUrhucLsNnfSdMDQthmo2H5AkqUKrF318HzFyzt2ujsdmq1kkKFFNs2+ccnWGbNvnxo/6Pp"
    "M79XKxUZGRkMeqrohVAoU77ygX17JFG4evlSnXqVMjNFjmMfR2+iVstevHDLYrHExz2qULGqnAOzmTyeF0s5Dj26f9fT24dIMLhP"
    "lwqlUyaMzR+ez5NjWZP5CWX0vBVlMGMxmkpWK9uofeNJ48f7+vv37tevStUyogRmE5EoyGTMjDlzenbuWKpMydKliz1P/zgXIZvN"
    "RiKR0uUrVa9TXxTEs6eO3bsdpdZom7Ro3bZDpyKR+RAFCpCYmrxp2fqTK455uHkRSp6qDaWUAsXA2LBNb84qW7yKf6D3k+n+9C2a"
    "S8rz2GYz9xs1Ydcfm1iWrVqzztSfZterXys13fzowf0SJYum6UVAGL2lHQrsO5V+mQwdOXL2j03r42IechyXL6JQlapVm7Rs26t3"
    "51tRsevXrtm3c2v3Ds07dOn168LfCHlXNd+EEDmPK1WtsW3L7guXbC1baB9vF6bHT5uWrchy82q/cFl/TElYRIHrV6+2a98kr/k0"
    "mWmDxvW2bdkgkytWLltSpnwpFxe52ZyDijUa1iFIvy/8VSaXp6emNWnRzGDOmxklHEJ3bt8MCAxSq2i3Xp9duXBg1uyYevVw3doq"
    "nv9rC8pgpl3LJjVr19+8ccOUCeMDg0P6DR5UtkykQwSDXggP9/9i7IRxo0as2fKHj4cqlx5BCDMMYzToJUksWbZizXqNGQafPn7k"
    "5rXLSqW6UYuW7Tp2KlaiEKKAAVKysres3Lhz4Q4SD77aAJPVKCBBrdGKRHhMVTg9ADKhbFESChYqolUxWblDod+eE6CEylT42rXo"
    "NcsXubt7bth5uFyxYDvA+fNRcTEPWYa5fg2XKBlJJJDIh+0BCJFUKnzo4Mm+3drbbZaQsAhexl++cH7hLzPdPDwbNGk2YPDQqd9+"
    "+fnIEYcPHdFptAi/251dEkGRxUq6uekuXTJZLB4YA8ZgscCEScljJ/3euU0VAHAAVK5ee8Z33xgtT3LACCFJIiq1fMjILyaM+YJl"
    "mJGDhw36fEhEgYKYYSkht6Pu/zbn1/i4WLPJPG7SFHd3tSnP2h+MGbMdXbl0oXP33mqOGTdmqAOGrlhxYOH8oXVrKxF6QYneM9SB"
    "xW42AahVXM/enZu3arNu9epxX4zJXyCi7+AhJYqGG63QtEWdC3+eHTNixJqVC51ShDG2Ws1YjyKLl27YvA3H8ccP77t84ZxSqa7f"
    "qEmn7t2LlSiCKGAE6Xrr7s3bd87/w3jX5Kv1ExRCmjU5f/0CVqs1+sBDT603I8O5TCsFagIDQlC8VNl3NK4BYWSzQKHCBbv1HuTh"
    "6eYfEDh33oq1K5cmJyVYzBa7w4ERDPx81BdfjhHf0naZd1UN6hx227Nz1307tgwZNW7kmBFEwpnZpvNnjx8+sH/nH5sB0Ohx3wwc"
    "OoBlQRLBbHm3Y/EYBixWe4sGtdNSYtevzV+4EG82Uzc3dtzXsXpbu/wRfvfvP/D2cRn5xaiuHTv0/GxQ/YZV9Xm6+ySJaLX45ImL"
    "P02bHB8bDYDC80d4+QSmpyY+uHdPFARf/6Cho76o37B6djbJU0BB1Cp07tyNaZPGrf9j+9kzf969HePhqb165WF6wm/zfw3JzpbY"
    "xyYotxp05zKDWgeEICfs1ktZwTVDOg7tULpsGUyBwZCSZlm97Pe9u3ZGlijed+CQwvn9JYDmjVq3atvOzdPn9LFDifEx9+/d69zj"
    "M6VSffzI/rOnjslkiuq1anXo2qVUmdIYAcOA3mzbs23X1l83629k+6j9EcLp5pTQKuEFaxUqXrFU2Qol1y1avfPnHVIi1epcCJIo"
    "oRSkG3DRDMYNW/cWK1HQbCYY43exXRxj4GVgsYqfde1y5MCeQkWLJcQ9mjrzt9IlCg/q3//BvbtHzlzx9HJ1ON6CDrwTBSCEKBT4"
    "9u1HHVvWV6u1u4+e83PFWRYAAIUCCIUb1+98PXrUqeNH5ixa2b5DM6ORsCwH7/agPI/69+61ffPOefMKtG+ry8wUVSrmzl3brFlx"
    "RYoogVrnL9TvOX79yqUL61YuW7dlvdEk5e1CkiSi0eCkpKytmzYeP7Q/JTXVajEplWp3T49KVWu27dAhMMjToCd5a+KdVdk9uvSp"
    "Wad+uQqVWjUo26yJG8IoK0to3MijUUOd2ZxnaGleBXABIuXcWgaxBkOWUW4o3bJsx8FdIwvnJyKwLCQkZS9bvOjooUNlylYYMnyw"
    "TKbq1aVjWEQhDw+3qjWq3I6KPn/m2OkTRxmGq1KjZufu3cuWL4MRYAwWu7B/154/ftuadCHZW+XLc7L07BS3Qu5l21RMNSWF5yuS"
    "mZ6RnZXRd+ggh820ZNr8CxsuaqmLQqWwguWi46RXgN/azTu9vFydfN27CNsIIRoNmvzNDzO/nzh/2fp6jRpXLJ5/0PAxPXt0qVez"
    "BsNy2/cdksvlkvQWovB3Ug7tXAS7esWaPzauUanVWZmZhFG5ubnpdJwkgdVCw4M8FFrvHVs3SYLQsm1bSXznO5OJJGnUODo6/sCe"
    "A5GRbpUqKgQBCKEuLmyXLj75IxS/zs9s3fmbajXKFy1aYPOGLXqDpXqVkgazmCvQGCO7jWg0ykpVSzdq3q5mnQZ16jdq26lb1x69"
    "a9QsL5ercktBnYcgip6u7Lp1u86ePD5p6uSsTP3d2w8wihs7JqhrZ++AAM5up7lTlAGc5dDo6hG3u1eeKocmICmUSh12ibsQu3fz"
    "rofJMYERwa6uOqVCXqNm5eq16l25dH72jJkOm6lGvSbLFswFSuNi41YvXRgTE121Rt3R4yf27t8nKNCPYcBByP69+2aMmn543lF5"
    "ptJT620w6UU3R5W+1cOqhZvtVhmrOnfqmM1m8fHz375ps0yubdGjXbH6xaIe3jQnmiRWjLbdLVykWPdeXd+K9X1lzhRvXLs+Ovp+"
    "6/adC+Tzu38/Zs3yxcuWLhNFceZvi8LDg+z2t9Mf805iAIyx2UzrN2rI8fOOHzm4atnChb/ODMsXUaVGrdp1GxYrUdJD4xIbG+1w"
    "2N09veCF0z/eARlEAQIDgxRK+e07FkFwc/YH8zxcuWoaMCix22c/DujT3OAAg8E6bcaMbh3aFS9Vqny5ohl5CB/MYEGgdjthGCY4"
    "2JcJ85UkcDjAoJcQxnmlXxREV1f28rV7c2ZM/XXx71oZKlY4cOPm1dN+WNqyzYwli3xDguWPJ0Wjv0ogIkmSKFBXN3cQ6Pnfzp3e"
    "eKJuzzpte3QIDPDz9fGaPG3ivftx8+bMPXL4uLu756XzZylFlavX7NKzT8XK5XkWAIFI4cjhYxt+WfvwaLQH5xnqmi8zKz2TTy3R"
    "vWyR6iUeRd+XHDghJtZiNkUUKGQ0Gm7fvF6wcLHbt24QJPh5e1CGUAAbWAmRfH39eA5s1ne74JES6NS1+4kjB9o2qzNo2Jet2nc6"
    "c/JYs1Zten7WPyDQy2J6a91h7LsRNiRJEBERWqTIZ5/1/yz6Ycy5M2cO7Nm1Y8vGZQvn+wcGVq9V896dewqFskadBgwL9N1PgUQI"
    "CSKE5Muv1arj4xwOB8UYJAkIAZUSK5Ssl7fn9v3n169clpRwZ86CFd9OnfZ5/77zli4rVSJ/epbIPB5qhRByBgZ2O83tD8Z5itoo"
    "pZIkubuxt6IeDejda9S4CZ7e3gMGfhEUUrRqtdJlypc7cZB1d2Nya/JeO4+OJFEEBJ4ePsQuHf7+2Mm1J+t/1qBVt3Zebi4hwYEz"
    "50yPinow68efBFH4evJ3latV4zkAChKCc6cvbPhtzY0919wZr3xu+Q2G7ERjbMGGhau2r5OYGH/90iWW49OSU5UqlZu7R+yjB2qt"
    "S+HIkpJkKVi08Lntx69tu6IBnUatzaApFIi3j9+TxNi7OTDGViuUr1Bm/Y79B/ft9fXzL1+u3M6DpwL9NRYbvN3Vwuw7Eziw2ahz"
    "gnm+fMGFCwV36d4hPi7l3Nlz+3ftOHLwUGpKYmBQaPkKFWxWeA+rkhFCggD+/v4urrrMzMzUVNHfnyOEOhw0KJCfPNFl8NDeBQqw"
    "bVrxv81LOnrk7OC+rfSG8QN69/rqm29aNqtrtIHNJiGE81Z6Pt8aTyTCyxh3Lbvv0KkJX37Zq2//Di3r9+n/1cObC4N9gn79ibl5"
    "S/ryC5W3N5+Z+fJS0BdVCuamY0XRAQzy8fIVs8Q/vt52eM3h5oNaN2nTXM3wJQrla9GuE960tkm9agY7IAYuX762/pd1V3Zc1oq6"
    "CPfCZpMhWZ8QUj1fw6bNPHx9Th46DACiKJiMBh+/AIM+Kz4upnTZSkZjpoePLvOBuHb07zSN+uj8RBAJkSQsEEqDQsIA3vmOZYTA"
    "ZqcR4UFFCvcVRbBawdVVk5mdMzvwLX4Q+05lzmksrVZisVCMkK+vd/sOzdq2a5acnH30yFGb1erh6eKwv6dB2ISCTCZzc3N9cD8l"
    "NU0KDuada2P0BqloEc261XyBgupNmxJ0Xg27dmuhd0DbNo1Cw0K+HDHy+JHDQ0aMCA30tApgt0MuLYjyjCtjGEahQAqOiU/RT530"
    "09kzZ2fM/aVGheJmCQYN6z9m2MVKFS1jvnCJum328pIZDC+U/hfNgXt6xlXuHBdBdACH/D2DbDHWlUOX7V2+u1m/Fh3aN0MIYcQA"
    "QNS9W+vnr7mw5YLaqg1xy+dw2OOSo8Oq5KvUsIZfWEBmauaODRvdPNyzMjM5ntfqXKJuXAsKyVe1Zh25ilfzyj0/7si+o3dzcQcX"
    "ECXBuR5PADtCyNvLE97LgRBySo5zCIAoUoZ5+5NR3kctUK7KOvOvCIGrq0vHzi0oAZPpve0KR5RQmYzz8fO7euWa3iAx2Am9kHPY"
    "f0CA/O4d8+TvzIvWTNLJ8S8LN61fufDbH6Zv2rFj+ndTe3bqVLFK1RZt2uTPX8DNhcEA0mOBZQAogN5Mo2492LZl44mjR0uVLrNu"
    "48b7D2P6D/qmc/euVcuFT5w2r2fHRmtX8YUKqkwm8bnVSa9MBLxAMAAAAQVBtLMK1l8VZLluXtDn1yPr93kVDcg0pk+ZOOvgkgO8"
    "QRboEgI8SklPVIYo2nzZWeLtooj3/bGNYRmlSpmWkuTq7mkyGDLMpmat21ntmTKGO7/+zP3Dd93UHp5eXqIkAsk5PQpUpIKMk8nl"
    "cvq+1hfnNfbvSE7e91gUpxI7Q0mn4Xxvn04J5eTI1d3dbpMcDpxnjIMTsEkcxxQsgJfMX7gYGEPq2siChuVLVy9c9OO07yckpplX"
    "Llk69ZsJHM8FBof6+fp6evvKZHKbzZKZnpaSkhLzKNpqtZYtX3HJylVhQZ4pGfaxI4YWyX/vu/HbI0t3EUVSsTwX6C8zmcQXkR4v"
    "zoE83zXxlOYgQICBgiA5ZGpZiCZfxjHDvRPHiEw8sfeEj8aP9WAtVouJM1YZWrN4jVK3r93ISsqOib7n5u5htVoEweHp7ZeWmpIv"
    "omCpCmUsxuybB2Oubr+sRhpvTz9REkRRfFpNqUhEXiaXKxTOwif4KI5/Zzp0ria8z4MQwrPYzd1dFCWz6akGU+d0RDc3ZuH8wG+n"
    "bLTbyMrl+Ud/GVOiVE0eweFTN/7YvGXQsCEDhw2+cvlGTPTt5OSMi+fPi4JDJpf7BwXlL1CgYdNWJUpFxsel7N55qF3H1l7uspp1"
    "W2r5pTNm+n43ZXF8jDhrZphMDjYbvAzB0pfb/Cdm/wXjOgEBooQ6wKHUKdU0FAhQNwqUZlsyuMLcD/O+T0u1Hdi5U2/I4FjO29ff"
    "ZDLyvMzd0yc9JalB82Zubi5nd545v+EM1jNerr4SFUXR8fQuD+eoRUmkAsuyLMdTAh/NwcL/zUEpMAAatRKAZutFQp6F1w4HwRgm"
    "TwrnOJSQYD15CvqPqpacaZs+5Qsknpo2KWXekl/LlIu028X8hcqWHBlCKZhN9Pr1u4FBfqEBmqR0cVjftjxz9+zpEwsWz+3aq1ur"
    "BkuaNxem/1DAZBIFgdjt9A3jt1esiHxqNaZTDYhEJCAAFEkIEFLyGluMZe1Pa6u1rVu6Uunzp84RSu/fveXrG+Dh6WM2p3fs1f3P"
    "/afWrToqJkouLm7UlYpEQDlbMF7EIxPKchzHcZR+UoD/4oGc0SqLMLaYJaAvwBiEgNEochyy2SAsjIwdMTA11d6mWXKpUpFLV3MK"
    "BEcv3B4ztAWD0Yx5u6uUi1g0f/HSeaPyRVRZsvoPtUrm4x885nN267Yj7Vr11GgVlStRlZLNyLA7x7HkhrBvFT48pQlPegIoRYBV"
    "Du3N9VE3Dt6s07dug+aNTxw+XLteU7NJX7J8qbTYxHlDZ2bdzHbTemIPJEkSIijv+rC8LiZ3CAvG+B3N6PykAO/pYBgGIbA76EvW"
    "BIBz0Z23N7d4ftDBw7fu3xcHDQz+44+4tBS92UbXrdrYv6+byUSOHzlVq1LhpIT0yRML3rwVP3P6b99/P9JgVJ0+kzVlWqGp317W"
    "aNBnvYOsNiqKOYY/T2/hCyD+a5KDeQaw0ZdoAuQOUJGQqHXTgUD3Tdl7Ivxo86FtAsI99NnS1pnro49FuyrcPT29RUkkEkIvIqCe"
    "XRwG8KopQ58U4ONxFQhEkYoiNKjvi+qDzSb4B7hIjottWjfMSk8cP9L35k39dzP2FI4IvHzxau0qzBcjg5u0WN6o/lEfj/jISDdD"
    "hnX458EYg8EgArx6xvjf8mJ55P0lOcScgAEBEEkCBB5enkKysGb4Ct/yfmk3UzmLzMfdTySCJIlvNJrr9bcOf1KAD/SQJIlSUMj/"
    "wv46/9toFJ1rhgsWkC9b4puSYuJ5L5WKKVbMpVTkg8MHPq9dXVawgDfHo++nukliZulSvoQiq5XYbCLAC+Pdv1jg/rcA0Csy6Tlq"
    "IkkiliNPpbfpitlF4UZdqJPd/ytly9PzSJ39zaIgCAh/UoD/ZBQMACCKAiWE4xl4ja07uRJMJMpxTFiYCyHE4aAch6Z9FyiTMUQi"
    "RpNoMpFikSqMkdkiAX1BpEvp83Htq08z9+mzyebnAuLXqSPJ6duSJIlXcYRIQNBrKOEz2y0RiziTYLTbrBh9UoD/IrDBIAIYTRYA"
    "5O7GOve8v64xRkAItdmkPM5BciIcjBHGYLWSHIV5CaOfV0xfzPq/iLZ6DJ/os6TP39N+yG33/WtHRJ/ueEeAWMw6bA7B4XB6nU8K"
    "8B87MMKCBNlZWSzLqNToTaHsM1LrnGz+vK94zT9/UfD6anGkf7nM/YVC/0pBpU+fGHqFijk9gEOwmy1WhD6eOOD/ygNgwQ7pqaly"
    "BSuXAyEf6k2kL8Y8f7Xn+O9+Gn0x5snrcChQDJgDGVCakJD4UZnF/58IAGNwOMT09DSVitWosUQA/fv5/L82//8i8ZLXF1BKWcoh"
    "hFKSEt5bLdAnD/B2ZQ0cgpCRluGi4729WVF8DwpAXxWVPoOL8iIc+pSM5dr+NwZBT58Ifcmnvdwn5H0DKgM5BpyUEIvgUy3Qf0v0"
    "AQhQlkXJycnZ2YaQIJm3Fy+K5D20Iby+H3hO7F5gZ98iCHqzt6KUAsioAiMmJTXFIXwIzvOTAryJHFKJchzEPLxnNpnd3NwQgCA8"
    "vonOyXX/UkSQC4EIoZKIEAKGBcwCSICAAnpTXXrb7ovmbhGgcsQrZYqkxPjk5GwvDxdBpB+BGvzfQCBKGYCU5CST0VKkmK+rN7Va"
    "yPspSKWv5RGcA0YlwY6y0rEoUCL9PWfyd7wSfY2/QAAi5Ti1Jj09OSs9zc/PxSF8UoD/CPQHAIyxQ4K7d+7wcqS/57FuqqvFJuEP"
    "6f5RoBjhwCJiv2kmeCnRSN9cvN9OAEMIKJV4xW7F4dNJj2IeFSsR8XHURPy/eACEsd0OUTdvaDXyu8d1j/aoCRYQ/atFufQfBZ1v"
    "9FqMqc3Cfr/HUbaO3mZlMCYv1hL0/jQgb0AsSUSpYm/pYd9RuHntYosWdT+OVNhHrgC5qR2eR7GxqfFxj+SMSsfJWaUDgCJA/z6f"
    "R+HxclIqUyHBzhiykNWE8D9bvPWSSOPvR8aEYOKAAvlVHIvu372XEwDQTwrwX9AAQohcxty9fSM9PdVPGYglVkIUfUA5kJyys8dB"
    "MGVY+mRDzYus8vvHbogApTR/BOfuobx580ZiYpa3t5vDTv/rfOj/CwQilF6/esUhWNVIxwAjgviCKO/9mfwX2WhEn1o4kWdvKX1u"
    "UenruQX0Rk7gr4hRardTP1+mUCHNn+cTEhLi/f3d7HaK/uM5sY85E5x7ZzDGdgf68+wpOafQEF3eW5Yz3gc5qyPfywPlHq/WkZxK"
    "nsdZMPp3VO3JI+etXvHIsw/4BQ+EQJKoiwtTqJDcbLKdP3uKY97HRLNPCvBPNcC5piAmOuHBg7sqXqMCDQGCclpG/l3r9YwSoLcQ"
    "UP+FMryOtrzqfCWRli+rYhh06cKfVvtTm6A+QaAPFfwQIuPx5UvnU1MS8ukKshKXUw6Pnhk49f7u5csMJ3oBA0NfxMnQv4lzXrTS"
    "NOerv8a3xwhEkRYuxAcEaK5cvJiQmOHv52G3/7ezAR+tB8i9KQghiaLjRw4hjLTUDQMGoHnWmDo1Ab3fc0N5TgC93OI/BfofV8XR"
    "l+Ocp7aaPvUiQoECljFYxmAZy6h5Rs0zGhmjkWENj2Ts61wB57jCoCAuMlIdH5dy6fxZuQz+6y3CH7kHoJTyPE6Iz7p0/qyKV2uo"
    "TnqMf/4KeLwPFX2ur/0vYtTX/tZPuwJKWbWMOCRrnAkAISI67icDJUQiYCfA8XzBAD5QhXJXErzKnYJcjipVVO/cmXDsyIEWrZrg"
    "TyzQB45/5HJ8/ty5uPjoQE2YTFJSIHmcw78eo9CXST+l8Iacz0uBEJZzmQfuZF7KMEWlEwGoiMBCwQ5yLVglkKtBkXk/ZHgoW7uI"
    "zSiy7F+8syDQypUUPj7qcydPJSZle3m6vNNdAZ8g0D8FG4SgA3t3EUpdqQcGTOFjqmb/a1+AZEzi+hvRS+5kX0tn/MC9MLh5Ubkv"
    "yOqghAgIKA6p/aFXubJLo4oLPOOmdAClzk4h+iK6FmOw2Wj+CL5ECW30w9hzp08o5P9tFPRxKkBuAlguw4+iU86dOa5TuOioG3ka"
    "/+QB1k/hafoSKvBpqP3Xx2sQL+/quwMAlSijlmUeiU7a9kgRhv0qKfM1YaeW0Cyt3ij8q2rqAT69I+p09552V9kYVWk2Jv7zHsOL"
    "bbwRRjms4ZBEEMthFr/gFCWJKpW4Xl2tIJLDB/cKIvynuaCP1AM8SQDDscOHk5Li3DgvGVVQIC9EzLkSm8uI/wVl/tpYPI8yvIyS"
    "eVr7XqwY9A2++ZP0B6KiQx8Vq3FB8eFMv3w9k4PbhYeV/jWhd/E1/TNu1NnV1JdqA+ZMb9Qwyjyg1kmfBGuXWS2rb2+xJyFTq2FS"
    "H6VkZdpZBj/vVB0OWqmCIiBAc/r4iehHKTIZ/u8mBD5mCMQwyGQVd+3YyjKsB/VGOfjnn5le5FzSjPJmap9ByY//99lwPNctvJSs"
    "eat+AWEsGAVLvBlrqFrOn4otXfvzuoUO+69vfaiu/NGU4aFzVxT+rs6xPf0O3rqj+P1K6dTOXP2Wl6JS43bcvWo/s3/SKo+o+z5y"
    "XnDuq8yLgqxWGhbGlyuni41JPHvqmFxG/7so6CNUAJRj/iWFEl+6cOPyxTNuSi+15CKBlCO2z/LrOYYaEGAGIwyUEqeg0zyugVKK"
    "EUYiclgEh8UBAjCYzWPiKSCglNqtDqvJKjpEpxo8D4Re1Pn1FkOex9E/pVSicp1CE+pmwxBILdebrBzQ6+GQe60H7CvRudPWcYvi"
    "zpFC9VfVXuFxd/WPB35qcvlq9v2+Bb6+Vnz2YLkwZU+F8wmR/r6JgsQ+v7/ZmVusWUOFEDq0f4/dgd7Djp9PLNCbxn+AEezYusls"
    "NYXoCvCEF+HJGMBndABhRAmxm22iXeQ4nlfI7BaHJAkKrRIAAaUEKIMYs8lkc7WpwxQY4+zUTJJM3ZUehCFAAWFst9pYhgsqEKTS"
    "aZNiE9MepTA8linlACjX3j+fcaP0banCE+mnFOSsTJQEG5EUETpLQiZWI15/uXuF2Kr5D8y9aH/w6FZLfH9fp/NzHiDO/CD2iK26"
    "7F7lsookve/Ry24XLJVOpvs2q30oLEhpt+cusXxy4hgjm41WqaQODtJcOn/hUUxKcJC3zU7/i5Tox6YA6ImJYmJiMg4f2K1V6twk"
    "L4peXLaFMEII2U02hVKZv2LhfOXDAyL8tC6uFovh8r4rZ/44iViEMGIRl23OcK/kNmnGtz6+AQxGmVnpm5dvOrP4lErQIhZsZktw"
    "4fDOE7uGlQlFGGen628eunFy3fG4W48EKrA8S4jTWwA4S/rf5sDQZ0hUxDH4TmbczbToWEu2kUK7QGC1HIPwkpsPriZK2ZktV2VV"
    "+8VIeF5SyqiSr3tN1EuSht5mHyRr3DEOcn04p93yKmUDBMIjJAI8npb+OL2AEDgc1M+PKV5cs31HwpULpwtGtLRaJGDZTwrwoYS/"
    "Cjlz+OCB+IRHobr8ClEpIQk9WzWAEEZ2iw1JWFvAJahiWKOO9YqVLqJ6/IJaLUr/UTxixYTFvFJmMZtcy7j8vGGOipPbbAAAPh7+"
    "48YN+1Ykp2af0Mp1PqEBI1Z84R6spgLIOXBRubh3r8IHyTfMWslGs/okvUzFMyxLJAIvrbukb0UDGIz2PLy4Pib5lFnNSK4mwDat"
    "OFrmUPmpConCkjt+7pZMjjVr5MiFcRARsYjIOequTadyqXkxfSkfU4Q7qBQRZipDNI/0P/YtjxEmlctwpUqqrX/AieNHW7dr+R9F"
    "QR8hBKJAMcZmKz2weweDGXfqgwGRp+l/zGBJFG3ZFr8CwU0GNSvfpmJycuK3X34V8yi6aGSxKjXqurlqXNw8m/avdu/a3dPrj5sk"
    "Y8nypbVyeWamwMs4SkGwSyZMK9WreXjBAdGmrtW7vk+w2mGDW7cfHD92+NbVy5cvXrRYjN0HfNa5ZZe9C48cXr3fYjArtSpKHzPt"
    "b/sglCpY/mZG9JAofYapaJeULNd8mbcURcPyeehlRzMyzZJdGlogqqWXiTBUDqBiAIAiDghCDCZaNxWHtIKosCOZSRLxE9v/1PIa"
    "pw4ghOwOWq6M0stLeeXCxYxMm1opF6X/XkbsY4wBKMjk6O6duKtXz7so3dWSNm/5A8IYgFj0JpVG22xY04aDG7p6KaxGGhoY+Ovi"
    "Jdu2bD159PCubet5Xubl7We2mWp2qvfnttNyq/LhzbsEQCHnBIk6S3nUPBt17TpYkUwly182vz7bsmfPgYS4GDcPn4rVajVu0aZw"
    "0SKhod52B3Sd1q5C60qbp62/cuQiJ2N5hYxKzxJB9C18byRH0pIEY+RRRen8aGzX4N16fu7B9tejIq8WyFfJf3myw3LVZCmTL3+j"
    "gKBMuwMDetyOBpSAVZDMICEEmDgwQs9Jf544gOagoJAQLiREdfdu3N2oG5WqlDEaCGKYTwrwLwcAhBA5x5w+fiQzKz2/rggvyiQQ"
    "nTVvCGOb2QoUlW9WrdWIVkHFvO02MGcTzGKrjXIc36Nn+5492wMAAZAB/LZ4jUdJv6ACodE376ecTv1lxuIOvdupZFoiAa9k1mze"
    "tXP6VjfeQ+fj6u7puWLlqipVqnTo2Dw3aLQ5wGggCCOHjYaVDBixeuTpzWe3z9qScDdWrlawPEtJrhr8wwx1rnpL11LDOc7cP/Di"
    "UQtOJVVXt3l0dHXC/rmFV9ecXqXY2Fi7odvJuL01XQtpsFmkGNE82IYygHJD9ZdMYnTuCwOEQJJAo8FlyqjPnk25detGlWpl/ou5"
    "AGb02IkfGQHqfLZo3vz7926F8gUUVE0RZRgsOgSr0ZqveP5eP/VrPryR1lNtNRJKATMYcoomqNVGrHZqtVOrVaIsEgScnpVKM9Ht"
    "izfcNV7XDlzavmtrsWqlHQ5peLcBfy4964G9DPrscg0r4xDOy8OrSsXIzGzJZqd2O7U7KJEQxtgZbAgOSgnKXyagbJMqCrkq4V68"
    "Pi0bs5jl2FxXIIm4SgvkHaQXHW9KqOQ06CpYciIj8EBKjYfyCIdb2jcny529X7tdxQfdWsXESWHHMy2ZRLJatNEm1ClMKRCKc+pS"
    "0TP01CvnkOa8lFCqUjIpKcL+A1kuLurGzZoKjv/ewKyPLQ9AKeU4nJltu3H9kkamUxA1RYQSYs426Tzcu0357OsdE0vVL2I1SXYL"
    "xQx+es8KwphxPliWExyoYMF8mdkZ7mGuHOLNNqOX1s9016jPMmRlpcedinGl7np9dmBYaNVuNe7eulGqVPEsI2EYBmMGYQZjBiGU"
    "J+dFAahJT9RuinYTmk3cPaXdqE5anYs52/Q2XSARGwfLfYzyHhfWfOEhrW+eHuFuGTSnwsFpyoEeR860sAzz1TE2xcHrwpI7oosM"
    "iS+snf6L5sic/0YY2R2kSGGlVsPHPoo1maW8m2c/KcC/pgA8D/duR6Wlpyg5tRwUkiSxDNeob8sJuye2GFxbr9eLNlCpGKe/wBgI"
    "pQzrHE5Icu4/BQCQCCiUiiqVKpl1ljItK3r6+SrkcqVCLYkiEOrh4eWTz698k6r1xjS+/uBC9WpVeBmbO7TEKfSSRFgWyeSIEKpS"
    "Y4ZBgBGVwGIgGm9di6+aTto7qWbXhk5q6B/UpuaYXYyoUeSruCfYIkLGe/04Ncr367N/urpd/3ngPXcPsd2v1dquGlwmuEI+jR9m"
    "dFMu4XQbleFnxf31Z1AjAFEEHx/G11cRGxMXE/1IJkP/uZTwx6MAOcibEJ6Bh/dum0wGLXZBCBFB6v/L5wN+aO8doJs8cUZSYrzR"
    "qD904BTPUIzBbLbJZchistlsdqUKYwwMg1gWCKXOohdfX6/qdap41fAI71gwsmvZYk3LSIIkCEJYzfDgdiH+DQJFpb1KlRrBIcF2"
    "O3Um1BgG5ApEKbjpcFJS2tXLN1lM167carPalDzSG20ipTwPGRlWpaeuy9edQgrnc9gc/xw8IAAHYQPkht4lzt7KKLJkc1/ubqPr"
    "iT7fnKp5N5/39K5R3q5C1/0ukuIOo/FNzXCfdJnX8CD+ncz0Y8wmUZUK5QtXpqakp6Uls+x/r0v444kBcpep8DK8/Y/d584eD1ZE"
    "qIlOpALDYCLI9m0/El46X/Vq5VetXJ8vIiQs2Hv16k0anQtDxSWLltaqUeHEiT95XsHxjNFkdXGROeveRIH6emvLlCgaHF5QFyAX"
    "OUkhVzIM6xUS0LxVwyKFipYoFq7RqhACShGl1EWLo6MT7t2+p9Vp1qxaV7Z0iS2bNoeE+fM8XrFiadkKZV3dlKlp5qQ7SSoZv2TE"
    "0j9mbMxMT3eW4P3dGADl7XAQJLaEd+rG614VHhzZVGJx5RoXsNJhvqhhDpghHMoUjx8WfESX6X4+O/COATUOtfnIiYP8DfeDEAJR"
    "oi469tJl+6mTGZWrVy5ZMtJmo/+thMDHRoNijO0CxDx6yLM8R3mglOW4kxuOnlh/jJdzpeuXPzv/XMMBjULc/H6buManuGfxIkEz"
    "f17QpkPzR3Gxj+JiS5cruWTBsl69u1y5dN3mIJUrF7dY0IULd9LTknU6l/IVirtqfW/duC4KQnBAkMMmbdq2XnDYlSq1m7t7jRqV"
    "EuLTNp440qtX5+1bt3r6e/kG+p04c6ZL717Lflo65PM+d7QPxzf+pnGbhlfO3bxy8KKbh1tWegZiEMOyzl13/wT/5DoBO8HeKtvU"
    "mse+PF1kTlrLixfO7jOiylWKe5S5fSvWM+lKOX2I0MzjuFZfzmB0bLqnmlAm2yz8reEmNKeX2M0NYwY9enCf0v9ep8VHVwqBkChA"
    "RkYqh3mO8hQIApBrFM75zye3HOFlsg1xhoy0dJvRXKpu+fOLzlE1sha3b1m7rX3fTqsWraxRv7pIpaMnjg8Y0F+vN+7ZeVCt02g0"
    "CqPRuHXzXjdPb0JESpms7KxbN29Wq1nD29vbaDI8uHN344btTZvXE5G4edvOrj17r5y2pFXPVksmLr297vbdEzeGbR4t47nMlPTF"
    "E5eyLMMreb0+m1fKgL7OCozXVA8ECFhEs8x8qwoJsRVUhzeVkvtEBPv5n/JzfXBdMyDi+rGKKRczE2sXftBcjF95NWzbQzq2ZDbO"
    "u5bgDeTfSTpTVxeGZVB6auo/i2Q+KcBbAkKSRMxGA8YsQxln2Q0lOXdW46allKYmJbIcq3JVXz58HmHEsezEvd+oteqfj023EJO7"
    "wXvVxWVhRcN3/rA9nk+u26LB6b37ilWsYDQmy5Xcjes3wvMFMSybEB/n7uFiNumvJMbF34+v0aheYEjwbz/Mq1G2zsoZSy/8diHh"
    "dvyFNecZjO/YrHKNkloFq4XyapnMSQ0RyrJsnpTw04Ox/pb5zw2EEAKHwPbs9/DBDQVJFb71m3muTOP8BVWb1qlP6iML1PbxkGV0"
    "dpxcxURYQW2UMIfI37XdiFDwcGcYBiwW039RYD7GUghKBcHhnHf1zH85+RaO5ylQIhGFRun8A61cSwgxW40MYjb8vEoml6WcTYk3"
    "xk3c+8OfB89sGrXlWKnjpx8cad+219Dvvjl79IAkSfkLFb5++dI3Y0e52D01SS6XjlycvGLy1f3nL/78p9Zb+8B+T6aQ8XIWAKnk"
    "GiIRzGAASsmTTsN/HC/mkf6c9TH08RJIcFjAxU1s9XnaxEl+3gXZFRlCJVWR/sNO+9ui199Wds427Kto5GIZg8CZROTBIeFvaQBC"
    "QAmo1AzGyGaz0U8K8EGRQs9Mb82b60GAAFH6mLOjEgUAlmEpUI2bllKCgXFR6lw9XPwCfJCOEe6RSvI6+iPGBd1/jGgRJuPYNcN/"
    "N6cYA7LCWcLqIbtGs2pXz1+3pwpegT4CEeSskhKn36HON3eueXy2HJrSl3bFPyNn9KXSTwjFPIMwYjiMOJwz8guDVZQ3rpf+pzXw"
    "2wWTwZ/dn0X11K9QI8fEuntD+XQSL3PYFP6etgC5wyBwj1PCbyzDhIJajTEGUSKEfIoBPowwgON4QgkBCQGiT5aBolfih5yMVU7B"
    "JgOMgdv066rv530j07L71x2Mj4rOsqXdvXDTFKJ3cXe9GHUmICCY17K+BQNbNW6hcuV/GTpDI+lEIgEBZ+/lX8/bQui1cfczY7yc"
    "0koBGIWCsyaZRBEbotNstw1UwAgASZQCjmOgOb2TQotGJRf6s2Dh5IiQc7HewdaHpXwK/HEzP8jEYWVic8OLv+eQEIDDQSkFjACj"
    "/97EgY9OASgwGKvUGolIEjhrj52dAOg1FOeJWSaSpFar7+y4+7X6+5FTRjWqWy3F5KDAUATGTINgdwwYNZzleKUcZ2XpJwweHbM3"
    "1lPhzSs4QqTnKwue42pfrALo5Y7gheOzWMSw2Hr1ykXT7gwvo0S9qJQEvA0s2WCzAysBb4NsK/Ti7mVq93XRTIrJ9GOUD2MyysUk"
    "0wjf1BlVr9TwTTWILIP+PnhBGCxmQgjwPP9fnI3ysSkAoZSXIQ9Pb4E4BGRHFANIrwobX4DGH5dHAFVi5aVF5/ud6tO4T5MmrRvH"
    "JSSe3HuUsJJCrdInZ0qilL9EZJNmNZq0abXsyGK5XC5IDoTwi2T3+QGGT7rEngMe6HV8A6KI8LYha10PX2pWu8oOgwvxz2YbFkvc"
    "K/NpRRw3tZnzLrXtJsY1VZyVZcExh28GdmeQhQEaGRLTt3BC+6BHCiyaBCaPTr6ZGiAEhFCMIDtbkghVq9WfguAPQAEIkfNMvvCC"
    "DsFuQ9bXZA8Rel4TEAKgiLi7exlu6vet2q/x8Vo2/LfUu8mVh9X0DvTZNG6tn0fQLtjpf8A/ODzQTqxA4Rnpf2Vy11ko9PcDfTnP"
    "RiVYYi+615b7fFZcWflE5SJM2e5VFly+WXPOgcrjItaVL1p606qq11H+Bn0stX2Npc4+uhSVOKGhfUKxJLuITAJjkP627c/bWYGS"
    "UkRRpJ5ePn8fSP17x4eStKNv7y0QQEhIMMfJTNTwGP+8+CY+NxT0+anlCFHQk8weE3p5urrrY7O8lD4KXqFUquRIrpapRb1DImL8"
    "o2QkPLVw49k3yjMUHV4W9b4Apr10XjSh4MDIyyC2KLTxWiXb1eg2O2sjj3TFhulNR+YXN7S+GHuy9Nk/PXt0ug4lyne70CjWeKUA"
    "Oqf2u9osOM1o5zPtHAFgUN5ZufTvqiIkJ0uSSCIKFXlbK2Po/5sCUAAGgNJcvh4AQHrDvin6WPJsDihaorSLi5tRypZAfBkWdwYG"
    "uZL5jBo8cSlAVZz62ukrFSsWqTGorhTgcDjsJrOpUNMi6oqaDtN7JibErpm8zE3pKVEJnkzbfUoT0FMh7N9Hys5mMoQ4OSOTK2Qe"
    "JrhnVl3KCl1+Pt+y8xGres6KrJDdb2MVvfvlhfMPti2Rsp3cm11l4uJ8C3Zc4c4kJowtZQhXcFaJcPjJqJO/Lf2UAsui7Gzp2nWT"
    "zkUVFhpG/xYLRJ6+74QS/B4zyuyHIP08AiuAnENIBLuzSB3AlcMmCaQ3vBYYY4eDhoYGRUQUunLxrElhdKFuIojPbcNDL4RBecY3"
    "IOdPkiS6aNxPLDhmSjd0GNylapvqN/68LJcpWn3eivLypRN+tUbZFKBkeOaxwiLIQ7W+AfqhufD/xV9NokjGcDwiJkdmvCE7wQBZ"
    "Kakd3cxHXdYU9it/kdjGnnCpEJFe23ffwktpSWcdNOyUZGSbHI5IY5gkrX/LIoldgosKREDoLRhcZ+DCcSgmVrxzxxwcGhgcGm6z"
    "ORvu3oxFVbIIAKwiYAQSpWoOGykAAZa+D1fwLysAAapm0AVjeodlA/MHFF3ZfIyO4QUCBMGa+Fs1PMJ0nFykb7aHR5KIq46pUbve"
    "2bNHs1RpLpIbvPZerZx8LH1KUAkiCofy+v7rfkXPbP9xrSpI61XAe8ng+YN+G1mzWd1d17bJNDJREvK6jucCX2etD32FMP2ltXVh"
    "hVjDw4PJCReSLLetcNmohpiIo3ahQ72z46+XgvTK1yzVV51wKCJXumrkU1kX7kE0D1jurQ/T0JYK42eFirnw2CaKeevs/lYUkmNM"
    "JInK5cyp0+b0dHPdhiV9fbVGI3mjSjgCVM2hM5kJDEA5N3+jILnImW2xt0at+6pykVq/Nxmqt0gMZj5qD0ABAVgkR1JybNKlUy2t"
    "+m2dprvzzIGEuz1/ab++3/Jm+Yrr7cBihr5mla6zX1uAeg2aLJk/J82R6AOBclCQHC4I5TT10Ze2bzsNd26LDABlME43ZTQf28pV"
    "q0u5nVwsv79O58aK/NVjF3tMGbDl+w0gPWXvnwsjnmTfnuObXhU0OitMndKvguyfoq4vfqioHA9h/mSDUNBPE1apltxwMqZGthTq"
    "tzeRVXRxu2NkdEHuD3RcBiUYgCBVQH4VF8DLw92K8iyTV/r/LvJBuZwsyyCDQdq338CyuE6Dxhi9gTo9biqTCIuH7ZuVZUy/1v93"
    "F57ZHnej88L+4v27mQGF3g+p+i/HABghvUCqufvWLNsAOMXFE9uGHl4gl8G2uydwWtq1zBi5jOExQ3NQ+2uFARhjq5UULBhUvVb9"
    "LHNGOk5CgOljfiL3Hr3awebdr0EpVcgUN05eDSkUVLNvXYfcmpKUkL9Z/qb9m+xZ+IdCUBJMckPgZ4tz/vFtlCjSsGRODP/j1pKm"
    "jEaDa5UqWcDVlFpZldmxUVBwkQb+3gY6KPihhI62LqVc3/jRFyUj+kdWGFi87IDiFQYUCGsYFFnMJxwzIEj/XPrzulmqUuGTpy1n"
    "z2YVLVaoctVqFiu8jvl3Bl4UAaWg4lmMsT4lLvH+1WhjVqrDPHDVGDEhFby8WpVtSQTyHkrr8L/tAEDOYqUMzW86NqhQMSzAvrNb"
    "H9rJnfgoStmHNn23bbOPJkepWUopoej1LwhFCDp176NSapNonAWMDDBPBlPlqMLrMn2EErVG82DfvQXT55RpWEnn4goIVW1YKz4p"
    "7dCaPVqlC6HkhX/4VhpkMSA7kmL2BP4UFXvI5XfvkKQwv8iFzVWGRDK8S1DDA/3uOkLbU1Q/+GrPq8Zk0YNjwZmVRRgosVsFm0Ww"
    "A83L9f5t6X9i/hkGWa1k2fIsi8XSsl0nXy+1wyG91vd1MkWU6GQw7Pjyaed3+ik0KCPletqDjY+upj+IAhnXrsngfkXKsRizCH/M"
    "CkAoVTFwJi221upvxh5d4Jq/OPFztaam9Nk1/XzsLSrXmOzGlTt/2X7vJM8jESHmCYHzl6EwYzJLFSpGNm7aJtOYlszEv9BbvNpl"
    "oyeTALHVZAmpmq/L4N5zu/344Nhd0eD4ecD3WrW2Xu9mmVlpLPOOkSSCULXrFa7mo/R8W+/HVtxiORUrXzvw2NbR5x+m+g5L6WlL"
    "EPv6gWg6/t0VoysPUp4iU4zQ06D/H0m/8xBFqtUym7cYjx7NKFa8UJv2Hc2Wv+6DybH9ACwCwuAUiWw+tmrhyTXxCp6KaOnFLXMO"
    "LUQspysQZpXxTddP7nZiuR0ofses6L/uAahGxh25dWzLsslX920EEYicO7J/tT0+VuntzyPMmK0yu+OLo+v67/lBLgOJiBQovMIV"
    "5MlkEZEOGva5r3dQghCdCakccHnXj76GDqC85JLBlpW/cP4qbasSpaQ3ZRavWlKuVNw+dVOt0jzxAE9T/2/lEkkUNIhYSosCfVgo"
    "60FDT78hpT2PRpetOKfbbFPYroE7WjS8fQejSAc3ooDxtwfXDyRLrjyWXjR/+h8iH/R4GopazdyKss75JQ1jYcCw0f6+2r9cEuNM"
    "uUhE4jF5ZM6s8ftny+6dslJk0usLeAWBQnXy9O6YO5eoi04fm7hj5dSdm2fr9SlKFiRK0MeqABghswhlXH2PDVtXonYbluOwSQQ7"
    "YSUZ2Cxli1UyOByS3ZYpWjdFHd92cmOi1e6iYNnHhYsvvOA0j8harDR/gYDho8dbLdY49oGFmhhgCM2rA3/BhOSUCRDKKXn7Ncfk"
    "Hl83HtaqTpfaRUoXGfzrFw8v3k88HSdXKXIzFuhpDXgrB4OIWZI197u0r1ToSr8q5zIenU651CfywLeNT5hO8ct7aqXTAahwMw0R"
    "aqvl1T2Sv7sTJdLcOZD0LUl/Dq1FCPA8MpulCRPTHz5Ia9a6Tas2zQ0GZ7H3q9TGeQYyjtEq8Mr7J6JO77iUFOXArJSWUD6omNrb"
    "F5tETFkwOhgH4dw9evWZsa7xaCoCvGMU9C/3BCOEbBLNp9C0Kt1kyb2DDmM6yGWSDABwpmRLSnlgy8wqWLKyPv5BRnpSWGTF6X9u"
    "zqfxD9JoHRKBvMD2xdAF2WxSqbJFY2NSzl84TlSSi+TBIIYAzaUpX7WtMY8UI0BAEfGhp9cdu7j//KPYR7c23AiuFpZ4Ix7ZcZ5x"
    "Un8/AEDo8VygYL3gyNvmixwSBGv5W/r4WY+6XngYbuI9tj6ocj+5cIdqtxuUTlp1O+j7K50fIPfuvqfd1XzYmQw/Nafw86CC9JaU"
    "8In0syzCiI7+MnXXrqSSZSJ//nWBUiEXpZdu/UYoZ+k3AXCVoS/Prb+ckZSWGnP5ynFN4TJIn56VFHdTyLSmp0scoTKGlfESMfZp"
    "MWJR3R4mK5HgnS+f+feb4hFCFklyYfFVY9aNK0eoHQFFwDCO9Axbtp51calfpe2Zy4esZmNwWJE1m39MxmKXyOp2CcllCAiQ56IC"
    "9FS9PQKAilUqnjlx9n58FJKDG/V0kpvPc/avEFkGMya7sXyXKlRPM7PTVC4qsCNJJxlv61nCPlaAfxT+vkwBnHEjQXwxXXb82YPf"
    "Jp9tXyqpSWWjhXov3e4n3XIMqxddrVLsEaP/gbt3mpxICUzFGfo0VQFvmVxJiPRM18zfDnwlifI8Roh+OS5l44bk0Hy+vy5ZFRrm"
    "b7W+GP07mx8oBZ5FmEUKQFdNWZ8t6HfLYQZEHt08V6RAmUDv4Du3ztnSM4gkAsbIRok+W+7uOan+UF+Zi50Aho+dBcpJRmDGKtBF"
    "tfv17TZJ7e2GEQChSC4DQAqda7ZoSTdkUoZNdhi1vMuxG8fu2YQryXfab5lilgTWaWNQzhV/dkEiRg4HdXXVzpq/KMg/PM76IIa5"
    "iwEBYEJJDizI6cp91TojiUoKRnl1y4W2E7s0G9q+esuGraZ0iTsbjYyM8xK+y4loFCGwC4K/t/9nZbNPBhPJ17Tg2k472jN/6PnG"
    "pRK+/T3fD9sKdA+P7drEi0a4mrMITQTjmevASIiifyD8KFf6RZGqVIzDToaNSF63LtkvwG3G3EWRkfnMJonB+IWiDwASJToZ7Hh4"
    "vuvOH0AGR+6fRSlJMsQQUQDMZKcnurt5A8MwMjkwDJIAczSkWOn1AxZX9ws3i4hB70M4PwgFQBQkQFSg06t3dQ0tTImVVcqokgFP"
    "pTEzY+nWn5FdlCnUOpXOAcSampCQlXg+6fbuLT8uv31Yw4NDEsnLcTzDYLNJyp8/YM7iJe6uvtG2O4+Y24gCBkyA5lmenhcuP9kY"
    "lidiwXaHbcm3v2yZuXrzvBU3t1+q1qGuVTRjhF+W+fqngp8HtWNMbXZauXaxOD++1uE6hxNbbLpUuv26zotdSg34OqZ++fRxhxt8"
    "e7JWfM0CqoIqKRNlX8q2JicgGZfzBf+yNeflBIAkgasr8+CBo8+ApC1bEoOCPX9ZtKx69TIGg8TkGYWL8sJ9AJFIDEAmkSbumb3j"
    "4PJrRtOJuGtUktSEerv5Aa+88PDK79t/BbVW0jCgYHmFTJIMvWr2ahZWKMsqMgi9n7rSD6UYDgMIQJGDtChYiwIWk9Mg3QIZNhAl"
    "lGakVkv+fJFV3PPZHDYkirczH8VYsxhQLb3wR6YE3nJOwaJXlM4xLGPQS2VKF573+wpPV/9oy9273HWRCgwwBJ6sc3x2OkOenxDC"
    "DofdI8S7ZKnyFrNZEBxWi0WfloUR877qthClAiDXKVVd60q7XfX3K3j9OrbsrGtX3dYP8ygY9XBr202NfC/+/uAWqWllKBWNkH7m"
    "PlDhzW8xyi12IISyLOh0eMdOU7ee8YcOxpetUHzJ6k2Vq5TJzn4i/ShXv55Ml6A6GeOuwCcT7t5/cJ3BctGW9SAtFjAn2gx1C1YB"
    "nY5mGCHLDIIEaRZIN9pTk3yDitfwLaC3SNx7nCz0wcwwooAQFkU0vVLb+UMWl6lcX+bnC0oZKGTITYtUcgeRLuoTESAKWC/aE+wG"
    "ieXio2/GmfQTru47kfpAw8Gr/ADLGPRS+QrFlqxZFxgQEWe4f5e7ZgULCxzNY/0pfTEpRAlRalSxh6JFzt7mi07FapRxLep+efWf"
    "WqXumWGAb8H805eSZoJo03nnn1DTo6fu+rhQ05Sq9y9+veHL8YkHo/3qz29iEptMiawaGhSqyKegVmS+azFFx2KefZOCnzzJMgI6"
    "HWMw0K/Gpw4eGhPzKLV953bL1m4sWjTCYJAYlnlyqujZPmcFh8Zd2nEiOeZI4g1ktkiiKAoCKzkAGJvNYjFnAQKkUyEXNZLLkYvW"
    "M3/Bdq0H7h6wrKxHsEPCCOH31lbAfjDynxOZGqxSv0IVvVSeE04vicpOogBFXf3MxtQ7107fSbrNAC8hS7jaa4/jGiDGYTatS7jw"
    "886Zy5Xak0PXuGLWQenLIieGZfTZUrFi+Zdv2DBi4MA//zwmuDoCpXAP6k2AEErw4/4Ap8Q8L8qEIaIonDlyPPrCfV0rF8aVJan0"
    "rdkQ9NdYHSHkEEihiGLBHgEKF126KMdgL1gjbUm1jGMx2b9cjay/g59cQ9G8vt/tRQ+wHexpFm1ETqMuyim8on8p+pRStYqhANu2"
    "m2bNSbt2Ld3X13X011/36dcbKJhM5AnyQc8HS8RVhpfcuzBz3mfQ7af0rEQqCoAUWaLI67yB5RJT44ev+BLU8oIlqiWZDdkOK8vy"
    "lQNL/VTlM3eW0QuERe/VKH9AHWHOgk0K4JDIwUfnbhxaC4IMOP4avggsi2QKlG4AgSA3j1DvMLhkA8xQwaE3pvkr3GOunVhwdf+U"
    "Mo0zrBJBCL/kIrIsYzRIIcF+y9aunTT+6w1rl1nURisb4SuGMIiVqIieaw/L/VGikobT3dh7rVSDCm6+XiER4XF7YjAH5H23QFGJ"
    "UqWHBxElDDYAZDEyGNGGAdebBl0/moTN9vTM7BSGxyARhJ9fdf3iDswc0SdUocAyOT5/3rpgcdbevel2u7VO/Vqjx08oW6aowUgp"
    "BeYllL8TRDIUmSj8fGwpY4UMak0ypQFmgUhyzDQILX6ZWUMNNiQDyjG3juwFiYBEBId5V/CdQZENK7gF4SdrPP//FCCXETI66PcV"
    "O0e4+s3auyA1KdZms1GRUMFBZRwwIgiOI8m3BFOGcxQzxYzIICSibRd3jCndGDGMggGb8NLEJMMyFgtRKBQ//TIjskTxn6ZNuWO+"
    "ZlBnBYnhGnAlIBFKcJ5Us3OciVNKGGCy0jOP7txnjDUkRyWoqY6+c7/4YlstCQJ67K8wpgCQbZcDQEUPAFw2S5ZsVF91SA7EPfVn"
    "KKcGCj1vegihCjmWK5h79xyr1+rXrU9PTs6OyB/cZ+CQzt16KOQoWy8xDPMyfPe4wAGpGNgdf+d+1HnCK2SYZXLqV/C5zPsPUx5R"
    "BKKSBYcIdgdghGRyrUpVtEjjqfWHlXH1NwsUv62msv+oAjyu2kc2gX5erKafS+CXOyfHpUYTjIibb0hA0To+EZv3LRk7fxDHKhCv"
    "oCzSab0cLEc5/u6j63uT7k898EvbovW/LN0wy0qYl8RSGGNRpKJA+/btWrxkiYljx168eMaozQ7AYT5SIAu8CALKqZd+elcKBoWg"
    "JIyQoUhT2FQYvdcN6U/PknhWEp39jUYHZRUUbMia4VBHIF3+QMm5sTiPrUd5SgGdgEcuwwol8zDavmGTYcPGrPv3Mn18XAYM7d+7"
    "/+CIfL5GE5jzwp4XSD9lgDoQbbN+bKXQ0gIhRJ8JGIXIPSyqDCAig+WTN00l6SmRddoVzVdy24NzloQ7jDELcbLyJRquqD/aBYFe"
    "IE7e8z071A/OAzwGQtTqIHfTHkZfOwM2ipVaJjs+NTZpm+yEhdgZBxCzFSGk0rm18S+xHmFgWMmgPxV/Jfb+zQk3TlYOLlbRxc8o"
    "EgSAEH5RthgBQlnZUunSkau3bJ43e87Shb/dtl7NVmf4SSFu1IMCSFRCefO7FAginJkX7ooqXqMwqwQsAFD0bmigZzTrRVP8X+Dk"
    "GASYgfSjcUgC70bFGbVGsgrPXoCc+g6glCoUWC5jHkTbt241bNycdft2lk4n69i1de9+A8uUKy44IFsvYYxfVumQw6BR6qrEI46v"
    "ObFjgWeHsTE2IwALyOHBygMCCyCeYyiIqQZGrXt052LSzYuiw8YIomQxgy3hLH86q5pRxqvw46Qx/J8rgFPUGITNIh1atJ7P8HVz"
    "j/1+7doJSIu3UGwBBIgBjABREBwSdjdRh6dSEwcURCnerI/wCbl46saUQwt2tv8Wi1TFYasI5CUcOMMyRiPhWNlXX39RvVadGVO/"
    "O3PmSJYy3ZcL9pECNKCTQCKU5KoBAkQQkbMqu2gHFjl5UgpPwS3qTD6/3bzYS9Z1vUANMCImQaGVRwwvo8zvK9kcz6u/k7VSKhDH"
    "MfcfCJu3ZmzanHXvbqZWJ2/RpnH33v2qVquIEBj0BCH0CsNPKJUxTmSIzqYnL9i3gFF4MK7e9NptAAyYJXKZYLdTKjos2QAIbBZj"
    "SqYRJAAKLFYGhLar1Hd4hU6+co1z7+C/Mk+C/SDlHxAFhJBDhO75SrUJK3U07sb6qKPRsbdSs9NEhDzlKo1PCM/LDx1c3eHXPiCX"
    "YYYnxK5keU6hoJzy6MV9x6v1quIZcjQ1uqR7qIxS6SUiyTCYEJqtJxUqlVyxYcOqZb8v+u3Xe4k3MjXJ/kyoh+QrB0VeNSBAFKBU"
    "YKVAHE+Fy3k6wpzh4FvMDdNXu4qnP4pi8GxVmAAi1qek3wn0MUZqNQYKV65Zt24z79yZER2d7eqmbNmuaecefatWq8hzYDQS55V5"
    "xacSSpUsirEYzXZLWR/v3w6styclgFyeX+dzT5KAEqTQfH96+aOrFzzDSxQrXsWaGJNtzNI7rDqZ0sXVs1pEhdZF65TQutocYJOc"
    "XUf/UswJAB+oDgAgBFl2ggGaBhWtFlz0aPzt1fdP3DClu8hdS+q8iruFOFTqY/uXgllgOBkItgi1e4ZXMHAMzczYeutgeMVujWa1"
    "6lC7//L6/bKtBCP8QsTitHNGA2FZNHBQ73qNGi6Zv2jTupU3DBc9NT4+KMhT8uFB9ow3eCY+fuwK8pIqFOA9LY17quMZIdEmIgq5"
    "hWRO0WdZpNEwNhs9ddqyaYt+376spES9j69bt16d2nfuXq58aZYDs4nYrJR55apTZ6ZExtB4wVJjXqf8gUVXdpiy/eohhHjK4qqe"
    "+f7g5YAAU/zo4imX/IUH1x+oovScylO0ZKmp0Ni3cN2wCqV0bqIDMi0SQvj9B77/AQXIvakMwoQSEyGdtk3dt3MByFyAkLvEcdiZ"
    "GfLyx2odsupZggDjEp7hroTdR0VA8sN3zvQu24IRZeu2z21TsGqTgMImARhAAqUv3L7CMJgQyMqWAvz9vvvhm5ZtWs+fO/fg/l0Z"
    "0gUvtZ83DXAnXk+rwZP4OI9KADyHiOC5kRPv+sidw+IUfZ7HKhWTmSnu3GVavyH75KmsrCxTSIjf4BFdWrfvUqJkAQRgNhObFTCD"
    "X73nl1Aiw9hOiYzHY/bMS7tyunx4xRspMaakaIxZ+r/2rjNMqmLb7qo6oXP35DwDM+QcBUmSJUhUEEEFATGhmHO85pwARQVEclKS"
    "gkTJIDlnmJxD5xOr6v3oAVG59/re9T5Fp+wP5pOPoafPWlV779p7LYcrPjaNxCQKAJhhsDlDaviF6U9BoCriqgdY+pEZL9jIrPu+"
    "ujmrFVD0R4X+VwEBLnEAASIcjWjSa++RrRU5ZwFJSLAhjIFzVljCmQncpKIApjJl29zOjTqAxQYahMuLNCTghGR6ZO+rGz/rM/oD"
    "v6FgUY4lOEyvzAGEgAhEVbmqsJatm3w6Y9qWzdu/+GTq1i0by6AozpaYCGnRl9PgItB+RYNf7v3/DPr/vQfPGHDOLRZssZDCAn3R"
    "ktDiJb59+yo1TW/QMPOu+4cPHTayXv1kakIoyCKVMfTv5BcY53YJnwsHa1scPxReWLl1MRLsLWMzdlXmIk3nlKQl1l6as/fYoU0U"
    "maCUQ5jQSh8IIiEOjoBTyjUFZNKuZZ/2iXVVEzDCfyz64c8vjcg5IIRUk4+s267FQ4s/27Nw+fEtZUU5hhJChLgkjyU2+dqUem0a"
    "tCuoKPx0+YebTv6ALE6u+QOGShBq5I4/ROQDB3/Y3Dd34YFVO05uXTb+09qyK0AZBnRFGmCMAEgoyBBA9x4dO3buuH7t+llffLFz"
    "x+YyXhxjj0+A1FiWKIOFcsrg1zT4/UOgfyke8cuUO5LjWq1IFPH5C+Y331QtX1F57LhXFKF5y6Y33jyy/8ChqakeXQe/jyKE/u0o"
    "I68W5GIxVjLl8OaXljz7/cT5sw99xyorwCJHe+Lz1CCnlIjW8qqCV6c9kJmQeeuoF0KlhZvO780rOh8MeBVTQwCSO/6a9CaDWl1/"
    "W5PeNgoqA/RHox+uCm3QCAe8Gsuyuib3uvOxzuNVxVduaGdDxVWKvwIxCctuU5MyGrboe9vB9QuwyoEIOqfxkj0zKvEQARQILDm5"
    "Kc7iPLv9uztjXlk28k07xwhDyGT/rOc2AgufjxGCbrihZ49ePTesXT975vTdO7eWGcUx9vhEnBpJkSM67PATDX6eEF+JBj89d/7b"
    "QX/FLoafoZ/SizkuwJGjyuIlwTXfV50763W65J59ugy/5dbuPfvERMuKCj4f/dcVnst3fYKQJCAJke8KTj/41SMQDh8Il2058gMC"
    "gVsEV1QSKTyJALAoKiVlrtpp3a4fGy/ZjdSG3ZIzXVSPF+xRjqj61liLKCc4HC4AnwrqxflgqCHAb+QAQVilPBxiHoRdbs9rG6av"
    "2zw/oOthNQSGCqYBRASHh4CEQDcNnVMaYkZcSgPAiFOcc+FovXY3QGzKzq3LP2rUdXzDHqf9Jd0SM3wqg+r7lys0EUUqIT4/Ixjf"
    "MKBnz+t7btuyffaM6Vs3rz+q7o+xx8YLqfE0SeY2xIEChYuuHJdra/3b6J9f9hv6V3z4tcR09d9jlGOMXC5iGrBtW2jpMv/atVVF"
    "hf64BM/wUYOHj7ytQ8cuNhuEw9V1/X+X5gLnHCNEObcRFOCwp+R8w7jkh1e8CcUltVp19ppqXtF5wKJkd3ZLbLAl9xDnwHWDSLJa"
    "FZj+5YugBAAARAkkS5Rk88TEvnvzKwNTG1QqZjkgggnifxYV3atGHZpzwAhhRAzOFAagBUvK8kAxAAkgiARZqEGhtJRyChbBlpER"
    "Ls7p/sEtWQ3bIIuNK9q+iryb3PH2qJhwQdG8rXO3lZ3ZsnbmIyNffq3NQJ9KCSYioDCl+Epm5xhjDuDzU4xx954du3TtuGv77gVz"
    "Zq9ft/pY1b4CR3SCkBLLkpzcjQBRTgHxSzJBP6sU/daI58q7/hWDKUo5IcjtJpoG6zeE5y+o2vRDZVVlMKN28t33D7/pllEtWjYT"
    "CIRC4PsN0AcAyjkBsBEUNJldxPl6YOSCZ07kHhvec/S5Y3tAlOqk1K2PbBD0IWQXrPYH1n246tsvIDbWxASKC6ifABGxIAIACxsQ"
    "UKqgNCBCwNR0yjnCAsKcw59HQvpqkkePuHAShDUDPu0z6ZbmfeYeWXfo9I+F3rKQqblle4LNnZFev3+THj2z2nx94odX5764Z+18"
    "JNgAdJ+utoxKc8elhkrLL5w9TpLTEJPe+ezhgBqc3HlkflDzI97IZgloYHKOEWKccc4xxpeCGYwJQhD0M4RRpy7tOnZpd2D/sUXz"
    "5q1Ztfx06dECW3aClBLPUlw8CnOBgclRtTHHL1Lkf5sZ/8ZFKRcE5HETf4AuWx5Y+rX/h83lwaBSr36tuybeO2T4iPr1a1EK4RDn"
    "nBPyT6HPOOecRcqRJmNuEYcxHA76m1pdhXpg6JeTjm9bndKx93cHv8caZQTaZrbymzpwjkUhXFm5asW0Js06fzLydU7Q9ye2bjq+"
    "Jb+8oDLsN7gZb/PExqfe0KDLsCa96lpdAYOT/8c+59+625T5rzJB9wiQOOdOCQEB1YRCNZirB3bmHd5des7ir2CK5lcCHlf0tmBe"
    "5bH9oGJs6rRWxoXnVv5jxcczlnyAsJRxbTcB4MLWddQhfPDATKKEnlr60gPX33t/+xFOBmHKnBaMAcIa6PxSjwqPlF4BIDIDYLNj"
    "AcPJU7lLFy5YuWzphQtnZVlMsKbE8qQoFieBRIFyxH7hT/Nrk5iLeQLXFPLkl7hp59xwAOPqPqMrzWdSEARwOIjPR1d/H1iw0L97"
    "d4Wmao2a1ht2y8hBQ2+sXStJ00FVGKArqLWxi4VgDsAYc4kYiUBNCOg01kp2VpQ8sertfaXn1t094+llr2/bsJg43K36Dj++fV24"
    "rJxb0fYX1l+oyh399kgiekxuoER347rta2s8zEyX1aG43FHOmI7pTdvF1I0V7bEyFhFoOiiU/+EVz6v+BPjpjowDQsinM865hJBH"
    "sN668On9u78HjoGawBkgDBxAtiFB4FqYmSpkn3rqm3fl2ESw2rhmCt7KPp2HTt63WdDgxfnP3TvsKT0Yfu2Lp1af3T3nppfSLa4R"
    "331U2xHzxLUjPJj4dEYwlhDCAApjGOMIqsIhxjlkZqY/+/zjo8eNXfnNsiWLFpw4dqiQ5MXZEuJRagyNl7iFAb14GvwS+ldKhNGv"
    "4n7+q4AH+/1s4SLvnHne3bsrGTOat2w8fNStNwwampocrWrg9VGErtDAwzjHADaCNAYUAHMWbcMbS/Lf2z67T90OD7a87t3DPzy/"
    "4KXwqWOdrx815/B327Z+jQVralbDpnFZe7zzEOeJqfVWlh2fs+JjqurUqATRhkuDh3OXH6YmIADOABPAwlK75aXbXn+k5fVlYRMj"
    "dOm260+4116VDjERDhCEOeIIQGOGZHWCww3hIJgcsAgIATXACHPRFle/cf9GHbadPTB/+acQHweyDevhc5WF7TJar8pqnHPymDfn"
    "/I9n9vbrO3b5gvcPbFl1Q3neortn7D/z4/I961cc2/DJ0Be6xWcEdFakqRqiTVxOv8pNDgQhhDFjNKxSRYHY2Nh7J46/+dZR69as"
    "WTBnzt49O0ppUaw9Pg6nxNJEC7dxxBgwBPB/EwxiDACB2y0Eg/SbZf6v5vp2bC/jzGx9TcuRo+/o239AfJwjrPwyx6WcAUDkBDMZ"
    "c0k4DHDYV5ZhjbJjzGX8xI6F762cDNnHGz80841jW5+a9gDyG2J6Vqdr+n+88DUB2U3qvbnd4FgmgRLA1tgKb9kb0x5GHA0YOJ4Z"
    "xoajm9WKUqAGIAyYAKMAAJJIHC4RsAGAMb5UZ/tzRhpXXwj0y1gCQELABDhRVfLNhd0FucdPVBVo1Eh1JyRGx9dJbuh2uO2C/XjJ"
    "6S92LwiePMZNInJEZb7q+VXn8s9M/PhOjGxSjGvyxM8f/+pR/4Uc0wg1a9frxi63vvTpROYPialJn45+a2zD9n2/fnvX7hW3973n"
    "mfYj7QxClFsE5JIhrEGQMgKIMSaKxG6FoMK3/LBp7syZO7ZvCauBaEdsEkmPpUkWbuWIs4iB5EXhqp8c8qpDINK0c44SIAizS9Bn"
    "jDsciFK0eUt45qzKTZvKTUNr067lyNHjbhg0OCbKEg6DblCM8S9uIdwyQgBeHRhj0Ra8szLvkeXvHjr349K7v+yZXm/AinfWf/s5"
    "ChuZ7bre1vOOF6dNksJMN/y3j3jSbXd/PP1pTBxRqcl7n1/90pqP5yz5GKwekxnIJbS/5vpRTfpQ2W0aoTxfaX7hqTJvRXGwMtUe"
    "lZZQq1Pttp1SGqfJ1rAJP7fhqCHAf40DiHOLgKwCUAwhBnvK8mbtX3k454i3JC8/UMmVAFAOkgUD5qrOjTBwLaFO0/7XjZi7cZaZ"
    "X0pZ8PV7Jkfbo+96Z4Qkxenh0iG3PI6Y+fWSjzCxgVNc9tDc81UlD74/GrDYusughcNeSpHsOcHA/JPrutbt1DU6vkxhBGPGmWGa"
    "kiA6HUgzYM/uPfO/mr32+2/9gcpoR2yckBxPk+zcxYGziKT6z36WXxCAA3BKuSxjSUJ79oY++9y7dl15KBhu3qrJqDHjhw67OSZK"
    "CoXBuAh9yhnnXMCEcS5hJEgw99QORPmNdTq4JTTlzK4nZz+lnD/rqd9k/1PfTVzz4XfLPpQFj+YUXxr79rRl75WcP8MA7JmZ2x9e"
    "Onz6faf3beMiadqlb6YrefnaGRAIgWATZCsTMTN0oBrIstXuSY9OciRk9G/U+fYm1ydIgg2DaYJmgsoY8OoM5M/sG/bHC2P95xyI"
    "DBMbjIcMFtTMKAm/uX3BrBmPlubl+b1VoJsCI5wBqCpX/GCXu3UaOOC6EUfzTm3btZyZDDgCk5baxSnXjz3MzOMndomi61Th0ccG"
    "PbSz/HywOB9rdPWFXY/3m7S76nxlfl5B9vE1ZSdHtuyd7au64+PbFh9eh+PTe6ZkKjq1iiTaSgyKAooJDGVlpfQb2LdDp+7AyZnz"
    "p/O95/1SlUF0iVssYIvIrlzmKgCmgTsPwQkZPtPAjANG4PEIeXnmW++Uv/p60d69ZZlZaQ88+vDzr7zZ5bq2nJNwmAKgCPoZY24J"
    "u2SsmFwmyAf67Stef3/Ws9uVsmc6D333xPZHP78fygPMgl6+7dUT5blT5zwjS7GaVvbgqJcqguWbNy4UZDc4xPn3TrcI4psr3kUG"
    "QrJcUnrh1NkDXVpeP6T7yDOh4lBpLg+rwBEBgRhMD/grCnOKju/afGFnr9YD6squMtXUGaIcBIKtVmQYHP25zVP/CgQAAEYpRohg"
    "TDAxKLRKbhhdr5XPZUOyoMuCYRFEpz0jJeP67iOeufHxkU16MclSjIz8ylwe1jAnjNKS4nMbC05YJOvpqmysc9Nfid3uD258ccnB"
    "VaZmhssLVKf1ri6jF+5aZMHOkpxj23T/fR0GLb9wsOTogQ1HNwSj4ofUabIx//Sbh9c0T6yfbJHClBs613WekZHYp3/vrt16U47P"
    "nz2bV3XeL1dxwizcJoEFLtIAIW4auPMQFJ/h0xTkdGDGYO68qiefLlq9usAT5Rh7z52vvfVu7z7dMJaVEOUXoR9RG/fY8JLco58e"
    "Wd85ubECxpDZD23ZsBQQeWrIIx579PDJY0SvZjK9bosuj/QYP/qLidxvGKbSvfdtj3cf9/CsR6jCTGRKmXVMNfTc8reNogJMZAQY"
    "YRZXt9G1TbsPyeow9NrBLRp1VGSkMFWRRWqVnJ6olMyGna676YUBj3dJqG9wJGCCESIEBYPhnTv3pGekw587wri6Q6CLdRPucCJF"
    "AcPgGKNIVmCTIcygUjNyQhUBQ01zRHGMlp/ctO7gxu0nd0HAByYnkoMzxlSfXLdR6+TMPReOGRVFSLBygyEGYBeH9xt/qPj4ye3r"
    "BSoit7zrhQ3Tdsz7bN5rsjVO4/5FTy4tDVVM/GiChdtUIfzJI3O9/oqn3rsts3WvT0e92jUqo0pnAsaUMQKYOMENsPfoma+mz1j5"
    "zRJfoCLGGZ+CasXSRBEkCgYA11TxiRm4eZccici7fwy9+0H5xg2losj6Drjhvoceb9mynqIBUxnIWKVg5cAit7aMuqzkxV1fvzHv"
    "Bex0HX7+hwe/+cf6tXME0WnLSDv05Koxi57fvHaeKLtBZuufX/P18Y0fznxOkD3MI/TqdUcw//yObd+BIHPEATPArE5aE3ts3KED"
    "myGgCFanaepANZAEW1LGgObdb2jRp2NyowJ/qVdT4y2uTHu0VQKZgU+/lK8zpxOvWb31gbvv+Hb9lloZSYrGMcI1J8B/53oYMyzi"
    "L6fPTUmrFRVl0TSGMaLAwzpjFNkQSbU4mng8Ky8cHPvZXd+uW5SXc45QLGAZY4Gqfu6QRg24a9Ft7w5s2nWv6S8qOQ+KARxzqoIW"
    "OnZwc3lpMRARATKD/iKs3Nrpxh9KjgdKCpHJThiVr19/z/zTW7ylhQITtuXs7dV+yI6zB4pPHl2UvbNj4+vqOzwhkzpFctBXMHj6"
    "vX7ivLll2659enbqcn0oqJ44fqRIywtbgiKIVu5ACOk69BpB4tN9739Q+dwLBQcPFLdo1fD51958+PFHExNifAFKGFdFfvui55af"
    "23Vrky66yRjn0Tby1I7Fb89+FvvDfXrcWmWGZy583WKN042qx4c9HWuLenH+C4RZTEEfPuzBpvEZTy182QiqnGAO6NyhrXnnDgJC"
    "AAQhgjAX09Me7jfp4z53X9Oo8+6Ks1VF54AjUbRhEPSqqqNHd3yz65v93tw7m/Zv7o7xCFbOQNPMMK2+IaGUAgBjKCEhfumiBZzz"
    "7t07KuH/nXdYDQF+I/o559TlIu+99eETD084fuRoj979PR6rplGMcUSxkAHXGEMYzTq1dfPRHwARQMCpzpDBHNa2bXt9OvbdQQ27"
    "vL15+j1znsveu5WrAIC4Gkhv3m7yne/kxcYUlZ3FYZMDAo5OH982b88qIgiKqWAmFpee69SiV99GPRbvXESwNVSaG5tSKzYm4fzZ"
    "w6bXv7302NAW/e2YWAS8uez89GUfbTy2KSWzVStnckxK7A0D+zVv2bakqOzU2aMVqNiQdSuzWbmjTgfz3U9OTp1SSAgbd89db304"
    "uU3bpuGQqRtAMJIlMmbFG6u//liIjp3QbrBm0Dgr+eTMj89/+aioi9Qujeg1esraz7UKv2koGc06zBrx1L0r3s4+tg/JFu62FZTk"
    "f770Hb2iAkl2jhACE2fWemjUy31adN95YqupqIAkXu7dsG/VvJNbG6U1fLHf/alpmUcCRYFAOTMUAAqSDKLkZ8qgxj3cFodKOQCS"
    "ZQwcGAeMkcuJiYDDYTMmWgqGzbmzpg+5+XarVWIM/pzJwFUcAlFKPR7y6eSZTz1y730PPXnowL7S4uJ5S5fVqp0cDLLLJ/oQgCjA"
    "8VBVfmnuPm9ObtjfwpN4TUK9Fknp7+xc+taqj7SiIiLYGEKcmUhASc1bD2s3LDf74KZDW3zlpYhiFq6Kbth8ZJdh+0/u2XFiG6gm"
    "pohraky9Bo/0uffDXXNL9u0GipLq1H10yKMPT75XNEVDrRw+/JFZfe/TdTgRKOn27nC1sDimQYOt989NJlaKSZQNFAPmzF/06Qfv"
    "n88+GetMSCbpQUvVqZwLjRrXf/Yfr1zfp5uigATACagajbKSVw9teP7TiVjjTXoM3j7yDa7zXDPc5eNbfOfOUWq0at+rT5v+r017"
    "WMB2UzL7D7oniZEvlk/GBuYEcYFZomNuaj1QFciSlZ+CBliWuUWom1p30DUDzpmBNevnqiXlDJBIRMNQgND6LTpPuenFBlFJu/OO"
    "7yu7kKsGWrgSmsfWyoytHU9I2GAIuCiS/ILi5KREQQBd5wvnz2/Vpk2rVvUIQHaet2fnto8//dL4CSOrvPS3NJ/WEOA3o980PVHC"
    "3NnfTBw/6rax9370yTuVlcqYkbfk5WYvWv5tRkaKqv7s2OWc2wgiAhAEGIFugkWG27/7ZPbMZ0COBiIA08AVhWOjmcQ9cpQ3+zz4"
    "/Ui0cwBEtaw2HZ4c9BT4i9/7cdmJI1t52ASTgQB2lzMU9oHNDqouKGCi0DuPfLXt0MZlq74QJAePj9r9yJImjphiQ2/8/tBQdj6w"
    "0C03PzKv791rLpx5Z+fcN3pObBMfezq/csp77y6a9yXlpqZoXXv0efuDD2tlJFT5jGir+P7hDT8UHpnTc5KXaW0/HOE9e5Zx7Z6R"
    "T7/b7Q6Bw7M/fvPW9Mdl0WOy4JRH5329b9m61bORLYo5JeAMTCoKslHlQ4IEhFviom9uN/TGFl13FF74YOEbSnkFFmRGDWCqlFIL"
    "Yjx62CsqzCgpAsMEJILig6TYHx5fdV1iusZAxEA5UAoaBZ1xmxUhBKEQvfGGvkNvvmXM6FFzF3z92eT3Swrze1zf57Y77uzTvf2z"
    "L7y5cd3q7zZsME0MgGpCoN8L/dQTJaxevfWeO0YMGHrLB1M/VhVqsUiDhg5dvXLF+u+/v2nEzcB/0YGDdMZVyhWDhQyuUsY5FCqB"
    "AhGxlIwGmY2GXnODkFm3vCwH55eHCgrBYIAxcFWIjo5v1iotMWvh99MXfPtZWfY5RAnmiIPeunPfW3qPP0X9SlUh0jjnCFT1gj/P"
    "lZZ1NvcoYcQMVUbXbtQjuQ4lZGvekdxzhwViP+u9MKr9zUdyj3zw2cNrq873btC9VnRUr3496jVodeHs+d79Br71/vuxsZ4qn57g"
    "kN47tvGJqXefLc8d3XXM10c3rFo7SxadJjbH9bzjmpi0SgpPfPdeZUE+Rdxatx6S5VWbFiImcIIBm9jt6Hrd8O7XDjhacoJX+Tgi"
    "pi908NCm+buW+6juqtsIJBzyV4AeBmKlPj+UVQqUxdZtNKjzsKzk2kZsnDWjbuestr2zOtgEa9CgYYOrJuiMU84tIt6xc39hQUl6"
    "asKFCzlzZ36+9vsNwNn0OV+lpWdu37xp2uQPd+78sVW7DpvWrcms07Rxk1qKQv+EmcDVdwJQk7qjyPZtB0cO6dv22k4z5syVRNEw"
    "gDEW5SFbt+6/ZUi/WQtXdO12TSDwr45dzsEpgRdAodyJkcMCnWY8unfrN2BxgSx57K7YxIwbGnbZHyzet299qCAPOLFINp3qzNTB"
    "ZgGPxWGPDRYXg24gTDiloOmOhATZIleUF4AoE5XTsLdHn1HrRr2ETLh744xpc1+zWKJVvXLaI3Ncsu3Wd26l4XDnG+5YNeQZXTHt"
    "biEU4FYbMg3QdOqU8EFfabePbjGyc9JbtP9h0tz+M+4/vmMtFq0k2vn1g3P7J6Rv9VX2enOIUV7FZZGLCChNSa5dkJcNugmSiBDi"
    "zLB5YlWXxCrLwa+DYUiyjXNuaCFstaQ3at61WS+lvGjz2R+95cWqGgKDAg19dd+Xt7XslB8GjiBKADBAZT/bvTljNgceedNIb2Xl"
    "hh/WnM/z9u/eMS/n3KyFK4YN6a1QMCns3L5jxmef7f9xd3lZcZ8BQz+fNV0JMfTnI8BV1gvEGHN5yMGDZ8fcPKRu/UZTv5hpkSVV"
    "jUT8SNOZJyraarPn5Z4n+Jp/e4Hg15kISEaIUh4w6LQbntrR6VbVNNJt7mbu5ASbQyCQ+vqA0MnDYPMA6KoahuiEpLRGpeU54NOC"
    "RRcEIlJGuakiq5VkJHbvONQLaNu+FbyolCGEBdveo9s+Pb7z9gbX9mnYdZrjY1OniKH1F/befe0tzG4TDLx1y8KvW/a7tVbLCp8h"
    "iaIaZoAQxggL6JkNn2j5eSAIWbGpAud5+ae4IFNTq5PWtl9K+qlA4MOdc7XyEiI4GGeIgKNJ2w5Nep44v+fons0QULmpi5JNKStH"
    "FUAcopCZ4uLWsgsnQNMAiSwUzt6xWmzSc+ZNjxWF2Dl/6T5/oclovGTvEp1ZEWA2wBiBarKfZuwv++xMA15+4x1NC58+m5+TVzJ6"
    "3PgzZ85OuvuO2Pjv2rdvHg6ZnTp36NKtw8nj5+Z8OWfJ/FkHD55q0aJ+OPSnKwddVfMAjMkWdPLEhdHDBqVn1Jq9cInH7biIfmCM"
    "WSTh5PHjAb83s04Dg17pZOM/uz7ACDOImCwhAKGuI6aFOwYhMBgoFEydq0AXjX5/8bGNP5bnOkVrn6R6req1fX7DtKI9m0GwAwGT"
    "KhCTmJycUahV0LC+YtWXoChItHIGoOlc4GFq3jtlwodZrYd0GWFNSVfPXuAMfCXZ10TFxLjjyquyUdD4aPOXN9VuKRCBMY4wppy5"
    "RLy66NymH78TRIdpBlJTG2QHqwJKECPMMM9KrTNx0+yZ309Xgl4UFUfLykCygCoE9u9bvGeH5IkGt01ISUpklvzsY6CqnGIoDVJd"
    "uf/uyQ0stjVnD/xYWShhfGPmNcPqdakMUAlIS09ih+hEhMDkEDSBcuDVn8yV8aooNCM9mQJcf911jZs2nfnF5IqAXllRccctQ5Z8"
    "u65F0yyDgq5CnbpZ77z1wsljh5Ytnte+zUuhP19TxFV2AnAGgijFJSQZumJQKgqgcMYYMMocTqG4LPTuG/9o2rx1y5ZNqIkIIZRe"
    "Vg76hT32z51TEIDGeJjyyNcYIYQQAqFrfJ2uyXUMDghAAhA4HKjXTUIScCbbPUOSG9qiU6Zu+Kz05FFkIooAcUKDfiRbpDhPw2v7"
    "DqvfZumxHft3rXzjix+Rw41FkerhkGHYCaSm1S8/f4qIjkPHd20oye4XV8trMAKIcy4KsPLYRqiqIJZoE8ig9FblhsoNnXBgNvt3"
    "25ZC2I/TM2/rNcbhiVu0bUHFqeM8HAbGiGQzKnwSAuw22vcbO+LGxzflHt9Xcg4x5ra5e0TX6ZCUNqB2OxMAAcgAIR0iP1rY5EGo"
    "/tkJ+lfWdIwx2YJtEjE5SAgefvypO28fnpZR+8XnHvl0+pe3Dht6+7DBn301d9e2He07Xde0ST0VE3dUVPb587/agWoI8L/NVzDW"
    "dZ5ZK2X+shXjRt3Sv1uXOUuXtW1RT6UgEVxUFrh/wl3nz55auW57lEM4k10ZExftceNA4KJq1JXGyi+fOUGAhF+YHQH4DIb0auG+"
    "EOeA0OMtej/WqjcAUAY2CSasnXFw82KwxgAwQBg8USnprYpNL5g09+T+Z7d+izDGsgMhQoMq4xiIWOgrKjLU2xv3Prh5mUAEtaoi"
    "u/CUkFSL65wjkBAuM2HHhUMAgmlojqT0uulNlp3bCboBGIPOAVHi8rCAOnflZ1i22KNjIDUuweoBlZfkHgfd0AGg1L/k28mPPr1h"
    "clZrhQIGQAg0A4pDlFysyIcuG3nDCP0WRzrGuMOBs3OKP5sy9dSJI0NuGjHmjpvz89598amHsuo2GD2i/+ez542/7Za+13WMT0pq"
    "2bat00aWrdq8Ye2aN979yPhTXgVchUkwZRYL1nU28a5xWzaue/jJZ9q2aXX2Qs7k997JPn/ui9kLU9MznnvikfzcHJfbc/Oto8ff"
    "NdbQ+WX6bb+9w+LKhTvG2cXDhGMMRSHvgdKzP3pzw9ToEJ0W6455dv3npw9s46puUkqICJGxw+qmJUYkQrkWE5/erm3P7zcvBZ9C"
    "jcBdI5/6qOc4X5hijEVAldxo/MGw8LkzACyzeduM5IabfpiLQOI6jfQNAQDhHBDmnHFGJVGwxUZ17z1+QkbrbSVnchR/vGzrlFC/"
    "TWyWhEnk3+bAf21n9q9DxF9s/JRSt0vcvv3HiRPGNWnW0tC1Vtd0ePbpSQhg0oPPzJ/12YIV3/fs3OpcQXDViqWdOndt2DBDUbjP"
    "F7xw4Xzr1s1N80+5q16N9wCMMVHEmMCUDyfPmDYlHA6ZptGiZZsXXn7ZYOTmgb3bd7xu7F13lhSVfPjOW4NuGvHsi0+GgxdLEP+n"
    "uSR0JUxEACNjkIRqqVwBw+FKb7cpt1TmngdKgTFACBgFwQKyDQmIW1Bci84dkxrv3Lu6JOckkmxIoUwLdL/hjuWDn1RVQBgJCCrU"
    "YMs3bvCXViCrzC0IDL1lm1621Lrb96+B/FwwMegG6MGLs28ciAgEevQft27w44YJAgIGYDJQDGD/HOv8N/+8jHFZRjYZikoDQ/v3"
    "vXH4iCcfmwgAxV6+e+eWtIz0+nVqj7hp+Iljh+cuWdmkaV1BAF0HVeEII0JAkiAc5jU3wb9zHwRCyOmE4uLwmTOnPVFRDepnqIrR"
    "v3fP7LOnruvZ94OpU5KjbZu2Hxpzy41LVq5p2CgrGDQjgT3G/+mlzOWHAwfOfjJXRRLBPqovzt5dWHjKG/L7DCXFHruh7MSJk9uQ"
    "iThHgGSPbGUuR9BXzLwK4ZirgWY33HFg2FNlfpMBcgjET6H+q91DZeWcEBARivFEC45QIKBQHXGNI5Dcrr5N+riRENT1GMniiE7s"
    "VvuajvGZzGSU84vv8FdOo/+nA5AxZrPho0fPFuWfi09Mv+mGXivWbWM0NPvLOetWr6ysrLJarbMWLGlYP+v6nr0GDh327HMPV1To"
    "giCi6mEAHpEX+HMC6aociYxcbHHOvV7mdts6dmihGyCJsHTJ6pzzZ+Yu+37RnJmd27T6bNbsFi3byrKUnZ3TpnkdOUoUAAyAQBA4"
    "4/+JgvkvMgdyWZ2Qch5FpIcbdCaNO+sckABP7FhesH2R4IvIq3EAzcu8UMyxKBGEmWlww8g/u2953um+ifUwAx+CqQeWBbyloOvE"
    "YgcT88LKcloKGKOL87VI9Z90HZt123vXxMSYDEQAxQDFBISwgH553fGfMZw5nPjY0QsjBvVNSa81d+nypi1a97murSRb3R7P8JGj"
    "u3fv9NLzL33x6SdffTVt4bLVdpslFEKCKF/udP9nHgm4WgkAF1WdDYPrOueMWi1CZUVFfEJSq5bNO3f64KP3P7l77NgOnTppqlKn"
    "bp1zeWWzZ3zp9Va2addhwOABAMg0+EXToP/sLLpUUKrOtJHBebnGIxYUVhnnlp7zVxVAmALCUL0lcwDOVA0wh4TklvV7HDi6c/Br"
    "N95xw8Qu9dq+u/azo3tWxzbt7JDt2Ue3Q9gPiAAgYIgjxDkHxijQs8UXcrxFTe0en84QwgShn1mB/CcT6JxHhokBOBHwc0+9tGvb"
    "1ms7dXnrg/ddLtuHn87YtHZ1rcysjtdd6xIBAN5zuePi4k3gcbFRAGAy+HPPwPwlQqBfXxHYHXjvnmO3DO07e/HK7h2bA8Cew2dv"
    "Hti3R5/+I0ffec+YEXa7o269OidOnKxTr8HHn31uk2XD5JzD73s6/+rZc5uINpeem7Z3+Zmz+31aCAC7RAlbHcgV3TujxQ0NunRN"
    "SlleUnzX7AdKTuwHUQZMr+9z9+IBDxITFp/du+L09tMl51HQG1QVxdQtguiMSujX6LqRzfvVke0h85dCv/9JqR0BMM5FEdmtgAAo"
    "AAZ4/bWPXnhm0pTP5tx756jiKsNiET1W2LLrSDAYzMxMfvfN93fv2r54xbdJCXGqyhDG6CqC/1+GAJFY02ZDr7/85qL5sx98/HFq"
    "oFCwYuCNwwMB/c5bbwyHg+u27a2d5CwoC9w4oH+Hzt1ef/ulcBgsFggEKHD4HZ/cL8pHjHOXiDgBnUG5bmKEogSCEAgIbBL4Nfjq"
    "5OaFP67YdnAD2K3xrsTSnONxyfW6t+wxqtXgAem1AMCvAQIIUgiYmoPILhFkDJoGCvsZ+v/zWybOudWK/AFl4bwFB/fuTq+deduY"
    "O1KT4/r07E0w/vq7NYwySrkg8kceeHjFknlRMbH1GzZ+9Z0Ps7JSlTDHGF11sPnrECACNqsNz/1qwczPp1WUldZp0HjmrFkzPv/i"
    "i2mTm7ZoXVyY99CTz908uPe06fM+nfzR9v07jxw6W1RYPLhfZxMgEAbT4Oj3e4SXs4lyFtEyEhFiAAalHplUMDr98OqZ2xacP7ID"
    "mNmw7fXPXn9/m+TM6ftWTVn9SSj7BMSldr128AOdRvZOqkMN0CiTCGYcKGeM82qxnf8l+hmrHiP+NfgRAklEufmFd94+CiHSrEmD"
    "vXv3K6q2cOmyCm/VgB5d3vjws3Hjhnt9VBSJbrBTx48ghJu2aEowKMqfd+Tlb0UA4Jy7XSgYhoryqvjEKIcEA/sPjYmN+eyLaR9N"
    "/uyTD9+7YfAQQzcO7NuzZdfW8WPuOrhvzx13T7JZpH4DB0Z57KGQGSkT/V6y5r9YJmcigNOCZ53f9/aaKaf3bgAODVp2mdhz3M0N"
    "u7o4KAY4LHA84Juya9FXm+Yq2cchLq1ft+Gv9ZjQ0BZVpVFyJfXS34h+zsHhBEpBCf/svSEERIBw2HTY8R23jtZUZeE3S+wCnM7z"
    "d2ndoF6DJhu3rH304WeXLZ2/YfvehIQoRWGEYKsVOIdwiEdGYa5SwGD4ay2EUJWXcgYJCVFq2OAADpdLUVSLiB966O7vN29TwsqM"
    "aVP6DRx65mzR2u9WRsfE5p0/PGPalJsH9svPL0mMEqI9RBIR/z38r3+BS5MxJ8G6iO5aO/XOd28/vXttVrNObz746fp7Zt3VqCvW"
    "uFdnBvDyMK0luaf0unPNI4sG3PIECMJ3i97r+vFtc3IOxtkIMMp+kd/+VvRzSYLvVm5ct3aLRQZKKWcsIv1vt8L6dT9MnHBHSWng"
    "4L7dd0980C7AB1O+HDmkzzXXdnr0mad9QfPBx5+ULdZnH3+UMooi7YMBFgxWt+5dvYC56lUhrsBpjDnnlAICEETsdMd98tF7nvi0"
    "evXqqTpt1qp1917X9+3ff/IH7xUU5C1Ytmrk8MF9ho6a+uHbVVW+svLSbdv2pKRnRkVZTAMQvoIP5P8tHzAZ9UjkguYfvOCZ75dP"
    "RbFJE0c9+9mgZ69PqcdMFDTYxXMHYYQNzkMGq2113ty4w3XNe+UR8+S+TSsOfK+4Pd1rN0OUmxwuxT/8V0CHKxlzcM4dDvTisy/s"
    "3rF12IjhsowlC2IMGQZ12vDmzdtXL18yavTYJQvmapo2ZcqnWzdtuGfSIy+98vy3K75d/s3ykcP6WZxxRw8f7Hl9P4skMQ74ast3"
    "/xYh0K+eOrM78OIFy9569SWn015UUBgdl7Rh6/aC/IJuHVq98tZH48fdXOkzgsHw4D7dAKBLt14H9u3xeb2fzPiqZcsmoZAhCALG"
    "yDAo/HMzFcYYQv+0cRIhMBmNtpAd5dm3zXo87+C21Kbtp4156/qkOgEFNEbJZRrUP/u2nHPOnBJhBB7ZOX/a3FdA1/sOumtu30ex"
    "yTUG5EqCmxgDQkDNy67qLi5ZxsXFFaIkpaS4li39ftWKr1998z232261wJJFK15+/umtew4+9uCkxXNnPvfqO3dPvNdtAQbQtuU1"
    "rdt1mvrpuz4/YAEhANOEqx/5V/89wG+LiHAoyEaMHNyhc9dN61Zzxlq0aW+3wuQP3ktKShk4ZKDXTz1u8auZi0pLSpZ8u7FT2/o+"
    "jfa5ruvkD96bPX86EUTdAEWhMR6imxBpZ//Vjgt2O2YMVPUKsEAAlLNYC1lWcGLc9Ad8Z07H1G82d/zHHaNTykKmgImA/+nIDkYI"
    "EAkYjOj8k063AOBpX76w+utPB/oqFg971U6wYjLEObrsOyAEiqIZhuFyOSit7lgiArJWjy9CrVqxb772nixbuvfstmnd6nsrK7+Y"
    "NdtltWCMqWkCwPh77vv+22VlZaU+nzcYgNlfzqnyekePG68biHEGFHH+10H/XzAHuCIHvF4WH+sZN/aWseNHtW6R9eO+k/O++uLO"
    "ex+IjbYijErKwtOnfTxy9Lhr29YvqTIwIpJssVpkAdCcrxYN7tt3UJ9uY2+fcOjgSbsTs4heM6OMRl5MlmDt91uOHj0jiT8pfXIO"
    "jFIAoMDdEv664Pitn9/tz86FuOjXRr7SOSalVKEiFn6LyzxBmGFcGTTfv/bm3j1vAcDb1i++af7jAW44bdjhJpcicEapww7vvfXq"
    "fRPGMs4EgkQB2eyIMrZj+8HNP+zTdZ0gqKyo+OSjd+s3bLhq7eajh/ZPGHO7zsBud3AOfl+gXdtGb344ddGcL7u1u6Z/z57Lliz8"
    "eNrMVq0ahcLV7Qx/JfT/LQgAAIRg3eDlXlpeaYRULmBy+7i7Bwy5KRDkbgdesnChr6rqjgn3BRTmcovr1m4+uH/v2LsnzvhyyTOP"
    "PdjmmvZPP/+0xea4ddjAbVv32mzAOHO5SZSHRHmIzYZDYfW5Jx5cPO8ru7XaN4BzIATcHoIJWDE6FqgY88UDWm4pF/m4ARPH1mlT"
    "qlDpsllNzhnn7F8+JMQQMXT28YDHYxs1Q0jcvn7xvRs+ObTvxAfvTlU1jUQMDBBgBC531IE9O8tLyzmwSq/3yNHTQ/v1vnfcraNu"
    "7Hv32Nv9AXPM+DtVVVm8YGnLJrXnf7PqwL4fJ977kGixEQED8JDCbxo26PstP77z0ZTX3/5w2ZpN3Xt2DAbZVZ3p/n1zgCtWZmQZ"
    "JAlCISAEKit93a5t1X/Q0Pc/ftvnpVYbHnrDIIfT8f6UL65r27hRk+azFy2OdYoAcOddk7IvXFj23QpNhzXffrdx/dr4hMS7772z"
    "uNh7Q8+Oc5Z827lL60CAEYw4cF3Xln+zrF379k0a1j5SUdFv2tjS0/vb9Bmz9qaXuU4Z+lnQL8sAAJr6bzr0KGNOCe8oz77xk/G+"
    "CydG3vFCxzP2xx+758fDZ9LSEjSNcQ5OJ9669cBN/botW7uZUf70Y5MssrVDl+vumjBmz/7jE24b9sYHn04YO7xPn0EWi3X2ogWi"
    "CAcOnLx92OCMWlneqvK5S1YkpyaoCrVaiCwD4xAOg2lerTX+mhPgyimppnG/j1LKEAJVUXr3Gzh2wr2ayl1usmXzj7t3bH3oiWe3"
    "/rDBMAxAqNu17W4bPWHjlm31GzUtLszz+s3XX/7HxDtvo4Z++MCe0SNv/Wrm9KSU1Hr16+s6YIxMymKdeNfOH599bBJCSOeQZYvZ"
    "cNeMl+779PNej4omo4AvM8tgkgxTp3w+5aNPZCswxn7tm8QYM03TNE0M4NdZt4Ra0+74aPKj8z7tOaFR88YW2XLk0CFRBMY4ABgG"
    "pCSneKJjd27d3KxZw5KifFEiL7z8VExC0pBBPbp077Vq2WLGYcTI0T/u3HbmdI6uslYtG8xcsOTC+TNFRYUcEeCAEVY1XuWlfj+l"
    "lP+F0f93JECkRIgJwRjrOiSnJH70yfuZmbUNExTFeOPlZ9q273Bt20YH9u1Jy6j95bzF70/93OF0P/noU2+89HStrHp7du/+bPL7"
    "U6bPmzlj6sqVSztd1/2LKe+2adchMdGha5RzbrWgLTt2L/jqi6w69Zwuj64xCtAkPub59v1bxLu5jOHn5kiiCDu2bNq4bjUhjAhY"
    "EBC/SAPOgXPudOIEjxDvESxWTACVq3xASqPxja9DGqSkZXiioo8e3i8hiLQc6xpPTYtPz8g4sH9fnFvu2KW7pqqKAuGQSYH3Gzh0"
    "/97d5/Iq+w0aYHc4Vq9aYbfiqkq9Xdsm0+cufffjLxLio3SdRxo4CSEYE4TQXxsMAvyNF0JgGFzXGMKYEFBVs2Gjpr37DRAR1M6q"
    "u2TBbN2kPbu07tmldXmQrVy+wuV0Lls8p0WrawYMvr6kyrDbybCbb5n6/ptt2rbHqNqmQBTJqTP5+/f+iDG6Z/yYqZ/P8ES5p3w2"
    "//Tp09FRnp69+7Zs3TAcunixwAEDeKKigZlWhEu8PiII0TF20wDd4AJBgog2rN9xYM8uUZK69ujTtHmdcIiHTBbxC0xJjcqoVfvY"
    "0aNho9rRlXFmkUnDxk12bN3iU1n/gUMeuf+us2fON2iQqWnQoVMXgsmGtWvuGT+ye+++c2Z+NuHeeywWyetlbds0JWLTUPBvhwEM"
    "f+8VOQ0QQpQii8X6/uT3u3Xv7g3zITcNSa+VOXbUsG17Du87em7SPRMK8vNvHNjj+JHDbdu1lxFlnCEMZWWldoezzTXXGhQQQgiT"
    "sAIjRt6YXjura88+U6d9QikfeePgd1//Rzjg27dn9/BBfWZ/Od9mRxfTZU4ALBZLZUXFg488O7BPj37dO0+6Z5LX5xcxY9x8/KFH"
    "J44fffTokQ3r193Yv8eCeV/b7QgYEIwBOEHQtHnrU8eP+Hy6IODIWA4HaNO+U2lJYXFR5XXdu0uSuHnTeosE4bBRp25S42bNly6c"
    "F9bYrWPuvO/hJxgFzgETFFaY30f/hgD4uxPg8tPANCEUYpyDYYLb5Zg5d0FaevrEOyeMHDroyKEDiQnxGqWCKCKMREw453YBb1q/"
    "NjW9VmadNE2JxMpcFKC0uCr73Jk27TvWrZU0fdrkk8ePLluzYdq0D79ZtvCBR5564YlHTp/KtdowZ9XtFlEe154fd1aWl38+a9Zr"
    "7330w4bvn37kUY+dLJq/ZPmShYtXfb9g3sy1a5Y/9MQzLz/zRE5OmWzBjDHOASNo3faakuKi3LxcQlj1ojQ9LdUwzLKKyqQYS4fO"
    "3dasXK6ZgDFGnI+8fXzjZi3DBm/evNGEu24VRYFxiLTH/Tm1O2sI8P/KgYulbqQqPD4+7tPPJy/9du30uYvXbd076vbhQMgNg4ct"
    "XTR/75Hz0TGWzbsOL5jz5bWdurjsgkkv7ugilJVXBEPBWhnpOuMb1n43ZNiIZvXTisu1sM5vHH6zZLHs3bNHEoBdnF2kJk3PyHxn"
    "8tRmzRsP6N3phVffXrdm5cnssh1bNzVo1EgSjaUrN82Ys9gfCBYX5W9c/71Njtw9I82AJs1bCKK0ZeNap4QFgVitopWQM2fPEUJc"
    "DgcC6NWn/9Ejh86czrfZSCDIBwy84dU3X0ZAdI15vZTzv/tDF2pwf2UyYKTrXNN4bLQrKcGlaRAIUFHEd9595/lzp2+9aVBGZlZp"
    "cXFxYX7nbt0vaXBxzkUCx44cstkdicmp5T6qKGpKSopOKSaYMTANQxTEUDDwszoP5+npGS4H9lYZpoNkZtW1WCyHDhwEgLOnT427"
    "bZxssdptNpfLOfbuifXqN9QMiFi1Kgqv3yC9R+/+Uz94p2nzFg0bNQoGfBvWb3jluSdH3DaudlaiN8y697p++pzFcbHRug6AsGFy"
    "3eAYY4QxqXnMNQT41+kBQkg3uKZzjCMyWyCK0vuTPzyw74jXW8E5mT/7qwYNGuv6pbEyLgCcPXUsJja+fv2UYIgTgsNhRSKEMWqz"
    "oNKyisrK8voNGzMOCKFIv6goiiY1eXUfG0cIUcaioqPdHk9KavqK9RuBCy4nYIAVq7ZEx8RRWt3rhhCYBnvmpZfuG59727BBySlp"
    "wWAAI3TX/Q9PeuQR08TU5G6nvXuPaxUFKKuelP/LF3ZqCPD70yBSlEQApsFNg7e9pinBYJjQpWtnxsAw4FJVhwJERcedOXH0vrsm"
    "vf7O2/0G3vjV9Gn9Bw1u3qRueVXw9RefzqpTv3nzxqrCEUIcAQNwOJ052dmFhf7MFBcCOLR/D6O0YcNGwV59Z8/4bO13a4cN78cB"
    "Pv987sQJty9Zub5xo3RVY4SQiKlMamrigq9X7N27r7iwMC09o07drJQUTzgE1ASEkEl5IMDwlaYIalYNAf5362KfMQoGGAAHhDBC"
    "lzfHYEKCYRg1eiwAP3PmrLcq/PjTTxXk5466cVDdunUKC4sxIe9PneZy2cLVrkGIA4iiXJifM+nucWPGjy4prnjlhWfvmHBvTKy1"
    "W4+udz/w6GMP3PXVzFYIwYkjR15584PefbsFgvxSwooQ0lQuSWKPHu0RAsZB18DvowjjyMh/pKZf8+z+6Qb3d2uF+B0+sp/9dqXC"
    "AganDQDAHwKEQJRg395jRw7uj4uP73xdd7dbDF8cn2WMuZz4qy8X7di+rWnzFt8smo8xHnTjzXfcOZZRDgAWK9rz45G9u3cQIlzb"
    "sUvzFnXDYfbr0sWlhmd0cUX4WvNoawjw/43+CBwZowBAiBC50rXZkESAwpVbazgHhMFhh2AQEAa7DYJB4BwAAWfcbkcyAQBQTPhf"
    "u83VcKCGAL8z+tG/wH31XvwTDy7VeVi1Oii6qM6J0aX0IvIfUMYIwcDBpPTiFs4Z/6lBCCN0ucEEuuzdXMyJUQ0HanKA/zruefWN"
    "K+c//RECAIFgQUCYIELg8m5PBABAfpZIABgMTAqUAqXAGZgmAwDKAQFgTAQRMAZCQMSA4Jf5K7/sC8aBMmAUTBMojVwt8EugR5c4"
    "9vO/WLNqCPBbYwjOObs4ZYsQYIQkGYkiIqhabj3yogx8Pl5VXBEIhoLBoKooiqqXl5d7K8qDwYCqhkPBgKFruq6bhsrB4BRM0zRN"
    "wzQMi0XEGBjjoiialGqmTrAsYBETghBgLBIiCaJksdisdofVanM4XO7omJiYOIdNlmWLw2FzOO1R0dFuNxYFiFijRSBvcjBNMHSg"
    "jHF+6VBCqKYYWhMCXRnsnEfqnRhjjJAogiSDCMAATA6UgaJAYWFZaXGJ1+urqPIW5GWXlxf7KiuUsFfT/FwPSsSUCBUFhpHucUt2"
    "mcgWW1y01WIV7E6bBRMsSISARRIwQojIjIEkCbIInFPgJjNDOlVNXWcmYoJqIo0xzJjJGJR6qwIBIxRmobDh91NNMw0DU+7Qmd2k"
    "EmMOSXZLksPliY+NT05KSY+NiY6K8sTGxSSnJrgcgAkICDAABdB10HVgjDPG+CVC/C0p8fclQHXLMWORRmJCMBHAIoOIgAGoBmg6"
    "FBZWXDh3oay8vLikOPfC6crSfFWpxDwg4IBL0i2yHhdtSYx1piVYXU7BZrfZrZLLLrtcNovNiVFkI8aYyIwhghEiHLAIcjSYTFF0"
    "BIghyWaVQRTACANnwHUj7NV00yJpgkUGKaTTMDUQJiYCDhAAYBgDgB8AcQhyrpmUeP05oZDi82mKwn0hWphvVvjcZRW8ykuCihxW"
    "XVjIEKW46NjkpNSs9LTM+PjYtFppqalxVgvIEkQEgzUVDBMYY4yyS+P/fwdK/L0IUF0sZBxhEAQiELBYQATQOARDUFkVPHn8dH5+"
    "QU7OhdwLx3yV+cwotYuVSVHgdtKsDHetJOSyiU53TLRH8jhEgWAOMiYiAFU1waCyzYooA1VlSLCFVYoQAo5VKkoC9gbMQJAGFLOy"
    "So32OFo0TjRMZrHY9x/OP3Wu1OMUGTcJQVnpriZ1bDlFvh17C+0OuLaty+URFVXDiAMEOWcm5QgCmCBRVDgYnCGXM1s3VEoFp4Ni"
    "ESmawBkXBCCEV3mNKh8LhbHPR3Pz1DPnwOu3llXYg+FYQGk2Z1JG7aapaVlpaWn1GtaNj3PZbMgmggmgamCaQE3GWLXc51+VDH8X"
    "AnAOCLggIlkCCwEdwOfn5eX+Q4eOnDt3IT/7dGHOIVUpcpLc1Gg1OZnUSoGsFNHjTo7yWJ12iSBAwBFiCNtAcKuq6QtQnVLTlIor"
    "kKLSOhnOmCjbqk3FomQJBLXsgtCDdzSxyOKaLYWvTj00+/2e9zy3ubJKj4mWlJB+bduMZx/oaprMZnfMWLhv+ZrDOXlVsoQT4l33"
    "3t7KJmoPvrorIUYCDuEwe/O5xu2vcQaChsupbtpZ8cwr+RYLki3INNHdd9gbZOEZC7UHx1fUTvXuOuD2h6S2LXwWK+g6DYdxVBQg"
    "ImsatVlBFHWEEAde5dX9ftMfRNk5xrnzUFxiLSq1BIIpHKXEJtSrldk8M6tOk2ZNEuLdnijBSkBjoBtg6tw0q7Vh/kpkEP4m6BcE"
    "AEDlFYHTp3MOHjyYff50ae4BXc1zkew6qcHWiXR0W0hKALvVGeV0AUKGyS0SpsQaUrFp8DK/4Q3gvDKSXVR1LrfSr/BJtyQ+8Oa5"
    "QAAEjINhGu0Rv/643Y4DFfuO+Z6c0OCBl091uSa5W5eUtVvznDaUECUXFwfH3NRgwsjmlQHRahU4B4yRqpqjh7e5c2TboeO/qpvh"
    "ef+FXkWF+b3H/NC5dfyHz7Vngjr+yR0vvHNi1Zy2GGOBoJJS0xc0P/0gHSgrKlES4lhGGlr/g2mXLSOGeEaMd0y6W+t5HV3+Hf5y"
    "rtMXEOpkavfdqdarIx49rlOKoqKIxaLGxGCMrXFx0LixzTAAYzMYDAWDp6u8Jw4f+T43Dzauci74MgoLdeKTmtXObNa4abMGDevE"
    "J7hjowQKoOmg6/CXaSMV/gbo54KAfL7AP55/Ju/sdrtU3CituE0Sq98cMjPAbgWnHVGGNZ0bJudcLPciQAwhPncNX7270hfUh/eQ"
    "O7fxPPS+Nxigp3KUHh08N3T0SBKczdYevj3rgftqbd9c1nPMnhPng80butfvLOnbNbFr+4Spc4517pC+90TVjb1qORzWxHjH3GUn"
    "t+wpLqsMd2qb8eoTvQJBDRPQNQNxwhmnlGOJnDrvCwbMkQNqcY6IiAb3SXrutdP5hUpqqgUQ6DrTNZi30OdygNPFmjeWYjz8ref1"
    "Z16B1Rs8Q27wPjEpuGWH5f7HLaNHGv166S++Ltz3qGPHuvCX89wrvxNqZRgIkeRE8o9ng0WlUFxCO3fCpoExlq1WcLpQ3bogilwJ"
    "G+FwUWFx/rHjG7Nz5QVfiuFwLauzUUpqm0ZNGrZp2yQlNZ0I+K9RVf1bEECWUXZOcfbRRR8/XJKUCLIECJCiI13nugFlVYAQw9XX"
    "VAAIPA4093vx9ZnorYdcp3LNRRvD7VuT2a9EKxoZOLG4X2f37cPjS/L0Oum2NdtKs4sDx88og69PbFTHeS43EFZYWYU+aXSjMY9t"
    "mbPktKawLm2TTUoJos0apz40tplqiLFRVsOg1XEEQpFCDCDgJnVHuwEL3qDpcMlgpeWlzGoRoj2SYXKCIRQChwPXr2fJL9YKSiCs"
    "ImbSzAzsD7DEBPW5RzVTh8UrPfXqhF54IiBL0qfv49PnLYGgeeasNmRA4NFJysnTzvwCHBsLM+Y4165nPbuFOMfAGaWIMq6qEcME"
    "EROhVm2hQUOMMVUUqoTPHDl69Nz5Rfu3N5k5LaHfwP6PPvmQ30//AjM0f4cQiAsEKiv9qXFmahIKKBBSAAAwYggBxiBgAEAXPwoc"
    "sV9SNSGs0MPnVZdDv/dmV4oHY8RcHhLtYoePh3UvtdpwYrx46ozWoXXMwRPF44ZleOKtsbEyQux0TmXn9nWubZ389Nu7stKdqYkO"
    "zrFssYY0SikvrggdPlXeq5MQG2XTGRAAk0JppVo3w2XotG6GvWv75CffPmCaPKxqb31y+rZhabGxUnmVxoAXVagOGxrcx0aIXZI1"
    "WVCLq6S7HhEyM8LllXjLDmH4CDM3z8hIF21WuagYpaWZ9etr585byiukzdssYdXqdgZuHKTJEhw6xJs1M4jAuQoXpRkvxfacc9A0"
    "pigcAGEsEEG49lpXp47l7vi+n8647sCP34t/lUmqv7w0IgAAAfB5fQ6LIsvcH0KE/OTvFalUXnxxACCYB0Jwcy/NMPgPB3hIw8fP"
    "VY7s43l+go1xmp4i5ZWYisEdVhzvFvNtxrMP127fzD30/j2azsbdWDsQpPnFmijyccOy1m7NadciLibKopvs2msyvlt35tkPdlkl"
    "AQB1aJUSH+sAxjkgjKBf91r1sxINk5u6+fpj7abNPzZrWTZwuGtMyt2jswJBUyCgqdxuwTrlN44rwJirGn7nBdu7n/hMg367SH/h"
    "Nftzr0f16lFxbRvzq4WOM+dDUR7tjnst3bsY13VCPr/z8YdCiCtbd6ILuah+PfHsBev1vQ2CCWMI41+4RaHIWAKpvoPmnEMwSE0D"
    "iM0MhYMudxT8hzaDNQT475X2f8p8gTMASk1qcn8wKIiXCcb+1KpAftFcyTkIhFcEBKuFT3kCpzRMfuj5ku+3B56b4BAFVj9L/nyR"
    "1xfUHVY5Lg5LFuIt0rq0ti/5oO13W8sYY68+0qBxltvv1Vs09Gyc08fjsioaNSkdf1OdO2+qK1lEi9WFAfmDejisIyKbwIDyJ+/p"
    "ahpGMKwA5ZKInrqrAeVNQFKRGA4EKAeGAMIKmzAq6ebBMZoaMgyu6kp8LLv3Dmfd2uVWMfDAOKYqlmNH0V1jvAePGjePsUmSNRTi"
    "D9ylb9luVlRSt1Pv2N649RaBELTrR10gWof2IVm2SiJl/PK+DX5pb7jsfwLGiBBOCAr6fRab9eL8Pb/aiSBcvSjnF81JOecYIUwi"
    "8g6AERABBAERFIE2IQBVFSVxboMxBIj/yg3+V9sZxrqhTltMpiwJ188sPHZaHTvEgxFVNd6zlVUCm0SwL2je0ifmpl6yYbKKKrNd"
    "c+d17RKDYeP2gZm6ASblsiQ2rBNDKQASrRgJBAMwhAUgIgDERIkIcSBW4AgATEORJeRwYG4CAOVUFQFAAi4KcbESAso449wEYMlY"
    "5sCAIwZM0/SsWqAo3lAAYmNCU98KeoNE1YSP31ROnNJKysw2LYWkJKGySup/vTL1CzL185hACD3/RHlZuVRQZNm9x1NQFGxQDzxu"
    "dBkH/ulpGvlVCYejopwCQoJAMEacA2OcURZRTb00cXYpnPqT10yFqwLul/rdMUJEIIREesWQKFRv4AZAWAFVpZpm6AatqgqUl5VX"
    "VlQG/EGf14extnn997d1RCbj+MrGkPzyqMkweHIsWT1ZWr7LEwoYD4+0N8qyhlVGGcvKsDZr6A4rDABi3RIRLACC4BQQkjAhLgeE"
    "VdMwuMF1TTMNgxsMl1eEFE0sK69iHAWCmqoTg5qGyTkTGGAECGGsmZpBjYjkP+NMQkwEk2EdBEYwJ9iURCxKuiRhq5U4ndRuJzHR"
    "PMphIAKyRC0yJ4KoGzQ6ijMOlJGO1wJwMRgErx9168I7ddC8XlPTaXaOlprKEuLxpHu1rdvN/ELZ4xHeesUXFysZVxA9vwJ2lXDI"
    "4Ywq94aCYZBlSZJE2YIsIhEjPVGRnhETKAPGIt1+lDH+Ey3+ReNqDQEu39SBA8JIErEgAsFIIEAATACfH3y+oKooxaUV2RculBSV"
    "+LwVPr+vqqJIDVeZWoVhVllkhaByt1P3uKndgew2pgZdCBMExpWgzy8SgPNqrQauaECwcev1oiTaTZPrJnPYsUgwJqJKEUMsFDRC"
    "IS2sKnnFZkGpv9yraroUDCN/GEIKNkFUdYSQLFudhIhWu0UQUyxWu9XulGWLxS4SQjAWBYwEQcCE2KvDDIwwiciUU8oYZZQxxkyT"
    "0ZBmaiFVKQsGA15dCxuGauphqgc5hAm2SJJus1IRl0V7Ana7Ee1hMW4tJQ3HRltlK2cUe9yiO0Pg3KxXF4cVzLneqpUeCLFgAKka"
    "dtgFw2C/8kdDv0ynEOKc+3xV2zd8svuHuZRJSLDJVpfdGe10RdsdDqfDHR0bEx+fkJKWFuV2yLLscDrdbiID0Mgr0rVqgmHSS315"
    "8Id6CQt/DsRXxzWSSEQJiQJgBARAYVBSHPJWVZaUec+cPFaQl1NZUVpZUayGqjgN2EQjxs1SEki8W6udriS0RYmJZmJsniCoRLJg"
    "QZAkKoqMCJLVJZzLMUqqZEIM/lOYG3kDlF90+uUAosBkCQkEYQIYIYrMwjLT66eqSvPKyOmcQGm56VesXkXWDCtldsnqsDtiPDEJ"
    "CSmpCQ5HltPldrs9UZ7omNiYmCiLJBCCiYAFAoJQXXHCl/dG/7y3+dfQu/QFA2CR/dWsbqI2KVCTmSb1+kKVFRXlZeU+byAYCHp9"
    "3vPlRftOFvi+LzENL+clNktFlEtxOo3YqHBmJtRKF61W6okWYmJkhx1xznQdDAPpBmKMo+o5Sh4ZqLz8LSEAjCAUMp68Xe3ViVf4"
    "whVh7PeFKn35Xj8NqThUTs6cYXuDUOnXTSYhwS5bozzRCU53dExsQmparcysrJhol8fjiY2TJAQUgEX6VQ0wDBqZuob/3868P4YA"
    "FwdEkCBgiwUJpBqVJaV68bmivPziE8eOFeRd8FaV+ipyCPVZZTUuxpWZFtu8sRwXF5ucXC/eAxIKCRZFcmgEK5RVmtRvGEUmVRm3"
    "UBAYExUFhcOUMnDp3GJHXsWGURA4MAYcEAIOCNlkkMTqAUWMULmXn88Pl1TxU7ksp1AIBAqrtChKkong8kQnxyWl1+pQOzbaExMT"
    "k5iUmJSUIEtABBBFkCImu5F9LnL0m8B4RN8TTIMbejXR+RUuUdG/jsp+yttRxDUDIYQIBkHCFhm7XZ7M2h5CsggAAeAABoBJwTRA"
    "06Gs3F+YX1xSXFJV5c3JPnViU7bfV2ToOZJQHOX2u1z+Zk0gIx2ioyAl1WK3iYwhxkHXsaqjS+/04uQzAg4IM4tMrFbJRc3YGDuu"
    "JQqCTRBtWLByJBsmMSk2qEhBLvdphYVVpUV5lf7TeYWVmw+Evg0h1bQhMc4TnR4VlZyakdmgYcOkxLi4hNjERFlA1RMOug6axjir"
    "Nqf6r/JB+CN2fbDbsSgAZVBSRg8fuZCbV3j00P7c7NPeqlyZltkkX3KC1CLdntzYkZTgzqxdT5IsRJAFycORbJjYMKmp+wyDa4oZ"
    "MFVgCoCOsBmx2AJAHPFIsosw4ghEkbsc3JuDIw0IDjsIGBgHVeU5BVDihbx8fvicWBGKUYx4jaTZnYmJSbXrdG6SkpyQmBCfmp4S"
    "Gy0TAgSDcLE12jDAMCJnOleV6qmB6uGuy0Ldy9CL0O/nLhHhVeQrwwRQL6rpRv4xDJE5GIGgtBRXZi2XiOshAAoDKAPdgOLiYF5u"
    "QVlpeW5uzo6Dh1etv6CEzljEkpjoovr1eP26JCmJ1sp0SJKIEKKUqCozTaAMUQYEI4SAUm5SznTGgQJoEBnBxwwhEWERERERkhjr"
    "SU+KFiCeQNAUfSZTOfdW+X05+XnlZXu9AeXEWcu8raZuRmtmotOVFZ9Ut36jZlmZtVNSEjNqx1hkQAAmA00FSv8qJwDnXJTQ7h+P"
    "bFy7urgwO+w/Gyo75XZ4M1P58GviEmKddTM8TmcSIAETGweLYSKN8rBCOWgchYCYCIkII1Q9JQgIX9RlqC7qo19ZKHKEwGHDVZRa"
    "rZBTyPYfg+IK2HPKWlQerfEke2zjxKRa9To375GVmRgfnZ6eEh2N0cV7AYOCroOq8ss3bwToMoGdyA71B90M/fOkMlIG1jSuqhfp"
    "Uv2uUWKCIz2tvojrc+jIYaRuQl6ev6igKDun4OihvQdWnPdVHZJIUbSnpEljPSuL169viY93YAR2h8i4gS9+3ugS3zGCyOtigZlz"
    "bhhU1w1uhoGGwaIBMREwm0Vs3tghCibGxykLMiQEQ/5z2WeqqrbmF8Kh3eLWNdFBJY6IdeITGrdo07Zpk8z02plul53R/0rF9Q8g"
    "gEDQ4QP7vprxuQhlN3X13fMw1KprM4JOjUoMXKqm+4ImAs6RhjFCmCBBihz71R/xz5VIrhROoJ+PMAIAivbgeYecd77uyC9xueNb"
    "xiXVadqz6S3NGifGx6SkemwisAjcTdB18PvYpUnan4UdV2HJ+4rvOyJ6V+0nCQhhSE5y1cpwdepUH4/qTgHy88NFhSUnT509dmjv"
    "zgOHleBpWcxr0pA2bHakvFyWrRbG+L+F409PDRC/OCRKGQ8rDHhETQ8xhDEWG9R3iIIfYTYKg2GW5xeUhENHs3OXLV8JLz/t9MTU"
    "njzti46d2waDv79Vxx/RDs1BtoDPFzyw/9CKb5adO/Zd56a5Ywc54qJdvnAcxhyL0QAEkAVhCyACxAYgARIAOwDLgERACGgATD8I"
    "QS6FgYcBvICCABUAFziIDBGOBAAKiDKOLVZ8+gy7bZx93P1T7rijvyhaou1gApgMDAN0PTIXVR3AIIT+Krec//tqRGTQGYEsE0mq"
    "DvkCGhQVek+dzjl38vC6tevPnlyz7H17SkKqZlAsRAEIgGSELRB5gQhIAGwFbAUkAHAwvcCCXA4C1gH8AAogP4AX4DQHwpAAgBkQ"
    "zsMcqMEEu43YHWTv/uCKlUJuYcu02t1atul8XdeuDoeDUv67b0J/zDwA50wQsMUCCMPRYwUzps8+tv2zWwfoI2+oo4QMiqMx+g8J"
    "gDkSIyVpAEw5drnx3n3Ki6/WfeqlOdf3bFFSoQmCcHmCVSMT+6vrl+rqHMYIYxxth7P5lRPvHHNrp/WDeiYrRhJCDMh/QoCzHAhD"
    "GABzRDhXGWfuKOHoMeWjqXK5r2ffAWP69O9bu7YdIwiF4L8UAv0xkStC2DS5388CPtqgXsrH7z35j49WLtjeZdIb50VZlEX0f/Vp"
    "51Ady1xe4GcYM5+XtW1jf/m5Ey8+0efz6asSYuRLYc1PCWXN+lngFJFMJ5Qytx2+27hvYK+uI9qvHt7HHVZ+r2y+Ol6N2Ap63Gjm"
    "l8oDjzVt0/nLeUtXTrr/ppQku99HvV7K2H/rVMZ/4EdMCMaEKAov99LWrRqvWT3PmnrfqCeLggr6P3ebV888MmCseuibMk4pIMQr"
    "KsxmzdxTP/bP/XL0q69+4XYRhOBfujPWnANAqRntEb6cu/65R259//7jw653lVVCJFT6vTYODkAICiv82X9YNu+5c/rc1Q89MIJg"
    "VOGjhsEJIf/Vpmvhz7DZYAyyCEdP5JSX5FmtJBDW7RbLv658VcuVMM4ZRxdLHBgzUeBYYEgARBBCDIAC4hxVG9wapt60sfTN0sD4"
    "8RNfej749POTwmGGakwS/nmkGusWZny1Yv60CYteq8iqBQEvj3IjxhHDiFJgGEwaMWi9GDIBB8QRcIQ4/Hsb5IguAVjsbPE34pxF"
    "dZZ//2Sz+ilFlbogiISQ/wdVrz+YAIxxgsHlJDO+WjV98gsje/vufiw9rImGyS/VFSO5GUccgCPgCAPGSJZF0WIhMuUSZdTkXOCA"
    "QqpU4bNVVelV/rCii1VVuj8AVV7q8xuhINFNwWRRmopsdidD1rmzPqlTv9bwEYNDQVqjlX+lR8MsVjx12txnH584tr93/yHYfxRE"
    "ISyIpt3Grbag0yk67eBxYUIwFkQsSIhYEJIARJPLJhMNE1NGgQNnnNGLj++nGl5E5JRjzEMhfNNg7nKeemxivyEjXnxg0ghFBUNn"
    "+L9fXP4jh+IZ45IIgoiefvLNI9vf+vDJmIZZyeVVBhaiOWAACxGsCBMiOSyyXRQljh0mEygnwbBaUFBUVJATUELlAf/ZnKoqL1UU"
    "0KgDiAfAKluiZNkty06nK8rhcjmdrtj4xOioKFkUsUAIkZxOi82ORFGOj4+tSQD+WRFT04yF8+f6vBXBkOnzhkxdMUzVNFVND1E9"
    "yMwwYYaIw5xrVgtz2cWEaHtySrTLSlwuV1x8YlJSlMtuwcwnYIXYQhRpplGl6UHKfJxXMXaSg8SxgHEkCVZcbnbuPH35DckaNfHt"
    "D1522q3BEIuY//0FCcAYlySgzLhz/KMJfOHL9yKEXaoZL4kgytE2i4wFm6ILlCJvEB07U1FSYRZWoty8QElFmIINBKfNEeV0RDvd"
    "Mckpaam1MhPj42xW2eF0OF1Oj0e2yj+dvz9pdAIAj4S2wBhwDoZRA/V/tRyO6g0bX/ZhBkKghPVgMKSoSjis6rpWXu4tKsgrLyvx"
    "easCgcqgv0oJVjEaJFx1WM3EOHtmOo+OZXFxLKuWFOVWRclnkU8xjlRD1nRkMkJZyDCY3SFZLOz5f+j7jw+cNuOLjIw4v58KAvmr"
    "EYBzLhBOOR19+0P17NPff1zWdQsiUWE9JqzQ4krH/uMVJZXCyWy9KiCA4BGssYnJWXFx8anpterUqxcb7Xa63DGxdrt0sdADkaz3"
    "YqOYydivCknoV9q2NQqBvyUQ+kXzEgIgJNK3CgQDxoAiv0bGSQE4QFAFb1XY7/eHw0phUcm506dKigqrvBUVZTl6uETEVQmJRkZS"
    "WUK8NzmZNagn2B2y0xlGGIUUwTCwy00+/Ty0dEW3yZ9/Vb9+ajD4XzwH/gACcM4xAosVPfLQ04nsvcfHaCfO4L2nHSVllrMFjrJg"
    "lGxPjU6sm5ZRKzOrbv36DeJiPR6Py+MABGBCtaasaUZQXl0e+8X4RQ2s/x8e4j/7AoATTIiACIFIA1XkQk0H8Hp5wB+oqAqcOHbi"
    "wrnzFZVlBbmH1FCOTc6vlVaZkqQ2aABZWWC3C6l15ZWLlLendPt81sKUlJhLjgp/BQIwxuwO/NbrH3/2wUPjhtoOZccbkJlcu0Vm"
    "VqOsullNmjaKjXFHeQQLAh1AN6o7yE1qAvysd7wG5VcBQ/hPPbCXhpmEi/2zBoA/AP6Acv5c3vGjJ7Kzz+RnHwz4ztotF1KTy9u3"
    "Yzt3w9m8EV/Mmi5JFsb+K8f1H3MCSDKa/MHkqqqqOg1aN2natG6dFKcdWwQwADTtp909chuDLtvaa9Zf5NxgjFX3wxNCQBJBFoAC"
    "hBTw+/QjR06eOnn6xJE9vqoTu3ceePaVD0aPudHr/a+osPwxOQBCIMsgCCAiUAzQNIjMPqGLHhA1cP9bseJSpy0hmBBksYCEQWMQ"
    "DEJuTo7H446J8Zgm/4ucAD/92BFtboxxDdxr1i/5wBDCGGNZjkQE8F/CyB92EYYQQqTm+qlmXQkYCF2quyoK+6tNhNWsmvXb1+8+"
    "APDL71/zEdesvzXBaj6CmlVDgJpVs2oIULNqVg0BalbNqiFAzapZNQSoWTWrhgA1q2bVEKBm1awaAtSsmvVXXP8DIFZKrton/5YA"
    "AAAASUVORK5CYII="
)


LOGO_BANNER_B64 = (   # centre banner: Dr. M.G.R. Educational and Research Institute
    "iVBORw0KGgoAAAANSUhEUgAABBYAAAGQCAYAAAAa8+PIAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUND"
    "IHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2Afk"
    "IaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAH"
    "vgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBb"
    "lCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc8"
    "8SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G"
    "/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5n"
    "wl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k"
    "4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCB"
    "KrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRB"
    "yAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3"
    "GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXA"
    "CTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTS"
    "EtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQR"
    "NY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+Y"
    "TKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2ep"
    "O6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H"
    "45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acK"
    "pxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6Vh"
    "lWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFos"
    "tqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6T"
    "vZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsb"
    "xt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3"
    "qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5"
    "QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1K"
    "NSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAq"
    "qBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqoh"
    "TZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2"
    "pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqG"
    "nRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/"
    "PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPS"
    "A/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtb"
    "Ylu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy"
    "2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn"
    "7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suu"
    "FxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz"
    "/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgACqMpJREFUeNrsvXecHVd5//8+Z2Zu2V60"
    "6l2yuqxiW+6W3A0YbHrHIpQESIJCCCkksQgJCfySoBACX7oMhNARzRgXLPduFXfVVZdW2r63TXt+f5yZu3dXXdbKkjWf1+tqr+7e"
    "vWXmzDnP8zmf5/MoESFBggQJEiRIkCBBggQJEiRIkOBEoJNDkCBBggQJEiRIkCBBggQJEiQ4USTEQoIECRIkSJAgQYIECRIkSJDg"
    "hJEQCwkSJEiQIEGCBAkSJEiQIEGCE0ZCLCRIkCBBggQJEiRIkCBBggQJThgJsZAgQYIECRIkSJAgQYIECRIkOGEkxEKCBAkSJEiQ"
    "IEGCBAkSJEiQ4ISREAsJEiRIkCBBggQJEiRIkCBBghNGQiwkSJAgQYIECRIkSJAgQYIECU4YCbGQIEGCBAkSJEiQIEGCBAkSJDhh"
    "JMRCggQJEiRIkCBBggQJEiRIkOCEkRALCRIkSJAgQYIECRIkSJAgQYITRkIsJEiQIEGCBAkSJEiQIEGCBAlOGPbxPHnqxEln0ndT"
    "0U85ynMk+ulEPy3gL4DRwDeAtRgCJhX9vhT9jRX9PwSCitccCdQA+4HuQcc5OMrnOS2wqXVrcmUkSJAgQYIECRIkSJAgQYKTTyyc"
    "QUgDdYAPdB0mmc8AVUBHRARcAzQCtwPFiDSIFR0TgDcBtcBK4AAwHRgGtAIvVbzuddHvfgqswRAWF0evtx7oTIZdggQJEiRIkCBB"
    "ggQJEiRIiIXTE1mgADQDV2HUBT+JSIS5wK6IFLg5IgBGAssj4uENGJVCPZCLyIWYkBgGTANmR0TCPuAdwGXAb4DPAwuBq4FLgAeB"
    "vdHfTgT+DpgRPf5t4A/J0EuQIEGCBAkSJEiQIEGCBK8GvNo8FiYCt0TJ/R6gGqNKeDfwBWBZRDjMB4ZjlAqXYUoUHsMoHc6LXquy"
    "bKGAKWtIR6TFuUB7RBRkI5LiJmB89J69QFv0u8UYlcLXMCqKDwMNydBLkCBBggQJEiRIkCBBggSvBrxaFAupiEDIAu/ClD98GaNI"
    "uBijJNiBIVJeExEFayKyYDhwPsYrYVdEHjRilAtEr3seMAnjm5AGxgJPYZQLV0W/7wXujl6/NyImMsDl0efaRX8ZRAhMjj5nV/T/"
    "BAkSJEiQIEGCBAkSJEiQ4IzDmaxYiD0QGoA3Ah+MCIE+oAmjHmjBKBJSwLeAh4ERGO8FC3gxIgCuiAiANJCPXtcD3Ohvp2JKGXqj"
    "v6OCOKjFlE30Rvd7MWoJos8xIiIllkW/W4nxYPiTiARpjt6jmqRLR4IECRIkSJAgQYIECRIkOMNwpioWhkWJflyu8FaMh8LPgYei"
    "RD0VEQczMWULl0UkxN4o8T8X48FwAGPgWB0l/M8CLwAbMYqGLuC3GNVBDnge47OwC6Nm2ApsBt6C8V14Kvp7G1Ny0YVRR1wLPA5s"
    "wpRlTI0IjueizzEhuv8MZ0DniAQJEiRIkCBBggQJEiRIkOBMIhYU/a0dwSgU/ixK7r8MfBXjcXAh8DOM6mAxpjRhFMbA8S0Y88Wv"
    "AT+KiIMXo2S+gFEiVGG8EcLoFif4jwFPRkSGxnR6AKNYeAyjbEhHhMPT0esOBxYAO4EfR2TIcOBKjBHkExHRsQg4B7gAWA18OiIw"
    "EnIhQYIECRIkSJAgQYIECRIkxMIJkghVUbK9O0r0BVPW8Bbgzihhfwr49+g510eJvRsRCWGUtC/EKBiewigNqoHtGIXC/ZhyB4me"
    "rzAeCIdK6AWjLiAiF4LofqniOT8Dfh19hgJGMXEHpjRjV/Q9JkffY0f02B2YThSjgLXALyLS4Z3R9/pp9NwECRIkSJAgQYIECRIk"
    "SJAgIRaOERIl5zdidv5fihLvEqZ8wY/u78N0dZiFKXOYEJEJNcBdUdLuRK9xoIIMiFE8xPueyGeNkYtuMfowKgc/et73MMTGxdFt"
    "NKbsoiP6Pi7GbPJNmJKMizElFnHbywPJcE2QIEGCBAkSJEiQIEGCBAmxcHg4GKVCN0ZJUAMsBR6Nku+pwO3AEoxPQR3wmSghfxBT"
    "0kBEJDwF9GDKFl6pjguVyob4c4HxXOis+J5XY0weezBKjEnR93UicmIm8HpgQ0ROFJNhmyBBggQJEiRIkCBBggQJEmJhIC7FtHxc"
    "D9yLMWLUGBVCG8Z8cXiUiI/GeCjsxpgwWhgPhb0RyVCZzB+SVFBaHZs+QWGedwJaBqn4dxA2RzcwSoyLgfswrSznYMiVjRhCRTAG"
    "kFdhyjruxpR8HIiOSeLDkCBBggQJEiRIkCBBggQJzmpiwYoS67/C7NpvwSgVrsb4EdyB2d0fhykruAVT7jAKo174CsYUcUCZgFKH"
    "ZwrCUPBKwRGeM4gd0KB1RDIcB0wvTAs5cu6/B/g3DGEyIiINpmN8FVoxLTDHY/wh8hiDx9diSj1+g1E9JEiQIEGCBAkSJEiQIEGC"
    "BGctsZAB/g4YC/wzxsDwBkxZw3nAA5g2j+/BGCNujXL2n2NaNzKYVBABkUMn81qDW/Lp6iwasuBovIKATkG6Fpw0hMGxfSkBbCzS"
    "KnsQsaAOZiji0obdGOVFB4ZgeRfGk2EYxujxAYzvxEyMimM7xqOhF+PjYLiMgd0sEiRIkCBBggQJEiRIkCBBglc1sZCPkukrMDvx"
    "b4uS4/dGpMMbo0S6F6Nu+Bym1ME1igM1iDhQ9HSXyOddtD5YYqAissCyjl1+oNRxixVQQEBIQfKDCAfBwSGtMgcRDtH/dwI/iMiB"
    "GuDD0ffeC0yJHn8zpnTkM9Hx+xKmU0YGo3bYSWL0mCBBggQJEiRIkCBBggQJzhJiQTDqgzTwKYwi4f2YVo1ulCR3YpQMd2itemMC"
    "IZfzyPe5KF2Z0Cv8IASRw6oLDsFHDOGXO5g88PEJJE+lqEAAB4eUSoWCxC0sVwuyB6PmOA9TDvJFjA/D3OiYDAMuwngvLIvIhf9N"
    "iIUECRIkSJAgQYIECRKcTAQd97/MV9AoLAhLCAqUNTAvE41SIBKilIWgUVFNuhIQFKJAiUIQlFJRDbw296PHAfN/FEppJUi9wCiE"
    "UVFuNQFoBNUA0mzuoyK9en+CpkRjuve1A10IXcA+FFsRtQfFXq3YHwp9EJb9+ZQowDefUaT8ykJgniAKpRQiIeU/Es88yXxmzOsp"
    "JBTMl/fMccEGFaKt1MtOalXDxWc8sTC4U0M3psxhQpQkLwFeA3QqpVYpxSaQdhHV3dNTRELQSuG6AZ4XDByL0SBSSp2WF6PCDPYQ"
    "/6DfeUAo/VUMArmUSj1tYb0UEu7EeEu0A/8CPAH8EFNGMSd67HXACoxvQ4IECRIkSJAgQYIECRKcbVAYP77pwDkiMgNkKshEkBGI"
    "qgPShoWQKIEkSurpN+uT6B+lTWIPIAogAFUA6QS9V0S1AhtAXgC1EdO9sONsPPCnkli4OEp+24HvY7ogxNgVJcXLgE8CfVqrh0ul"
    "4EkR6bAsRbHok897SEQGKcVB5Q7qjBntB39SIcCraGgRs202Vk5jPa3RCDIdaMG0pbwH47UwEtNR4wCmY0YdpnQkQYIECRIkSJAg"
    "QYIECV7t0MBkQc5DWAhyvsAMkBYkdIwiwCgHlETO/JYyOZllgbYpKxUq80sJIRSQAIIAJETCwJKQGkRqQMaJ0hdEyWkB9B6EZ0E9"
    "DvIkRmG+LyEWTu6JvgT4KKZ1Ymv02Jcx0hIHUwrRBnwHcJRSv/P98J5czkUphW3p5vaOfKOldXAqyQOjjgA7+hmc4pNTlIJlK8tN"
    "kWmzsIoWeo/AbRhPimuA64ExGPXCpcC5EdGwC1NOMgGjatjNqf/4CRIkSJAgQYIECRIkSDA0UDSDXIyEV4vIJSimi0g9CFpMiYEo"
    "jbYssFNgOYZUUBZhGBKGPkHgEbhFwsBHgiAqTwC0hdIWlmVj2Wl0Oo3WNtoCRUQ0eB74HuL5EATZUMtkRE1GqTeg1F6UWi9wv4J7"
    "I5IhnxALLw8W8HFgGvCfGNX/3wBPYVpITsLstG8GNgCfDAKht6eE54VWOm2d4zj6jcOHV1+gtCooOUUdD2JZjDYklgpj9cup4zWA"
    "aoXq8Cj91pPSHTWqtkeQrwBfxRg7XgI8hGHCRgDfwLSmzES/ezNwH6bUpJDMPgkSJEiQIEGCBAkSJDiz81eZAdxAGN4gMA9kGLFf"
    "gVZonUJZDlgWCvB8D7fQRSnXQ6Gvi77eDty+XkqFPMViHrdUwHd9/BAkDJBQCIKYX3Bw0lVYmSzpdBXVdQ3UNjVSW99EtqaBqro6"
    "UjU1EAqWW0J8l9BzIZCRoEai1bUSqp0oHkXJr4A/YDZ9E2LhBOABPwNuxkj4XaAK+Kso4a3FGGagFJvCENrb82gFWjPJc8O/nDat"
    "4Y9ufvNM5aQ1vh/GSpahzeoFMjXQvQs2roa2DYps/ak7MQpIKYe2cB+bvRcvK5KvAv438mkQ4LcROXMh8PcYY8e7IgLhNcCfR4P2"
    "IYwyJEGCBAkSJEiQIEGCBAnOQEgK1MUQvkcIrxJRE0AsoiRSWymUlQKl8YMS+b59lHrbyHXtobtjL4W+Lkr5Ep4X4AcKLwARC8GJ"
    "zP9VVO0Q4osYg0gBKCFSwHOL+J6HhCFhGKIsRSabpaZhGCPHjKdl7HiaRo+msakRq6YGXA/cIqHrKhEZB3qcwI0KnsV0Rfw18GJC"
    "LBw/fh0lubdilAv/DfQBb8IoFX4APA2q3ArS98NziyXv09ffMO21f/fpK/Wcc0eBdjlFeoWyV8f+F2H1FnhmnaKhhVP3/kBKpShR"
    "olE1T32sdP+tPWFPc62u+6pCeYLsxpSU7Me0nPw1Rl7zHkybzueBX0afOEwmowQJEiRIkCBBggQJEpxhUMDFQniLiP8mRIbFDypl"
    "oa0MaJvQL5Dv2UZf+3b6unfQ19dOIVfC8xWea1MoCYWColSEwHcJfBcRHyUhoXggYNnKEAcCiMILBAkUIhoRi9CyUdrGIgXYlEoW"
    "uV172b5xM6EEZGuqGTZiJBOmz2TCtBmMGDUaXV0DbhEp5gldL4tSF6DUBYL+EFr/ANT3MYaPZ/6JEjn2THnqxEnH+tRm4GqMd8LP"
    "gVyUBF8TJb0p4KeYuv8DwAZE+rTW2LbFlq2dVyj4q3e8a87Vf/rxi7MLzxuFwuXYpAqqnxk45OMcFzuw/yW4/Z9g3a8UTROP5U9V"
    "9A6xSUhkDHKcjET8bEelcMMSG/zneaL04PYu6bytWlV/SaMPCJJSqHqMj0IIfAjjs7A9OrZzo4H6Uww75h7Le29q3ZpMYQkSJDgq"
    "Pls1PDkICRKcnpgPTATmR9HPEnWIaOgwaI1uAKsFuoC1ctwRVIIj4R/ybclBSHDG4RVoNzlNKfkgEr5DJBwXd25QVgrtZBABr9BJ"
    "rnsLfV1bKeY6KBU8CkVFV7fQ2+dRLPn4fglHlcikoKpKU11tUVXrkM2kyWZtbMfC0hpba6xopguCENf1cUseXtEjV3Dp6y3S0+vS"
    "0+tRyCsKfopApxEcQGNphecV8YoF0tkMI8eNZ9qC+UydM5fahkYISkhPL4Hroywjzwf9BOivQ/ALRNqTdpMDMQ54H6YDxBpMa8QC"
    "sA24MyIV3oYxGVwZr1FaK3w/sNracjdWVdvL3vnueUv+9OMXMnN6C4QFKBZjbuooGbn0L53qUI/T30bkaKiCogtFD1ylcGXgyxya"
    "EJCIQdNorQglJBSJPsrxnXwhxBeXrKpipnMuaZUe/6T78Mfagj11NvaXUyq9SZD9UZeJmZi2Kj7GENMDtmJUIfsxUhs3mRITJEiQ"
    "IEGCVxUmRsTBkohImNcfLaly5KQOE0UdYttlccX/b40fF1gnhmBYDbI2us/LJBwmRrdjiZLWYkiOhNxIkODVj1oI3wXBRyQI58Xi"
    "a6UzaKsKkZBS307yXc9T6t1JyXXp6VHs3+/R1VWiVChiaZ+aWovRLdU0jhhG07A66mqqSadt0HGyHkSdH4AgBN+UOfS3mozmJQFU"
    "iAqF0A/wfZdcX4GOzj727+tj7/4+2jo98sUUoVWDzjYRELBjSytbX3iBB+pvZ/qC+Sy87DJaRk/ADopIdxehVwJLX6DQ80TpN4Ne"
    "Afz+TD1pQ0EsxKaB2zFS/Cuix34JPB0RC49Gv88Cea0VpaLf2NNTvLmuPvOJt7977pyP/8UljB1dD0Gfye4HM1qHIxRStmnhEIrR"
    "SFgWeD6xmQd+AIEcTDwcjsmJeAh1yCaRgxdjwdIWFhZ4EAYhthN9HgUhISKCEJrxeRQ3SIVFSEhO+kirLDOduWRUpulx94E/2+Xv"
    "qCtJaUVGZdZHHzOPUSZchPGsaI2O8blADzA5+n/PmTI4P1s1fCmwVEW7JWrQeXkFAoslx8kLdkWBUOU4qQyMkiApwcvCabLj1QCs"
    "VGbO6aq4Rlrp3/U8WWN8yVGSj/nKfJ7y8wcnPa+ia211xQ706kMkiAPmn+P83uVk7zDHukGZHfHDYRknJ+lMcHjcDNyszLo0oZ80"
    "UGjK3tPm/4qKxw7e5jicnrPy3JnIhXkC80LhlujcbgthdQirBFYL0iX9JMSxYlUlEaKOvA1zZURqUPk+Z+rYOkHFVxwXcQQFykGx"
    "x8u4BgfPqceCxcdAEh0N6+L4KPrslevJ6ui7rJUkhjrT44fD5VQXQfBJCeX1ICkkRGkLpWsRsSn1bcHNPYdf3E2uIOxvV+zb69Gx"
    "vwclJYYNq2Lm7NEMHzOM2voaUo5tXjXwEdcnKLiEgWf+HwYEoY9SAlojoRAGIRJKVEsemC3biutIqxBLQSpbzfi6WiZNgCDw6Ost"
    "sn9/J627utm6Yz9dvTZWtpmqpkbcYp5H77qHp+67n1mLLmDRVdcwetwELK+XsKsTET+Fdm5ABQsR9W1U6kvAnjNtXA1FKcRboolv"
    "NfBfmA4Qb8KUPNwHvIRph/hwdIqUCC2FvP+epubMp255/4IRH/vzi6jK2uD2gRuCpY/8jjomCTSehASAYyk8L6Q3V6KxNgNaEYSC"
    "rcEKo+eXGanDIAs7n4Hb/xme+Z2iafwRFAtKoVGoUOF5PkW3iB+6pK00jpVCWxqlInJDS7npBMRL5JEuMPP7FClqVR3bwy08VnqQ"
    "HUHrby2sf7WwHscoFGyMcaODKUe5Avgd0BuRO+sxXgx9R3q/06EU4rNVw5cq+I6uCDYOt9tyKhYUdZz/P9TnksP/3BYtmmsxgdnq"
    "eMFMgvIEp3Ng8Nmq4Q3KJLjzKq9TfZTrQU7RNQi8X2BlbDQjyKvFdGaphu8MPubqGI+5HMexVifwe6BbDKmzNojeMTzDk8DTBPOB"
    "ZcoQCvWVRIIVkQZaVdwHrOinIRei+8exdvVfOxAihBJt7EXnNEQIIHpcbgthVQCrjvGcN2jojAkPK/q8Sh16rQ/hShFWl9+zn/A4"
    "W8bVQXGRHhQXqSPEHsc7/57gnFvx+5Nnsy4VkfJAwovuSDmzFqQ12rBZnZCaQxc/DEUpRFwyLopaJPxjJPhziMoelAKVRUgTunsI"
    "iusI3d3kc4rde2H7th56enppqE8zYcpYxkweQ31DLVpr8HykVDReCl6ABD6iBaXM7GVZoFMKVEhYKuGXBFEKCAkjgsHWkK52cIs+"
    "hbyHwjQRCAOQwCcIQkwpv8K2zE9LCaVikb17unluQxtbdxUpSgPpumHgFencvw/Ltphz4QVcesNrGTlmNPR2EOT6jMGfVqCsh1DW"
    "vypt/05CCc+UUoihIBYywB8Dbwduw3Ql8ICvY0oi3l/JwChFqqOj8FcTJzX99bK/uKT2vbfMA0pQLJmV6khlC5Hngjg2odKgNC++"
    "sI/2jjyjR9ayv83j0Uf3cOONE/F8l57uEmPHNTJ6TD1CgBUERsEgHPp9jolYMJ/BwkEHmr7uPtpVG97oIpmmNKXdPqpHkXLTVKka"
    "sk4WO+WgtEbZCpQgEnIsXTRNmYWiWbWwJ9zNg6W72Oi9cEedrn+/IPsq5s+bgDcA92BaeC7HlEmsA74SETwqWpfD041Y+GzV8PkK"
    "1uho+rHjaUj178CoV2DBUMcZXMsRFnU5xI5LPLbC/t91i9kNWguyWpLFMsFpRiz8c9XwVQpu6k8KwFKVwa4qz20na9yqg36qw16H"
    "Rrot830gEMGPk6Mz/PpRsFrD4nh+tJQqJ5PqoPnnxI7/kY7z0ebDaJ66L0CWBGKSUP/sSwJPdkK5rJLAqyQTbGUScguwo7XSjp4T"
    "/4zHyOBk9GhrV1ixZgXRdRQCPv0/K89xYJ63LRBZGcKKALoGr3cVY2aphu9YKBwUTvQ97IrPOGhMXekjqwPAFTHvXXFNv9pJpcFx"
    "UXxOrQqVhzrKtS4nON8eaW440TnkaPHuIUiEg1Q0UjlOZcAcc19oYqZVgqw91Gsk8cPpRCxoIJgpeP9A6L0tehCwQdUifjdSWodm"
    "O8WSZstmny0b9+O5LqPGtDBp2iSaR48knU2D5yJukcB1CX0fghCtwcpqVEYjfSX8YhGnNgW1KXJ5Fy9waai2IFei1FVCLCkH5r4X"
    "khNFlS04oZBpShtJ4L4clhbSGYtCzqNU8glDE8VbChxbk0nbSOjT1dnD5q0dPLuph/29DlW1I3C0Yv/endjpFFe8/nVccu2VpG2L"
    "sGM/EgTGe0HRoayq/xbR/4Wi82z1WCgC/4cRjrwHI8Vvwuyg/wTYR0USpZTyS6VQ19am0tOmNQMOuD1l48PDzDgGKQexLPa15Xjx"
    "xT1kUiWefrqO1m02w4ftwlJZUtnruPOOu9h/wEJoYtasA8ycs5++Xs3CeWPJVGdMqUUYHrv3QjShaaVxtIMUFAfaO9jn7oLJPvNu"
    "ms3lN17G8JaR7Nyxk+2bt7PrpZ3s27CfXa37CNqhJqyl2qqlOlWDlbIIlc+xcDyCEKqQHD3kpK9TKZ5UqC5zSMsvcG80z14MjABa"
    "MEqFh6PzclV0Pn6NMdY83YLmhninJQ42nCjYsJUaEAy9EsSC4ph27A5DKFCxEEq0EEY3FQdIKv59fQg3hXCTiLo1Cp7ui8iGVVGN"
    "a7JYJniFr1UT5Doqul5jkkH129YO2G16GQM1nqIPJ5keHMiGMC9A5vvCWlcJrghedDWeqQmugokaFlfOj6lB8yOHCcCP5/gPPtaH"
    "IhKOlGAEgCeCpwQXUCJ4A6imBMdIKCzvL3U4mDxwImKhvEYCtuq/b0XPtSqULZqjlhyUz1FYofIRIFAHEwledN+P7wsTfCW3+sgy"
    "X1gVwnIfWgcTSxpu1tF3SCtFGkUm+uwWoCtiMpH+93IRNFCUgWP71T/XDoyLUigc1U/EwOEVCydK7B4u7jk2YkEddZ7gKONPKuYw"
    "BsRPA1U0AoTKxE+RkmZxCIsD4daoZGdVYNRraw9HdCV45Ua3iLwGKX4O3PmIBcpG6QwSgpSew1brwQnZuSPFuqd3ke/rY9yUiUyb"
    "OYOmES3mZVyXsDtH4JWianeFk0mhatOQ0gSeS9u+HqrDgLrGGp5Zv49Vd2+gdUcnbfv6OH/haP78T+bR2Jim1FUgRJGtT7N5ex//"
    "9PnHeetNk7nxxsn8+ldbkEC4alELqbRFvhjgB0I265CyNbmci+cHFAoe+byL7VhU1dSzcH4dM6cVaN3WzhPrt7HrgEPjqPE4Wrjj"
    "Bz/mmUce47XvfgtTZ82Arg78XAFs1STSd6vSzmxU5tOYzeLTGieDWKgCbsCYNt6BKXVow7SQfA44ByPf+0qUyA4glkUkrKtL/3DT"
    "xvYpX//a47ecM72ZpsY0iGtMNA6V7CuBjA1KaGs7wP3397J3zxT27HqQkaOHc9WV11LIdbJj+2Yuvvh87r5nC+ctughLB6xds4qX"
    "XgrIZMeTdtqYO6+OVKYavBBKPljHNvVprbBCm2Kfy/5wH2pewHlXzGHRtRcwfdp0GpubSFkpxo8fx4KFCyjli5SKJTo7uti5eScb"
    "n93IY/c/irstYJI3naZ0E66UjjDJmYmwVtXRHu5nXelJ9gQ7f16lar4iSGnQk3uAncDs6Ly0R2RPLfCPEdHwnxh1iQJKEMXbp8cC"
    "ioqCopRSZFBklSovovqE+myczM925MX2cAt6f0DVH6iFygRMYVlW2h/IVe4OhUoIzIK5OECSxTLBaXOtWhGpYK5TTboc7B6aVEOd"
    "+Pg81LU3WK+gBs2aHiwrIUsLEkZO0yb4PIMT3GWV82M2Ou6pKNnQ5c5E/XPN8R5/dYT5rj9lONx56JfKuwglhLwIKOMx5Cdz1LHg"
    "ZgUrYkKhskwgJtodFCk18KdzCFIhVisMVikcm2/Uweq6yjKImFzwleBHpJ0fnfeIAKj3kFt81C0e8l++sDyArniNU6glhpSEDIpq"
    "palSijQaWw0s2QgV+EJDCaEooZEuA2G0RqpX+ZgaHBdlIxImo3SZzNVHiD3g5c27VLz+0eKewQqFEyEWDiZEZBCh0K9OqFStBIOU"
    "NKGCAJkQwMcD5OOBsC2E5QGsCo+gpklwaka1ItQSeh8k9P5RCMegUiiVQqWaCBG8nvvJWM+TCxp45qlOtm/ZyKjx47jo6qtpHtEC"
    "YYAUC4QlF8IABTjVVeBoJFfAFdi3O8eadVu5/XfPsWt7N3//qSVc9Jp53PvE0/zrfz7A+96zgOkzR/DVlevo7XP5t89dhuMFuD0e"
    "WAqd0Tz93AEuuXQM+zo9/mz5PTRWZ7nyznfy0JN7+Pq3nufTH53N7HMaaG8voUJFXU0KW0NXr4vnBni+iwYcJ8WMmWOZOnk4z724"
    "h0ee3sABv4EpM+fQ0baLry7/PNe89fVc96absDMZ/I4Os2aLvAUJxqDsT2qVeVgBoZyeOq2TQSzkMcYuy4DXRwnsXRijwBeBGcCP"
    "GWzEUnEFp1PWxrb9ue/cfvtL886dN2L+R/9sEU7KMeUQB800Apk0PT0+65/pYf36vWzbuouLLn4tI0dMpK/vAB3t+1BWmlS2iW3b"
    "XiKbGYlb8nDdHkaOXMTo0dPYsGENv7/jUdasG8Ull05i5rQsKm2BFxyTciFNlvbiATbKizQtquXtH3gbF1x6AcNqWgY8L2NnydRm"
    "odZMgk51inyYY7g0c27zbLY+vA1vfREv76OyCpHwoOk37jRhKxsLi+fcdWzzN9+vhK9byjqcscfWiNy5CNNq8iJgArAbY565FdMS"
    "dEf0+9OKWLCiACkONqqVJhMFUNYrvrgfWX59LMHZgEVfReRBxLoHFfJOX5nAqUJiii9CcOjFcmUAK8NoZyhZLBOcirAg3jXNKk01"
    "UWKgVDmpgYPrrU4kpT+UFP9QAWvl/QDwkFsKyDINXSIhgVIEcubucmpYerj50SnL3Q8lGz72c3C4Y62OMh9WKlQ8MKRCRJcGosz8"
    "9bJSnFc9JgIrNSyuTCTtmECI1sBUdD8d369QL1SWQegBRo6qbEZ9tGRvoMeCKodeZaWdKu8K9ydx5lqLVAvgRgRDTC55Ih8vKVnq"
    "I8t9YUUAN2uodyIiIaPisazIoAeQZETv5cF8h3CVQuNKrFx4JfSLp0dcVBURMTHRpI4Qe5wMYuEYzDUPOx+fqFj7UPPYYBVNHEPF"
    "SpqAgYoaP7rviRAomeCjvuMjKwIzDsvlOokPzClHlYSlv5HQ/SQ4WeXUoa0qsLOIqsIv7EQ7Kfa0TeTZtRuRoMTF11zPuHOmgx8g"
    "vb2EoUldtGWhajNQmyHf3UfXvi5GjWtg9Z3P87ef+QWZdIaF88fy7ndNY/qUkSA+2TqHCWPr+bOPXMLsRZNorkvzle88zbvePZuF"
    "85pRvV0QCDUZh4kT6gn9kDt+t5Vde0uMX9hEoc/jez/bwAubOhkzrZHf3L+blT/eyBc+OR9sh95el4kTqvE8n75uj5LrU/ICSkWP"
    "lK2Zf+4EZp4znEee3M6jz66jdvgkzpnVwl0//jUb1j3Huz72R7SMHkHYtp/Q9cD2L0Z531NW+lNo/bPTdaC+XGKhHtNtoBW4GyOx"
    "vwUYDmyMXr8qSly7Kv/QirJDpUApRWNj5vFC0fvyN77x5H9edMm4uvMvGInl2OD6/SuhAGnTZeGFF7ez+g8utjOfGTNnYNs5UukG"
    "PDcEHTByVDNTpk4g19fH2DHj6O7uYveeTqqqW6iqyjCsJUsqtYRNGwtYei/NTVWMGDEWgsJRvR2U0gSFkAI5qs9Ncd7NC7BSNvu2"
    "tZEel6W2rqb83FKpRHd3F51dXezbs5ddO3bRunUrW3dsZfikFkaOHUVpI7jdLukq57AzmsIiRZqdQSsbvGcPFCV/W7WqeTz2XTgE"
    "uoAfRYTO24Gp0Xl4KjonYzHKBSciF3pPuwU0CpyqlKJaKarQpwWxwDEurgMXRjlkgH+ohXKAIRYRiSBx8CZ4ypALh1gsb/WRWwPh"
    "tsCQDKsHs/wJEpzkJBdLQRqzg1YdJQdxknvkhOXErj04dr+TECiJYKlwmaCX+wieqCjg5IxTLShYqlD1dpRYZqL5sUYpstH8qA9B"
    "LBzP8T/W43yk+TBKArEJQTQ+QhGFqwRLkvnoMFiu4Na4TCFeA2MiIS4VqPyZKsvi+xUNlSaOmpe/e1xO6tTghBUjO5eKdeoggsGQ"
    "CvHNReqLIl90lSwNkFagXAYRJ8lVEcmQKsvoVXlMlZSAaDzCcvmPVoI6CwbT4LgoG133VegykauOEHucDGIhHkfqOP5G8fIqwI/m"
    "rRDfAhGjAK0gFUIl+NJfouNFY9MzRFe9p+RWH7XUQ5YFwqrBPjDJHDWkqCMs/ouEhY8iaLRGO1WQHkEQmBGTqp5AZ8FmX/taJp6z"
    "kAkzp5DOOtDTReiXzBkKFNpRqOG15Io+Lz7Zypf/63eUcjm+dtvHUOkMW7fs558++xbe8Y7zWX3HGh5+aAuvG9/A6HHNKK3Yv7sH"
    "sFh85WS+dtvTbNjQwcILRiNaIQFkMjajRlTzwONtSBjwnptmU1+f4o47tvLM+nY++kezaBxfx49//RAbt3UzYmoDP/jBBv7ney/x"
    "kfecw/WXjWL8sAz5XJHuXhe0xg1Cil15smmbKy+fzuRJ+/ndvZvZeaCeWQsWsmvzRv7zr5bzjj99P/MuuhDduR8/nwetJ4fS+TV0"
    "th7L/varkViYAvwpxjfhbowE/wJMacQcTC3IfVEMN/CNbTWAZMhm0wWnT/9686auq2+7be2bR49dnBo3pgpcz6xoykSwbhiyc1sv"
    "69Z2EgS1zD13LuPGj+ahB39PVbaL2bPnMmXaVIY1N6OUHpDg7961iw0bXuKZ555Ea4tLL3sPtnM/u3dv5cknSlx44TCGNWpTFnGk"
    "YFprisUiukpz3ryFvPby1/HAnQ/y/JrnmTJ1CufOnUt9YwPFQonde3ayY8dOtu/YzvbWVnbv2EXr1lY2bdnE9HkzWDTpYrJOPUFZ"
    "nqoOMUErLCx88XjWW0MP3b+xsO4avGgcBjujc7ENeCEifS7DtPrcCbiYFqCn1RIa79Q4qChpMcFGGlV2jX6lF3mOEqAdatcH+tU6"
    "A3cU4pakFXWDB5EMFeQCBy+WPqaG3Fdl6el9gZGerg4qFkySBTPBSQ12TW1/SkXS3Ei94AyxyepBSe4hLsRABEspEJb6hMtdtNk9"
    "jQJOOdTidJoTCzGZE8+NGTRZdLlczFKHn2tOynynjn4uBIUtAkrjR0mgg8ISU4KikkunEhNV1HKx0pjPUTF5ZIi6+NpKRzv8ToVK"
    "Ia69t9TBXZSOh0Q4luuMyAOonOSpSoLcqIECpcrEd6afVKBofN0pIfNcZB5Ropwt33T0Pc33UwMUC+U8glT0fZW8/MT1TJlnDxUX"
    "ZSriIlsNVA0dKvY4VbEPJ2HcHZbg4mAVjUQqGqmImeISiQFklxI8MZ4vFYqaCa7ILzwlv3SRpYHQ9Wox+R06nOBRiRXZSjdL0PtF"
    "CfreG+d3dipFGLoUc104VaOwU1W4pSLabmTGeZeTrfIgv4+wq7P8OrqmCrIObm+O3/30cb7x7Xt46NHnmDNnCp9c9jqqbMX8BWO5"
    "/LLp/N//Pcw9d6xl69YD/OmHr4BMLc0NteCHdBcCIMuGrV0Uix6NjdUgCiUWYQBV2TQ1tQ4rf7KON79uBn//yYV86Wvr+df/WcfU"
    "cTW88Y1T2bell3XPdfCG106gpjHN1VeO5rmdfXziX59geGMVb79hIre8YQKTx2RRSujp8ygWfQpFn2LBY/SoRj70zgWsfmAjq9c8"
    "xuRZ51Hq6eRr//RFXn/LW7jhbW/AtiDoySGW30xQWqF0TS2kv0SZWj09RuvJKIUYCbwTszO+DtP5oQbT+WEH8DimXGLg+Br0/X0/"
    "xLZVZ11t+murfv7ihdded86k0SOnKivtQNEz7TfSDu17D/DrX/XS1TmdCROb6eh4ga7O3YwZM4HLLruE4SNGRK8v+L6PUgoRIZ1O"
    "M2nyZCZOmsiY58by0IMPs631eRR7sfUknnqySG/vDt7xjnEQavCPUruiwXd9xBOmjJvKuPdN4MnHn+SJxx+jdesWRo4cRV8ux/79"
    "++nr62Pb1i28+MKL7N65k75cjlCETDYd1fyG5vuVB0ZFYIhgKxuNYq+/S3b4W9sV6udpXbXDuDT3f05rgCd4/6EFPo1p+fn2iGB4"
    "DtMP/o3ACqD7NFtEu3Sly3VUr50ul0Ko0+Vzntg0rI7cBi5eOGPvBUERKg6uHzzMYhmbW3kii10l9/rIfb6w3K8gGJIyiQQnA5qB"
    "O2lOxQ6rrU5uu7ETuQ4t03iHQKkJHmppCbWyiKIkCiu6hs6U2mxlEtDFlbuWaRUlFhXJZqV8/OX4WRzPsT5EW0CIlFUO/XP52ZAE"
    "HiduVqb0oV4NIhTSEUGXjQiFTHSO06o/uRxMJughSOiOdL7VoOQ1jK65mGTwI5IhJhcykXIlJhrCiPhLRwRKWYVRYTZZ+a6GQJGy"
    "oiPq3n1QN4RXK7lwqLgoLo/Rh5lt5RTOt0NJLhwqZhqsoonHoFQoaUSpAQRD2QMkMvON1TRF5KaSSKurZIkrsjZWtVV06UowcIY/"
    "gT/zAF0lFD6H1/texGwSWulaPNejq3Mj2cY5aJ3CLbmgNA0jRqP8NujZg7g5VKgRrdG2xYH2PKo2S9pxePD+58lWZxgxsoVzZ4/l"
    "prcvgd5OWuqqGD+2mYcf2chHvvgBbnjtPKqdPvLtPTTVpfFE+Nb3n2LD1na+8Y3HuOqKyVxy0XjodtFKo0SjszaeH+B5XVx9zUSm"
    "zB/Dlu338uKWVj78ntfSMq2Zu37wAj05j8svGAl5nykLWrhyQze/+vUWrrpsFDvai+zrKDJrWh2tO3pxNKQcjeeZ49nVUyKTsnnd"
    "dXMYN3Y7//erh2kcN4f5i87j9u//nJ72Tt7y4XdihQF+dy+kdK14Pf+CzuQE9U0kAO2AWEN+TQ81sbAGWApcA7wVmBkRCp1ANfAA"
    "pkvEwePrEONSa+3V1aWe2L6t63e//91L750/f3jdpIkNmE11kzpbFhTyOxgxYhYLFlzH1i3P0tPby3XXX0t1dTUAnuuxd+9eDrQf"
    "wNJmyRk7bhxNTU0opZk5cxYN9Q384P/+l/MvuIiZc5p56slfUSptBjUxWqkOv0ypmBnRguiQEgXSTpaLLr6QefPmcvvtt/Pggw9S"
    "lcmyedNmXnzxBfa3mbYumUyGhsZGSp6LbdnR7o9CqcPve9vYeOKzNdgSFCR/lyieOY5JrghswihHvOgc1QLfjX6/jbjs9TTB3+T3"
    "rV1RPfL9wHdUhflUeXE9Y3ccjv7bwTtBsVi7vCMkyjDph1gsPQS3TDIMkJ8udpF7PbjNE5b50FWpYEgWzAQvd2z3u81H3gqHTAxe"
    "mU9nKyElihRqaRq1Mh2VEXhK4Ut/4HgGYJmOFAnlGnv65fC26q+pP10IJ/N5Tl3Ce4ZhhYKPx2qD2JQvTT+ZUFUmFkzS7VR4LsSt"
    "I9VpQNiocoR2MMlgat8VjjJrVKrC3DEm9pzIjDAmSw43Vg42DD27RlRlWUtl5x11hOtevcq++6G/U79hrcVAJU08FoModgqUIj3I"
    "C8QQCyEFpL6IrC4SLivBSk8EH5WoF04e0gSFTxPkPhg/YFXXU8z1sGvTGrL1k9ClXkr7t1DbPJ5UugqCPBSLEEajPmXK56mv4off"
    "+yV3/P4pvvb1P+Nvl99CTUMD3/vO7/jbv/02b33b4yy5ejbKgzmzxzDivnpq6qpYvfp5Vn7z9yy+eDJ//OHLeMPr5vDIY9u4/57N"
    "3PS6mXz8TxZRm7Jx2/vAcQhDQRd8liwag9d3OdcvHo/vhViWYtyIRq65ajzih/z8jlaamtIsmN0MtqanNcfn/2stc6Y38tUVV1Ds"
    "yFNlCb+4aydf+OaLrPjUPBbNa6CU98gXfHKFgGLJZ1dbjunTx/Gnt1Tzv794hl19Y1hw6YU89oeHKZaKvOtP34ejwe/qBYvqoHjg"
    "c1iZA8pOrVKiQV75CODlEguC6QCxCngSuBK4DugDfoVRLITH82oKVaypSf30gfu2XXnjjdNnTZrYBFmH0Ie2vZ3cd5+L7YzHsks8"
    "s/5JLMfi6msNqaCUoqenh7Vr1/Hwww+zbs0aDrS1sWDhAmbMmsWFF13I7NlzsCyLUaNHc9FFF9PW1klX5wZyfd34XhOrV7dx6UXD"
    "cI50bpRCaws/DHB9nzTZmBihuqaG2bPnsOGlDdy/+j7WrlmDk3JIZ7NorbG0xvd8ENC2hef6lDr6SOXSZBprEAkr5KuCVoafzkkH"
    "u4KteYX6jUi4Vw7FBSh9JHpxJzA9+v/3o/tLML4LWznNVAvLcntXfrN6NIIsjaRtE0FNiAfdqzWcOLR0VQ1oSXm4xbJSxVBpmhUv"
    "miXkFhe52YPlnrAiYeQTnIxLFWPei8BEQSaGSEMoan6omK+g/mTIsV/O9RQ76qeUWpxCTUyjWlNnoGpBR2UQ8a52Orql1CuqBohN"
    "mVcfot98a5i0ljwUGoAVGm7pJxX66+azkQFqXN6SUZXkUT+hoE/++b6vMrAbhIkY8+djlr/HJIMGtBLTqaKCYIjXK4jNKY3hkzVY"
    "dXPM6+SrHq3AZxh4nS3p9xxQ8zG+Z2ctgXeo7jVCvxdQuVRClPFhUCZeSiPGt4SQPFLvwHdsEYpKVr4aWhSffJyA05myFGHPn0vQ"
    "90mU0oRg1zaS7+tiw5O/I1NVB7076di/hwlzXk8qpaDYBl4O/AJoDS3N4DjRWbCZNm0cf/V33+Dr37qLz/zzR4E+bnjtfP7t/6vm"
    "u9+9n8uXzMaybS688Bz+63/u5i+XfZ05M8bS1FTHtKkjqbU0//A319HZV6S6ymJ4cxV4Ll57DpSFUkIoAX6Pz82vmcobbjwHx/UI"
    "DvTwlx9ZRG+fy+xzaunY2sNT69pZNH84LaOrwVbc/cBu1r3Yybf/7TJSoZCqdejo9PjCt1+itsZm8jkNhKLp7AsJgxDbUYShReCH"
    "7N3fx7DGOv7kvefzo189x/PP5pl93nzWPfwUbqnELZ/4IKlG8Du6ULbfIqG3Apq6Qd17OowO+yS9Th7jp7A7+tkAPM9h1ApgnO4P"
    "Qy6EdfXZx7Zs6Xz0wQe2T774kvGZ5uYq0Dl832PTpm4mTFjM6NFjadvXRkNjA2NGjwag5Lo8+cQTPPzwoxRLBWbNnkX1okX09fWw"
    "edMmPNdDoZk1exaWZbFw4UJ++ctf0dzUyDlTX89zzz/FC889xaILGnFS1iGnEKUVAQGhF1LYV2LzI1tZ+9Ia5k9fUH5OKuVgOzYl"
    "t0gQ+mTtLI7jgAiWZRGGIaW+Er1dPdROraFxzkj61hZxe0qoKqlgX4UUKUIC9gS7vfag7VlbpR7RWMVDT6pHXE7agJ8Al2BKIDqA"
    "OzFGjnMwLSe7Tqep64O53SuBlZWPvVg/tUGUzFeGFLlZoeadrFrSIQrKjjkgO9qCeayLZUwyVLpyx/LTAmF9CfliCbnZhZt9kS4v"
    "YuSFExa4JTh7sbayBZ3x+zByZYzwa76GJcoo2+ad6h3W+H0sBbYo0qjlafTSdNlMUEXViad3uFhp2ljuDhDd7EjFoE7N/m03sErM"
    "ZsKqw/aYjwzTfGL/l6T0KiYVFKw2fgqVKgVT9lAVqRRiA9R0Rf38SSYUtkXnb3V0Dbcei9GfMq3D5wNLFOpmIuLwcNdzpbJAAKXE"
    "ECllQrxMmpXLOg4n6T+ycehZMbJaBZZD1DEqNiVUoEURqrKbwpLoPN2sUIsHnodXhHhcDXQdpjPF/ChfWDxUMVzl946JLlEm+bEB"
    "R4jK9yQi8MJIGRSusAjXalhLVG7jJ+TCiZ+lIP8u8Xv+QUJSKIVTXUuu5wDrHv412UwWRUDn7heZOO9Gauuz0LcDghx4ecikoK6R"
    "F17YwG3f+jWI8OEP38R1b7iJv/2rF/mv//kpN73hIhYumsqY8SN43/uu5t/+7ae8731LWHLtXKaNaeK//793UQwD5s4fy9gxDViu"
    "i3R001Dl0FCfAddFugr4Jc8UW0Vl9KYkWWN5xozYLQYQ+Fx+6WiwNNJdIJ3z+JdPXsDoljRKoKfN5T++/gyzpzXwmmvHQ84HW/Hl"
    "b7/Ao2t2cNsXr6XlglE8/KMNfOJzT/Oxd03hndeNZn97ESyNpeFAR4HamhS3vO18fnPn8zz+3Aucu3A+6x5fy7c///9Y+sn3k2mo"
    "ipQL4QTcnv8mZd8C9lNnMrFQF7Gj7RGx4ESPPxy97hFzFDnCeHVSViHwwzsfeWTH5c88u++cJYvPMQm741Bbk+fAgV3Ydh119Y2M"
    "Hz+2/Kc7d+xg/br19PR2c+GFF3LhhYtoaGhk69YtPPjAQ7Ru30bDs+uZPGUymUyGmppahg9voVQM2N/WRmf7JmbNdlCWddgPaGGR"
    "O1DA0hbnXb0AZ6Hi3rvvpSnTxLjx41FK4bolgiAglUqRzVZhWRY6MpYpFgr05fOgoCZVQ+PIBiZMG0VrzU4OPLCXBq8JseMpUGHj"
    "0BN2sdPflnPx77HJ7Dscm3+Uzuwl4H6MueY7IpKhGhgVnavdEclgYZQmpyVmdG/qihaq1cDyF+unLtGKFRrmKYZsJ+dI+KXAzYMD"
    "7MFjXJnFc35ENMxXqCWUP/PxT9VHWixjJUNKSdkBOVM2zlIUDcGwuCjSWlKyVCOrPOl3yU8WzgTHitgoyxiHmvaCFiGiFB4KLazV"
    "qLWWkX0v0bDSUkw4lddqXKYR7fTfnIKGFKrLqBb6pbOns4njYNPGuK7aia75wT3shwi3CSyTKEmQ2FRWDtH+LSITShJSkv556CxX"
    "MDQoWK0jgs2JSIVMpFCoVpqqWK2gNOlDlLiok3MOVwBrQ/r9dvrbHcshWyJXjMO10W2lMq0el2jFUm26gR3W56GSYIgVDKDK4yW+"
    "RgebTh5t7TubEBN2ger3USpiOmKEKoyMUSEaY6sxqpiJWrFqcHzEqTmG6wTmV8ZGR/J2UjBfGVJkyAiRwXFTTDpbgCVgK7BFYyvB"
    "gXpL1GqtwomKsKsYnYSEXDie0WOubgkLF0tx7+eQoFZCRaqmjkK+h6fv/zWpTJrqumpy3Z1MXXA9DSMnIL07DNUYeOBAybL5/ao/"
    "8IXPfQ/w2bO3k9tvf4gf/eQL/OWnPsCPfno3n/3s9/nhj/+edNbmzW9YxNonNtHXkYOCT7Vjcc0N50JKQ74AnXkC1zVXQ95HCoEZ"
    "G7aDU+NEXy8wJpESgAgSeIgfYKUcAl/wOouIQBAK6bTFtdeOhZxLmPPp7Soxc0oTixeNoL7KAq1Y/dAevvPzDVx07ih+9pst5Ioe"
    "d967m91tfcyaVG9KyLRCC0igcVLQm/PwfeHGa2eSSb/EA+ueZ+5583h+zTq+98Xv8P6/+qPIc6EPkd7ZqODzljPuXUpbba/kCH05"
    "xMIcjCHg48CPo9jmRmAXxlvhyAHpEcwRQ4Ta6vSDGze0P/vUE7vOWbJ4CqHYbN7cC9JEJp0m19dBOt1CY2PTAGKhbX8bY8eO5ZJL"
    "LmHUqFEAzJ17Lr4fsL99P7t27aKvt5dMJgNAfV0DWw5sI9fXQXV1Fd3dPh0dBUYNy0ZyPBmQuPf19JFqSHHu9bO55N0Xkh7j8Mtf"
    "/5w7f38nr7/pDYwYMQIrIibiKVxEKBaLBEGAbdsMHz6c5uZGqrK1bN+2nZarmpn4plEEnk/nAznsejti8c0n6JZO2oLdHRb2A0Lg"
    "BYe5qMPy36gj5QE7gM3ROj4eyACzgNkYxcJm4IdnyvRWIFythSU2qtVC1VtKot18dUoCECnv2Pb3UQ4PsYAq6Ip2qqJza8gGpbhZ"
    "GwOvm050N/dQJENc22pLxMQrU9uajm6mPjusLyC/KEj4mZJiuSeCF435ZOFMcKxhQ9zytKhCk6SLIRUq3eojn5TVFjLfFrXagnl2"
    "pLYZ6ms1DqiNakHqI8XCilhe7nF6t54cbNqYUhU72XGXnKFXK9wmsDRORn0Z2Cc+IGr3xkBH9pJEZVgS/81Z22pyAKmQikgFU/ag"
    "TdtApake5PJvnbzr4zaB5ZXKhMpz5ld0IQpEDmrvN5gk0GWyQ1Zb5npepmGZpVhmRUaUh1rLBisY9MA18uhlFoqG/sGjzrrZ1sy3"
    "Zs4qiqAJCZXClf52k2W/G6XQSKslLLEMuTshTqJPBakrsCo8xFirNJCuPIsatVbBWg0rFDJRo5ZrZcqFhkLpFpsODyAYxHjy2Eh0"
    "nKRew0oFNyNhxXVxlsdIoXuMB9lBwQjxOj5LWBiPOKSqq/HE48n770DQtAyvp6/7AJNmXk1Dy3ik7wAiglIOpFLQ2MjPVv6Oj3z8"
    "P/nQ+9/Ip5d/kh3bN/HmN/85f/bRz/Gb3/8/Pv3pD/G+pf/ED3/wB275wHXMGN3MN7/2J2QkRDpyiIBqzxmiIBCUrbGy1eAokJDQ"
    "9ygVi5QKLr7n4rseYRCgELQGywHH1qRTFul0GqsqAypASi6W5+P7AaWOotmgCEIaqy1W/OMiVGhy3Y5un7/5/BOMaq7i599/DU+v"
    "2cef/92D7GzL893PX8558xvZv6dArL8KABGNbQsl16OjK2TJZVNxg008/MxLzFowj/VPruHHX/8x7/rYO7B9Dz+XA/quFtX5CVKN"
    "nxYJj3mvxDrJw8M+wesxBYwFrsLIvLdgfBXOwSgXnuAIZRAiEByppaNATU161/4DfWvWr9l3Q3t7LltXl2bHzm46O0dxyaULESnR"
    "3dM7oLuEUopcLkdNTU2ZVIgxcuRI0naK3u5ebMcpP14qlXAcxazZ89m/fxwPPPBTzrsgx/CWKpPWi2++sph+pkUrz+hrhzHnQ9Np"
    "mdZM2kpz4+vewNe//nWeevIprrr6KtKZrJmAJMT3fST6kNlsltFjxzB+/Hga6uvp7uul5HpkrWrmTD8Xe0Y1d/1mNQ019ShHYYc2"
    "Pj5d0h720rXVwX4xPMJgEQRHOWj04UJkD7gjOoczIxLBA24C5gGPAC+eSfNbt4Q40OWgVjpKfdyReJdHTtXiWW4H6UemiZWL6KEI"
    "gGjBN90vhJUWaqWGBg1LLcUyDRNeLskgcfAQ72iKwkFwlJCSmGgwsj8bdast4cSikqVK+pOFONBMkOBITGUggqtAi7EDdeOd1thg"
    "jH5zOgfV5aCWpZS615Gok8QpuFZ19Dkc837L0qgVqYq5wpPTOuE9yLQxJkWciq4AQzrNwrK43MWXftOz2CjWj8iGyja5QcXvC/Hc"
    "eIh58WwiFXSkVEgrTRajUqiOiYWIVDBdEdTJUilswxBCq8trlcRlS2au90XKZSthef0aWN5SSdCpiuvJ6r/OuxylllsiKx3UCg03"
    "2arf4+RwBMMJYP7h1r1XO4Ebq6o8hKKEKGWUiaW4Owj9Brpq4Lzb5aCWp5T6ji3lOZBwiOdcqSAh/f5OVWXT6cGEkq4cW0q1WshS"
    "S9RyC1bZinlDZVYaH6sw6kaiMZ2ElDKRtBJuQnGzwCohBBmowDg7dxS8YzuyykqFbsffhW7X1SiNXZVGHM1Td/6WXHcfM2aPo693"
    "L+OmXk3DiHGE+U4IjXe+qstAOg1hwMjRTWQyadzAp7EhS2PThXz5vz/NH93yGVb9+E7e/I7refj+J8l3FKDko5WisSoDpRKB66Et"
    "B2VrcAyV5BbzdLV30HGgk56OLvJ9OUrFEr7nE/oBYRAShqFRKihAhSZGsTSpjE1NbZbG5iqGD6+mqSFNOuuAHxK6AZ5riIaso/Hc"
    "ALDp6StwwbnDee0VYxg5rY65rkcYwE1XjedNrxtPodfFD03UbtmKmhob8UP68iWzUROGdPf63HDVdNzS8zz1wkbmnX8u9//mAZqa"
    "6rnhnddhuSUCzyf09vyp0tZ6bdf/gPCV0WEeL7Fg0V8z7gHfBs4F/hajVPgxxsSxdBTWmVT6yG+ttSIMZf2WLR2bn1nfNmfJlVN4"
    "zQ1T6et5ij/cs4sRI89j5qxZFIq58t+MHjMGS2s2b9zIvrZ9tAxrQSlFGIa8+MKL7Nq1kylTp9LQ0NB/AGyLUilk9b2/py/3NDe/"
    "cRxTJzfhSCQQjLoRhGGIVwiZdukUqhekue+pP/DS8y9y8aWXMGx4C6+78Ubu+N3tDBvWzMhRo0mnUrieRy7XR01tHTNnzOCcaeeg"
    "LE1nRydF3+M1r3kN173mOhqrmnjih0+z5hfPGCIiEHAUlrYphUW6w66cJ+4LWZXac7RcTx19320/cC/GvPEN0flaXXHutp5J81uX"
    "BLE0eGUG9fGMUoRoJDKJkiHcyRuw2Edti4rSv4CG9Adn8afQMHAXl3JtaZeNWmGJWmGb3Z/llqJen+COVSXBIFRIpqPj4kTu3Ckw"
    "hAPcYiPzNeGSEnR5ErcKSYwdExzpGjCu2UoEUSGexM7uVAS7kZN9lAib/utxCz0Np+BaLasWDLkwIYVaklZqdToycbQrdqBOt7H+"
    "Sps2RjuPXTFRUEIoiVCIlAglDDFjzPgqpPVR0hp7b7gSey2cXQG5IpaiG1IhE3V6qEGXiYXqqCQiVVH6cJJUCstC6JIK8rts7iv9"
    "5yU2U/QGkUODz1Q5aRVDkFde14bsotVB3ewodXNK1EoLVW8rOZmlHAetceqsmWspn8OSglBCvIq5Vg+a57TEppiKFGpVGvWdLIpQ"
    "KRA9pHNuZWzkRyUbBQmjuSImsQYTC/0+G5aUx1Wro9R82xBWt9hDqLjoV8+YDRkVN4dDI8KKEFaFKro2xBw7Scxpj3yFBr3vEW/v"
    "h41ZfQqdSbH2/vvYtnUH5y+aTuC2M2r8xTQOn0CY60DCiDwaNZKtm/fwv9+6k3e8cwlX3fAG/uMLPXzgw//ExAnNfOJT/8L4CZPI"
    "VmVo27efdDrki1/6GEG+hLTnDEVactEpB6u2ChS4+T4O7NrFnl076ersoJgvopVNJpulpraa4SOGk8o62LY25euWEIYBQRgQui7F"
    "Qolcb56erj7a9nSxdcNuQhFq61KMGFHH+PHNjBzdQLopi1P0KfQVCf0Avy9kdFOGL956IbYFhQ3dLPvUQ7hBwGf/+gJsW9PR66O1"
    "piqrqa1x6OwsEYbCyOYsHb0lcvkQ1/fp7tG8/rqZ5Arr2Na6l0UXL+S3//d7Ro1pZt4lcwl370cCrxp3/62o7FqU/fwrEdEcL7Hw"
    "RuDdQCPGxKkPY9b4W8yOdyNGzVA86pBT6qi/tx2rdc+evtYNL+2fs+TKqezd28HGjbVcfMn7GDN2OK2tL7B3T5opk6cCMGnSJC66"
    "+BJ+8L/f55+Wf4YPf+jDtLS0sGbN03zrG9+iZUQL11x3bfk9giBgx44djBo1nGnTZnPvvVWsXbOGhfNHmFk5niGVAkJcr0RNuo7X"
    "XXkdPU4Xd//mHr75zW8wfcYMrlxyJQsWLGDL5s309PZQX19HynFYeN75zJo5i2KpxLYd2xk5cgRvfvtbuPKaq6hL1/HSPRtZ+eUf"
    "snP9LkbNGMWCN8/jpTs34LZ7ZFqylNIu3aWevkCkVSl1stpCNgDZ6LyNAKZFBNEU4CngrjOHWAjNDhB6rYsiQCOEEdusKnbvhy6x"
    "Csq7ciG5KOB2pX8HiIqFMGbDLdUfEDiDEi9HscJGrXRErbRRN1lKOJkEQxx0xJ/BRqJdp3CeBastkSVFFXapqDQiHLRzlSBBZQAZ"
    "Eo2TaMy7StBy8M6ZBeUWiS6aQCkjUTxF12qliWMKtSyNWh3v/scmjqdbOcTpYNpoduqMUqGEkK+Y5wplYkEOUjmFg+T1Z2MHGuNF"
    "wOK4/KGSVKhR5lYVGTWmKkofToJfxmcElselKV6FyqQkIcWIHCqVCYZ+9UJlad+hrqHyznKUuEZKpPL4TCtFWtSqNGpJSqmVKVHz"
    "4oTwZBAmh/MlOjtUC2auleh68irm2jg5VhVjKFZppVFdGfR9gVKLQ9EoJSjpV3YODbkwMDbqk5BCNO78QeMrHu8WKvI6qJzvMK2C"
    "lSYl3OJgvBAYIrJKR7FSKlqQREGImhCilgaiVwaEBEpF5MLZWdqlVOoYBkBhtrj7/o4wyGhs7IYaNq9/lnWPr+O8i2biWB1k6qfT"
    "PHIKYf4AEpjYWI8bSVt7H++75QuUSh4f+Yu34pc6ePctr+HJJ9fzb1/4EWPGTuKHP/gdEyaM4OY3LYZ8H44vOJZFGJTQjo2qrUM0"
    "dO3Zze7WTezbvYtivkRtYz1jJ02mvqmBuroq0o5GBSUkcAm9oqHDxPgrCGIk9nGErmpQ1ihCIO8GdLX3snN7B9u3tfHMup3UNVQz"
    "bfpwzpk1kobh9YR5l0J3Hj8QtBcQhJDr85kwroEbr57AtKl1dO/uIxChoS6FbSu++bOtfPNnW7AtxUffMZl3Xj/GlOEXPIpegF1U"
    "vOW1s/j6/61hb3uaaTMm8cOvr2LUmCaGj2jEO9CNeN3ThH1/Q2rkR1Aqd7oTC/+CMWv8ArAeuBC4DNNi8ifRY/kjD0gIQ+juLnK0"
    "5wHbe3pKmzdtOgC4VNdUM3VawOZNv6N9/ziUrsdSB3BLJVLpNJZlcd3116E0/OJnP2X5rf9IdVU13d09nDN9Gm99+9uYds608nu0"
    "bttKqeizedPzOKlnyWQ6aaivRleSHgoQQSlFqjrNtqd3cv+XHmbeW87lTW95Czv3bWf908/wk5/8mOHNw8jl+ti9fg+O5XD55Zez"
    "Zu0atm3fxriJ43n/H7+fSy+7jLpUI5tXb+Gx7/2aTY9upmpYFZd/5FLOfeMsMpkUEy8Yx/rfPEewS+grdpOX3h4UW90jC0EQhDRp"
    "NPbRwuOtwG8wJo7NERE0AiMznHYmEQu9EkStugRf9H0hLEZpLARLTCIxVCFH2QGdqMYcIU9ITkKKgxbPg8yrKpIt45Jtam4rkoeu"
    "FOrmtFJLHVEr7Je58zO4REJFgV5sVGRFNYUWzNPIai0sUSrsIiIXJPFdSHCEa6C//jcKDjBJejkRUVLehcooFUmtTYBrn4JrtfIa"
    "iHwKbopbTzooHFGRueBpl5i+4qaNAmt9MRLFkgg5EfoIyUtIvmK3O5BDG7SFHGzedpZgmYJbKssfMgwkFeLuD44yRNFJSpTeH8LK"
    "yhK9SpVJQaSc4JUIB6hNykoF4ZAxREz/qUgybklMTselOZAWU9KRUWptRtSSjNKr08I85ySWPamzjFSgItbQMQkUkTuqYq5VFedI"
    "Rzv/VkTm+tAq6MVKhab1ZxR7DBWZOzg2KiDl2Mg9xOhSg+Iip0LhlkaRRZZm0PMzSs1LRwl/HD+dbHKBaN1KqehaUJoAlvqw0kPw"
    "REUlHaevN8+QjkVlH+mXKCQtbucnQz83RUTj1FfTfaCNh//wAJOmjadlmEsYjmDYqBlIqYswDNHaRtdm2bF9P5/8xLdJOym+/8N/"
    "5b771rFx3Y/563/6GP/673/Ppq1tvOPdf8lbbr6Wr37zHxk/eRjs64DAAyXomnpIpejq2MO255+mbft2UlW1jJo0heFjx1NfW4UV"
    "uohXQvwSUvDMTCl+/8CN78S19hKtYAJxNXqVVlSPqGXs6HrOu2gi7Qf6eO6ZnTz26FYee3QLs84dy3kXTaJ+VANuZx+FXAmtFOmM"
    "4l/+egEO0LM3j+sKNdUOqYzNrV9az79/+znecM1EMmmLZf/+DPmi8IHXj8PzBNcP6Mu7NNdnePcbZ/Pl29ZSM246KdvmR9/4DR/+"
    "9HtJZTP4uV7Ea3sLdvXd2I3fPdXW1MdLLOSiv4mN/l6M5oJPA49FN//IpILguiFKH31Wqso43a4bbGlt7Sp1dPSlhw1r5Pzz+/jZ"
    "TzZSXX0Os+bMZ9PGtdxzz91cf8Nr0FrT0NDA6153I6NHjeK5Z5/D8zwaGho574LzmT5jRnnS6Ozo4K47f88558wlnxvJ+vW/Z3jL"
    "DpZcOR3H1hCEA46O0gonbZPvKfD4T55m57N7mXvDLCZdNp4llyxmd8duert7aGvfz5onnmbvnr1MnDyJKedM5dzz53HeovMY0zCW"
    "PY+3cfePH2LDwxvRjmLWjTOY9brpjF4wmnRjinTG5sqPX8rE8yfw2H89zbMPraGX7nYrpbeFEh6VWDjGKa4P2IdRKTwXndM88DTw"
    "4Jk0wRVEsIkNgcJWDYvNrqhEwRpDXkcYLzCemFKIQrSQuiIHlULEC76S/gUxXuBj5UJadOQWrkibEo+1KaVWp0XVv9ydn8rgIzbh"
    "UhKZcYmO2n3JPA2rlTDf7GyYunmdkAsJDjH+KQdY/Y+oAePNRIEmCBRTqkSINjtRZBBSygRqQ3mtxiSHpSRuPbksupXrlP3TKFA8"
    "HUwbo3CqNa7JLxBSiEiFvmjnO66bPlJXnMO0mns1Y4mGL2qISAUzn8eEQkwqZCNSwTp5pMJnYlLBkEH9KpP8AGIhHKBU6DfeZIA+"
    "7eDkL0pDK8hDi6gsIiIOU1Er1ywaF9XlwxIftTqj1DxTomhe6Xi/78C1S52V3SFk0FwbHoJYic9RTPBaUQtqEVpNvKFJEeIojSVG"
    "9j9UhHMcG/liiKyimM0Xb5DXSmUyH5PQVgVZlTFjCReW+qg1odJkIjWxGoJ1o7KVqaNMN44sarGn1EQX3VpJpnpw9jQ8PRYmTylC"
    "v++14ra/BQlwqrKIFh743QPYVooZM6qRIKB55FyUlAh8F0ILlRaozfLNf/k5P171B1bf8z/s2bmfP/7j/4+/++u3guXT25bnb//i"
    "bVx60Qze96E3M2bUKGjbYxL/dAaqa8j39bJt7UPsad1ItraBGedfyvCx40hbCikVkWIBkQARcyUppSMfPAulpEKlYAhUkagmZnBb"
    "ahEkCJAgwAKG12cZeeV0LrpoEs8+u5O1T2/jubU7ueDiSSxcNJ766hS59gJhGGAhuCWfwBccR1PbnOF39+ziv7//EsveO4N//ffL"
    "UFU2H156N3/3xfWcP6OBuVNr2NOWx3ZsOnpLjB5Rxztffw7f/eUWpsyYxvPrXuIPv3qA17x1MbpQIAzzWUp7/lLp7MNKO5tO5Qg9"
    "XmLh7zG1+ZMwHSH2YCT11ZjuAg5QOOKEEzHh2ewxvXVY6vJ3te3Lte/a2Td67rkNjBplMWzYcIrFArncdmwnZO/e/TzxxBNMnz6d"
    "hoYGqqqquPSyy7n0sssjd9GBV8GunTtZv3Y9gQeF/D5KJQdLp6ip1YwZWw2ef1iCJ51NUewpsfHhTex4dieT75/EgtfMZewFEwgm"
    "+wwfPpzde3fR1r6XGfNmcPXV1zB51BS6Xurh7i/fz9o71lMquUy8cBxzb5rN5EvHk2nJ4Ps+fsnHz7n0dPbRtaMbt+hSVAVKUmrX"
    "ovfoo0ydMiCBPeq00AP8AmiN/l+MiIXtZ9L85pVbnglK6VYHIU0Y1XALoShjvjK0gXfZId2vqF8tUUksVFgVVQRluiLZiXd/HIQM"
    "iiIqXlDXZlFLArPzU38ydn4GtPdSoEShI1mlMqUX84yMN1wKGiJyQSVlEQmOQjIcLiExhn7GhVkrTTo29Ipr84f4Wq0c9xaQUmpp"
    "GrU8jepyosXLl9Oq9eQrbdqIwH1hBXFaiojTmDwtVZRAJHNCGQ2Rr4JJjqLuD5WEwhCRCreFsDwmFWIJer5cvmKk6MWDlApHbwU4"
    "eFSoigQ3iAaKFQWUnhJcUdG1rfGRLl/pJaHotaKYIMZCipcrZT+RNs2vtrlWjnKO+h3mKavD4nk3Nmm2h+goHi42MoaulWWig0gR"
    "UWVCpBQRC/FY8pC1Ifo2gVtQurwpMpRlEZQVR4qsqJtd1IoSOvpM/V5UZ9cA9A5/1LRqwtv3McJSDVYGVZ1l/SNP07p5Jze8ZiaW"
    "LpCunk3KsQjcPIhGEaIyFqiAG65fwIOPbuRTf/NVbC38y7/8MR/+2Lv4wj9/mSceeIYvf+NvuPTaKyDfDnu2m/fM1kI6zc7N69j2"
    "7BPolM20BZcycsxELA24RcTzEQnpL3axEBURCvEMKNF9Fc2E0XVjhAtHWeVECN2ArGWx6LxJzJ8/jnVrd/LYg5t58ZndXH3dLMZN"
    "aqbYlaPQ66I0KEthWwocm989sJsFs5pY/veLuPe3rTS2VPHBN0/lzvv20LqnwPyZ9diOFRlLKvbtzzFzxigu29HN05v2MWPmBO7+"
    "5YPMmjeZCROGE+wtoug8F7/9Q2TG/i2o8FSN0+MlFm6PbtMwsvmFmFaFf4huPUcjFZQCxzm2y1+bGaO9r9fdv78tPzoMfaqr65i/"
    "MMUD9z3MY488w4KFbyRbVcOjjzxMb28vs2bPpqa6mmw2g+OkIlJBKBZLFItF9u/fz5qnnmTv3jYuuuRqHrzvF3R3vcTU6c1MmzbR"
    "yGECOfwXAKqaslQ1ZMh3F3n2zufZ+OBGJi2awIVvW8Scaw2ZMHbiWF5/zc1k8zXc96WHeORHj9O9p4fJl0zkwlvOY+o1k8g0pMj3"
    "FujrzGFrC6/LY/vju3jmly+w64k9pMRBqgTxpEeHuvtolZfxBXEM+22CaTv5n0ALRr0QnInzW2wwpTBSZjc2T1RxKYIcYvkaGnY+"
    "DsBjR/RD16kODMrKMkZRUTmCwlVCSeJadMFF46HW+rAkQK3JVJgvhS+TXFDxwhmVWaiop0j0u1uUsFYIV6A0EplFhYlhUYITvEZA"
    "CFBlV/qAyt3uU7PRoiKDPFukPoW6OYVaGXsW2Jw+8tZX2rQxPm9hhat75c1PSIXDjbFVGuqtSGWSxfgqVFeQCpmTTyqsM0aNA0mF"
    "HCF9YiTo+Uit4A5QmZzY+atMbMOK6yWIyLk4kTQ/FT50BXBziFqD0hVmKieuXEhwbHNufK6syvgoOj+i+nVmQ2niWBkbVbakPVwc"
    "G1bESHEZlh95GyCsANOGUkfkQkoxJEaU5fI5BY4oUkrdnEGtiDd+nOh6O43I6FM3yx3yYQsp7X93WNq/GFGkajJ07tnLg/c8zdxz"
    "xzJmjKLojqaqppnQ70NCs1llNWbwtEZ68lx8zQK+MXY4b3vbZ9m0o53FSxbw7a//lM9//kd8+h/fR/PIaujcBbkSWBbUNuL6Ppse"
    "/jUd+7YxeupCxk071xjwu0XED+nXKxJtXsTEgRXdt4x0N7qvYrWxkoj4iK4VOTZtivghDpoLFk5g7rljuevOF/jutx/h0sVTWXzd"
    "dGzHothdBK1N9wklTB5fy0NPtdHe47Gv0+PP/v5ePvUnc/nu5y9mdJMNIowclmF/R5EgBD8IONBR5KpLJ7Nl2zqKbi0tw5r55ffu"
    "4qOffjt2dRov76LdPe9VqeZfKrvu4VPV580+wb/bEN1+DIyMHtt3rH8cBMe2jImAiORLJb+zo8vIV6qrq7jiCpvAr+aJJ+opFtMU"
    "i9sZObKFLVu2smPHTsaOGc24ceOor68HpQiCgP3729i+bQf7D7TjBy6NzVWUSr2EYRMjRykuv8Jj4sQWKBVMJHWEGSr0QxSQbciQ"
    "rc/g5l02PbyVjQ+3suC6udRemCGTquaxlU/z4q83sOPFXYydO5Lr/voqZr5hOk6dRe+BXnI7cmRqMqSdNHue3svTP1jHS3dtophz"
    "qW+ow6l28DwPP/RyGl04+rSp8KM6IVs5xxIae8DuV8cCatQJgYqlndFCpvoXN3WKP9Ox7jZUyhp9BB2RDH7Un9o1/hH4sDZQ6v0i"
    "+juiQkRUeUF9OdRJrFwgkqTHrZai1/uiwFqRcLWZWI3nAkjSijLBywo0QzHX59GulyFI2CtreJellVqZFo2DlI0nX+lkWcHNr7Rp"
    "I+XEU/rbR0Lk6i7lRCEhFQZgmYbFOjpPaRRVKi6BUFRF3VBOMqmAmJaSXXE7wphU6BWhT0zpSn/5Q39iJyfxug4GEQyBQKBCgqge"
    "PYS1gvoL4IsxuaCOk1w4SS0rz7o5F4RQiOKjgX4aISe/j/2JxkYMIkNURZcZI1fXoMK1StQ2C5lgI2UT6qEy/433t20FKVGLYwPi"
    "VLmETsokyNk9FyoI3ClSbFtKWLLtVA0o4aG7niDtOJx3fhO+r6iuHoP4RULxTfntiDo2b9rPJ//mJyil+NzytzJj0Xx+8tPP8MlP"
    "fIMlV/0Jtdlq/nPFx7jlA6+D9v1IXxFSWVR1Hb3de9m45m4INOde8VbqGpqgkINInRCFrRFxQEQaGCLBjC9DLiix+nVbKiIcYo8F"
    "Jf2DS4595pRASCvNG26cy4zZo/jVj59m955ubnrLAqqbqsl39eGFCq/H5z1vnMLdD+7mvR+5l2svH8PWvT089PgebvnKYvB9Hrtv"
    "L08+38mbrx5Jfa1DV69QLAnVWZvXXj2Z7/9iE+OnTmbjC1t55O41XH7jBajteUK3ZxTFvR+0qmqfBO2eilFqn4TX2HeM8wVaK4rF"
    "gI6OYqxGOCpyBb/kemFfT09kXOh7YGumTB3P9p0HWLduJZocb3zTP9LeUWTnzk3s3r2b9gNdFAp5QglIp6uxdEhvTzejRk9m2oxZ"
    "/PpXX2XjS79CqSYWnD+a0aNqISwabwV1jJNjRJCksimcrINfDHjh/hfRT2pwwO3YQLYuzdv/vzcx722zkJqQjt3dBB0h1U1V1DfX"
    "0fZ8O2t+8AzP/voF+tr6yNRnqG/IUKUzeKGPJ64fEuQ0Kjw50/ard/EMK3ZDg9O4fdzhzli8OJUDeaHc8zlu2xSiV4Zws6BvIiph"
    "6FcbvDz+OfZ8UJHvAkrHx2+lwHyELlEhochBAUCCBCcSWL5S/cDjMiJHqXkpMa0nM1HrSes0mDsqTRvtV8i0McJaob+rQ2UtfkIs"
    "HoSJGparCul0VdT1wZQ+aLJKV3R/OGmkwmdCWBtEKhJjIiz0RaRC7hCkwlCN7ZhUiA0GQ4nHSogoEFErFOpmRbiYE9ttbjjU2pUQ"
    "DMdO6MbnKCwrOtUp33g5vrguXiNUOVm0VLjKho+bEjbj7zGU5r8xGR3NxUtSmFbFxZjklbMs9j5kyxhRobf/LeJ3zAeNrs2w8ZlN"
    "PP/sNm66eRbplE+xNA7b1gR+CXyFNbKGjr4in/jUT9ixt4NCKeS/vnIXX104hUnTZvGlL/8xH/nwCq6//nxu+cC1cGAvYa6ISmdQ"
    "mRrad29k64sPUN88gUnnXoXtC+Rzg2hIFXkkRA1FVfQzUisYX4XoPlbZY8GUSsQDMXqeqEP7LRztcHkhU8c18ycfv5IffO8RvvM/"
    "D/Cu9y+iaUQdfW199PV5NDem+X+fu4R/+M+n+fxX1vH2107h1uUXEgbCr3+1nb//4lqe3diFZS/iT941hUIpoOQGdPWWmDShmUXz"
    "u3ji+T2MHT+Ce37zGHMWTaWxuQZ3Xx4p7Xq9ZEZ9X1kNfzhTiIVj/pRKKbRWx6xYiF7eC4KwUCx6hrEUoBgwemQVN900mi2bMzx0"
    "fyd33/MIO7Y/wCWXXs6kyRez4aWXsGzFefPP57e3385FF13NsGEHePTh3/Di80/R2aVZdHEzs2YNZ+zYRlKWed0TmZdiHwcnY6Ms"
    "UKGCEqisxnJs9m5sY+y20Qw/dxgtE4bhFz26W3tZ+631PH/7SxzY3IkoqB6WxbItM9mXJTehlKm2YwyYA3yQY1YtvCqTlngxOt0X"
    "zsMFAGUVRkQwhCo0fhGAKJYitCp0vVIhKursoE4CuaDLE3G/G7LAhBBWBsjNoWhCFVISkk4RCc5IHCRvRS1NVbSe9JTCf2VbT05U"
    "cFMcyMblD6lTaNpYMZd29beM7E9IJAqskmt/wLhaqaA+Ll3JYBQK1WiqonIIBzXAfPckYJvA8sp2oIWITMhVKBUqW/ydCkJocCcQ"
    "4hplpVESLlXorToyMtbH1/ZwXjLSTkZsdOas25VldF5kIl0UWZVCPp6OPCNio+64vfHQrBmRB5ZSE52y2bZpjxmThGdNG13lHES9"
    "SJibirvvbSKetjP1eJ7Lg/euY/S4RiZPS+HmM2SzjUhQAhHsKps+12P5P/6Kkh9y1x++wA9uu53/+I/b+Z8Vt1OVdRg3ppHvf+8v"
    "qK3OwL7dhEUfncpATR37dzzHjhceYeSE+YydughKpViaUPlBoy4VZpMsVh70+yhYZaNGyiqGfuXCwJIIic7xCVoRi1BlWfzRBy7j"
    "pz96iq9/+X5u+ePLGDWynt49XfR0FRk7PMv/LL+QD751GnPmNuKlbD72iQf51k+fZ+k75vKW10/imz/ZzHmzGzhvei179hbww5Ce"
    "XpdLzx/HS1uexQ8F3w247/YnuPmPrkV3Zgm8vmG4e95BJnsfQW8w1CPVPlUDUWtFPu/R2+tGaoVjXVZVKKJCz5P+KzwMsbWiod5h"
    "7twWHDvNSxs2MnZMQNu+7Wze1EM6sxvbbuCpJ+sIved5+kkPVIaGph7Gjy8ShLVcdtkkhg1Lm5nWfXnLbUwu2Cm73K/J0hYiwjO/"
    "eY5tT+5g9utmMGHRWNq3drB+1XPse34/xd4iVsomXe1g2TpS2QwwUorZheNY1MOo/dDZ1QjnTF04D/ddKnd+JJKNi4Qo6FKKFRpu"
    "VaLRFUHZyWjjVTYsisiFEIUodVOIXiKEqwNRBweOCRKcgeRCZOJ4S2Ti2JoapFp4hT7bUhXthMVlEOkK48ZTYdp4cFA/sCwiue4P"
    "wlINiy0UtjKmu9lIrVClFNmIGHIU5ZbBJ+n8LB3oqyDkpdKs0SgVTiWpUDl2wuieGz2gCNGKVgtus+AW04no+NevRKVwYrFR5TV9"
    "psVIsSrVF3CVrC1GpEI28utxItWCDBHpGnfR0sLEslICopImObvG4+C9TqUQP/da8bvmKdFYtRmee+x59uzs4L1/NA+lArQ9HK19"
    "gsD0GFP1taxdvZmvfv0ePvjBa+jY186jD76EsoQvffkO9u3v4aMfuJKrrj8XlS8S5AuodAYydRzY8Rw7Nz7C2BkXMXz0HFP6gI5r"
    "qyrOWH9HB6UUIjqaOCpJA6ufMDik50J/l4jYc8H4IJ4YlaQDeNs7L+BXv1nPN7+8mj/66BWMGVlP795uujpcqrIWl14/nofv3skH"
    "P/kH+ooB5587igvmD+NDfz6X5zd2c+t/P8eP/uMiamoc+vogXxCam9JcsWg0v71/Ly0jm3jqgec5/4qZjB3VRLinl7Cw+3rLql+E"
    "0o8M9UpwyogFy1L4fkih4OE41nFPKQeNFz+EwLTqmDWzhjHjLFLOHB56oIPde15i/PgU7e3tbNlyL5deVkP7gVZKXoa580YzcZKD"
    "7wmN9VnwQvCCk7JSlRUVVIxxEUp9JXY+vYu+thwb7t5Mrj3H/s0HcDIOmfoMdspGRAiDgdO/WWwNCyPHNQFqBMHDwzql1XPJwnmy"
    "MSCBj8hYZdqOrtCoZZaSehvTnkkrTspO5iDnfAQdGbix0ldM9CPyKhR51RznBGcfsaCjJN0WSGM6RKTKLuSvXOtJDUtjh31HmWsw"
    "pYjq8k9tUjXAE+NVNK+eZDRoWKHidsGoyKzR+Ctkohahzsn3xbgvhNUhUVvJqJVfDtMJIm557PHKla4cilzQptXsMgt1ixV1KtDH"
    "kRQODAUTeuFE46Qz8bMbHyrwkC5PpNtF6ksImbil5hCvGVZEJFhls9/BCqSzY2aUoG9Q/i4jpLTrrfie5VQ3UPKK3H/3eqZOG864"
    "ySlynRlsO0sQFsyqGgr05pk+fRifvfVNfO/7j/HTn32cKy5bwN133kp3b56uji5mTx2B7uolLAYo20anqunet4G9mx9l/DkX0zxy"
    "BlLIReSADDhbnWu30LVuc5ycMaD3TfT/Se+9NPLuEJSKlQpRZ4gBpRL9f3fEFpTHCi/kDa87l7Rt8d2vPcgHPnIFLS219O7vw/MF"
    "50CB9c+0M3FcHf/5xSVsfamHDy67l807e9l9oICX8yl6UO3YoAO0FnpyHtOmtLDuxQP0lgxh8vAdT/HWD1+DlakiKHaPD919b1Hp"
    "iY9FNUVnNrGgFBSLPp4bYGnVb4hxTJOgWFrjpBw9MNKJknbcAMvRNDXWA4rFSwRlNZB2qtizp49JUzpYOG8SoRQplFxqqmrRlmOm"
    "qGKpsinwSZ8F48FXM6yGqsaQfGeBrse6sDM29SNr0SmLMAwJg0P1DgjRaCy0pVAZbdJGOdYJUBACCbCUfVaFgfIq/U5xcOYJFBVo"
    "kS6bcIUNt9qApTRaTA/ok0cumJHkYILjED0hEFkeoJb7KHylCJOSiARnMLnQn8CrpSmjWohMHV8Zt29j2siEOGgdaNrIKTNthIEl"
    "WVKh4Eiu84PO2bK4BCIVkQgZom4QaDJobKXKSgV18s5PuQTCRSiUFQshBTHlD5VGjafD+uUDJcAW6XIIb0vBLanIGM+SSCV3mGOk"
    "DkMqxDJ1lYzMV31sVG5hKeApWeshi/u7C0mk1WXIFAsAGubbUemFJZFiQYkxvT5r5sfKGSUFXttiKe05T7BQdWlefPQl9u/r441v"
    "nQq+j5ZGtHYNoeALTo0DjRlahtfxN39/AwvOHc3yz/2SJ57ewgP3P8e7330JTvU46Ogj6C4g2sJOZcl376Zt5xOMnjiPppbJSKHP"
    "GC1K5I1XViTAxv/5FX2b9xzxW2RH1jPi2tn9pAF6UAtKK3p8cElEVFrxciJfP+T662YRhsL/ffdxPvhnV1DdmCXXlSfX4/L2145n"
    "6ftmkBlTzQ+//xLZjMP9q/eSylh89hPzaay26OguobWZ/3xf0BmL+bNauOuhfQwb3sAL63ewa/Mexo5qJij0In779So16hsi+sWh"
    "HKmnxP9JocjlPFw3IJ22cBx9TLeUY2EpnXIsq6oq60StIw+x0ngB5AqQz5PJVJFO1UAgjBpdxwXnT8UixHEy1NXWo4MQcnnIF81x"
    "1Qzt9o9A4JmSlurGKhrHN1A7vAZla0I/POw2ghnSFrZKaQurBuNxxLHcKC+06qzy7pdX+XeLndldEYqE5AlX5Cv6yfsnOcHXEbng"
    "KEhF5EJW6WVZpRviXTibU5foJEhwsgNFFe0+OTAhZVQLFV4Gp15ybUwbjZKiXAahYrJDnUrTxsOQDAm5MAgNCpbpaBylUOUSiKzq"
    "P3cn06wxwroQVpsuEFASoSjGX6EYeS0MbLd8+qxfXrRmFZDleWSQB8TRP+/AOCfB2UiQ9HepMeOmrMoRhli1oNCoBh2lnrYymmJ9"
    "to1FXRfd6kFVZ8Ig97rQL2TsjEPglXjoDy8yZdowRk/J4OaqsbQDoYsEIXa1jVQ7/OD/nuKLn7uTru17uf5N5/H7Oz/NDddM5y/+"
    "4lvcuephyPUQ9OYQBZaTwnNz7N+zhrqmcTQOn0ZYypmzHnVpiJUHiFDc23lUUgFg/0MbDN2r4pvRpJQ1u/FjSqOUiYjLz41NIV/O"
    "mQ+EG66fTUNjht/8dA0645BKp/BFka2yyTSlePR32/jvbz/LO94wkZ9++ypu+/xFXHFeC735AKUUlmXk8ZZWFD2fiWPraarVhIT4"
    "vvDM41vAAWXbhG7vjNBtvxIpmWYF8e1MJBZ8P6C6yqa5OUNDQ/qYb01NabJpO+3YuqahMX34E6gU6Oik5z3IueAGkHeNQ6gXQMGF"
    "fMmUUGg1qBbnmKPQE76JCGEYIqGUb0d6fkiIUpqUTmNpuybEr+3nZY/tFuLjSjGphn2VLag+4AmURLqKhLcVokDSi5j8kxlMxsmX"
    "ExEJWVR9lVLLqpQmEzmc25yFC2uCVw25UNF5YWnsZ+DEQeOpJc0OMm1MKx3V5sef5dSTeIcjFJJVxagVdKRWSCtFJiIUKksgbMVJ"
    "H0cCK2K1gochmguEFIjWAhnYGel0Wr88MOS4hK0FCe8rDlq/jlZqc7jNlARnG7HA2sBsgEcdweLYR4b6mi+Xi8abL2fdWFTR7r0C"
    "kd4Zodd2hQrBqk3TumE3u3d2cv6Fw1E+BH4NaBcJfOyUQjWm+fq3nuCDH/0xzz63C9u26Nq6i2JPH//5xbfzg29/kGkTm5DeAhCi"
    "LA0idOx7BiedpmXkHKRk2kmKhBXkQr8D0I6fPnhMX+PAwy/h59x+6jcmEKKbOohk0OVodwDR8DLOvAqFt7ztAnZs7+TRBzaTacxg"
    "a43rGUX+9p19jB5RzdveMJnRC1uYML0RnbZobEjT0lJFY0MarTVKK/xAqMpmmXFOI319OWrqsjz/zHa6DnRhZ9OI71pS2vdaQq8R"
    "CUECczvJGPpSiEEGncc9hWhqUlmnsb4hi1Ih6PA4bV9fJrcdleOIH50DORUTpyIgRCmLTJjBEbuuoAoNFhw4UZY1wasDIabu2zNT"
    "HUWRVWnCW9KoyB1ZsE+iHLDSzDEOnn3Ry1xkhYvqciMX/eCVddFPkOBljO+y2/fiFGp+Gr02jZRNHE9Vj/LYtFHTr1AYoKBQr2zg"
    "mvgrHISyWsGOzBlNCYQxb0xXlECc5PPWbbr09HsrFKNbKSqL8OG0LE+Lpew+4AIlZGVBZHFaCWkx65fFsXkFJVHN2UssRI7mXaEy"
    "yoWYXDiBJOP4SQVFl5L+TZd+cuHsmRlVrIRWIO6+K6XUOdZJZ0ALTz26iWEtVUyanMHttVA6Kj0HrKYsT6/Zw9e+/QR/85fX8Ocf"
    "u4Sa2gy3ffNJvvn9p/jKV9/Ka95+Iexux8+7oC0sbdPXvZXQ76Nl9AUQuP1nQyI6Jz7vYirG9/z+qWP+Lgce3sjI6+aaiFriDMyK"
    "SiIqW1BaFd0kou4SA1pQDjz/23+0ke5nO/qT7WqHc/5sLna1c9BncJTmXe+9iO+tfIjxE5oYPbKe7vY+3A6XxReNoLH+YrbtyNP6"
    "9Wex0ezY20eu4BGKZuq4ahYvaEIcTbHg4YswbXILa59rRyzNgQO9bHh2F4uuOAedEwi6F4GeiVP/8FBZLQw5seC7gSFGTnQGQTU2"
    "D081T55VhdbRq5xCP8JUNZT6oCMP1r6KziRDPHEqhEAUvqrCymSbyXaOltDedCKvVyBHmixWuY1KglcDuRC5I68qId0lpN5FSCHY"
    "Ell+nszFlP72fGlFfRa9zEWWuyg8UQQkRo4JzkxioaxaEEUatSwdKRccFK5SaDk1XRBi00ZHmVt6kGnj6aQKSq7xfrWCBWUfmmyk"
    "WjAlEAzJeRNYFasVjGdBSDE2a4weD0/Tlb5itxlfoISsKqnwOyVRuOr41684uUtG5NlIL6gBSoXBBrNDOFeurVQsqEFrydmBODmW"
    "LF77EhW6tlVbz4E9nbz43D4uvGgkWQdyfRlsO4QwMNdpWrFl8wHyeY83v2kODaOHQ7GH2eePZse/38Mvf7WOueeNIfA8wlCw7DRe"
    "qZtiYSf1zedgKRsJXVA2isB0o0ChygRDyJ471uLnjl3ev+f36xh53byBLSgHdIiQqEQi8l6I4oHY509FLe3NaOhP1Luf7aD7uY4B"
    "7zV660Tq5zQd8nMMa6jm8sunccftz/PeD11Ctsah2FNixIQ6ZmvNh5Y9wCNr95HOWsyfNYy6aodf3LWZc89p5KKvXE1zvaZY9Cm6"
    "AY2NVUyd1Mjzm7qxbc0Lz27nvIsn4qRs3GJ+mEjuMqUaHh4qIm5IiQWFwg/D6LAf/xcIRXQqyyjHrWraeU8N3TVCEB5n78WXEeWF"
    "HpR6YOxcuHY4pGpOXVQlhDRlhJa2anY+U9uwd5eaUJdNn/BrSXzRJDT/q2JJrXBHpiSyqoTcUop2fdKq3IX3pJ1uHb2erSAlkEEt"
    "LaGXlxAqVQthQl0lOAPJBU3ZxPGWiFzoSqFwRZW9S4b4MxzRtNFWiZfJaThulsZqhTTxTZOpKKUZinMmsCJOzt1IpVAS473jRmTD"
    "6UzwVqoWPOgqIb8sIjdlo8cCBPvI61cD0JWMwLM9BjJmjWFFyc+pHvdnaylOGBgdn5LijNA9ME9pgZTFS8/spFQKmDq1msCzsFQK"
    "rULjfxAK9JU4f8EoaqpT/Nlf/IYvf/F1zDp3NH0ln7rqDCNH1kHgI75vSg1EKBW2k8nUkk43IUEelG1mP1HE1soSzbUI7Pn908f1"
    "XbrWt1Lc101mRN2gFpSReWO5NWVlC8p+dUPENLysFpQxFi6cwAsv7OXxR7dy2VXTCAo+xQNF6iz4t3+6kMfWtfPlr63jj981i46u"
    "Ar+9t5V3vn4Kzc1p8r1FLK0JAvMZp09t4oWtXaSzKXZu6+DAng5GDK+FfJ8Wv+1KlRr5dVBdQ3HF2ENzsSljHIGPOMEJ7/aIhHVZ"
    "7UwI99alHv1SFb6UcENML9KhrqPS0NsJY6bDFR+EiReA753CWUSE6qzPxG1ZnvtyXc3jz6kJdsZ5GROxIFqS0PRVtrAGZqdnVYnw"
    "lpIoPGVqVe3oTJ9McU/cgjJyP5+QRt2cQa0qoShVJGCJaiHBmUYsqNgwUYi9FlakKvqUD3XrydPVtDHB4YkgDRNitUI68lTIVBg2"
    "6iE4ZwLdIWJqyyM/hfgWu+PLGUDuVqoWPGS1i9wUfwc/UnscQekxH1itDorhE+XC2RgHDSQazDbmECsWWpMJ0AcsQu/AJYHXOzaV"
    "riIoebz43D6GD8/Q0pLC99NorRDxAU0oQtiVZ+LMRj732av40Ed/xetuvI1LLxrHU8/s47x5o3nLm2dBZx4JfFSqGt/rBHpJV800"
    "pALKKBVQiAr63S3EPFZs66Jr/fGfnv0PvcS4N13YTxxIpE5QFeQCUs49B5ZEyKCSCE54HtJKce11s/jlL9dw7sLxVDdUk+vow7E1"
    "c+c0MfeSUeS7ivzbVx+j7YDHpz+2kE98fC59u/IUiiGWbUHgUygFjBhWTUtDmgO9IZ29BTa+tI8Ro+pRSiHFrtk4vZOUlVlzxhAL"
    "cSLrKc8Yap4gOeHij07rmknZfBNd7TY9fsEQQuVFZOigLdjXBlW1UNUM9aNkiKbEI32PgMlNaabNrq+1lDU5lDADnLCFZxgYj0ul"
    "EnLh1bCgCia49GG1B7iR90IABCJY6uReJ3E9uh0lYJFqYVUaIRWpFvzTw2uhIQo+B19hqwdffQkSDCbNHMWyNGpF7G/glmt4h2zc"
    "DDBtTJ0mpo0JjkwEqQpvhVitkK7wwxgi489VpgVqv0KhJMas0Ytk4WcCsVtuGwh4qFUu8kU3IkgyEWFuHeHgxaRCck2c1THQ/H5S"
    "4ZSO+dbBcdhZh7AE2La4necpP7CshjR79/WwY0cXCxc2k3YswsDBtkNDKAQ+TtpGD6siLPhcf81EfrfqPXz3/9azdu0e3njjdP78"
    "oxfTkLbw9hfAdhAJCYN9OE6DofjFBWUhUkEuEJELytzf8bPHTujr7L1zLePefBGIjsiEmDToL4FAxX4L5sz3qxviFpS8/BaUwMjh"
    "dYwd08iTD2/hqhtm4/SVCAIfd28e8iFtHXkeW9PK333kMv76LxYQdOewbGhuydDTXSIMNZ4P2VqH8WNq6X6pE9u22PjSPi65eDKW"
    "beO6fcOtMDcfp2bNUPgs2Cf7SjeHNUSUkJLUy1i4FUUpTchSNWFEdhh1DQrC8JSFV8qCwIOqevBjr5D80EUpB41D0VDlkbFSjB9b"
    "l21oypxTKgbjlWITnJgyV0RwHJt02jbSpGRVPrPn9ohE8KHLE1nnIfPcaNcnHZFHJ5u5r5SNp5S6KY1qqJSNe69cg9MGjJz8ZuCm"
    "gS7N5SOwAFjLID+IY1wClsSERUVNZZd5PfMzacV3RieKUetJcFATUqib06hV/a0nhy5pG2zamDrNTBsTHDzXxESQUyaCVOSJMbRd"
    "ckJYZcrgzDzvVtwCOTPUCpXholm/pNUT2eYiE3xlSJIjlPOti+bcAddugrPzOnyF1tvVMZlRmUKeVSRDkAcYG7odM0OlwbbZtmU/"
    "hbzH+HE1SGgjoUZJCEGIk7GwGzL8+Mcv8OwzHfzpH81l9qIRfP7C11LI+WRCQeU93P050wVCWaiwC9sugBoDQaG/taOK7ZQryyHM"
    "7w48vOGEvk7f5r0U9/aQGVnX75twCPPGgz0XInVDWb0QqxZe3qx00SVT+cVPnmThBeOpq02R7/RJNWV56JF93PbjDXz6E1fzz5+7"
    "FEouupSiz/Po7XNJaw2WEIRCKIqJYxt5YWMnqbTN3t09dB3I0VifISz0pEOv5wIrNea7It5JbwtxUokFFQgEQhSdvayrTBC0qCk1"
    "un5snW7EC3zC8NQtIgqzwz+AzDnRN4/dQi0FVtQdXdPvJOoFRLb6A9/LCyFlM2ZsPWPH1o578YX2iaBalcI9oaBEhOpQkbWMLEmc"
    "RFx7JiNmTkMBT8lqF5kX93X2Iy73ZAe4g1ULaZOArUyjKHJqZOMVmBiRCUuAmzSDnZqjXcP+A9Ag0k/IhBUkiBz6tZdGRMU8Xf7+"
    "h24tJdAtJuBYBbLyBIiLBKcBuWBFBqUp1LIUalVZtaBU1F3r5I/rM8m0MUHsh6FMH3uo8FcY+jalgqwORMr+OmVSoWxixxlFLAgm"
    "APaUrHWRCa4IvjL+QYcoh1iHmeu7Kg3Yk/n1rMXEU00sCawTqVzbY9PIs8tbSgDxCzN8r2eyZVsQhmx+qZ1MlUVLS5ogMCaHnu9j"
    "WRq7uYq7797OH3/iDq66ZAJVYy/m+cd28Z1vr2Pph89j9jnNeJ15sG1EKRAPaEerWkJR0WxnlU0a+5UKQUQ+Bhx4aDPFfd2HT3ar"
    "M0c0ddxz51omvW+xmXXUQEVCmVwg8l4YUCohZVd/k9K9/O4kzQ1VjBrbyMbndnPBZVOxUjZ+PmBYrcN//eNlXP/GqbRu6mbdwzt5"
    "6pkD3Hn/LqZOquM/PrWAhtoMXT0l/CCkuSlLXY1D3oXuzhy7dnXS1DwawpDQ7V6gq70WkL2nLbGQaiuy932TyV8+nPQDe2n62SaC"
    "6pfjCUDWVs6sBtXcXKPqcEP3DA2vBLRCMlUoUmYK8n0oCaokUXYWGsbLU6ArpqfAhAmjRtcxc3ZLzbp1+xfW16fvtyx1Qm0vdZ9H"
    "4YJmOt4+EWtHgTFffQksRZjSyep8hiJOkgNkbRxsetHjobxs4vQI5ILhD1PKEAupcos8IxuPd6NOMpZgFAPzgSUKJqiKZL/ccbic"
    "kJmfFv3qjUCZJSk2OePgXu9LgOUKFh+OqNCqsg1n+SqvF7gphJtE1PIQWR7AypD+jgIJyXD6EwsqGi8ppRanURPTqNYUCqfCQ+Rk"
    "VnInpo1nHjTc3E8E9SsWUkNMBAmsE+gKAV8EV8ATM996QllRc0YlJ2btIkAt82FFTJb4CJ7EJcvx/C1rA+iKCZSgXJ6UzKpnIRoU"
    "TBg8d58CrC63uyzfzr71XSmHMOyYhV9ssasyFHIldu3sYuTILLU1DqGrsWwh9AMyNQ6FPo+vfWc9V18zlf+34mpq0hrthay6ayMH"
    "ugv8v/+5kVS1g1f0o7aOeXy/hGW3oCiVN2dFRV1gpIJcwJALe+969oifedItV7PxK7897O/3/v5pJr3vynK3h4F+C5UtKGNjxyO1"
    "oHz5lNeCBeN5+KENzFk4nlTappRzmT67iZqGLP/4Dw9w7wO7aO9yGTu6mpQDj63dz6btOS49rwWr1yMIoCqboqmxio6eHmxbs2Nn"
    "B3PnjkJZmjDoHhuKN1nbzacJsaAVuhCgC375st77zol0X9ZCOLkGa2MWy9OInKh1nKJEYVqNqp85zGqx0ipDj3SdecGVEJEKtag9"
    "7bB2M+zcjSqUCHsFZeXJD6snffUcrEmjwAqh6IAlRioRmir64SOqWLBwTM0vfvri5Y6jv60tVTyRGcxSmnxjmtLUOqhx2P2hcxjx"
    "g62k9hYQRyMpTVBlk+DMGmIRudDqS2x+JVESdPK7Q1CRbNsKbJElTkUyVKyQjb+MBGxidFuizM/5CuZVljboCoIjNr2z+qXsZRO8"
    "+LFIMLfEN0Zh5nWkf9cher+V/YRCTEr0ExVWlPyV31sNCpJjNYSSCQHqOz6yNBBuDqDLryAYwmTYngi6gfqhJhbMWJJy68lIuYCD"
    "olS+juRkvmdi2nhmkU/lMgirYt5zTgERJLA2LoOIb7FCLeTMKoOI0V/OJ62eSGtsRFks7/6BLmvzzHPj57jl715Z3JbgLMH8SkIh"
    "XrMrFYVDE2/JyljpGCCG3JIzSyl0Uo5DkHPE650uYaDslM2+PT10duWZOWsEWik8H5QKor4dilK+RFtbnksvn8CwCS2Q62XGFeN4"
    "9zvm8OvfbOFAX4kx1Q7kA7St8dweQt/CsjQiJZSKcsm49EFVKBdEUdzXxYFHNh/282ZGNDDuzZew5/dP07d5zyGfU9zXRW7zXqqn"
    "jDDu/bFvgqqgQQd5LvS3oKz0W9CRfejLw4jhdQQB7N3dxaSJw9BFH7IOjz3Tytf+93ne+sZpvOmGicyf3URdY4YPfPRe7n1kHxef"
    "NxzbUfieYGmL4S1VbNvdSypjs3tXD34pwNIWrufW2W73LBFnPdD3ihELVp8hEnQxIDerntzCJsj7oBSd146CtAXdHlbOx84JUn/i"
    "xEIgwUXN9rApLdZwhJCQEF0RYilltg3j5EXiHpRqkDmhSP/u/qDfyVD3rVQKHBt27Cd/55O4u5+hx3HozQ0nq7vZS4o1bXXopycw"
    "hxHMmdBBY3UJPB/8KH0JPaqrUyw8b2R67Li6+R3t+ZmuKx3K2LIeBxkEdr5I2FGEgg+BkLuohQM9Hqm2ImGtTXp7nton25Ml6wwj"
    "FiI56WpDKJjdrAAI1dAtdv1md6reQS1JoVaXE7Bjc8adT79nQfmngsVUEAhqUPAQlzboKLCPP4cVGd3ZUDa9s+l3Z1fK7HCVEIoS"
    "ggpNki9CiFqukVsr6+ztmDiJd4+j17ZjwkENDGAkOt6xTDkyV1vsKVntwRJPDLkQVATJSRh8XFgB3HoKEsfymHKUWppGLU+juhyM"
    "NPskq3ES08YzD0sUCq36/TD6iYWhJYIEVsdJjEesTjNlEGdyYmPmYXBVTCqExoddFB4Kq8IvyBfznIKEpsXmAHIhwVlE8N3cHxf0"
    "KwqHllRgG5GXUiCGVIivvVDOrjU9DLxhoV+cCKAsTdvublw3oKWlCt83m1mh+IQIpXyRhuZq3nD9JD77X0+gQo/3vmsOXfn9/P6e"
    "Vi6+YBQt9Q5hXwmlNRJ6lNw8jl2NUr4pLYhr0pUyG2XS76uACth79wtH/LzDLp2BEDLq+oVHVC3s+f0azvnYa03OqMzZrGw1ObAF"
    "pdVPaMaeC3GyqV7+SLC0YurUEezc1snEKSPQWoMbMn1qE3POaeamG6fw+ncuAHK0b+thb3ueXe1pRCtsx8ILPESE4c01OPYBHNum"
    "u6tIT1+Juhob+kpV4naeB85TwJpXjFjoOb/J/FGfT9cVw+m7fhREZAO9PhQCcBTeyCy5BU2kWnsIM9aJ1JtkLexLR1qjRzSoRlwp"
    "HUQohIEQuL5htG2F5VimjYYIXskncE2lt522sRyNUorAC/BdHwkFO2X3/028dXmypyHHBisLjz3I9g1bWTNzNttmLkL1NDEy1cUW"
    "q4bN3SM4sGc065/p4Q1OK4uq91PyhtNSq3AswPXRGYcpUxpZeMGYlt/fvmGJ5wbP2rY+LgZAlULyE2sozqgDNzTRSadLz1UjwdaQ"
    "sXCe70oW5zM1MDPc7bYAmRAnsDFfPBStl1QFweAoQyyUd+0im5VBwd5SjGfBfAX16jDkQWWwAEYVUCYUKkgEjdkdLJMAKCNNjksy"
    "KoiAOND3FRMdQhQ6dlFv8JRaFYgsjlUQpiuAKreQKxvpRURFTDhYg2whyy7nygS/HlGgLDKvSLi6hCxxocsTkxRIEgwfd1IVjaEJ"
    "g8fzEKpx6iMTx5WxkWLUQfukeC2coGnjkCs3EhyRUF1SOU+kopvxw1AnfTwOIpBbw0q1Qjm5OXN3TON504/IkqJIVM0c4keEriVU"
    "EAum+1FRhAJh1BGDZC49+6iF/5+9946T47rufL/nVug0CTODHAlGMAEUk6hEKEu2bMKWJdnrQFoO65W8Fv2c3r61V/Tbfd59b70W"
    "tCvvemXZguQoyZagZCWKBEVSIsUggAFgAjDIeXKnqrr3vD+qqrsHBEGAxAAMfT+f5gyAYU911bn3nvO7v/P7tXROvI78YDb1aBRu"
    "a7ee0qFlpa86xozaZI5LmvMkoxUdPjyNFwo9PQFJnGoV5bejWU/wJxv8mw9eypHROp/860f4h889STO2rLlyLr/329cQ2oSoFmP8"
    "EklSw9qEQqEMLsmy27wFIm1GVMmcITQFGg5954mTXu/Sn74eVJn7+ktOCiwcuXcrF374x7MeLJOBBtnXjK0gokztGCOZqqXXpja1"
    "u9R2cwxqSarPPvutjkw+773tv3yw9f3y5cPce/8z1BsxxYKPq8ZceNEga66Yyx//yf0pyX28wfq/3sKOPdN89MNr8ACbKJ4YElX6"
    "B4qEQVobN+oRYxM1Bvrn4FzNc0nzPM/X5ecUWDj4oYtaqBFNC3vrx2V4AlVL48pBDg4Xmff/bcGrJpym6qJxuKv6vYHV82RhGFKk"
    "ptWUrSBZ8h47XOxwiQNNbyICfhDgEotNbKosCsSRxfiCOsVGFnVgjOASh4ggnmCMSekueoYWBtV0ZvkBND3k6CEaS4tsWfjTbNfX"
    "stR7iump87Fzq6yt1Ni1eC+H2M0Dj2zmsFV6Fi/hHZdB4FlopudjvX1F3nTjMm/THTtvRPl8qRQcO53L9WsNDr3/fJo3LYWRKVp0"
    "jxwYUojnFTn4Gxd196yXJbAADh1JYLnNEjWXhaLO0k7bakFQXZue6Eqr/cC0OmNbRdSKzjaD/FRYjtMsMB1AQw4gmI42B5MVd14H"
    "cJCDCt5xlOROEEKBCF0hakhwhMgaH9noo8vzpNTLgIQimR89JvuaFg5hB6BxogQm7ftVnLSF1ZoodWR1HXdrXfW2hjhQJUZadLlu"
    "QnwqxQdoylr4mHY098gsgAstxkIaT7eFIhsKaghRIlHMGSpkXqBo40bg5m5UnKNyBta226LyGMn0XaQNiM4WuJZrC1hNBQ6TTLxX"
    "X8ZKAy13CFXS9RGSvK1OU2/3PK1yHW4YDW0LV7qu0sKrag4KLG8fOmS66CKzsh9kY0JhQ85SiFttSC9vYO+FDmcb8108Pc/3DC6x"
    "HDlSo7ccUir62FgxnktbPk0KwU+ONujpK/Bf/v31/Oz7L+Lhx48yPK+Xta9bTJ+B5rE6iIcRSOIauHTeq8ZZraKouuyMOnddSNkK"
    "x+7bQ+PwczP5e1bOpzi/D3AU5vfTc/4CprefWFagcWicI/duY+7rV6XPUzLdhJaOggeqPPThf3xB923HX2973p9Z+cFVLHrPCgAG"
    "+ot4xjB2rMbihb00J+oUKsrvfugqPvLv7+bXPnw7YcFj+fJePvWna3n7mxfTGK+nWlBGsA4KpQK9PQFHjtWJEsf4sSpm+Zz07iW1"
    "lcRj55/p+Di9hvrp5Fkz/ESznqmYpD/kwO9cyZI/fRRvIjodBwKvqc23z/MWLhrwhlBRrKY9IQg0q00ak036h/tZfMUCgt6AwyNH"
    "Gd0ziovS7XXRpQs4/3XnETcSnrjjKSYPTBJVI4ZXzmXldcsolovseWg/+7YdIHYRxZ4CXuijzr14cCEHFQoBOmWxD+1FDvmsGdrB"
    "0N6v8vWde3lqaJzFPfDEQZ+guI9LCwXmTMCeQ2UO9KzgV662FPMjXwQSR6nkc/XV82XevPKqfXsmL3RWt53O6uk8QRq21bryrFVQ"
    "SI8DkqS7c71MCy8Hm63qjYm0HQ/crPAV2iGTtSSs8TrowD7SARBo6woMbZ2C/NTfz4t/mUlpNB204k6QoJXUy0zNA3+GDkJbZDEv"
    "znJmmxMIkTUZw6I/0LylKgMVRCghlKQNKoQZY8FkQEabWSEzdCQURUVmnGY0UUKUAD7qoRtEGaEDXOgmxKcT47ohOzXqF7QFGJlZ"
    "0hDJ2iGWF1TWFkQ2FRAammqIOF4c9fVFiDau1wxY0FkCVrrjueMCZLWR9jPrXPM8ZvW0dEurr7ujBSJ3t9GX/9wmJj39VHHE2qFn"
    "ozP3uST73DFKoh0gejdEXy3z8LZWK2YHW6jNXJDZiNFbNQOwMrYjkWasoQ4r4lfPfuwtVI361UDUTBgbq9PbFxD4qeZ8YBRnU0aB"
    "8TyKJQ/fFyjAmhuXsOb6xTy6bZRdT49x8YIyxuRz2NKMGyABRvJyrMPSUbNMVwTV9Fkf/cGuk17rgndcnv4/mRXkgndexTP/8xvP"
    "+fNH793K3NdfmjHgDbkgV1tHwZvVe5tU43aB7huWLBjg2MEpFi+egxhDc7TBBSt7+cd/eA+PPXmMSslj1aq5BL0eHJnG8z1EMkMA"
    "FULfo7dSQIygAuNjdXCZRICtnefiiVXnFlg47V1YMLW0n5/wlGfeIh/vLYvNssEe04vzHZ7ziKYjJo9OUewpcfm7L2XJG+YzfMkQ"
    "ixYvJDqW8O2P3cnmrz7KFe+5lHf/wduZf/5cXGK56M3n84Xf3ki5t8hbPvRGrnzPpYxXxzDftdjvNTn6wCSTI1OYotA7vwdPPGxi"
    "X/jy4wGFAsnINNHfP4jb8gjMN/SsnmBpz7e4Ym+VBybezMO1aYoCD08soeD79JYCrr7ScN0FHisGFT8xaeOWEXAWzzMsWzYgF100"
    "OO/AvqlVk1PRXb4nE8+7hiqYqSbTH15F883zYSru7kyvRAQ5fY3np+ZW8oSzs7Q/81M8Awz6A5EVAYwE2SmTlxmcuBkgRJosFqTd"
    "XhB0MBDyxCBPGjpFGTu1FHLnh06dhU4RR8OzbSEd4AtrfNU1PmzKtCHSFgdNQYgihooIJQyl464xBz+81ueREybI+VergkUJRAlU"
    "M1q73iJwW2p37NAsKe7qLZxa4eFg3CobHXozOdCUxbnMAriQW08GyK2FTEMkRIhFSF6k9eQLEW3U1G5vsx4Xa7PVFtIdz3pma9sF"
    "TV7UtBlMs3n/NbNYTMUbU4AhJwm/3IvqNjCuRAguK9w62WydP5czF+wr5PN3x+nNwZz5mB8i+BlrKGc3zsIc3OJgQwvMAqKMLRNn"
    "Ao6vtj1c1A2ptWEgAbV6xNR0nYWLy+kunACeS7XnHRRDQ7EnZN/hBvd8axdPPT3JUzvHuP3uvdz661dzxe+8BjvRQB1YFxNHEYVC"
    "pa2r0Jr9HcdkGUgQV2MOfXf7yYGFt1+evpekTIe5r7vkpMDCkXu2sur3c0ZEzo4wbY0FPbtPet78XnbtGUWdQbwAiIkmmtjQZ3io"
    "xLFjNe6+c4SnHjvKocN13v76xVx35Rxq002csxg/pKenROgJhcAwOVVLgRLjYeOGb9zE/JcNsCCJor5w6N9cyvAXRijsq+IK5nk2"
    "GC1YtasHzOCqheFiUwyKjE6OM3lkksD3uOB153PtB17DxTdewLHoMI8++QgTMs7rbngdb/6NN7D9vp30zetl2ZWLMVkrxMprVhAU"
    "fc67ZjlXvPtS/AGf3Tt2M12Z4k3/9nWUJ3t55J8e54EvPczhp4/QM1imNFDKGBKnqd+uCmEJqg7/kaeQow+w/2fn8JXwJygUHG9Y"
    "/EXWXLmLP4iUqu0joIaVIr7xKBcM/T2GwUKWOai2V0ir4Dl6e0OuvHKe+f49ey9LkuZwqVKYOFmQi1PUN0z80qU0XjucZsrNrib9"
    "K7HwAkVVRpxoy4rL0m6DmC3egrSKIF3jIyMBGXtAZYYyrmRJQChCSYRyR/HuZyeAnayGFlggMx0gvBmOEG0hRzkBmHCCpKRfkBao"
    "UBBBNG2D8oGStIGFXF/Bb4EVJ3/vzrIiM4NJARNNXQbSa9R1wG2pmrRgM0FJ6bIWTinGMxrq+iQDFtIiI2WvnOn4zp9zJqp4U9hh"
    "PRmpEGcFzQscL0i0UVO2woyOXtOa29J1j5j9ombNDNbVDMHGWZfZ3NTJQksyAPnFMmdeKsO15lyqT5NzwY7XQJvBDuuCsq+2MSCw"
    "0WQ5QzCD5TXTsekM7z23aAc7pomjmcVpzkzUV9ke7lx9gUN9Y4RGPaIRJfT0hOl9UMU5xanQ1+tzeCLhE//zh/xo2yjlUoFndo9x"
    "4ECVf/3Lq/nAe1fipiOsdRgPkjgmSRKKlYCZ/lnaop2qanoir8Kh23ec9Dp7Vs5lesdBWkdW4oEYivMHaBwaP+H/k1QbHLl3K3Nf"
    "vypr6uXZFpRncfT1lZiejkhihxEPryxMNGL+6I+/z9e/uZNi6FF3lr6ekJ17p6k2Ha97/QL8Rkyzma6sPZUgPdgTQ3U6IkksxjPE"
    "sQMTnfHUYfYYC1lLQGP1IPrNfZhE0YI8zwR2PYq+YXG4rLfYKHHswDFqrsay1Uu44l2XsOqtF7PsNUvwQ59SvUBiY8R4eJ7HBa8/"
    "j4UXz2PLNx5l4eXzueED1zI1WuXO/30Po7vHeeMHb6A8VCJKIuYPLmBO/xxWnL+CkAJzlw2x8Mr5/GjjI4w8tJvxfRNUhkpAIVXi"
    "PB0NcPWwmiBzjuKuPswzr72GB/a/gdrexUTTx3jT/Ns5v7KDUuVaZhJZc7nnVrVxHFin+L5wxRXz6O8vXHz0WG2RH8h2PUl2KxZc"
    "IMTXDUPFh4brepe9gguvVNxLZvSc5nIys0Xeym0XPU01C7yO01ZzXISnSupQQCh3FPG5PkKncGOnEFOrqJfj3/NUiv2ZhaIH/V7a"
    "DkFJ00JOSE+NiyKURShiUibFKQMKz/5daSeT4Et2mq4Gxa22IiSYzL3DZcJP3QT5+WI7L6hidHOMbgFWO1KnBlFB5MyyFjqtJ4PU"
    "ejJ3iKCRFZcJLwwUeqGijQobNT+pzU5t221EesZtZbvjxMBCW4Mjd4lpt13N3hxQWmr0HaCC45VjX9u5Bj6fXVt3rXxVggqbBPpz"
    "bZMUkG2Lp84SqPDLDjbnbIWmtl/Rq1g41DaOLERFRDzq1QhnHT09Pi5Jz2NTgMERBCFjkw0+/42n2LVvgr/9+E004phNd+/hD3//"
    "Giplj+quafyijxEliSOsQuB5J2AGZO4Qrd5WYd9XnzrpdU7vOMLm3/vcaX++o/duZe4bLk31FbK2i7YFpeJXCiTV5qzcW78SzPyz"
    "79GMLXFkKfkGPENTLVufHuc1Nyzhvesu4s//x/385r+9hieeGGXnU6PU6wlB6NOMElSEUrmA8Q3GN1RrMVHTpto1qunpzMsGWMhX"
    "/1qCVJO08UbkpBoGCnM8vGvnugVeISjSe0kPi69dwBU/djkXrT0fP2xfbk+ph8svuzLDMBTxhUvffjGPbHqcO/7ybuavmMf4oXHu"
    "+qu7ueDqlSy/eikAoR+yYsWKGb93cPkc3vArr2X5a5ay9Y6n2f3Qbg5vP8TUoSbOnoaphQjEMRSFHcsXs6W5msNjQ7gxQzAacMhc"
    "xx0c4KFgLzeefxErKsVU08DaVIFUNeWPy4mBGhFYecEgc+dWzhvZNb5E7cmTWrEg0wkyFUPpBblzdMfLsADLxbBcC2CQWWQstECE"
    "NbkGgX+cUjOZkGN+2pcLJJY7xBE7wYPjC/lOob4XYyeVX0OAUASQtBwzHVT0XKix8/pf6O/rbMlAwCIkatbG6KYmQhMhymj13VT5"
    "eWJb22rcsbJe0U/b7L7mcTUbrIUO68lbC8hteV99gL5g68kXItqYgQrjuchdZ2+9p3JC2ZzuOLOxALIiV6IPOhTpZ9NisqPg3pSD"
    "CLY1F7TVg/xKe/bdWO6O40EFA6u9jK1QyHKIQvbyM1vSM8wb+ozCBpexFaLMCrWO0uBVLhzqXEWymmSqmjIOCmFAnLhUi8ClwMLo"
    "WIMV80P+7k/fwqe/tIP/9bePcuhIjasum0tSTyCOUXWpHkPgEzuLs+CJee6VQVMhxcnHDtM8XJuVj3fgWw9x4Yffg18ppplgXrpm"
    "jIVr/+JXqR88lq7ImjtDZCo42ffb//KHVHeOzXjflR+8nMp5vce1ecwcna4QQHq4nShxUykXfHCWYuBz3oIKq65ewE+//1I+/4+P"
    "0d8TcPklg9x/7z6m6wnDZQ9TtYgagpKPH6RzJ44dUeIoBIKqS+vPlxWwQLoLNs7rxT/WQCKLenKSvVsWFKRwXrFe9uZeMcT1v3Qt"
    "a953GZ7vP089n77nmp9ezeiRcaaP1amO1/F9jxt+9jpu+PlrWHbVkue91KVXLWbpVYvZ99hBbv/4Hex95BmSyCISnOJWJ+BivIJj"
    "b7CKvx+/gpXRbgb6dhC6BDt9EbuiNzFZ+wY7n9nKb112BYO5hYqcSnOYMn9BL/MXVAbDwFuUxM4Y8xz9Gg5sYIgv7EUDYRY1/Lrj"
    "pQMqbG6DCmcHSe+wnRzwMg0CT3NBRs1FddtFmsy0aSu0hBFnggfMQpEIqTZDkDll5F7pucNEQFsI6kydfswoThEKQisZCkitOePs"
    "Z2w3jJ8nvlOxrAjdoOh6D/pFW4wZjJz52M6tJ4PUevKWArKhkIFCflbcyWnMsxcq2qhwWw4q5H2+eVtEqiHSbYU4C+DCmtYal+kr"
    "zLIS/fHgAp0Cjg664q/d8Uof6wQ2GOjPGV6FXGRZhKKkbYv+mQf4PuPgFpcByM3c4jR7NdURaVu08dU2B9XZYt720GjEaUuiL4hL"
    "7RjVJiiGxCUYUV5/9RDXrZ7LP31jN5/+4tN863t7uPXf3cOf/V/X0lfxaTQsThUX2dQR4qSbeboSHvzu7ln9jEfu2crCd11Nqxei"
    "w4KyuGAOhfl9mc1kApqp3mTWk6oJfiV81nv2rOyn77LBFiBxSvuOEaxVmpFNo9w5ipUCYgw//OE+mrU6PeUCe3ZNsXBBGd8zNOoO"
    "6U9/v4rgBx6eMagYrFXixBIGPtY6RF5ujAVAIsfRX78IJ5b+b+3G9RdOOA0d6nt4C0tSHihqWXqGe8FTDj5zmPJAiaAUYgSCQoAx"
    "HmIktYs0LV4M884b5mf/5L00axGKEoQ+1//ctccFpLTQtMRZXJzQrCU0qxHRdIOpI1XG904Q1yI8zyBymum+CmiT8wYGWLngckbv"
    "q3PZG3/A4f4KW8eWs6DRx8I+yx2793HtgvN463A/RS8NlpMDFiDO0d9fZP7CHi8Mzfzp6bgnCLwTGqNKPSE5v5fxP7wSmU4gdlDw"
    "6I5X9BjPlYs7Ra3cLFpOQqu/e03b8SHTSNBnMw9mijPmTg9npygyeQkogmha6CNt4Ue/w5nizJ98p+/vq7bo753WnN3x/CMHy5L0"
    "BGmDBx8RSVkyFsWHM94OcJz15K0FkQ1hKuiYWU+enrOHwLoXINp4l0NHrOY2ZxBrJskqaUuGUTI7rC56PFsAalrctK1u22vF7Oor"
    "ZIXLeL6udxYz3ZWjO17BgMKtuVBjDiqk7Yqm9Srmzixnlq1wHKjgaKhSU6Wmjrq6V73NqY1rnmSgahKnmabJnBNEFbUOFcV4HnHi"
    "OLhvmt5KyM/95DLWvXs5n/z7p/jeDw9zYLROf38v6hQXO6IkzpwXTra4Kcl0zOE798wusHDv4ymwkAk4pqpheUvEcRaUKKjXXpXl"
    "uTyCTPt9MJxKI5tI6uYQxwl4Hi5OCJxw1ZpFPLN3DK+a8Psfvoqir/RUAoZ+62r6Ch5RNUG8lJUQ+D5h6CFGSRzYJMGon7FLzrwT"
    "oH9WojB2aCPCJhGJeCdsh3C4giBDZVMp9M/pl50PjPDE95+gZ34vC1fNo2e4gh/6DJ03yMDiASrDZfoX9NA7Nw1Kz/gEYQAGCpmI"
    "yPHLjENJkojJw1NMHJhkbO8ER58+wuieCaaO1Jg+MsX00Rr18TpeAGJ8/GKIc6e6dGRB1QxZWpjgN1Y8zNe/XWTflwY5cp4joQlH"
    "hpjTt4yLeYav7R3lsv4KK4oGGs/Tc6EKzuEFPsPDZfzAG2g0a72ITp6w1Itj7HQEke1mH68GBPm419kW9UqFETnOvWGGgOMIcFf2"
    "/RqF/s5rP1vFQUplVoxIa0nvFH+cjT7NjsJkhvDbTIus7iQ9pYQmU+GOYb1FPyJkYE2r2Dvzzy+Pi0BkdaiypiBmcwGlefrWkwMC"
    "N88UbZQWU+Ykoo0bciZSpyI5GaBgWm0QXVBhFteONS3dDWba4c6SEv3x2//mNgttZsx1V47ueKWACaSuD+sEluegnU/Gcsy0mXrE"
    "UMG0WimfC5B9gePjDm7NAbwoYyrUcNQ62yBe5Y5Oqg4jBlXFutTCXsWQJEpo0hYtdQ6rYPy0lWBqOqHWqNHTG/KRX76YW376fOLI"
    "MjXWwHgeYEmsxTmHaKog9Fzj2P2HZv0zHr13K8l0A7+n2GIrzGyJMDMsKFO9pRRckOds+W8DE2QClM8fQYIRD6cCxsPGgokTfvFn"
    "L6NhLWHdcsXlg9CI0cSxcEkv8XiDKHIYz6AG/NAnDAy+UeIEXJyJbM5SBJ8VYEGmYibfeyG27NHz7RFsT3AiYCHw0P6AsOCT6gE4"
    "Vcb3TzJ5cBoRxRiDX/AJKwGFngKVwRJ9C3oZWjnEpW++hG13P8HB0QNc/tZLufoNV9OoNnnk/i1svf1Jrn/ndQwtGuShL2/hiTuf"
    "wdZjGhNN6tN1bJxav+FSwUljBC/wwMipW4s4wPchCMAYDJZlS5TrbhrmH79VQPomWCjjeHY5E3Y5q0oP8p2jE4w3F2f6B89TlXSU"
    "j319IUFg+mLnyn5ygutLIuyVw8QfWpU2ZLpu6vFqAhdcLigk2qJLz2bq2xJWVAY8GDcdnu4pxV8ANii6oW0TBg7WWHSdB7eC9M9W"
    "G8TxxX2uOXG8RZzM4l3qsOZstYR4mjtbaIaId2nNzxffOWMhRkcE7kK50RelkAEOqfDhmRVxFMjaIYQwtZ68JW9fiE7DevLEoo2m"
    "o0f4OUUbN1hNP3ekShNHnB3qpF1uXVjqLIyBme40neDp2WmDyNOMXF+h2wbRHS/xsQJYe6I9MLONRGANqUvO6vbPdNhLy8z2h3IG"
    "KvRkrRCpk06nntMLHhPArS7TVLBAU5W6poBCVdNXLWMrJPCqc4I40cokqmmNgU11kNThSPv6Vdv/Lp6ApBaUE+MN6vWYciVAPLA2"
    "dXlwWQ1mE3BOkZMgRfu/tvOsfMID33qIpe99w3HAQN4SQdslQlPmgkgHuHCig2LJ+DeimSBkfipwEnc/EYwniBjQrJ1Bld6CodcP"
    "iKdqRMeS9JQBhfE6imA8g0syAMQTTHZDBWkxLnKGycsSWCBR7JJekoEC3lgd2+Of4D6qAfVRI6KC5xtCr4BLLDa2OOtSqkwtpjZa"
    "RYzBJukp/8JVc7nojRcQ1WKe+vpOkiPKvL75TI9Wuf+vf8TR3UdZceF57H/0ID/Y8EPG9k5Q7Cmkv9akD80YgxcY8AXPmJTJkluc"
    "nEr6WUzAGJiOYDKBZkRgmlw/dISnVi1hw6GlTAc+583fR60xRjnq47LBXgb8jMFxGrVfGBiMMb5C8GzdVMG4CDWCu3QOHKh2t7dX"
    "EajQacc181Rr9sCFdsEsawyyyZuZQMzA3loFEkoT3WyEzSgbDGw2Qr/H6bk9vNBCUU+E252dscmIzGgTEbpnzacT57nWgMJ6hBuD"
    "7AQ/FGnF+2xYT3pAKHJzIQUXxkOEQIXkFK0nDdz6AkQbN2hGu43TOUMzOy3zgKQLKpyV0VnwmIxt1FkonY0xg62gXcZCd7zkx80C"
    "N7eBOFo6Mqpti1Fm5AupVk4O3IUZs6tIqqdQPs6qOjwzLRB3pZaSjOTtDxEpqFDFMaXKdNYK0cx0fmxHfvWq3IfV4dTglIxuL2iS"
    "itA7dRi1OJeulema5RDPIE4xBpLEMTkZYTyDZ7y0PT1xqUSBKja2+IUTl6fVnZNUR6ZOen03/MN7CXpKWUuCj4gH4qfMguwr4rH3"
    "iw/xzF/c/tzAwjcfzICFDPVX6bCg1IzF0GF+22qH8J57J2m5S+Txc/JIUs0O7rwsO5b0PZp1RZxN/+ylQuT59aUubApeWpY6BMWl"
    "Un5exnJ0GR4yC0F8doAFASabxOcPUH3LMgpbR8E3xxfEVpC6I04szg+yD+z5Bj/w2sVTviKpEkcJUS3m2O4xHvvWVhZdupB3/Mrb"
    "8AJDfbqBs5YLr7yAa979Go7uHeWxrz7O5IFJeofKeAU/1WkwZgZipJpSRE5px859VQ2Mx/0cO7yTvoNPMOfwOPGkz3jsk9iQt+1/"
    "nB2jF/BXF85jd3GCN9qY8xdcy7uXL2BBKBDb07qZ1oGqntBpytgEd/E87NsWwbFGd2t7FQMMZ4OtcHzxldOF2yd56fLZUjSnra5s"
    "SMUTE5ERH7nVV/m0R3o6nNONZ6vwP9HJMHAbMKKwgY5WjTP4+7ecyO2iO043xtPC2qEbUXb5osvjrPAOZlHE0ZNUbDNjLdyWCy6e"
    "ivVkdkK3PG+D6NTZOJloo4P1eQtErO02iLTPXlqill1oatZXuLXQ1lXofJ0NcDKPLD0OVOiO7ngpg3E5COd3gAQZMbi1anUeJOSA"
    "wvEaNEVSkcZSxlwIO9rHXkT72y7gttT5YYY4cCrS2AIVUrZCg1ywUV/1808kVE0aOOvwPA8RSJxLD4CdouIy8CjVBzCO1BJa0npc"
    "sgNdbNoukTt0KamwoDuJsOG+r42c9NqGrl+EX/YzcURJ7fEQwGatB7YVecOvv/CkwML09gM0Do5RXDAn/+AdFpQmAxu0Q29Bs2bb"
    "59qTs12jxXSQlobDc0eUYjD4XgCmfQRhTA7NaYv12haFVMRYDAbxDUlsiWJQ9QiMxTPgbObeMQvI+NkTkq7FxKuHqf7Y+YRT4EmA"
    "6Xj5EtRFzJGG1huxRilKQy4toGmwuk6JeaFQKdAzXEEd3PWJe5g6NM3lP3YxCy6fx5GdR6lPNuhZUObaD7yGZDrmwGMHKfQUKPWX"
    "UtFHJRUZcS69wU5PfbXQrLk19LGhz9ZDwte3Ndh0uMZm57iHEl9sLOJTey/nibECP77iAd4/8DVe09zJ2xYt5+cuXcVVwyWK2PQY"
    "95SsINOfmZqKiBNX9Y1X83xD5yuwCXrdfOzPrIBa0t3dXnVIMned7Q1PZi6ZHa82MJB7sMdAQ5VqtmFPZq8pdRuq6iZa/Yt6VhXP"
    "JxTWZkXcRouutehErr5uOWMOGxueDfp0x+mAZlmxnSaBKUi1IWO/tE6SZoOimp+6+UAockuhw9mkDYSddI7cIpklWk7tbbtBPLdo"
    "o2aijR0sH5qaftZczK87ztL6Jh1rm5D6gJ8dIG3L8evG8QByd3THSxNYSEGEUKCYtTH0ZjoJ+atXDH3Zq188+sUwRzzmiMeAeK2/"
    "68sEGwuYlpPUCwQVdgG/rLDCwoZUzz9dVxtkuQl5XmKpqqOegQoJbRHhV/VeLEGkWV0WeAZRIUok1aB3GfOArJU8Exp2VnHOZTdP"
    "cepSkIG8vgPB4KzDuhMftibVmNHn0VeY/5Zl5Gbr6bH8cXaQeUOZOorzeulZOe+k73fk3sc7IrrjJR3NcdIBOYtJGRInikyRVjtE"
    "2hKRvYc8N29VFTzPxw/CrP41qQA5gmbaFprPBklbJVQ6BNvFkD8rVcWYlLLgcGksz4Kyuz8La8mJ9zkjUI+RyKHze/EbtuNGA2jT"
    "wf5ppsfrVCu99IlgcCTPebLnrENEKPYUOTYyxlN3Pk2z2WTswDiT+yfpndvHtnuepGduLzaylAcrIJDEL1LQUDV9uJ4P6kMt4sjB"
    "R9keL+VA/9XsGigy5ULGmxUOTVfY3jPO+3q+xh9se5ghD7xV84FpaCSnxtvV/D4J1sYc2D9Fo2EPl0rBWOC3KTdiFe3rQUoejDV5"
    "nqO703FJ646XTeklre/yk62zeZiZT2fRtvZCzgiyCFHmfezUEWUntoGmtPACZlMRuakski2UGRo7y2f7CusUNudOGlbZ7NC1wCaD"
    "9BtR8haNF3E6MkHKhMCpnoBZ0h2nWGS12iFsCj6t99CPRiixpGCDn8XLmfTAaQt/go8uz60n28CAts5BTvAsW6KNQYdoYyhte9MT"
    "RXinaGOkaeIbZQBDLmqW0+K7hIXZL5JajCyRDsHXs8I8Gj/hutFdNLrjJT5fvGyPL2FQcfgY4myt7AQf8rU1Zyv4uR1zxkzIBRp9"
    "6RQ8Pu1l7y7SNXVD3lbUaeHbYipkYo2ppoK2mApxu1zt7sPO1ZxLWyKKBQ8jQrOR4JzBemDwcBaMySn6BjEGtRYnDhEPUSHBIWow"
    "nsMmHoghSSxxFFMqPfvA9dj9h0lOcmDqlwOGrl/QsnJUyTUFJMtAhdwkWjImw4J3XMEzf/Hd53zPdjtEFrFC+nlwKG3Wwky9heda"
    "nFMAQFs/S6a3AM91fKVOCUJDoVgE56XtFiKplp9mh+KZk4ZkDAgh1VoTFDyPxDnQBFFLGIYYIySJzfL0Mx/RZxpY6M/uzgktEKlZ"
    "Ghf2ceC3r2DJf30cEzvUk45Eyu6ra23PmBudP+wvCDw8Eo1PunGrpkhX/6J+po7WKBQLrP6xy0kalkIpZOVrlvHYvzzO9u+nYh+F"
    "UpgyE14MqGA88ItQU9g1Dvv2M+QeYdTMw0w2KE0cZYE5xBXBXuqUkT1Psfju7cxZcCne+y4FIqhFp8hSyFJMI6jxOHSwysjIRBw1"
    "kz095WCqUyDETMQc+62LaaydDxPxydb8YvYa79Y0r9zi6xwUrAOdxXfnxp9TtuPsD4kokeaFWibOhG5OMDcpBiOaihtmffOzmLp/"
    "XGFT3lsZZ6cXFjYD6wx6Z6CSJTiKe4HgQtbDOd5qCdG2CJtq/tS643QgtCQ1bRqP0c800ZtzUa1ENaPayhnXWvAyEccgAxZy5kGc"
    "iTieiGXTYitkYEB4PFtBTqizsSsXbYzb7IzWqZnJxCq7gMJZBhaEDovJs9/OlAvzzpwJ3dEdL8U5I3iihJrZOquhKDxLk6aT4Zgz"
    "HPzse7/1d/JCwf27gI2avkb0OEAhIV1fmxmAUGsJNqZfmx1rbhdU6HhmQe+4jSZxNqFcDvACQ60e4TTEJkroZ4tVXnxn2aiYVF8D"
    "p5mNYsZoyECKwICNlShKTujsd/jOvSe9rnlvWYKqawsn5q0PGSNAsWnxnYMLWIZfd/5JgYXp7QeYfmY/PRcsmrkhqGQtEcfpJki+"
    "Lj+HeKN4HW4SGeiCos/REuGco1As4BdyxkKq46D5qWEGJGirpyEVkEyNK1LwJKrHWYuKUCz6BEaIE5fdE++MbyKnByycrBAWkLp9"
    "n1h3PSX/c1ryvoPwboRtwJ706YLESjIQsvf3LoOekOG/eYaezaO4SgBwLCa6d1+y+6oV/oVBWco09VQWMChUQg4+cYiDTx4i7Ak4"
    "NjKGVzAMrxhkdGSc2pE6Xuinz9++iDvm+VAAdm8nunsL1e17GR/wuHSVcGHhDu4cewvuaIFbdm/msme2QqkXrQMXrca8+1pYMQCN"
    "2mmACp2f0uepJ4+ye9f4iLO6o1IJMuqR4k/F7P3dS2lcOYBUk5mhKSwDLsVwP7Eulqn4Q3iyXcvBf0eIu8vkK6/ominkeHaSCEHX"
    "CGzsTLjlWdeUbs5eVjCZLPmIVIhFNqumSUYAeGLwZqFnvmNMOLgt7a0ko5q7ljgesMmDXy4gny5kG0iYFaycXnLzcQcbc+HKvEhs"
    "t1l0QYXTjW/XceoVqW5IgYU0psLMSvRMW0922g2GIjeGyIoCMhIiLevJE7EWctFGPxNqDGewFZ5ftDHpaIGIspYPX7qIwlkHFTh3"
    "gqvHg8TdFaM7Xg5zJrPpRTRlG6RE9GcfFuTAgnSCDPKiraA/kwH6dLARW210MbRcdhpZG0RNHXXtFMltCzV2QYWOwrE4Z39c3W2T"
    "xHqlgkfgCVNTEYlLmVViU8DACalgIxYVxaiXV8s4I2mR7ylO05P50PdwqjTqUebSN/P3Dl0//6TXNf/NS9KVMtdoEEkBBG3rKhyv"
    "uVCc18OCt19O49AkM+REJf3q95TouWDhcdFNm7kww4KSDDTwWPCOy2es3n4lpGflcBrhGTjQop1JR5u/zmQu1OsxhXKJICyiUTPD"
    "MKRFR5YcNFHX4VjhMoXGtD2i0UxwNs00K+UAYwTrLGJCxITnGFg42WamoIF5QqrJLxDHNxOaSWnYDxCYhwi9vwUZa91IEeKFZZhT"
    "RJMEmW5iez3EMe6L/83d8Y5/dYl/5aJKsIJAfGJNMCfpYNUMCbNRQmOijjqlPFhMH6dT4npaO6fqpS+qBwKCgJH9TSa3PMVAcScH"
    "33YRG0ffwHWmwGXh59gz+DCXLLqG11x1Lew/D8IQyiVYOoguLIE2MmTDnN4qHabUom/9y3YOH6reF4bek+IZvHoMRtj/by+hfmU/"
    "KoLErm2uLSAx7yCxb1QjfVKzF0s1WeuGCl9HsN0l8pVbfHECgGE2k+EMXEi/SmudbRVabbGmdlospC45qRgd454oAUoRpZDhyj5n"
    "/vQ5ux/rFcZtVpDWNfWprmeWUukCKRuKIiNOzUYV+tG0X/Q0hCX/2MFtncr+8XHgwqtZXfrFxrhN79ymCN3VxC1vIpn1pMwQCDuT"
    "yXIq4igUkNsKmFsKKI3MelKOs446XrSxk60QcFLRxg15XOaijanNZBozqVaTdNsgznrBNJOCLWcx1lt2wt31ojteJuBCCywQWv3c"
    "eqJ1VWY6rJyJeaZwcwYq3JIzFKJ8782+z3UVGq2vrgXedrY+dOfbcc/MqxxFJXEu8cIwoFQIqFUt1qUOEE5tSsW3BjGatiRYsuIX"
    "RHzUZqwBNRhPcHGC53l4ArVa1BKG7ByL3rOCRe9Z8TxRl8sZS0vAUSVlJ6QtEZLR/wWVtD3ikt99J233CC/TQfAyDQTTEQEnishO"
    "C8qsTR5lwTuuZMHbL02zFLWgCahFNcnYDV5bB0H1OSwoDeMTdXr7+zB+gIuiTEshq3s7GA4i6efV3KdTHUZ8EEO9nrS0CsslHxGw"
    "1uL5BpGgdo6BhZOOfpw7D2WI2F3EeLNoIl2mVhciTBH4/6KGw/nuKE2LTjSZfNdSvOmY0hPjJMPF2Kh5aFonvvFU/NgvDnnDYZ/p"
    "Y1zHT0iLmRlOKWDhBT5BISBpJim9xkISuVSZ1LzYvkQBE/P0sTKHdgyzbOlcDlx+ATseeQsThyu8o+8Brg5/iOsfYtuyt7HqNTWc"
    "NtN+IiySNCBKOKlB67NWRwvFEKTAffft5pvfeGYsju3Xe/rCPd5kRNQXcuy9S5m+fhgaqYZFB2YxQOzeRGLfZZp2qVo3j1iXYegV"
    "pxepsgVhfxeMfeUUWooOZBq1M061zvbGaPJkQU+cIHf+jaGl50OQnc5GpKf7VmbNTm9CYX3aApH+zjrKVIdXtZL2xMfIJgdrFLMe"
    "4aYcXHieU5QtCrfmbRaxQjNLYOqafo0zkUrbTVxOP9Y1o7RmJwWR6m1N9NN54hiKZqyFM1v65cmvDwQi60IYCDPryWZ2wJLrImQ/"
    "3xJtDLOWn0JHG0Sns0DHHPlyW7SRlmhjnAENjvbv6Y5zBypwFsCF52IqdIo4dkd3vFSBhfahQrrWnUgnTk5Ssp2B+XOzhU1JymrL"
    "AIQ2Q6GpM9lgUYulMNOyuztmDufsYSSoJXGzUCoX6esNOTJeJ44c1lNcJtronLZo/mIEsVkBjEUya8ZcqyDGUgx8wjCgVmsQxxFe"
    "GJz+E8/d+tRlxPC8xaDNVmi3RGQ2jNm/pUBHzkiQltVjevKfR3NHhGbtCzMtKOlwifA6NBc8kE7XCD2uJSK3oGwfBToMR4/VWHHx"
    "ihQUcYJK3hTkUvZs7gIhBpUgE6xM3Q5NANYJ9ekoFc60Sn+5BE7RxCJhYVSC3mdmI/8/jZVCnvvliSdOV2B0gMQukInoPTgNSdxC"
    "6snP0Uh+EcfKGS0ATUvthvmMvu98GqvmYCIQZDyQwv9+Otm6ZXv8BE6VCj3Pu4Uak6b4jamIxnQz7X2xjtqxGs1qM718Y87EjGLB"
    "kMMb6uXx+gKe3N9LoaroWJ2DtRsY9ucyMbWVu/c/jcNiXBOJpqE2DdFpMBVSugUEAZgyTz41zif+x/12z56Jz4VF/3sFIWouLDJ6"
    "0xIm3rkodYBIOhTzlIXStB+QavJrJHYZ4Ml0coPUk0sxJhSr52f57bnjd3bHbIzVJwqlszRG5ASJxfOFVdufXTflGgf519k6MVDY"
    "6NDxpFXwp4BCVR3T2Wsqe02rYxo3MqVuXU31qgb6mabqLvtsxsEWUs2GNztY42CTzZKVPJnJxaEauBZjoVsevPCiy2XgQoxubKIT"
    "zYwJkswSfbVtPSn40J8yFjqtI6WzAJ0h2vjsNgg5IfCRi4ulFpNZ0qvtpLfbOvPSKZrOZqwfDy50R3e8XOZKDqB6J3jl/3am51Sr"
    "9VL5dISua6hSJd3TJ2c6UlHFtZiK+RrbBfxPWnHtF1M45hKLJ8KcgSKNekIzhth1CuRnbnsud2fo4M+mwgqpTp4qNnPoq5RD6lFC"
    "vdZEnXthT147hBQ185HS3CWi7RBBh0NE/m8tHzB1zFAsUz0xJJa1IqSAicl0FDpdIryMCWE6It5r/VynSwSt90jfs9FU6pGjf2go"
    "S5Q75U5N+jvFO+59vfY1eT6JVer1OqKK5xl6ekKSJMa5BPErO7zivCfPLbDgyXO/jIwSmG+qJw9iiSTBR7Ufpw2cG6Se/Bx1++so"
    "F0Fu/y1woEb9+nmM/uR5+FMOwaMo5QfqWvvso/GDe3YkT1OQEoGEz72hagoaeJ5hbM8oEwcnKM8pElYCju0ZJao38bzsIeiLXKqS"
    "gCsWTnPZFWMkxTqTB2Oi8hRL3T6OHFrDYXMT86sJSx/9Bu7osVTBM1fZajlgnBKCAZ4HQYVde6p85q8ftF/d+MR9hYL/PwueHJDR"
    "iKk1Q4z/9FI40mxHumBUWSqR+3mpJr8sVhekzdzaR6wFrFoMT6tvvohhN4LrAgvdcaaAhReadOcUX5cJ8M2wedRZARY25QKAUau/"
    "MlWDrpOzChw12kDDdPr95qq6W+roioaqRKoSo5KkrzUJemuSASSRakfvZuaHTfqeKWMhLR67rhAvJnEkbzEZj9CNuWtCTEp9nU3r"
    "yRQs4NaCdAALM/qCZ4o2Hs9WOIloY0uPI2oxeHKwrUuFf2mUSh055eyPFScCGM7R2JCd/6lJsxv1X36vDX5HKt5Ne17Ze0QGEmyI"
    "0DXNDNiv5q4POBqa6irFXT2FUx/OHsMUDsU23WGHh0pEUUKtkWBFcdZCBhQ4dahLXfxUHc7Z1P4w+z61mnSos9g4oadUwCXK1Pg0"
    "LrEv8sm7DpCg04LSZkBDCirMABO0/fMtu8rn9PA63oKyQ11ETEcrhWmDC5K3WGT+JscBDJ0WlMeONegfHKbU0wvWtYGHlk5Du31D"
    "JW9Bzq0nBfFDolpCvRrhVCkUDJWKT5IkqHPWmMp24/XuOrfAwvM+S/0hpeC/0Rc+gBGPultBooMY75DgxNTjD0jN/jbCRSirgCJG"
    "oJYgkcVVPFBwOHpN/18fcgc//2B8T3OP20lFejAtCsmJwihVGXWRI6pHNOsxzVpEsxZlh/hyBnYPARuBDHBRz3LWyRRvjTcxPP9p"
    "pgoeU1MBD9SuoTB5Ee9+bAf+Dx4Cz6QAwWllIAq+wQW9HDhY41N/cZ/98/9x36PlSvBRga224GH7grTimkryz+WhrEQ43zTtLTId"
    "fwirJTyzRxL6qLsVqCu6Xu8J7Qs+BnoHkHRXyFdq6isnSIPPVrp9+jZsM3uI26cFs1V0K2zKXSBym6lGJtwYtWz90t72OtpiMEx2"
    "MBmqHZoMeXtDm5WQel9XO35+qmVh5TJqu3b5CmcgcUz7ZyFWXZ8/v1SLYHaK8Lb1pBAgy0NkbSGzkPQzECFLDV6waKPL+nzTPmDX"
    "EhLLLQe741U1lp/ttfy5QAUDN2fdx6l1KnmLj3k5vW4OM6vYgJw5dKaT4e54KUGAkjrWbXAw0NovWloKMwGF7vp6CvtuUjsmYg6o"
    "gnOW4cEiYoSp6RjnhMRm6GPnqX9+QuQ0AxlotSzku18UJxT8gCDwODoxjY2iF54ZZKyFlCXRCRK0vLlmgguaZwwdAEQeES2g4TnA"
    "BemUGO1gIRwPGrT+LgMXxGv/fev/y1orJOTgwVHmLVyAZwJckjoStgwvnhXoObiRlvZiDPgBk1MRcTMClHI5oFQMSKwDE0R4hccx"
    "sv1Mx8eZ01hQ0EIAIj/Al0/SjK+QuvaJ6iImo7la8n+ExxjN+CKEXyBxl9IX/AeUR5hy1K6aw74PXcSS//4Eagy2QK1sKh8/mOwr"
    "38U3/s0bw7ez3DufutZpUs/upZlxY41niJuW+kSTqBHjUPzQT30+z5TpsyrYJoVFS1hcW4l56l/40aNf4RnzWwzWI4JJqK+4iOrE"
    "I1Qe2EJy5cV4SxamRVYSPzfAkIt1GKBYBMo8ue0g//W/3MOXv7TtwSDw/wPwPW8isgc/dAnRJf1ow8JUDIkD3wxKLfkDMTQlccOg"
    "R9STo2as+SYNvCLqAkLTpCf8J62EXyWnJ3XHK2oT7RSCOx5cmO2kVJ8FFOhp///ZvpOxvrTjfeSMXqeiI+44xf381KKTbt7S0Mk2"
    "SSeKVZMBEqYlwucdd30274nvEIXKLawaWULTFYY6Y88yBReQzRF6VxO9sZkJgFoVjOgJBRJf7FzLRRxD5NYCsikvsiIRjLJWX6xo"
    "Y6cTRNby4boFUHeco5GDCiYDz3yZqRMiL5Nz/xS4k5sdbEjQTTZjjmVCsN3T6jM3/lhhPbAOuE0zgOxsCZ9KK27TDngPVvuwwYN1"
    "5rico8saPM17Gw5MmKS+Q9URRzHDc8r0lkOOjTZYPK9IiZgCqXuBtYrJxAnb4t6CyboljElLeTEmYzdYhvpL7D4wQXWqil8sYnzv"
    "BRalri30kbMJtLMIb9tOpsKOttXIqNkeTSaoqNlnaL/X8Tclfe9OC8rxiWk2P7YdcNz42otJNRfyyPMyEbJcayKrUzNhsnrDEDVj"
    "huYtgCTJ/k0Q8TJnspzN4aUagyqZrkR6NGcIwRhGRyeIohjrYE5/gYIv1OsxhkLNqyx5xOtZtPelCyx0YFkE5uv0h8OY5Dexbh7G"
    "NAnEYV1ZEjE4+qWarHGB95NaMBXQx9S5qcbKHvb8weVowWPe/36Cwr7qHjsQfOyIPRrf0fzWh64Jb/BX+VdQpMAUUySa4GV+JKqK"
    "8YXmdBPbdJQHS0wfqTK+ZwK1inhnaBkTgaiJlAJk4aXM317llv3j7Hjj0xw5PMw36wvZmizmmRWLWP30U7gHtuANz4FSAWxyYqBC"
    "XcpsKJaAIs2oyZf+6Ud8+q8f4kcPH/gnMfwPE7n7xbr4yO9cTuPKOZnnKaCEiFwpTXel1Ow1WvSexFIUS4mi8TU0daBXy95R7Qk/"
    "raXgU4hGXe7fKx9kOFuAwskAhtMGFWYkfzNtKs/UJ9EWXt066W5TzZUZJ91CSklvge2AxREhNNLJl516tRPrdqGrmZp/ymRoUdq1"
    "6wZxpuOt7aCgG5rojXlLRCCKfwJ7szMD4mWggchNufVkgBCoYNFbNCu+TkO08TOKjiQdoo1Rh2ZEkoNdXSeIczE2AR89foU7W89i"
    "Jhvs7D/8NsE3Xe8KksZzkGqNtIBVeRmsFWQgQkvDRNq9dooi3XX5jN1rhfGMhbUhAxk+0lnwz3Z+IpmddQYAUxC5qYDc2kTWRyod"
    "e32XCXZawytiwoHHRfx61IxLvZUKQ4MFDo3WaST9RCiVJF8fHS6rz3JRwbT4zd2+8snnEANxHDOnr8TufeMcOTpB75xejF865Usr"
    "XPKfAfjL//zj/NJPXZnqOEgqEokK4UV/CED8zH+lZTuJMLLvMBe84d+zfPEQO36wPgUXcu0ElRYm8ZnP3cEv3/oxbn7/29nw33/3"
    "BCu04cvfuo9b/+iT7Np7eMa1/dL73shHf/smli8eSD+95iz8HGRoOyfuOzDK3IWLqPTOQevTGcMh/XcjtA7L8/9mZhQtt0oTpCXn"
    "1LEpbJSQOMfQnHLqmxHF+OWBo35p8Enxy2ccS/VPc5ae2moiHCPwvqgVuUomGjfhodJ0FxO5QIveg1qQ/TLmClJP3k7Ea+nx/0LF"
    "+xqeobFqAIxy9IMXMufvnqH09OTT0VDhz8bc0cP3Nu/41XF3bMUV/msY8IZp0qCu1VQ7Uz280KM5HdGcbKQ2JWKYODCV2qH65gyy"
    "FoCoDj09+Ne9nkXTEyxY1mBi+UHmjMXsKcY0ppaiiw6gO3ZBvQaVEm3D0xxQSFseKFSAIomN+N6mZ/jyxq3cecfOJ/fsmfhHPzCf"
    "K0a6rRl6TP3qxTSuGQLfINNJSiNyXCpT8R+KEEpkh7XHvwP1+qQRvQllHp5ExBpS8TdT8v9JjOzVl0MG0B0vZKzoTALPgWzGpuOB"
    "ghdyGqCzBCh0vP8Wl/WwdwpF2izh1Bm6vDnYoRmbInWqaGqnYF876QZabIeEtsVVkgEKCTM6/7rjzCSvLYeISHRDhK5vov0R2rKe"
    "NGd4EuTPO09aCylr4dYCQhMZSERu1jbwcFqijTYreCIlZdEoxErXG/glGHdnq6CXdG0f6XSmkM6k/KxcS6YVIkJZhDKGonSKlr6c"
    "gMi2fkktX+W1W2Se6fuc73Up20pvBTYDn/aytbNlRzmrYFi6DhdEsGpI4GMJbLKim/M9PYeTunvyqQ2DIGHfVi/o3dNsHrmor7fC"
    "0oU97No7Ra1m6esVrLUtWn4KKEjqRgCpoKNoiwmqalp1dZIkFMtFBgfK7D04wcKFg1SCEOOdHmvhd//kdlZfMp/VqxakkaiCiOuI"
    "T5teXsZU+O9/dTsAu/Yd464fPM6Nr7u8w00i7z8Q1v/lRgA2fvP7jE9MMdDf2444gVv/6H/z8exnjh+f/cLd3PIzb2DF4qHMNaLD"
    "JUK9lptEZAMOHzjMla97MyIe1mqmvQAqLnOQ8DNjzTxDTa/VZIwJ8X2atSaT45MkzhL4huGBIrG1WBxhaehJtfFurR894/FxesCC"
    "PZWlJENNkH0amr/3Qu8SmnYN6kQDsw+fQKrx9TgVPEalmlyjjp9lwOwD9kotOYJ11NcMobFj6PM7KG2v7XJziusn3djeh6P7bp5w"
    "Y2+8LLjKX+wto9f009A6icYQpM928tAkex/dR7Ma05hopDYnxpy5TEAEYgu+wqIS0IdxU8wpRqztPcQxykTRQhJ/APoVfL8tCOKy"
    "1S7wIAiBkEYU89gje7n9W0/z9a89sXfLI4d/MFVr/POC+X3/0hvp1MSAR/Wnl9F4x2JkIkr7gjzpx+p50rA/Y6rxm7QvuEOcWqkl"
    "VxF4VS3IpFq3WBxGC2aXFvx/BLaSuHad5rrb5ysTWJBzJkjVWZC/ENFF1RNbUp3hMd4W/ssAgJMIN7W949NN0Sr4KLEInrY75OS4"
    "n8+1IqzmoEXXwmr2ElhaLJGm6oZI9CMt60kUH57HsPiFggspkTEUuaWA3FZIrSdvsZo6ZRdoMxZOJtqoqWjjply0sYnSzJxD4lZr"
    "jr6MyrdX3BjRzvaoE6x5s722S+a6cy7Wdsni3M+YCmUMPWIoSzuuX17AAjQzoV7UYZGsza0L+J5J4C1lBbaFZzXV6VjhoR8NNBW7"
    "9bIImw1wwWTvHYiiKjghfdbIRqdmjcWN24zm3hVSPo0R9CHCdlMY2J5U919krWXZoj6UfYxNNBkoF0lsWsxaVUTBWU3FBY3iVDA2"
    "BRfUSNY+AOociQMbJyye18vBw5PsPzDB+eUSplw+rUucmGryq//ua3znsz/PQF8JxM00dtCsGMssKD/zT/e1/mnDF+7mxhtWpS0Q"
    "LQtKYfPW7Wx5fGf6/pNVNn7zB9zygbe3VuRN33+kBSrc/P638rH/+1fT362ODZ/7Ln/8Z5/LXBsy6ds84iT/Pj12OHBgjIHBucyZ"
    "txSa1fT+4KWZjpiM1ZAby3e2eKT1qRjADxk9dpR6dYrIWnorBXp7Q5I4BjXOKww/kOqVR2c8PE4PWEhObcplhUGMyLddb7DKJDqo"
    "ll4NZFQSXS7TyXI82a9F/0emZhdSt9cR2N+XUH6ovvlzhIhDdRpXz+WYEeZ+djuFI1G1vzjnM5M68fSj8UO/dtQdettl/lVLzg8u"
    "oWJ6MBgsFsowdbTKE7c/lV5yZDNHiDO9YqXoG7Vqy8sUDcG3DIUe+GWaPYvxrhyGYhmSbNkKghRUEI+JScfe3Ue4++6duvFLWw9+"
    "/+5dj083oi8Pzen9clJL9vjTCfG8EtUfW0z9Z5YjB+q5IKghtj9O0/6URHYJqqNa9Dbje8vNVPxGreghVzCHaWoguFB7gn9UX76M"
    "6nTqUNGRLXTHK2gcp6kgZ021HGBLO/FWnM4EGU49HZFnAxNn+DNoy04qe2l6vZbnTiqPZ1E4UsA9nY46Q6wyvw/uOEDCnd1C5FWX"
    "yLZaW0TXNzUHFiARWqwS7wzPNsmcIHzV/hBZFyIbisitTgSn6elu/jqZaCOwXrN4jDMByqYe76veXbLPJbDQObf1LM/lZ7PQOj3V"
    "9az8/vzkNxCh2MFaKGSshZcTsJCg+GoQSedWhBKpdKzl3XX6TOyzNmPs5a2A2T29LURWFISbC0rmpqOzBi60WngkP7gwWFiewIYE"
    "1jkFJy7LWbrA/ymVP14BjDfml4YfE6fvrjci5g5XGKgUGD1aZ+HcIg0soSdZPugQzbj6LmVaqUkzIqcexjlEBfVAxBBFMZVykQXz"
    "eti1b5TFC/oohSGef3ol6yNPHOZ3/+R2PvVf3tMqxtvDtUCDL39nCxNTdfp7S0xM1fnsP93Lxz76r1pshFxv4eOf/AoA/X0VJiar"
    "rP/klzJgIR23/tFfAHDTu25gw8d/h5bNpSi3fOAt3PL+GzORSJuBApm+gmbfixK5kAN7trDqtW/DGB+NY8R4HQmxtkQvRQzaAiiy"
    "dg2XpIx943Po4CGiZh2XCMNzygS+R73WwPiFKVOaszlnTcwOoPfCd7fn41079c3nXF/4ZxKYB0zN9kvDlSiYbVryt4vTZYL2itCQ"
    "hl0l49EHUb0CZRgjRTlcl8blgxz6jUuwvQFOHcbJ94tUPnLYHvyTuxrfeujOxjemdyfPuFgjfAIKxRLEwvjOKcZGJhFPEDOLW17L"
    "GgQwmpoZNZto6AiuvQj/igsR41IQIgxJTMDkFDz++Ch/9zePxL/9W1+b+P3/45v33f6d7X9WrhR+beWKoU8Y2KPDBVxvwMTPLKf6"
    "3uWwvw5CiNIrib1YJqOflanktQJNUfFJ9HxX9g9pyX+M2DmpJUMGtmlP8Aktep9BGGvlIV1/pVfqWHFGzE9eWBIx3qmToOiMgvwl"
    "mfgorROq3Nby+YqFvIDN2ybiDkptE5e9OgT36GQrdBOW2SwW8sI8gZEI/XKzQ5/Ang3rSeTWosjaosjyEoaSCMWMrRCcomhj0qGr"
    "0Nb9aIuJdiPoXMVWi1UyQ/vlLI610uFYnQPHZ2vMpJXTcoQoiFDMWiIKL5NXsXXNhiJCpzuEdJOjMzpnHKn2TWq53HZVmlR765S6"
    "LTVNWVmJ0rHGzVbspqBYgRQUq4jcVBG5tSztNdp0OWGntu8ZHyMeYXnxvZ5XnqpXq/RWQs5b1sfYaJ1a0zFlU/cHsZmtpHVgFbUO"
    "m6R/VqeoTVCrmSVlWjBbqzSaEUvm9aPqGNlzDG3U4TTa2f/wN98AwN9sfJT/8ZkHmKnixQyXiM/+0w8B+K0PruXKVYsB2PCF79HK"
    "DjPniI3fvB+AT6//CABbHt+RiTNq688A6//jbzDTgvI4l4gsc2g5Q+TWlKbArh276J+3kKFFK9HadGoliUFEUoAht5LsdJrI3kvE"
    "S78vFanXI44cPEzcTPA8w6L5PeDARg280tAuvzD4WPr/nHmpRTPr64uyT3uD/+XmFv6b6w8fcCV/v+sNHteKv0em4/cwnVxKYJ6i"
    "YDbRTEKpxjdJw/0BTt+mhl6ZiIgWl9nzB5ehviCpb+pkRXr/d9GUbh5Jtn/iO/WvjWxqfEv3JDsx1tDr9dJb6aFQDs/+9q8OnEN6"
    "SpglQ6AJBD4UyjSTkIcfPsx/+9N7+Ne/unH6tj/8zg9++MO9/6F/TvEXF8zv+TNV3eUSRZyS3HoZ+//8OsavHUYONUAoAjdI5D4s"
    "1eRmmnaQQO4j9LZQT5absej9LpC67Q0e0VKwh57wUTcn/Asc/wnHE3RbdF8dwMJxSeBZ3CY3pUiizkgq3CkU6+cq8XHMbFs4nSvt"
    "ZCTkwEFCri7eZj90Tz/O7jOdIeLYceo/m8COZAlpILK6gKwvkVLEy5IWLyU5JdHG8Vy0MW4BVTPZCt04OueF0ohTWiebL8T55kWM"
    "Aeloueosf8+enbBsyVNZL4vnIDsJ9pGX10vY4sNmT1I72JbbvHRhhTM1Wnujtm2bqymowKS68Sl162roRF1dBsLP3n7ZblvLGDcY"
    "ShgqYm4riVlTEpPZBbdLte44yf0MKkhQwetdcr9XnvdUHDVQlEvOHyaOYqYnY2pOaCSuVRahqetBW2ZOW1pzzqWsBlVFXXqCHzUT"
    "Qk9YvnCAHbtHGRudImk2Tvkab7xueQtc+N3/fDtbth08DphIgYVde4/xldsfB+Dm917DR375zQD897+6PWUXZFaTGz5/BxNTNZYv"
    "mcu6d13Hze9/SwoifPJLgLLp+1vaifjSBSewoMzgrRkWlF4rMhHDVA0mxo6y8oo3InGcMt3FaztakLPvM5+TDKxI3zMTqfYMBCUO"
    "HThMdfQoiVX6+gKGBorESYJi8Erz78EE+2dr+/LP0o7kVDQ2cTJoppLrmNArNJAJFQm06D2lBTMhwjBGAhruQtQuMLEs1pJvKfh3"
    "itPI9gdu74cvxs0NGPzrJ+m5b9TZsveEIfpvtux/cwdPvWe/7v2ZpWbZiouCy1hqzqPfDBJpg0gbJFldLWfceOz47MNlsL6ACcGU"
    "qFbr3H33dv7la09x7z27jh3YP/Utp+6bgW9+4CbjQ0bjaVB1tRgGChz7v68i6ffTVdkTD9UCsa6SWnILjnk4pkWkrJ70O08OScl/"
    "FOsW+WONNxC7XjAV1xs8SMlPtOC57k75Kljo09dAp9Xks6mzszpGnmUXedYJw6dcIHRcmc5ocegWby/34q8l4rgxQnc10eX5yb8/"
    "SyKOki33gQoFkdUWEDUoEAgUMKcs2jijBaJDtLHb9/2SACI3ATdqS4tFc5OwWS3vM5HGNa3UUiTXPTvbW/taYJPA6pd5SrEl+yzj"
    "3fPp2Z432mL2NVWp47AKXqpnMQLcgpgvGdI+/LRokudqFztD4ELKuCmK4NT0J+gGi6xJELp6C6cIGtkm2Wn8oaCy4Pv10aevrk43"
    "WLGkh7lzihw+UmVwzhwm603m93lYly5YLq/AMoFBZxXxSR0bnEnFFR04p+AJ9WbMwuEK+w5N8uhTB3ldpYB4Pl4QnNJ1/tFvvpHv"
    "3b+b7z2wm5/58D/zwMYPdgSngjg++88Ptf7qg7/394xPpuBFKuK4jbU3XAoIn/n8Xa2fe/N7/z0je44AsPGbP2B8ovocQddpQWmy"
    "HittiTR2ijda08/T277Lsouvoqd/GMaPgAlSc1wElbxtwsvmiUNbM8Vm7fiCKRRQq+zduQtnm6gYFgyXCX2ParWOMYU6xr8zaY5H"
    "KWjycgUWALH6mBa8P7FD/vfEcjE2WaKeOaah9yPELJCJxjulZoe0HKgG5hFTT67D8Wtq3evxvYcp+l+MFhZhsMD4j6+g9pr5uMHQ"
    "miP1ows++dRdUVh/ul5s3L7Dq77zYLLvxxcESy9aYc5nob+EfjMHUaFJnYamyJo5k5hkC1AQKJVAioBl165R7v7eHjbdOcKWzQef"
    "2bdn8vaJo9VvO6JHegn394pfn/yF86mu6od6glYTvN6A5LweGG2Ac2D1BmnYdSQMyHTyGtcf3kGiZWnYBSax59tS6aAbKvwDkbuM"
    "xC6m4o2qbx7Hl/uw+lB333xVgQtr0sQzP3mRswIqZBvw5jYDQGfoC7xUC4XO5Kc7XjHFX6eI4/oI/VgkqW5BQbTD4moWwIWMVq0Z"
    "0OBoq5GHpyjamLfVdLbSdAGvl8Zaocpmlz1XO0v6LycBF9aYLHJbJ+sd4IKelfug4w5Za9E1LbV/WGFTptwa4KZzwaQ4yZggBYM2"
    "K4xnX/O9ajwXFsyf5QtxMOqOU1uT01hJAdMYRVRwOAQ2Gvi4gY8YMS1wYbaO/9otEamAoAokmNUJrE/g1q7ewqkNWx9Ld1LxNags"
    "vMMv9N5cr1b7BvqGuOKyuXzn7r2cf94A0wKDiUXEw1mH8Q3OgdjUWtIhGCeISWeeSzL6kJdqnSRJQuAbLlkxzH2P7OWJ7Ye5bJWP"
    "mF6Md2o13Bf+/L1cu+6v2b1/gl/9d1/riM30zPUzX3y49Xffu3/7jP/3M1+4lxtvuIRdew9x133bUsBh7xF27T3SXmQmq2z8xr3c"
    "8oF3tP5uw+e+PePPKQiTiS6S2kZK1p6JKOL3sPOJLfQOzGXB+VdBbSpjNZCJFhqOd39IWQ55q0b6ZwNIUGL02DHGDu/FWSEIfBYO"
    "VUhiS2Ij/OLQDkxhS1w7elqtJS9JYAFlDN/cqQX/h2p5s0zZ35eGvUiargdlrsSuqCX/KfWMxRBIonPwNKJmX49NXsccwOoBrSb3"
    "Ryt6XbSiF/oCpJpwdDIhDnX/vG/s32/3HtsyGhz7Xi04/JZDQ3tfP9cuvHRRuKy4WJYxaIboZ4CIiJgIqwkv+Dw3V5cTTVsdgiIQ"
    "4lzCI1sOcN/3d3LP3XumHt1y6PG9uye/P16dvqdE8mC4aO6e2o8toapKUrXU37IQu6ICDQuNJI2dpkPQKzRxK6nan5XIXUbR30Hi"
    "5oL24JNo0ewmcefLeHStGBlU1aUaeAm9wd9q6H2eWKckSrq8vlcPqIB0tEKciDI7i8nDhGZJW17YuY5N+SWrsdBNGl654EIq4rih"
    "iftYU4VYMtZCttafaRHH3Hoy0PQ0xs/AAAMtO77nOIW7LRcSjXTmK+5og+iOl0JkyWbXomzrjFan2eQsZGt4PzDgwbhHTtc+e3aT"
    "He1t4xY2RUATxScVZbNpF/CACLca+GjbDvOcMCt2AbcqbDyejZa35yXH6ZjklsPanWyzuy6TsrDITmwzAeTbPFjnwXIRg1FBZlnM"
    "UTrEHEsiWOQjFtlokU1J5uiTegZ0Qd0T3kO/kH1jMDJ0vykOb2uM7rx+ajri0ouGuOPePRw7WmXhojIT9YjBihA5gcQhkrpz4Bxi"
    "BKceGIcYDzGKdZId/KYxUK9H9PUUuXTlMI/vOEx/b8jixULQ24ucgtDMQF+Rf/rz93LdT/01X/3u0zOi8q77d7J73zj9vUX+6X/9"
    "QtZW4LFr7zi/8vv/wGf/+Qf82Uffz8c/9S0AbnztKj76f/xMVvR7fPmbD/DxT32V9X+5kVs+8HZufv/b+Mznb+fWP/oL1lx2Pmsu"
    "Pz8DBwwTk1Os/+SXWH3ZCta981pa/pricfToIepTh7jktR/AOMAm4HmIZvdLvQw80JZlZssktUU6sJlKtWHvyE7i+iSJEwb7i/RV"
    "CjSjKBV2LC/8rhfM2alu9upD/+yvLloFfUyMeUhwlxHZZQhlit6jWvK3osyTqr2BpltCJbgbNJap+H0ayEcFOaKh+ROJ3UGsNtS5"
    "vVr0o/GfWSGIp+PWw9tZOUjJ39g8Fn238djuN435+27clzx+w+7+FRct61k1b5FZSi99hFJAJSDRhCQ7F+JUIYZ89/E9KASAYWoq"
    "YcfOg3z/3t1861+ePvTg/Xu3HT5S/Z4hvmuIwv2VKxZW3ZBPc9Ug0c+tJHKO2lgTGgrHmqDq0UgWi0oPgfGk6f5Paehq6nYOvjyI"
    "zyOSuJ8wk9GPaU/wIAPhg1q3x6RmL0PdBXhyhICnVd1m1Ex1d8hXJbiwPO/37rRAPAuCjptzpsKJxAq7kdgdZxcs0lzvYjxCPxOh"
    "N0f536niyexZTwYiGCWzt8zPFVLniBOcwk042GiVVnHT7GAszJbgZHe80MJIRyyyy6HLj9dQmW3HDhEwyhoDm1KNg5kA8tkYnafO"
    "TRyNrPSzOEIRBB03ym0eMmLg07mVYB735uw9q7UKI67DHtgeBwjFmUtBXdNX1PHv3Tk3e3MI2jbMTsGIYnDjRmWdQX/koXiiLRHF"
    "2ZhX7VhMwYWimlwjaWMMKxLR8RSASl2FujnMs4eNp1oLk4g5GFQWfCuaGLl+errG8FAPl100yNbt4yxY1MtY3TFYSvddq4pH2gYh"
    "+T6sud5CXiEbNGudUCOIOmqNiCWL+hivNtiy7SA95ZABIwQ9vad0vatXzedP/93b+N3/fHtHQDo++8XNAPzST6/hxuuXp7u1eHC9"
    "z8c//T0e2baPz3zh+3z5Wz8C4CO/8nZuvOESEA/BY81l5/HxT32VLY/vZGTPQdb/x3/N5sd3sOXxHaz96d/jlg+8g4H+CuMT02z8"
    "xvfZtfcwH/2dn2Pdu65PWyLEMFWfZP+OB1hxxTsolitQnQK8NrsBMGJxGdiiWQ0qoi02g2ZsBhOWmJqc5uCup1MxWjEsHCqBQBI1"
    "8IKeyeKc87+NV0pEZ6/B0j8nq4vIiPYV/k/tCYZJ3DulYX+SWPuJ3RBO59JIFihSV08iRGI8mSJ2ZYndFaJ8iMBMAlPE7jv47l4m"
    "kssl4amxn1l+GLPSUPKM2T42Nfe/Nr5uwuLXq1FtzVPj296z++j2dy0Ill20Iryof0n5vLBf5uBLgMEjIUltQZ53KVMwJgUVvICJ"
    "ScuukSPcc/fu5KtfeWr8B3eOPD0R177WT/Eri+ZWHhvt90maSvOXLyR6wzw41PBl95SnFb9pJqJBFXORet4erK6Q2L0XY8oyEVWk"
    "bl+LUEKpq2dqmvYzjUtTB/HdIg2kDhjtC550vf63UfmqKHvxqWWZM6rSbgCmuzq+wkGFtR0EqZYYlZydKb0x11XI3RJsZunY7Q3v"
    "jrM9Ok/GYtjQRG9uZoV7KOlp1JmeGzlrATR1Is7OktvMITmRaONGRcczJ4sZbhBd0caXImAFCpss3DxjjdPZRW7bmuKy1iCbzgWo"
    "kJ84J6l+CTXSQiCN21xRP917PGRDILLWV705yEA1L/sks68WzmdyUCFvdegEFW1uQZv3/Gd9/40uQ+isziOXEdGNapaius0+/LEP"
    "HzWakrrPtt6CRfoTZINVs87isJllcLcl4gTP0TbaT9Qva2HOym80jz3x63F9ckGjWeaG1yzi4ceOcehQlblDBUarEUM9IYlTrBG8"
    "FFUC61CTaRK5VPMgNdpT1GV6DEaII0udiEtXDtNoJNy3ZT9vusajIuCVe06JufBvb76Wu364q8VaGJ+s8zdfeiQFFn5qdQpsiGRg"
    "h+Ujv/wmfuX3/4Hf+Y9fAGD54iFuesdVqUMEgoow0Ffipndex5e/9UPW/+VG1v/f/5pNX/z/WPPWD7Fr72E+/pdfetZ1rFg6P40+"
    "I9Qak+x+4k4WrbyGgaHlUB3vyOKlBbSAZvCBtP6c8mkcYjIrTwHCIvu3Pkpz+iix+vRWPOYNlogih7MR4ZwL7wt6Ft+XvvXsRbR/"
    "ziLTaRPVfSKyW6x6TEevwaoRX8Yo+z90Jf9JYIGZjl8n1oXq+d/WSrDfHGv+tFaCvRK5AZ3S63SufkWq9q0ami1MJX8GSZkxXeD6"
    "i48f+k+vHcWq4YK+zfP/8yObC1/a/nf7e3b+xF6z9z1zasPXrggu7LnAv9ib5y2SooRE1LFqM4rJCQJVU0ERDUISG7Jn1zgb/3mr"
    "/eLnH20+vvXow/F09OWhcvDFSrlvRz1yJAtLTH10tTeFgFXLrmoviV6MiI/yKCq/KY34dTh9XGrJeVJLrncDhYdkLHqDGy7+HbH2"
    "m+nordKw79TQG7Tziv8oTbfC1KKLZdL9uIpRHQw3S2gOmmPx0wJKIDiTwvQS2xT1i7vp6atgrOhMNmfSZWc3AVV0U7vnNrPHU17y"
    "rRDd8UpOXjW3OtsUoVsidHUTpYBiVTCiZ7yPtw0uzJxvz0UHV1jfBkG0JdwYZ8KNXdHGlx5g5dCNFr250/nlbKxx2dq+Nle291oF"
    "Vx7DelbmVAokgGhaeEWqrVYfP7s2P7VYXV9Abi4IFNLDJHKe0OzuRWxymX1hDtI1MkvDKGMGtXv9Se2Bc/Bhhq1rd8x2PJGBPAJ4"
    "6rKWCFnnia72MzFHMwvssuPX61xvwYohhpsSuDVG1ycqHXO8Gxcz7p1faj1J8YqYoGdz2L/im3Ht4Vump+osnFviyosHefKpYyx4"
    "w1IONxwDJYsnmZBj1naUyg64lMEAoJJaTxrJmLbZfRel2UzwjHDVJQu475G93PPwHq6/cglzBLxST8t/N3eCWL64/1nX/an//B7+"
    "x2cfAGBiqskf/uYbGegrcuWqeWlUqmuBBj/59lX80W+9M22PwLD6smUoNovGTCwR4aO/837WXH4ey5csAJSBvjIjD36GDZ+7nY3f"
    "+D7jE1UG+iusfd2VrHvXDaxYOhcVpVY7wt6n72Tu4kuZt+QytDGRMRG8LOpMa93Mf1dbKth0rMoGwSKlMtXpGnu3P4YHJE45f24P"
    "vucxXZ1G/KBZmHP+lxA5hs5uZnF6wELRe2FLSClVvcRTCLy02EWgL0QDcy8Nu4uJeLlMx1dK7N6Ndb5p2oVE9nKpJgtwOoEypKF3"
    "2Dg3qOiDrsf/vplqvt4cbvyS6y886B2qfdDBhAZeJFPxW/Flixsu/F8kegUTTT3yvhVPHn3Hwp06VPyLYH/tH8of+t5bHxk6dNOO"
    "6OG3n+dfOHTh0FUsKK/Adz4NVyOi0d4GcyZDuQD0MjoxzT9/7kH+8S8f0Mcf3ncP6v/dnDmlO2tMHzj8gYuq0U3L0cMNJj08nF5F"
    "rBCaLWYy+nmpxf/KVYLvi3XXm0PVD9vB4v1mKn6TRM7YvvBzOO0BLRFID9b1Ym1BYpljTLyGwDTV0et6Cvt0yPs7rXj3eLh9fY+N"
    "bh/+q51qIof6pmPlzpbC0zW8vqW7cL7sFnpYI21H2xagcCJ7uzOcIOwiE25MOgoii2ZofxdY6I5zk7jm1o2R6vom+um80Agl1Vo4"
    "0zTbTiE9OcG/HXd9Wxy6ORdt7GyBSLL5001mX1rxlIFAm/Ie/USyYnSWREGPjx2BG012+u9pts5nfeqzLeDY6QAfaUu4kSbawVaQ"
    "1glwAdlcwkyUkX4V01JGn22mhcJIbjnbzOwN6+qoZwyFpIO9kH8fZ6BCQtce+OyBCm0pulihKeCpEuDWBbA5QPo9AU8FX3RWxRxz"
    "vQWnYFNniNsSzCYLmy2ZBWI2w7pAbzqM33Mc6mgahYELv9A49vRPRs3qYKNZ4I3XLuTRJ4+ye+8kixf2cHiqzqI5Qi1OwT0xXnoA"
    "qgbUIp5BbHvFMyZtRyGj9KOOWj2mp2K47spF3P/oAe770R5ec/lC5gxZwkoPXuDzR7/5xue87oG+4ox//6PffENr11Z1LZYMKgz0"
    "FvgPH3k7qW1FCpmiruXSgFgUYc2ly1lz2XkgXvs91HDLB97OLR94e8dql0d+Qm1yNwf3/IDBBZcwd8lVaHMadTZ9D89DnG0fUahp"
    "1XCCQ9SiYshlHNEE8QIoVNi55UGaEwexNmCg5DF/sESzkZA0qxQHVz4U9iz5Ci5mtlvlTwtYWPzxbS8wCoVWldE6upEcjKn7o42n"
    "J6+fu3P0l1bukaenrqZmryNJLkHMuJtT/CcteVsxFGU6/iki2yfV6DpKpSOUg3FGm9dguZfe8G4z3ny/nVP4jvrsN+PNdRLIfjyp"
    "y2NjN7vh4v9iSeUrlMNic6g0uvc/XvvPi/90yw9GL/Y+NWZ2vW3PM3vet2xixfkr51zJkuA8Kl6FaaaxWscPQqBCbC3f+NIjfP7T"
    "P+K+e3c8fKTf/3T9Ny/dqL2lwwP/79ao/iuX03jPsjJlb5h5RbWxXWn2Vz+mA6XPENmrzWjzF9U3Vj1T8w5XP+z6wvtFzGFpxNdo"
    "yTtAyWvKkcY7pWmLZir+Ce0Lv+DKPR+TWnKpTNvLaMSvcb2BUPZ/RF9wO/MLPwg3H7WL//wxTyf9TEyyu+i9CkEFQNaKtD2YPaGl"
    "Qs/sJnIbO/uNkw4at+uWRt1xDpPXTuvJJrq+ifbHs2g9yWnMNYX1ms2X6Di2QpeS/VIthhRVGU9Ev5zATSmowFl5Vh2g8ToP2ehL"
    "5g5xFp0hcgp763tNz8qaohht7z0ZsECMbnaYG9MU0KQ/I7O3G7XnfDqH6uqoZq9aBizEHS16Vjv6/bt093OwPnfqdqQWlDV0xEdv"
    "83Ef89TMYJbNZkuE5nErglXTn8CGBF2TIDgRXNeCcsZwiT3uRjpMYej7Yf+KO+LDP/qZ6WqdBXMrXH3FPO7ffJjFC3oZjWCgnhCE"
    "PrEDTxx5F5kCOE3dITLLT+dSI0aMQX1BolRXYLoe0VMOeO0Vi9i87RD3b97LVZc5Fi9UXKFEUCyefjTmQvyaRWVmh9liJ2RAAsex"
    "FcC2PkP6jbRMiNP3PD5im0yNbmX0yBMMLbyCgXmXQzSJWosQoAFQ8FKXwEy4MdVbyGyAMvaXZAd3uXyvVPoZPXSIfU89iO8ZGlY5"
    "f2EPxjNE9SmM+LY4dNkXxQv3q3PMdqF4WsBCZdvEC19FWhtKe1pKrEjs5nvVuB4cbU4Smh2j71j0cUJzgTRtD8p5KCuklrxWomQp"
    "dXehVsKHtDe4GyP90nSribUg9WSV6/X3yXRygZmMR7U3eFCL3mEz2vwNt6D8ManZojlY/3ma7jw1URlD1Lx+wR8f/Q23q7mydzLy"
    "ksnpTXsem7zz0Tcd3rXj3UsqFy+9YN6VBCxiYV8P5VLMth0H2fDnj/Ldr299eveTh74ydv28L7lfuHibXD1UsceihQd/0+6qvmG+"
    "iNV/LXuql+KbPTIdX0WkZfUkkqPNn1dhjqv4d5mp6Cpp2At1sPyI1OKVRHYIXwqoLteB4Ovqc4Tp6EbTTH7CFYJtGphRt7D0XQbD"
    "7WaiWXXzyjvLdx36Ud9j44k30ezVSd4Wzwlj4A6g1l32XnVjwMDqnJ3gibRaIWbbblJhg8vEsXJl7YSZwmbd0R3nKnHNrCfHI3Rj"
    "p4ijRTOBxXPiZD+hmWjj8RaTXdHGl3ZMpYWobEzQm2La1Ho3CwyYZxVAqYDjOg825i0HKTtNz5aWzowe+TzNbttepq7qvgixCk4M"
    "ooqHEqD4krZLzBZjoXPOR6o0VKmpUkWpqaOZza2Ze5N2W/bO+ZxK2WVNVQwOH9b7yFpf9CYfxdOZ9tmzMrdImRGhpo4FCbI6waxP"
    "4FarYLsWlDPvmQme/XdBcbw094q/jca2vy1uVgdqjQJrr13II9uO8sTTx7js0iEOTk5z3pBHDFinGCOpDaWa1H5SMjaAgjqH+AE6"
    "EWEnIgrLe1MzBueoTjcolwpcc9litm0/zANbdjNZjbh45RCRTfCLJYznnXYkttbwFkggiGYAAoKQ6ytkLRHa0ego+Z9B5TjHHrU4"
    "N83ksR9Rmz7I0KLX0DNwHq4xgTqb3s8AmK6SPLEd74KVmEIRmklK3eiMVvFShkdmCWGCEtYJ2x+5BxNN0HQhQ30BA71Fao0YG1Up"
    "DJy/pTDnos85/Awgmd1xWsCCLZ9ZSQZxehGOX0v6g/FgIv6b4X8c2e3QH47/xLIfauJgMnq3TMZXUk2uQFyiFe/b2lN4CIjMeHwj"
    "9WQJFX+3Fswkkb1EnBaI3Hw10k/Zr8rB2g1Stxe7/sL3zHjjJsaa8/G9ozIVXWSt2z/5rsX/GyersPpjzbeGjxzrL/67sZ3H7th9"
    "eOs7DuzZ9/Zles3SefZ8vnP7Ye7Y+v3Jr/3NM98de8u8z1auveBb/puW1BuXD76NQ7VfoWY3Tt60dBdHGz/l7a5+EN9AwVsuk/Fr"
    "7VDhs9KIl5l6fKXrDfdrycNMRctRkHqyWgPZScXfKQ13sRlt3uD6g390cwp3iWeOUY3XUI1X6/zSo0b0qwP/su9vi0enqS3specH"
    "x+h96Fgx6QsrjYV9AehbgceBnd3t6lW2yGfCjTmo4NM+PTKzCyrsUnSzawEKKa0xF8nqbsDdcS5HTtdO0t7q25oZsBCjJLNc5DzP"
    "vHle0cbu3HnpFkEW3Rij6xO0P39eNnMbma31ti3MK+t8hABaFqYeQnIWo6WzCJeWm1b7OhPNrfocvkCIUOzQN/Fktud8+kxSwM7R"
    "0FScMaKtoaAdn6U7XhqAXa7fUVfFx93iw4gP/abDgnK2wIWcWJ5bUFoxJOhHEmRj0rWgPAGwcOKiPehZ9p3CnIu/ER247+emJmvM"
    "n1vhHW9cwue/voOli/spFUPGahF9lZBGAjjFeGm3ueauBwbEmdSNsV9obJmk9sMxhn69BymATllMaKg1IooKl188j1IlZNuOI4yN"
    "17jsovkMDDhsEOIXCqck7JgiGSlKqppZOmagQQoSZOCCdoAL2Oy9OwCI7M+pEGT6+VQbJM2DTE8+gbXK8MLrCcvzcI3xNNjUoFET"
    "6S8TP7qd6U99lb4//CDeBcvRqSoUJLvfHdmKKOIsGA8qc9iz9QHGDzxOEBaImsLiwR7ipiNu1FHxbHH48s8aL9yras9KwuOfw9hc"
    "qkZ+FY8rEGlEw4VJfzL6/KK/euaQ6w2Zum4IDWQXwkYt+7dTNEdcTzAp08nbZCJ6qzTcxYTGatmbVkPDTMZL1Zdx7fGfUdU5UrdX"
    "4nlWqvEbdbDwsBopSux6KXpP4Jul5nD9913B+5bULDJW/1e2HL6r/s4L7hXvgo317Ud3VL+y7dGJzXd8YHTbU5dPPjox/uSeJ//B"
    "3njeJ4I/eE216psS49FSs+XovzFHm++xK3r/jtHmPLO39ttYN6RF7wGJ7DyEkKIXyGT0BqAosVssTXsBFf8ZEreYarRY+8NnKPvj"
    "YpNY6na5sfo+N1D4gRsufkEK/ufUY5GxrjH49QNPLv27beKQwahc7okHiiZaVF6K6oA4dwDoAS4C9gPN7nb16gIWchChLaCVLUMy"
    "q20QLfE5q7Ro3ElGQe8mbd1xrhNWzYqMGBmJ0Lua6I1tEce8XejsshYU1mf2Zq02iOg40cbu3HlpxlMm2jhulY0xenPuMOCkLaE4"
    "W7GUqdj3e7DORzYGpPTtRmY7di4KnhMV6JqJ8nnQFkaUzvY4ZuUuKWme3tmSl9nOZoBdt0f+JQ7YESkYcXgw7qvc4qNf8lH8DgvK"
    "2QKDcwtKPxMcTTBdC8rnyjm94Dn+3q8VF6z5ZH30qbfEjer8scmQqy+fxyPbjvLgw/t505uWs7+eUA4tgWeIHYhTxFOccxgMpiiY"
    "siC+j+kz1J+Zor55EjfdxFsxgIZJSmGpK41GhHWW8xb3M6enwLadx7j3oT2cv3wOy5cMUEhKSBDiByHyvL2P2gYEWoKzkj3onJXQ"
    "wVxQ6RBz7AAgVACHTZo4O4GNd9FsHiUM51KqnI/xi9j6WAqq9FcwvT3gPCj0E23bSe2bP6Lyc4cILrsOWeSB58FUAxrNlK2AkPbg"
    "KQwMMzU+yq6tmwhx1BLDgoEiBd+jESUQ1ygNX/xAYWDl51Vz58NXJrDgAfOBjwAXoPwBSojwS7YvuAXhT5f9v4/aXf/n5Uy/Zmgr"
    "nmxNm5sEsbzO1OO5hN4jrjfch3WvkVq83ER2Hp5puL5gL4FXNdPJUqbjeeqbphZ8J9XkzcYxlOqQ6pD2+OPmSP1aNxG9g57wn42Y"
    "H+hY9BO24H2E3mCEy+ZdYpYN/sn4/9ry4MSdm39JTGH70Jrl/3Xnx1/ns7f2v+Ro40lqcVGm46sp+1sp+/dLLXmLVJNVrtcfJ5RQ"
    "JuLFCKFUk3dowTsskW1ILe4X1UXaGxyjLxxhOllkRpuvwZeKKwfT2hdslUiflOlkGUUvwpcvG+ds/91HWPh3O2kWyyubc0uL8GQd"
    "jipOE4RFwN5sKrwWeIoua+HVBiysy73NvQ5wwcySVVM2JvI2iKR14kqrP7zrB37SsQYYAAYk/X4zMA6MZK9nJevd8eKKwUzLYEMT"
    "vbEt4iitBPEs2vbd5dDNM+dN+orpijaexlibz6Xs2W3O/rxptuZPizqvEIuuj9Cb4w62lp3F9bbTstQXWRcgG/1szfc1TapeKiyX"
    "/GQ3pZDnTkFZbM8yAKPHX8MJWAqvhFh8pYILCalNcAMlELcxgM8EcLOPnKWWiJeVBeW5i7vnYCwoStC35HvFeVd+Pt616d826g3K"
    "xQo/tnYF//NvH2Pn9lGWruhjz3id84YCnEDa8u8wvsE5R7wjBhz+wgLsVeJnGriao/bwGKYvIDkawaQlmFvEHyyQJJbJyRo9lSLX"
    "XrGQfQen2bFnlH2Hxrlw2SCLFgxAUADfxwvD52mRSLURVBQhYy0I6ereoatwYs0FUI3BxVhbRfQQ6o7iNKRYvogwGERxJNEk+AHi"
    "e0RP7MVWI/zF80AOU7//SVw9oXHPj/BXr8JNTeEOHMGfN4C/eEHGcMiQj0ofVjye/tG3cdMHUb9E2fcYqhSIY4eNa+AFjfKCaz7h"
    "hX0H1MVnwfD33AELi4FfAC4A/gvwSPY8L1Xkx5PecFHSE+5b+Knt7uDPWyZfNxfGEyiHguqPtBL8moZeEyNraSQ34QUN/OJDLvCW"
    "mPHGr8to/X34MqUV/xgwxFTzMmPVJzBWK8Ex9aQsVXcxCqYav8+V/XtdJXhM4uY7zGR0hTodN89M/kZyQe/BQ//PDX8x/N+3fai8"
    "ZUxH/vyGIlPxv/K2jf2s6y38tSj9OO1xvd7tCgWpxj+Fuook2uswk7ancNBMR/NkvLkYI/O14JXo8aYlSubL4fqllPxxO6/051i3"
    "VZr2EjwZlqJ/h5bkKzRtSYWYxSWd83cjzP+7ERrDpbmuaG7Ak0dR+hFeB/wl8AlgHXA18Bbgri6w8KoCFdYIstwILcsvX1K6qcfs"
    "ija26dyaq++np65d8bkTjXXAOklf/W37QZlBI85cNjYprAfd3NnX3L2fLyxh1aywiUU3RB0ijknLevKsXs+GE4k2Rt1583xjALhF"
    "Us+i1dJRbLcL7zZ4o7ARdIPC+JmkvrdZC7o5Ru+K0BvjrCDK2yFmtfAR8JSbA7gtREaCDp0Fw0vJnjSFDlxHTJ+tdazzWevsMOde"
    "ErH4Sl2rcwtKXxUfvdVH1/q45Z6k9Phcud/M1hx76VpQDmQ5xC3AjTNtjOX4uNuisAHYoOgZjzuV8LnvofFcecHVf9E49vi74+lj"
    "F0xMBCyeW+adNy7lq7fvYt5wiSQMODKVMK/Xo+EsLjFgFFMQkmNNpr9xBNdweD0+WnOYuSGT3znM1HeOoZMxpav7mPP+ZamuYZI+"
    "i1qtQRD4LFvUx9zhCiN7x3hy+yh7D02xZMEAQ4M9FMoFjO9jPB/jeRhjTiCwmDXnqGQtEen9TXUVOI6pkKRgAg7UYm0Na8cQJvB9"
    "g3jz8L15GBNibT0VpMlX6nKRZGKa8Y99nXjkKP7cHqg28FYuoPrdzTTufQx3cJTi6vPo+YNfRIsBVBuIWvCLEPaz+/HvMrbnAcKw"
    "SCIeCypFnFOSJAEbUZp35VeC3iVfSRt9zFkL1HMBLFwP/DzwJ8BD2VOcDywHxoA9CLjQMPidgwx+9yDViwY48usXqhxt1jve53sZ"
    "Qucw1FEdouRPajkoa2gOi3UXy1TyAS3JIfXFEburZDq+VKxrYoyn/eFOykFNEm5V6y4WpyVRLWrR20pij3Gw9n5d1vM9A/d4kaK+"
    "mW9+dOxfSaw1Ct7jWk+uEksPypVSjf8TRRO4wcIumbYrzJHGlWlzobFaCX9AlIgg87Xib9I54Z0S2SGMFNQz/yLO7QW+mQGlVdI2"
    "s4h5RYb+YYQ53z6AnRPgyt4R4PsoNwMPkLY8rAEmgK8C9wJ/AFwDPA3s625Vrwpg4dYcZfeETCBLOiwnZbZOhm7LTxgSJfMFzxTt"
    "tdsj3jHWCmwQWN556pj3RuetKh3PaLnCzU65OT3d5hYHI/mp2yvkvg6cKKGbrWQ1b9eJU2X49U30o5GksRqeXRHHCYUNuWhj3CHa"
    "mFveddkKJ4yVWyV99ed05bzj1GRz6LiU6UYHN6rKbQ5d7+A221EIvJjitqXbAcTKbRF6ZxOliGJnmQGTn6imALLcEiC3hQgBgidC"
    "rC+d/m9t3W+ZwcHRs/b79bj2jFdeLL4SgYXcgjJRaIrDU8Z9uMVH7vTRljC1zPI8O4EF5cfOsQXlbXnc5df3PHG32sHHVLnNpS2r"
    "6y2MnzGx0qR+EtBB8Av9WysLb/jE+PavfSyOajI2Jbxu9Ty2j0zww4cO8MY3LOVQ01H0LD0ln6YDjR0YKK6uoL5j+l+OkRyIMX0G"
    "CQ1uwqJxTM/rBxlYtxCvP8DWEsSY9HBAIbaWpNakWAy47IJ5TExH7D8yzcj+MXYfGGegv8y84R56ywWCYogfhhgxYDzESLtdQgFx"
    "M40dNPuPZNw0dahTkqRJnDSwSR2lQeh7GTthECghWNTVUrtdNagoWItWGxSvu5DBf7eOsY99leb3n8ab24/pKeLGqthdk1TedRW9"
    "H3kf/iUr0Gottef0Ayj2cWTPo+zd+m1KoY81IUOBT2gMsVNsPEFQXjBSWXjNfwOZcknjrM7lcwEsbAW+AdwAHAFGgXdlwMLdwE8A"
    "hzQ0D/kTkTUNh6kegw3CkZ9diToDoYHINaUWH+nYxWp48o8EnhKYpiYMU5BNJIy5in+N1K1BGcb4Maorxek8mY6daPx6TVwZq0ZF"
    "CogsoBLsl8l4leyYXDV+zdA908t6RHZOrpTx5qVa9A4T0CdN+oFApuPLpZ5cjpG9IAspmgSRnQo1PCNa9jdS9n5AlIQEcpDA25Va"
    "82oIjGNRV/Sg7EHRT6O44TH8Nzvpu+cwJnK4shnAsDYTLd2SgQePkeoqfCADZj5NSqNudPeqV0/SnbZBZCh79vIzoMHIrNFNP+7Q"
    "kdwLvDlDfK5L5+4Y6wU+YjoSAZ+UTdIpvJbTp0XaJ2ypjZ3eaGFngv621bQvP09KX84AQ9b+MSOJO4WxRmDTCyn/W+BCm7Xw0WbW"
    "K5tIuglmpk6znThv0KzXO+6YM81sHnWdVE74zDcKLM/nUC5MG8hMTZlOcKrlXCDanyAfdei6WLnFwebUsebFFnWax9KmNmshfaZB"
    "xoCZbXAhELk1RNYHyHiAtNohckbFS7Fo1LP4u149sfjKAxeUtv6MEcVHN/m4Pw7go56Ch5nBWjhLFpRkFpRrE2T8LFpQrskOJlbn"
    "bIpWy6t06mk9i7EAgG3H3S2xsi6PO32RgIi65OT/LkJx+LJPl6f2vXF6733vrdd9Ar/AT799BZ/4h208/KNDXH/tInZNVbnIcxQK"
    "QtMJ0lTEOSpvnEPhgjLjnzxAtKMOHogRBn5mEYPvW4zWHK5qUyBAU40bk2IBYJRmPSEyllLB5+KVgzRjx8RUg9HRGtt3HsX3hUIx"
    "pLenQE9PkVKxQBgG+KGH53mIGDzPYPwUxrI2BRmcKol1JHFMnMRY10RweJ4hKJQpFRbgexUQP/UK0hpgUDFoyzIy+xpHgFJ60xUU"
    "rjqfIx/+FNVvbIHRGiZJ6PuVtzP4n/41GA89PJY+VM+DUh/jR0d45uEvEdg6FCsUHVQ8Q6xgoyoQJpVlb/xvXs+CH6bP6uyuLucK"
    "WPhEVhC/K8vnLDBFymY4BoyjGPXNFttr6qZhGbjrEK7goQKmaZm+apDGqj50KoLAg7oDZQKnKcwI+/BlH7GiRvZjZEQC41MMBtW5"
    "X5Lx5tXiXAkVg5FQy/60FoxStz8BLCRxJcajgebSCs2FZZVjzV6cDinq0bRvV08MJX+U2A0bqzVNtAcRR2/wmBa8vydyT2C1gOFx"
    "Am8XzuIKBio+xDRVqdIAHQyoPHCM8tNTuJ4AFUGt0n/nQUzksD3+JaL6VpRlwIEMUKgBq0hp018nFWv0gG8DkxlY0x2v8JHS6qW/"
    "E1QIZtiQzUpyO6FwW6etV5fOfULAZ5O0LECz5yK0nlGYMUv8jhMHId1zXGaJlouPxaofi0TXxOgtKZgjWWrwMo/f0wvOgc7E70Tf"
    "nzxZzUUcGYnQL0foTVGrGEzZPrPNWnAdoo1xxvJp5oKnXdHG48ctAusN9EtHi1fYMZfC1lqXMYGyh5f3QOcgZ4SuTmBThK6N0c2J"
    "QvICAbpOBkySgkK3NdE7m6IUVLEyewyY1kmlgKfaHyK3hshtuUOEDy298m4cvfJj8ZU6cueFOGvxaajDh9t8ZJ0vutpHMZnegp59"
    "C8rbzqIF5RqBTZ1x52W5Q5CCi4RZruc/R9y19IXQ5QlsitFbInRjHncvHFh4flhCjD9ZWfTaP25O7rs8mdx78YQMMTwQcvNNF/KJ"
    "v93K1m1HuXjVEE+OTnPpXAg9j8gppunQmoedsET7m2ggeHMD7DMNkoNNklqMqyoSK6ZgwJEyARScWMQafB/U92gmCYmz+J7PwqFe"
    "Fg7PoRFFTFQbTNfqjI9XGRur4fmC7/t4gcH3PTwj+IFBTApi5S/QlB1iIAxCisUSxVIvYaEMEqSR42LUKMYXXASY1EJTSVDntd4H"
    "Y9BGE2oNXLVG85mDOFUKF84nevAZ4u0HcY0aBoMmTQh8THEO0xMHeOahL0DtMH6lH5yj13ippo2LcHGD3qVv+lx57hV/rarPqYfx"
    "SgMWlPRk/ZPATwKDwEHgsqxYfgpYme2REyiHtWCsOh0f/soeALzphOBIg8lagpmI0MAwfeUgruSBZ8AI0nCdTUWHUL6TNd0F4plx"
    "ysEVzqcoCe+Uhn0tTkMadplMJ9cROx/fRBiZS8MuxLqEwCzDM3UTuWEdi96mnuzHaShG0JI/op58S1THNDBPOk++Q2jGsJoCVIGg"
    "QUBhpEbhwBhOAF+YvnouxR2TDH37AD2PjmNLfmtVsz1+nyt556O8R0XWoOzJAITXZ8DBsuzPf9uxFt7f3ZZeVcDCbR4QCGnRKkKY"
    "fZ0tfYW0BULHMws/IpRGJ2OhS+fuABXSDT9PAAqZIFQBQyhCmCUKnrSLBkVbgr9Jx8l2E725oUpT9Jamam5+9HKO3RN+PR1QQk7j"
    "43dS2KO0HeKmnMJ+Nqwn015rHbEZ+BZ1MH26LJ9njXUCn84ZPUF2KlzAUJB0HhWkDaS29WRyD3FtO9W016b+BrqpqW5tU9hsNC1c"
    "eDHggkIkuqmJ+3JT5aa8vcbTzLZuFuKpU1zORz9aENlQUDMSokSSFlzdAvXVE4uvZHCBzL66mQJpBLhbAtjkI/2egEmpv+fCgnKT"
    "RTba2bWgbIEKhjaQkMaboZgBDOEpxl3WdtffRL/UVH1zU9ymSF/EFbvnhyXUJfjFOY/2L3/zH49u++dP2uZEz9HxPhbPLfILP7mC"
    "T/3z01R6AhYt6ePJI1UuHobQEyLfx8WO6U3HcE3LwC8toriqwuTfHGDq+8coXttH+Yo+3KTDxYLxNKMqkFb84lIFhLrF8wzOUyKb"
    "ECcOz4spFHwWzu0F6cM6IYoTGlGMtYpTh3UpNdxIOid94xMUfMJCgOd7hH6BsBDieymcSHYYpK6Z3XsPtTEuchg/4xBrLviYcZTU"
    "Q9QhgQdlYeIv76H51H6G//1P0/veGxj72NeY3PBder5xL5X3vhmmwAQ9NGoT7NjyFZLxvZT752AdlK0HksaiRtOEA8sfqyy4/D+p"
    "bdTQc7OanEu7yTHgM9n3a4HXkbZI7MtAhrnZ38UoxxC5O+kLJgGS/oCexyfofXgUUXCBYd+/8Un6AkyiJIMhyUCQ8ly99KVeZtFh"
    "iEX4uvYEX3dFI6ZqA2kkC6We9CHSJ8JRF/qHpOQ9I8hybST/ByLTqF6pA+FXpGbPl0ayVJrag+IoeLtd6D2kJf+/gh5wRvDGm4SH"
    "GrjQo7mih3B/HTzHwO0HGLr9ELbsY8seewZLzPuHEUo7p2kuLOVGrpVsrVqD8iukGgrfA5YCJeA80haIr5C2RZSAenc/OmdjxckK"
    "p1kszG41sDynxYV0nKAAnsyKvsKW3GIyO62joUoz8wlPWo4Qr95gFNhgYLVkyUAoQhFDSYRS9rXQmRBkG1hOY8xplZ1e7HkRGuJu"
    "rqObPdz6JhDpy/L+IKnuxPHaEqeSaJ1wbskpxpvroLBH6K4mujxqWU9KxlqYNUBuQyfLp9lhMRl3WT7HP+cNnYVcQWTG/Cl2FHN5"
    "a5HpWOs0f9bM1LKoo/11ZJOnbkVTdFyydpjTLehagqAZUNVEb22ga4tofwElYPZZCyYvNFQ2FETWFhCaKq2WmpcItX6gG4uzG4uv"
    "1NHJDIpU8USpoZt99DYf9zFPDd65s6DckAgrYnTcMisWlAM5qNAZdwXS2CuLodQBLJxO3DXS2NvoKWuM6MgLvi9yikKAzlLoW/KF"
    "nqWvv2pi+zd/z0U1Do3C5efPYd1bV/D5b41wY+AzNK/Ck8emWTUcUCxD/VATjGHOBxfSc0M/FAwDv7KIqX85THSgTvGiCmpS5MTi"
    "MB6I8xDrMGUPTRxTdx+icvkgheU9uLrLpRaxdYfXTPACD8/3KIY+5XKAMW0xRxXBiGA8g3g+nknZCy7rc1OnOE1ILRwlO+QQEIPf"
    "X2DqhyM0RsYY/InVGE+wjRjEB+PSqBKHOkHKBZJDYySHJhj+f97PnF97G3gVhv7TL+ANlYm276M0OoHpGSSqVdm57Zs0ju6gb3CQ"
    "RIRS1SFZXNrmOJ4XVnsWXvfH4oVP2Ob4OZu//ktkHTmaAQoD2dddWcF2Ienp/B5gGPj7bL6oC40jbAf3or96BhT8qZjRty/kyC+e"
    "h2k6aDpc0yFNh8QOjKChB06R2Kn6fNIOFregXIBoAuxW3zxlxEAt/j1TjX8TiAj8R1xP4d9rxY2T2PNQLhCVErDb+eYBRA+LKlIw"
    "9D04yoK/H6F2UR97bl3Fwr/aTmFvFVvyaC4qta556fqtqCckfQGZEswC4EbSVodeoJ9U2PEfgLeROj+MkTppPEna9tAdLzFg4SyI"
    "wA0I3JZS9dqn4YWOVojZ2GgVbnEZK6Fzo2p2sBXcq/vU9RaBm3JQoZAloGUxVDqBBYRA2tTZzoKhJeolkqvPt1ghKRjhbvNgo1Ed"
    "aaH0L1sQpp0UPt+8kaxIyX/++J7SUysGZ1DY1zdxH4tEiFUpSB63szJ7W6KN8XH6ChGKfWmzfAbObkywIU+ow6xwK4uhnH/NgLpQ"
    "Om11Z2p15KKBKX05BQAKKTBHgPb7sKGKW5cHhr6Agq4lCKoQoSNN9LYG+rECSiCzy1rICI8EKoTIjUVkXQPZGCLEItgOGvQ5Hqtf"
    "ASDxSz4WX9ngQtr611TF4PBhfdYScePZa4l4tgWlVdmYYNbOhgWlwMY2UyEFFcoiVLJc4vi4858n7mwWdymI3o47D117Np6iiJdU"
    "5l35/8VTBy+tHdny43EccPgYvGnNXKrViK9u2s3bXr+cvqEeth2Z5lLPUPCAtw4QzA2JxyI0Br8voG/dfNx4gp1OMv2D1L1B1SCe"
    "olYx5QLRvhrj3ziAlHyKl/VD06FGEV9SAwd1WJs+tyR2GE/wPA8MGGMQP8Av+DhrIXFEgHgGz5jsRmeQkwgiHuIbxAqEPqYSMP39"
    "EabuHWHOuy9DeotIZBHf4FQRl0aKiME1Y6QeMfhLrydYMR83VsVNjeINDzD42+tIdh3GJD6RqzKy7f9n78/DI0uuMmH8PRH35qIt"
    "VfteUu3Vq2SwYcAMUsMMHzBAyUPb7JTaZsBsbhnbGAym1RgMHmxabQw/YIBWY8wAMz+sHvg+GD6gVQyYxZiW3EvtVaq1a1emltzu"
    "vXG+PyLukimllJJSqqr2Pc8jd7u6lHlvxImzvHHOe/4SM1ePo339OniSYGU9CAUoklDOLIgVN+/46mcSbbv/VHl39675XgEWTphV"
    "+DYAXwZ9Q78DwAx0a0QCmrDwqkm+x+GPqfTV1zQXuW02WsYn0XR6CsbDGsvDkDMupr98A268cx+Q9wDHAym+BKbr5ky6sMV+mnZ/"
    "CI7Xg4Q8p9pT7wIwQ7Pu28Sd0rOw8UWVkr8JS/w5OcqGYoKgMtLCU80WNv7BebT/9etwNiZhTZWx+1dfg5xxdJtGVVMxywp2vX3Q"
    "4yJ3A9gJPdnhNHRbyJsAHDfAwv8B8PcGjInl3rjVwHw3sKsFMIQBj3YqSf8W3PzIJSZddTr5pxUw5peT+9UKRVOt4GBNiIzuZWkX"
    "ug+3AlRoIYFmEmgx/z8Z6YuUFE2qw/t4P8XU5dZ69FXC3IRKzUY+SFD9GrK/LwP2Hgp0NNRVqkE2av6sJ3ozFQZRvBQdNlUL5JM4"
    "PlNihmNK2C3ziY3uSGRgyCdt9MlOSxySNt7jVT7dqL0njdaLfmFaiGwDlDaRPkMt0AF1moS5pdN97tUBNVA5Vk2B4DLDJsCGgKXP"
    "0BFi9BLxqI4ydU/hUsqZo1ULDoAi1FAS1JcE9yTYgAtYndGTvv5bJuFNgoZTEN0l8ITDPiAJiLVjrJ9Peud75vvIRt03uvilAS7o"
    "cWlFZlhQfTYwYQMZSQLC+EhaZb4FfwSlIgEX6HGAAbdqBCVWDuj1+v4xYWK7ZhJoBgWxRLqC36PyEqk6jqjUOx+IYEigh5j7oUdS"
    "rv5pInGrZfub3u8W7+woZi92l5LrcDvL+Ma3bgcI+Mv/cwn//it2ILOhCa9cLeDQFgtNzQLFnGPoCAhuzoFslhBtNlSZdf4mBEjo"
    "sbYiISAzNmi9hfK/5FE+M4vCyzmgbxfk5gRUXoELnu4OIAHA0zaaCJ6rn1MwwSMGlcso5/KwW5KwbAtEAux58JSCsASEmQAEBpg9"
    "wCLI9gTEumZ402XMjr+O/BeuoHzxNhL7t0LaBDXrArOmgZWkng7hMChpQW5shZedARcVYEl4t25DNrfA2rMXxds3cPH0i5i+fh7r"
    "N64DWQLujTLgAkpKsFcEuwW0dn7t7zdtfvS/snIV3+XY8F4BFlzoG/jfhy7tbzXx3d9Dkzn2mn9+h/n7DwB4GHpc5Sn49/0A2CKI"
    "kgcx687xZOQxml/JYud/fRVi1sWN9z6I4u5mRVcLRZpxBCfEu8Rk6QeUJSe5xfoMN9t/BSlOI+95IDrBzdRDLv9fYtr5FKfk/1TN"
    "1icJmE3eKmP985cgywqJawUQE5RBxqw7JbAlfOBjI4D90JMbxszzSQBvAfCfAGwA8DKAJLR/+QKAR6GrGD4F4DPQJJe52OXcM5IB"
    "0EnABGH5PeNLkAEBHBHm1jsZVCsIJGuUxTVAjmnCRl2VoEs5FYpQQcWCY6oV1JeoEpCuVtCli+ZGodkPRM0tV5pE0KNbkVDP82n+"
    "tGNpphZIczMjWIAIRwEMMtTEfbhOnYRo5UF9ZayGU6GbgDGquKFZetWCuTnMlsHPl8FHfZ4Dl3lVSBwVMOyPu/RJG8vLH83afRf3"
    "blUTRAIGo9U+TSTQDJ3ItZj/nzTBdECSV+P8hEkJgikslimpNu8wAFajygSIyyln9itgHIap3lL9CdBYgjhjG64FWoWEp5pYLgXK"
    "lIlGyhC9ZXDW9Vt+gCVCbw19xr6wIilcgfsFYLjfdLFe27vWYHtjgAV96+4wUCSGhMpaTP0W+LMSvCYtEdUjKNOREZRuZARl2RBO"
    "qhXonX85kTBtN80gtBpQodnonb2o3oVxhIrEERYLWMTmd3hg9YEFAqsyvOIkAHGiedub36c89/ec6dc7imjH5BThP3zldggQ/vc/"
    "XMWXPbwF23Y24/jNAvaWGW1NehSlYkBIBhcVFCkQSbDQJ4SSEu7VEmb+6XVdVbAxheJrMxAtNkqnp3HrubMAE9zbJTQ9kkHrV23R"
    "q+YxmBRYSj1ZwlNgl2BnkihfymHyz89iw386BLmvHTztQlgCSjCICWy4Cyhpg12F7F+cwMz4LSR3tgFFF87EDGSyCTef+1fMvvQ6"
    "yhezECmJ9m97FKk9m6GKrp4CBoaCgprKg5gASwMeIpEAqQTy187g8vl/ROHWNWzatA5ICMxcLYJLBLIl2CvDLU2hefPDf9G8uftD"
    "IDnNyrnrVvZeuvJyodsgzgA4B30zvwvAI9CtEFljqD5tLgkeB9BvwIZNUUvEgsAJAbYrf1RaQhZctLw0idbxSX0z1ZoAbNqKvPMR"
    "mnXfy0lrjDP2EO9p+Z22f7jxxZZ/vV3AtnSZW6xTnBCfVq32r6pm+0UqeN9JBfeTnJL7pKPQ8toUWr9wB3LahUqJoAaSbRHd46yJ"
    "RXYbsKQHQBP0uMhO6EqFR6DbHzZB8y0cA/A5Yx8ux6DCgka5e42/z3c4fdXJzipJvwCeIX+ygCnNS5HQpICrQ0KXY6BP+UmRYWku"
    "MCNvqhb8xOxLnFuhXxhgJ2F6IZvJv2UwgSiFo8kWS6ijiXdYiiuCALeZxEAT3ZcVC93RsyOC4Kh2lU3knHULhMSkyzlr0RJ2hzHk"
    "Vw44vDqVAwy8EJI2oqIFwjEVDEtrg6D2OYDL6sYQ7bUA0wYny71kOGN8wLQJhBaiIJFLRaapSCxOUOtXn0hzLpOmnN3c/B1pJtHZ"
    "hGigTksKiMKqBb2XBeaJIquBQmTax2pVo1RXLaRBXWnQkH4fUfE+dyHEbAeoHwhtXdSeAfc2uHA/6mKd0rnG695day2WAy440KBs"
    "gRkFqJE81AsFKJTWoA0zqr8B1wYEmiCGm0DtoT6sKP7qFkBPeDlBaEIIKLQYvUuuQO8SFFbfNBN1/WXr7tWNmYmgvDK8YhbKySPZ"
    "uv1v1+37hp+00+tueKUcCgUH2akyet68Bd/62E786yvXcP50FqnmNM5OAzemHSSFBo+Ux1AMEDOgPCg9/xHseBDrLVCTham/uomb"
    "v30BhZPTkFuSUGXGnT+8iNvPnYNzqwB7RxMgCJ7jQikF5ekfSAFKEihFsDIWyq/PYvLPLqJ0MQerNQEkJJCUEFJAuZ7+HWaw60Gk"
    "BNIH1sO5mMOlwWO4/psvgQFYO9ow/XcXcfkn/xLZz74Ce0sr7K0tYM/MgWEDHbL5LNL/FCIJEknkps7g8ukX4eVuYvPOdRApidnL"
    "Jc0XYRFYOXALk0htOPS55h1v+QkicRUqWje8lJ/GyoorFph1YOO6DNvWozmUWvGD5gD8PwC+ybz1HQCPQY9TfMn8+wXo8YuPQXMS"
    "XAWw3fzzVWhCQ1+aAKwHY4YlZb0WCxCAsgkouJ2cdz/AKes/Y3PT/4LChzJ/c/U2Wm2s+6vX4TXbkA7DUwozX72p2Pbi9c/NPrru"
    "JW9nUx6TxXfSrVIbyt6glxInyLM8tghgrDNAgQM9HtKGbvGYhq5W2GlAg13QN94boKsTUgC+xvyuAHDDAAtFNLBClzncNz84fYNI"
    "51rfiBiH0++XwcsgaSSDFzcUVHguimanfGJAaCfkl8Y18IYsx0CvArL+jWvROPa8du4oQX3JcyuYW/guGdkX3Qvp740IgtClBh2h"
    "PusbSrAmFlIset37cMUJ6PWTDVk1FpUWP2e9AhiO/t5Sz1nl6EkeK4PHS+CuUoTEUTTwltknbTRjQ4MWiDL70yCw1NutbmBNb367"
    "MA+Qswrl/X1UBcwFZ8jc0iWIlsytEU0KAD01BwwoEvCAXhc87IIQbSGotwydK4AqRokYBfBwAqo7ATxpgYJKo9WuWvBIwAGOarCK"
    "+qsZ67GGoK++7UfGb/UK2r7uk0DjftTFer4X+iILhNWvPvJtFc0Bh5cPLjB0JYcAUGCGBe63wGMWVIffEkGkb/TE6uhFrRGUQy7Q"
    "v9IRlBrQCvUuGkc0VemdaIDesdE7AGOrfqLMJQgrBbt585+07f0Piclzf/OMV8huLKMFWVb42jdtQnurjT/6iwlM5Ut45KFNuFzw"
    "UHAcbM9YSEgBl5W2aXrAAhQxUPYgkxJtb9sG+3ALcn96Dd6lIthVgAvITUm0fcs2ZL5pOyxbwp1x9O9LCUCAPYbnlAFlw1qfgqcU"
    "Zr84idKlaeRP3kI79gAtEm6uDHIVhG3DM+N3yHFBnkJT9w7s/a3NuP7bX8CtPz4Or1iGSFiA66LtG/dh6wcfQ+uX74Z7Ow9VKAPS"
    "giA2vCqaVpJgQYgEGC7u3DqBm5deRpKBLfvWoZD3kD1dAJcZMiWhvDJUaRrp9Ye+0Lb7a35EWIkTXnn6noFsVwQs+AmqEEB7xkZu"
    "ugzlAcmkbAS4cAu6OsEPbu4AeAFAH/QN//PQFQ4PA/h3JkFX0OSGaQNAbAcwa4KxrQD+BbpqwAajSU45s8jY3w6F77QL6m/tS/kP"
    "iGuFqW1/cA6izHZ5Y4qtrONu+9RJlLen4K5LYMv//yLuZMuFwpet/0XHQtJNWz+BgjsJiT8B8TgYN0FoN4BHqwFJHgTwzdDtHBcB"
    "rINudTgP4BugR27+D4TcCQcBvAhg1IAKMH5mJcChOdj631MpgucxyuU3BrhAkSAYa+c4fYPdJYA+CRrx0WEySWCDAoMBATwjEN5Q"
    "hWg2BZMGrMhNeEMAKGBAAWOqqgUiD6VbIVhXMXyJcyuAgG4yya4NBGBP2gQHCX/6wwr0UUTABZ1IoKuM+7FigfpgAjSJue0QC1Us"
    "CKBPaC6L7ErOWVDCDkaZeagMfs4nIE2Q5lpoEOneBQbMzPDKEZNOhLRxycE6VScHtGq2zXx+L4FGV/O2mYBuf3RuwvSvB6z7K0jk"
    "5gusbTPONQXqLUMMlwwxqkMMyaF+LCXhcUGmmothgwcscLcF1SNJgAIQv7EJj7/3FgEJ/T5wII66BLhAv4qUZ68h8NsngCf982mb"
    "Ki0rOO+0avr6pa6Li0gvRXzJGgGTGehb+LGVgpIcAcn0CEoFychaQL8FetGuaolYrek+0X3zR1B6wFEPPOaBhnxAz7cLvLTP7pXQ"
    "xKwJUEUc4VeyiBVUIVXrnWnp6AUwtJbni5ULO7XxDzIdX+tOXfg/z7r525tZteLGnRK69rej/e378Zn/ewL/8I9X8GWPbEGuNYX8"
    "ZBnbWhiZJsCDgKegkQUiTcif9+CRg6avbEf5Yh7Zl6eBWQGUFZre1IbMN22BTAu410sgW4ClACsFBsFqkiieyiH3v18HPECuT6A4"
    "noW9rhUzf38TFwv/DHWnBBLAxr59aHl0O9hjKKVAUkAw4N2Yhr1nHTb9QBeyf3Ues/92DSJtgxwX27/tMFq/dj+8i3c0z4ItANbf"
    "TaQMF2QCTBbKzi3kbp1G7vplrGtNYd2OZkxeLeDm6QKYAZkUUG4JnlNAMrPnn1s7vvqHRKJ5nL1S5KTcfWmIn5OS8OChDIolBzfu"
    "FFbj3Y4b5b8Bfdv/tyZh74W+5d8JYLMBDpoBfKtJ7H8MwPdCt0x0AMibSuRHQfydiZezm8S0s9kW9Ecb//rqL+wZ+Jepnb9+Aipt"
    "obwpeZAtOsC2aHU2J0EOY9cnT0Ilhdj4f19N7P2JL5Q3/+3136A9rZ9wNyR3O5vTTzLzf4CrkiBMGoBjF4CjAH4AuoqCoPkUbhpw"
    "5DkDNByCHiN5E8DvAPgF6IqNfKMW0FMM19WlRM3NAtu2EVpbAdNe9EaQvqjjXIsS0KijlETDFqHbonCmsFz5M3SasUMVoEIaouIG"
    "JSCRaiC3AgNP6NtWfbtaAiPPCnm/WiHSJ873X7VC92oGoinzkzScCo3aFxHcmOjqlJQOCu4nAEaXGFP4LnoacH1ro29BacAyvxMF"
    "JZYapLJJ7MvgkRI4V0Yl7wE35gwN65sr3WpR9s9ShLRxKYCcP6ozSvgpVhlgMJ/dLzB3Ggc19Duox/LLxM1PtOxXNICQdp5y5s5o"
    "K9lyp+noygAffFXGTqq+PPN40CrGaHhyPx9jvWaPp6PNoLE0Ubu2QVhRQrIUuyqAYR9ktcxz2cFoXTLVG/e0jbqvdXEB6ScsrQWt"
    "QaBkf6PaRH1wwYVuiTCjE0cLUM/mTfWkbmlb3akaFPHDvm40kXgmTaI/bVoerciZW8J6dVYTcqeosuVGNEjv/DGWCaLOu3HOmF3Y"
    "qXV/1LLjLe+2mzZdgDuNslPGlZslbFufxg+//RB2bW3CsX+6gksXp6CkjcuzApcmXSjPQ8oCiBisNAGDAgMSKE/MYubvJqGI0fLY"
    "Bth7Upgdm8Ls5+9AlVzNA8b695gZ8DwoR8HqaIW9K43pv38dt587Dfd2Adb2NMo3S7jxOycx+ZcXkdrRitSedfAcB+y4+mJdM2wD"
    "UkAVHUz+P+cw9W9X0fpVO7H+HYfhKQe3//RVeJdvmqSAUVHrxgQgCQ8K5fIEbr/+ecxcv4LM+mZktjXh2plZXH11FopZgwpOHp5T"
    "RLp9z//bvPWhJ8hKjUPde8xmDQPQPY8hJaFYLOHmzVl4rmcUqCG34WXom3thkvHPQnMQ7IOeDuFA8xL4pPX7oNsoXjHJ+l7o6oZz"
    "ULwVhO/yUtaPoeR1tH7+zp9tf/b4n6/7q9enylub4KxPwmuywJb4ZhDeBj3y0gJBT3YANqqE+Ory1vSBlr+7cWH7L748WH7r5g/P"
    "fMWGPAt6QJS8LRCUA+Gc0R4LugrhL6CnXRQAtEHzRbwZuirjJ8x/82WmoZssCFNTDi5cmQULD/v3J+E4/EYBFHwZiJL3iMCw0yoT"
    "jpF/+5qxQaMJUG8iCKSWDXB0Ahgm4LwAeirGDhlG6hYzaaDJBD5W5BalAfIEA8M+r0IIKijMmn/6Tlw11omvVaKcQQOTo2gfo899"
    "YZvqBb81RTRM37ROWdAgxn0k7WTahYRZF5uiI9oWvsn0z5kABiSo2waCkZ1LBReiJewuOFsGD5cQTjbxGgSWVZA2+pMgoCKkjbyM"
    "Ull0EHR5vaQouLB6VQtCg7btfpWJrKAebVwSIgjB+UlSmJBa1DigOEwKwu9KRJJfsQyIZr6EJw/O5qF681ABuLAafAshYz1M2X7Q"
    "k93VDDGRAvXptVx1cGGAgJcEkPFtUzIAWP2qhYaA7WsALNy/ulgrnvDbO/zzK9eAEyrSJto+t31t2TY1aIkog1HQMclAnnm8wOHY"
    "a14DvoUKQA8CzaDnmkD9IQi1NOCbQF2Cwhgiiej0h8bGKz4xtA26ayNhmT1Iu+WzzVu6+mXL9nG4s4BXxI3JMmyL8X3f0oFv+drt"
    "OHXuFv75X1+HU2bMwMbpOx5uTpdgQSEhGKTpD6EEkP9CDu6NEtb378DGgU5sfnIfEp0pzPz9LXgFD2yR5mpQCsr1AGZ4RU3MuPGJ"
    "w+h49qvQ9tYt4BJDlTyokofWf7cZ+37367DpyTeBUxa8ogvFmpuBmeF5CsomONkC7vzpKbR99S7s/W//CXt+7Vuw/YP/HvlXbmHm"
    "cxdAzRIgXeZPYChlQbEA6Dac/CvIXnoNxWwezeubAUG48Pkcbp2ZhZUSkEkBrzgLpRhNWx/9g9SGfe+E5xwvZy/CLeZA9xjf1qpM"
    "hVAKYKU3r31dGhcmskgmJTKZNJSnj/wyWiV8/33N/Ptp8+8EzaGw1/j2y9DjKUsAfs/8+VuhCSCZiSwW5CCNs5m/u7FDFL2DYtbZ"
    "42xMXlNJcQzA35jvKwH4KmgyxZdM4n8GjLerlNhGroI94/4zufxn2JJ6FZI+DyH2Mqn1YFwE4zp0G8ZFA3QcNM97xSQ2fwLdljEJ"
    "4B+rbMaybSIRQQgCK4bjasVnAMoLKxOkxBtKNCM/9VBAaBN1YqvLUErGQFtMsEGZJOjFJOhYCTTsEo0oRjY6l5oXBhP6TPJwxA8p"
    "KhBsUEDk02qcmT9pYKWl9lFQQVWACrrlYZYZM8zIQwfOfo94YwNl6q4I8FaRmM4wZE80Yv/9tNiKBIW2P6GjwfrnB6OSAHn/IIM+"
    "qNDl67Md/LO+m0w/2LeYMjZo1Ab12qAxf368CyyrHcJlwAEPlcFPhu0QKydB9Ukb3XlIG92AtHFJZ6eTIjwu1eRdq3ETHKnIykii"
    "UQvolUxZPyglbtzUAT9QtyI3dHYAljaen8APrm0iJIwuStbvJZY+qSPSA04gZkgoSCArQb2SeFRAdZmJLkCDE/woY73fO22ePwPg"
    "s8Q4JogHBPOYY562gbRdnaRB8J5KolldWRfl/5H3QRvEG0EX57G9IwTKSEJgM6QBJlcTXDDvlRHAqCT0WoysBcNhs4I2UX+so26J"
    "0H7Qhuq3QS9ZYDM9SbcNrt0ISsCFgAc8p4BuZgwo0uND3cj46HouDCQZXaDo9AesCkfLXU8F2ANJe7R52yPfb6XW/VLhxsvfDOEg"
    "O9WEVErha75sA3ZsTePP/8/rePFzl3FwbwYduzJ4vaSQdRxsTkm0pC3YNsGZdsAWY/0P7ETLV2+AyjpIdjRhy/sPIP9yFu6tEuSG"
    "BOAoAAIsBDxWECTgTTkQtoV01zrIXU0of+4GZMaGyrpo+dotaPrKzfByRXi5EmTSNtUKHow5B7OCc3UG7d+wG+u/7SBSu1uh8mXs"
    "/KmvRerARrilMtR0EUJIsJJQDEhrBoTbyGev4/brMygriURTCvlcGTNXi3ALCskWGyAFtzALaaWKLVu7P5lc1/FRt3gnB88FKxd6"
    "CsS9JasCLAT9/AxYloTnMmbKZXieB8f1kExYaG1NG46GJZmW6F++Dk3eKAD8EYB/Dz3O8fPmvz0GXbXwFui2iUvm9xIQmALwF9Zk"
    "6c1wcZGT4tOcFF1QOALGCZP8O+b3jkNzI3w7dOXBIRAuskWH3PWJjH298Plt7/3Xa4kz059jif+IJusBKB4zz7IbwJ8DOAvdFnEO"
    "wAg038OYWf/yQjZHiHAtK9E+DSL4gYoGDASmp/PIzRTR0pTC5k3NyGaLc4z3G6VS4SNNm7vNTclRvzfNMkbZqiqxXk1UPsrObbgP"
    "elyghxnPgdR4mZF1gVEVCeqMdENXrnQDyPhJqh/YRG+ikmZkYZM/ZQCr0gIxB1QoMGMWCrOGWyHPyjCeN7y0tx3AwFr0j5tP7IcZ"
    "KRZWtSyPcNMHl4Kkb5V1L1rOeB9IbwgqhG0c/u2cf4tZD7t1cEtElEmCRpOgoQRoyAGynjFqXp1BeCWJI02UwcfK4B4/8fc4rAhY"
    "Zk/wUJTYr8ww0yf0RIolkDYGNi5aYh4FZ+QqpmsU2CPukqCxBGEwARouMcEygOlKwcVohVn03cQqAiYUgH4crimRHhG5jLfhSMLj"
    "mlsJqQGGrAB6CWJUEHdR0PxNDb751v/GBKQMuBD57z0C6iUBHBPAkMMYMbzkKwEY+qDL64/4FTPBiDyIgPAwTQIp46ck3fvjJt8I"
    "uhi5qOgnYECaKhI/RklQCHyvFucFRWyHTdRlMY0liAZt0IjNlHVXYDs4AgyXzdjOAnjMhnqvBTxjsVjzEZRsSDjNOz2pgG7F6Aep"
    "CRgeKiwAJlMk2beqLiVkY6tR54D1d11YQViJL7Zu+7J3WonWn5l5/d9+0CtPJ/OqCeWywvYNSTzxrbvxj6/cxj+N38LFK9M4fGA9"
    "dmxrwbWiglV0saGJ0J6SSHa1gZtteJMOvFkXXtKFtSGJlrduBBcUuODCh7SIFKAMeSIBTIyZf7uF3F+/DrujCev6OpD780uY/OtL"
    "WPd3HWjp2qRBW6VAzCApwcoDJMHLlyFaE9jwHQ9AJhMoX8iBXQWZacL6bzkA71YZnCewBFhMQ9A0uHALt29M4c6kB48EbEGYvVJA"
    "ecaBIILdYsNVZXBpBonmLa83bTz484m2Xb8DQPdhBKSY955FtVZdZ5ghBKFc9jCbd+C4LjwvARICCVtCCj2OURkeDtuWYFaGLVP/"
    "GXP436UkXRHBrCIA5ino6oB10ISIl6DbDb4GwEMA/gx6WgSgiRJ3g3FRJcQ+JOmfQfg/8LAVmkixKbI2Zw1oYUGTLz4CYBqM4yDK"
    "e2mrTUy7rW1/dvmaSMiXy+vtV9iir4fCdvMsZw0wcR26iuKOASsmfPvi38qSWYNyWVcU+D+FAqFcJqTSqgIQEAJQnody2dVrTIDj"
    "KpSKZczkS7AtC6m0pWsi3hgAQrtB37uh2Ya7pV8WbG4UElXlhJVlu6sJLBCkP1OcCC4Inh/qMbokMVxwj8vzD3gJuSE0UOTzKQQl"
    "pSZQS5tS1yYzDSIKKqzwVjzHQC8bosYoqDADhZmKFghd1q2WfuNaM/GEJvzqF0DGv00RtDr94xEejqdMNcuwACZEhPJpKTcpFX2r"
    "wS1QtORz1fre71Xqxk6TDPfq8lt0BD2dfk+q6SVOUjhabSkBuAVGEpRJgZ4qQwx4UCOKaASMMQATHJkjzosEqFESx5IBFvyqBcby"
    "SMBYkzaOeua2qgTdAlGuODvz6pgPMnYbO9crjI3zE7ekSQz8f1qERlYr1Qw+LSYkQR0J0HNJ0FAZNOISjSrGmAeM1bvmiyV00bai"
    "1Szd9yuiBEfb5lZG+hu22GggSZAC6c834AJGQaILqwguSBNU6IsHUdWmpXos5p4Sca7MPOoBo2bvxhjILgAydJqfXk1Ui14yQHi0"
    "vD4ZGWXnj2ZM+wDiKiVHqwku3OO62Fvl0zqhq0d8+9HhX1TYQRyhLz5SZqyltQacF4IAaWxHUtuO5xzQMZdolBkTrrHXHJ6hMZio"
    "dSE7EoJ4hFJYITRkgfokcY8E6/UknTiuYkUGomSICnpqE4N6GHSeWDxPpAaJecIxkYWqDS6MkyYCr2hZWc2KEtJT5+4+tsAKIHm9"
    "ecsj75fJltemLv/LT3qF3B7FSdzOMtIpgX//6GY8sLsV//Tybbxy4jYuXJrB/s42bNyYxrU841bBxfpmRrvHkFJApnRFgpMtQVpS"
    "55ke68tYMlMdmEHsgSwJ5SrMfO4G7M1JbH3fI2jt2YrmN2/EtY+/gtyLl5F+ZD3IYrCnwEJCkoKSBDAgPYZISHh5B+5UGdKyIFMJ"
    "UMEDXIKSgFeeBNQsnHwOs5OzuDPpIl9WsC1CwnNRmlVgFxCWBAmCW8pDsYPmzQ/9XfPGgx9RbvmvNanDvW9FrTUz1kQQQkBKfRRn"
    "ZotoaUqiuSmJRFLCkgKup3BnsgDbskDm6pKZIQWQSEg4DmM27yCVlLBtAWb2QQZIKa4Q4YpWUswC+FNmfgszXgL4X5gxKQRBCPLM"
    "82wAcEIp3gXgHSToIIBxZr5uVN0zgd7DABUB3CDCVWZ0GtBiVgC3RJOVUykLhWxx2lb4PSHo25n4UWa8yoy/EAJXfVCDTCkHM7Pn"
    "aWfiefodyg4jlSJs2SIwPcMoFYFSmZDLCngeYNlUwdFh20DZcTEzW4TyPEhBmMoXkbJsWJAQRI2YzHG3gIRe0lMxAucelpxXOlx/"
    "lFUC0ZFQIbiwFmRRwjgKTfakUWuQgoCABc1RUGKGRwiIhWoHhvp9/JFDfkCQNmBCiigy67ohoMI4A33KOPj5QAUfWCgaErplkiP1"
    "IRw/1UsaJOpC9GajiqPAiiToqyGS6CkLeMoC5SxgzAagGKOmqD4LYCgaaHNtBz1GDUpOliij98BxHSZNUFv13lQRnFtVrTxpX4+D"
    "m8zFgz+/MiTBBJcEmgC4QEYBR8E4SqT8aoBxBWRN8DnAwBhX3XaF/66rE8rEI2XwhRK4w+dEsJmWe6MzpKsh9Hnx+RXKVaSNAIZM"
    "ItBJAYBQaedE5NbK9kffmRLzZOTWEasYfPoVJbaxQWUg44KPMoujIlzzCwqYMGuehV7zCZhxmwudIZOgHiPDJ0NVN42rGFSP0TxJ"
    "Y6MI5krMIGIQK5BOlnoJGAaJI6sHLmiANEFkplEIwxnGhueAYYMzZfARR/9AMUVt+jEznLIbhosmuiqVSbc+H1aEi8AHv1uqqurk"
    "2tjE5xk8unK9uOd1cVhXMFXa2+rYSFdZhP36wbjMSIn9anJeBC0lBthIQaAJDA/Uwyx6fNuhEFZvKR2P9ALILlZRo89aWCFkmZYI"
    "48sz/ghKe5VbInwbmTA3yFxxttVRYhyVxOOCecTVYB4YPBp9N/M5ExpYoEUnJTXw+bP3TODPCmBVTrRu/c2Wbd3/Wp66+sFS9vIR"
    "dgt2IW+hWHTR1pzAt/XswJcdLuAfxm/i5dduoqkpgd07W7FufRpFpXB71kNrwkJrk0DaErAkAM8DVZR/E1jpfj6TlaF8Jw97VxO2"
    "/WwXUgfaUDo/jdQDG7DzI29G4cQknBtFWGlLAxKk4HkKEhLEEixY91USQwgNRSpPweMyStMzcErTKJcKmMkWMXnHQb4E2DahSQCy"
    "wPBcfXNOFoGVA9d1YFnNt9o2f9lvNW175NeVO/u65xTumxzOultfLIQ+MsmkhUxbCm0ZGzP5Ml47dR1tzRkISZCC4LoKqRTQ3p6E"
    "4yhMXM5hXVsS7e0psGJYloAlBfIFN7jRNxUAd4Sg/y2l0ICGECiVXZTKzllLiD9R4BRAfyWF/EYh6JuVUqc8T/13Bk8JzVMwQUQP"
    "M/O3Q1dAfM7z1P8SQv5nIuwFQSjmf/Ec747ygNv5ElpterVF2CdIUDMIswLwlGJ4GsqEMkUWUhLSaQHPY+SmGIW8Qm6WsWWLxCOP"
    "CrzyiofL08CNmwLKI7S1qHn7zX0+BbCAEASLpAEv7u9eh7nMxb4DDIGCKLLvE+ikSaDZBN2J1WFWXjCgs4jBrJ0LMXQVA0iPmCNN"
    "KuRWOcuo4wj7H/0EO7xpSETAEpuo4v1XIE8zMOizmjv+SEnT/hAFFQqGV2G5jMuky7l7oiWS0X2UEfIxn4nbBxeIGt1f6K8f+8zf"
    "mRREj0YcVU+kr7VbAf3R0VE13n2sWh/WQMbp3jirnaJiTf0xkBGgLHJGm80ZbYJY8ojUKNlZkgEPBEX6T30boVsZqCsotWW0+4Gr"
    "wtzy7wiJI0rMwyXwUyVipAwwYGHpN14+aaMbIW30qxVcDqt9zO1vTy07F5wNhDwrqQiAGi0xF6talVU50tAjAkOY0u1gzTs8cIcC"
    "wExg8BGTpA7XWvvqMxTahzWTseoz26CJOtqegjSoQAKka26zpAHWIZB4khl6pnwD/VRIhGriIAYECUiw8SnalpfMj8MMhxgKAbjQ"
    "w2YP514ORcfDRsBg46OiwIIetdvQqrp6QIX+6LlWvOyquntZF4eFARUqyFQpSlxNkZ79COeFaaOMVpGsdg2JbzvswHYIo6fatjqA"
    "mSwF/za/SwGjzOhVQNYzZ2k+jqpohZDDQJEYEmrCAvVbzJ+VVSMoVysWjI6CBhM4GDHLgU0vgLssqK4y8JQBU44poNdQ3PsQ1miU"
    "X6s6Hl6lOPteuJyotJ+sQFbqX5Ntu98lEi1/Xc5eedIp3H5AqTKmZz0UijY2r0vibY/twNXrBXzxzBTOnp8ET+SweVMaGzc0odDK"
    "yLkSKZvQlFBIW4SEJZGwhG4tYQYJBZDQvtNTEILR/OXrIRI23GsFsAJcZxb2+iTsf7cVXGCwo0CWNLokQKxXkUHwXAUlFNgtwvNK"
    "8JwiiqUiCtMFzOTKmMq7KJWBhEVosQXSrgk0oUtd2XPhlR0Iy/aSLVtHk5ndv5Ru7/gbEsKMn7h/xLr7SgQoxebmnnWQKEw/G+mS"
    "f2adjO/f04RLV6cwmXPguEBLk8S2zWls3tyMv//Hq5gpupCCkEoQkgmJpqYE1q+z0d6Wxvr1zXj15HVcvHA7m04kXyyUSwAUNq1v"
    "u5JO25lcbnZmZsbJptMJsqRAa2vT/yuleMV11Q4AM2D1cjY7i6bmpk8LiU4SyM3mizenpmcBJNGSSuLGjRlgY7PX3p6aIgJSSYE7"
    "2TKmp124JYV82YOrGJvXJfHIo614/XUHM7OqwnE7TrTtA3U34r6RJJpw+oy4MujH9oNuipR4AkkSJugOk9OV9EgvF1ywDTGRIAEb"
    "jIRJKHzGeRVhB69+X59w0qKQ2M4yjN4++ZVFlYn5MuUC64R51H8eNwIqzLDmVJhtEKhQvaeWAU9kFEwxiad/q502pd6rcasSJdxM"
    "IGxfAfTtnqNvVaCAowo85rLul/cJAtXcYzkBYBymAmONYL3hewE+9BMZvy/Y7+X199X/s4RJNIIbd6Ig6aj3jEZvh3ygAiwgiIPv"
    "8AkYXdZ67REHwIEG9qiCGyQITnXVwnAJ6qkykw54SQNP/nfWmVQ+z+BslLSxFCFtjHJAUBVwYFPkfBg7Fx3bl4xULVVWLKw+h4y/"
    "5mmz5uTffjOhTFHQBFAmUVURe+dF1r6GDRlm4MkGkgrWIyPRJKVRZzf8LEYZZIJCoeeu63a4AdZtEcNgZGxCo6rPKmwt/ISTdaue"
    "9keEJFQALPitP/4ZUX67HoVAEEXBCmM7ZUBWG4LfSdO2l6JKNvsGtECMm8R7wlQfZc06j/rrDOgLQ9f4MjdyE66WPj72XtXFXgEc"
    "jRK42oSKUYQiMmnHB37Cqkcf8AlbRWmNbEfCtAhoew1I3c5WYReV0T8FdLnE3R5o1DGjWv3YiecF8TRAIZiNnVIjNuEFG3TEAkOy"
    "z49Bq1qdEQUXfDBRQJhKTAUbZKYCwcSDulrOC+P/EQKeYVQycS23Ja8eO8URvbvH0AWAvSmZXvdbqUTm78X06z/qFW4+Xp69tclx"
    "ysg6CVi2jS0b0vjmzSncmW7H8YlZHD83hStXp9HclMSmDSmsa0+gpS2BprSFZIKRtAlJIZCQDNsWkBZDCtZkn9KCKjG4WIaUAiIh"
    "IUBQ0y6EJJAQeqylq6AEAUKBPYZyAcUO4LlwvCLKxTKKMw5mpsuYnvGQLzFIEJqThA0JQtqQ62sQCoBXhioXAbJgt2x5Nb1h7/Mg"
    "+WkQXWN270tSPAtvAImu+0IDyzxPm6BSWcBwJiZu3rnJAPIAkoDcNVNQtkVClMuu305wi5VipdSeEruYKeXLgJrRrRKqFSAHoFKx"
    "KFnBwcaNaXR2tOHO7QJm884cQzvfM8cyn0MK5uwihSjhUJiU+kG4bf5bMtLnaVHobNfqmYGwckEYZmebyPRVI6hW8APu6veNlj2L"
    "IEEL2yMaMEM+B13eP+jfILocJj8FVsibFgifU6FYBSqoZe9nCBQlIkllIkJWlCAEfBJNwW1X48MBQsX8cHiseV4k2JTZh8GOy9zu"
    "kr599CdhVJMwmX8fUuDnojcrq3zER+6Vs+qfQf/8JSKgWEAaFjmbwd8hWnIyFQXwfFBB38YCSYSVAQ7pBMMH9RwmlEiTLjmmXNxD"
    "2A7hauBoogx+vgQ+WoJCEhIeM+QS+nT9G3qftNFvgZiPtDFCRhmMFvOrOAICNyByPiqrlxpM3LqoPbbMmoMUBAvYxEhS2O7hkgYQ"
    "PIQtX665TXSIA9JX1nRZ1S0pYwy6oMAdHGFRX8Wg+nk25dbVYEejwAXDPa71bS64MKKAbkU0nGLRk/DXt0E91dGKP4r4I4uAJGRg"
    "8/0ExzF7Fr0hBiqr6vzP81v1/HNvIdRLHwSLVtUt432OARjl8CewuhXVRlz55351UDFiB7yK36o32bo3ddFvuYvy1SQj4zDDOKES"
    "oPTtRbKi6nFtLl2qbQcRG6DBB7VgfK3RPWNDHPPfiwyUSQfMbg2/Gk5kMTaVGRLcb0FNyEhLBJnztVoxYRRcIBCEIZG0Iv6pZMCU"
    "stFVh/Rzu5pfYwLAMQb3qCqdWyU5tj97ZuLeTu48gKxXk5kdA3LjvhcKd878l1L20n/0SrNtjleCW07AsiWamxL42keT+PJDGVy6"
    "nsepiRlcvDGLi5emkUhKtLfZaF+XQqYliVSThWRKIp3UPH+WrdslbClBJHX1tyQIV0JKAWYNiAuh+Rk8M3TAUx6U58J1FErFEspF"
    "hdm8i9lZFyVHgUBoSQqsb7bRkiCkJEEwzKhpgNmBcspaZ5s2XG3aeOCPrOZNv0tW8jV39o7pxr8/5b4CFhZKxvNFfT/kKia3iNbZ"
    "omjP5911yvPaPZfX5fNu+7pMU+ZrvvKBzLpMUysLNLVlmpPNLclkc3M62dLUlBDSssslR1q2Jdeta0dTKk2lcl7lC7MshSBpSXUn"
    "O+VOZnPlUqnsWYIcAhenp0uFmelS4U42P82uO3XzZj43nStnc9OlbHbKzc4W3TsAT2pAAl6xYOP+GkF/t5IVXT7XEunJtkwgEyVW"
    "kpEAxw/I16I/rVYCHfRlkjYgtulhZaKIs+Aqp1RZrici5dC0ckAB0MHLAAPZaJWC7+AK4ABMmDUgQzWnglrRuoRklH65bPXNlh3h"
    "lYgScK7GPkYJN0GAZIEk+S0rYbBThgZeilD6GThMGLxKEGFYMQY9oEPf2EZvWBr79CYQnVD3xFnVAW1QaWIqE5ImeJWgiiTEb2+J"
    "lkfTEnUJEXAhTJgEEgYg8BMK/2ao6O8fCyhSUFzJcxK2QwAOY7gEPlr2b5WWMHpyPtLGciTJiZI2hpUe86+dRZXVPGFFSCXoINYo"
    "OQhJyhjEApa5AU9VrbkXkJiF618Co+DTrbGuZqgmSDWJ+CADz7kBMKH/7iolc0PmdjRIpr3ImW0kuIAIuMAQYCjfD0wwqFcBA4po"
    "MMGUsZd5LurxRz4g4DIbwN5PvhHeGlPQQjQHWCAKW3VkBPj2CVijermMqroXAIyw/slGSuMDfQpB+cp9YvgVMdpW51mhYKYXufWN"
    "ep5v3+45XSQg69sMn1OqOdJyYlcQB6OiasyvOFrB/jTIdhAkDCgZARX8d+eI3SgwwyLdjqmoUg/mO2cUjKBUsICsxeizQC/aVS0R"
    "DKx65QLAemqbmS6UgEQqIPFFQOhbAiPPOu4w7zLIwIteAPRpGHaV9G7wPsn8wOAyWcn/3bTx8N8nWnf9x+Kdc99fnnr965Wbb3Nc"
    "gXLJwqxlIZW0cGh3Cw7vbkV2powrN0u4dD2PG3eKuHghC9clSEvATgqkUjZa0haamyVSKQuJhEAiacGSAhIeLMkgSVCQYJKAcqFc"
    "huspuK5CqcgoOS5chzVZLoCEJdDcJLCt1UJLykKTTbAE4DHBU4QyewC7YM8FSECm111Ite/6i9T6/Z+xEsl/8MqzrEHo+/vm+b6r"
    "WMgXXDA8mp7l9lJRrLMlbbRta33Xw5s2plLWlq1bWzbt2Nm6fl1704Z0ys5s3tTS3NKUbE42p5taWtLplqZUOtXUlEimk5YkS0pL"
    "Sk9JKhQUpBDYvKUdEBKvX5nC9EwZG9YnsGFDGtMzZUxMXMHhB7ZCSEbZKcItFjk3VfBKhbzHynGFxeVy2S3euT1VyOVm8q7nFWZm"
    "SzNXrsxk79wqTM7kS7dv3ynenLxVvn7zhnPr9m33zu3b3q2io+4AyBYKQsWAAwyqrB2o5k4IA287uMWu7EEWQenw2jnNhZyp1K5F"
    "EztSeNDCYIhqBIFhwtYAMMGvUBjWiSgHZd/hjYBudcibagWfpLHE4Y1PI8ycX4mRCMi9Kssyo7ezcpUTp2iwA9OHrJ8tWpYJc/Nt"
    "AhyGTghIl2s6kX1hs6aKMOCBP+uYxFKtYLLAQnvKwIDfW3q3xW/dsQ3jeLPf/x+5tZRzKm9WdkapGowzzOMJk9j6yYSv47aZmuNB"
    "wWEKQASqaInQZakO8agmcVQdJRCSYHhMpmph0ecdUhHSxnK0YgHhjVtUB31ukXDtdLuDVVHSXDl6TDbOPiz5zHBFRZa+yXEjpLTR"
    "G1cfVMibK3oPCi5R0DJRnRgo8LAL9HvgHgeRMvYGvyADzzJ4LGjTMHvjcWNsXS1wwW+LYDO1Qf83gkcYUiyGFWGIGUetSGtEI6sX"
    "OAIweAbwTlK4BjxP0l7hn6pAD1nD9y5BL8ehfdNwFEzwImBCRfULhwB31C+pyH/XPk3rXNEkmh6WDCrck7oYEuFCkzHWsLdAJQ/G"
    "3bQb89kOCYLlE4YSVRBaR+22ZeyGS37LAMNbZN9c6BGUAgyLeNSGetYGntQEpsKQ8VLdrW3L9YlU5ZtsaPLUJGRgF4sgA7jqKiZH"
    "7/aoC7zggo94Bmzxq+YaWWHCwAtqhUSna48vKAA8K+zmkdS6/X+bzOz+emfm9W8tTd34Oq883cGlPGZLhFlpI2EnkEpYOLTbwqHd"
    "zSg6CrlZB3cmS7idc3Bn2sV00cGdW0Vcv8YGSCUIW3P7EQjSAqTQ/x9ShHZOElIWwbYEUkmJdU0SLWmJlgShOSWRtCRIMJQieIpR"
    "dADFZcAtm8OYcO2mzccTrTv+zG7O/JnV1P55kglPee7qol4xsGCMjAKKRZUsFNW66Rm3fXpGrju4r21zKmnv2rIxvXPD+tT2rdua"
    "t+zamdm4ZUvLuo3r0+ua0slMIp2gppY0mhM2FARcB2htb4G0LFx/fQb5kotH3rQXVyZu49q1LC5fzSE3VcK+jq14+JEOQCbx0ufP"
    "4x//5SQOHdiKBx/ciTPnXsedO1Ngz8HXPnYYiWQrvvBPJ+iV41etwwfWW7v3tCfLjtuswHjwoTakUh6yuSIuXriDb/rmHUjYCrnc"
    "DK5dm5m6dWt28tatYvbGjeLNK5cLN27fcq6+ftO9zIzLk1l+fXoa2elp3CmVKQtQ0XE0AupXbDC/8VspKHLbmYS+5W4KGKYj5FQI"
    "id8oUuZ2jxDbVVDwLMaMjsY9+7gBFEb8CgUfUIgSyhX99gfzzwLrm92yKVlWDQIVoqPQLELQI+5zKdiRBGqZAeqKwAX/O22TKCkK"
    "g9cSMyTpGgW/pN6pQNL1P03Z94gDft4BH3WDHsrw8xsUEPQrcNYL2jLuvo4HpbnkTy2oLM+lyPtTg29j/eJxYcA7nQD4Ca8O6AgK"
    "HhOKARloZdN1dC66G46efMavNEhQXZUnOWXaIFy/1DVSteDx3BGT/tpZkbVLI3omwuD0XrBx0RtwHxRhAHZkzRm6b9RfB4sZIAUX"
    "hCLCkXo0T1Jgqqj6y+AxlzjjcLj2DRwZN+63gvlVW7pNxeeCwKqBC8KAC8wMJj0+2gOZhBJZF9TvEg0nWQwmQD1W5JZ1pXaQKoDQ"
    "EPAOCWnJcBFwONd9Hp9EmEuivERbnYuACWPRygSPQ5Z/z9jPsHoMQU+6W9WyoSK/Z85vMInJjYxGXspeGd3oK4MnHHAmagfupi76"
    "QG2SNCjfZAgZk2YClVggNlprQKGW7WBj0yyE4BpzpC3N2G1AwQGhxIQiomeBa06JYDOCsmxiGgs0aIF7JbjLIj2CMkH6O8Uqv68P"
    "ptjmXS2Qrqwx7yehABYaDCEv2G+Xud8Bj5XNhCKv8RcUOcOxdX8KKzB4ykplPiuTqf+HRaJbFWe/0fPy3+AVJru98mxT2SmgVLAh"
    "LAkhNWnj+tYENmcSAADHAxzPQ6mkkC8qFMsOiiWYagRPg5FEmiNDAkICli2RsggJSUgkJBK2QEKQ5sIjzZugGHA8Bc9hKHiA5wGe"
    "C5IEkcrcstKZfySr+S+STetGrWTbcSYzavMNUKVwzwMLpqUKySR1btmc/pqtm+2ubduaOnZuTXY+3rd7296O1o07t7amNm9tQao5"
    "hVtZF7dulrF/7zpcf72Av//cVRRdwgMHNuDv/+EKJnMlbN7citbWFC5fyeLOnQJeee06blzLoVTy8Oprl8AKOPKtX4Hs63fQtnk9"
    "CqUyLl24Dqfk4uatGbz26ln0fv1XYPi5F9HaZmHb1gz++I+/gH/7wnl893d1I53ehZH/9SrOnr2Jr/maHXjgwQ14+YvXkJ0s4Bv+"
    "ry1obibcvllGa6vV9u/+3ZY2y/Y6PDcP1y3hzp08Ll/NO+fOlW6dOlm6msmoi1df57PXrrmnZ6booufyJSK6IiVniQApNHmW6+EN"
    "KRVj1hCWUPtl8jIy+qqRbN5r8V6r+Kz+7c+ILrENb3/8JNQw32u03IAIBdZlykUOWcLdSLDHDd1TCkdKUkjWmCCaQxC2FntaQXJm"
    "/qCyvJYgyHf+KkhMpQlQoiW2kYSyvwzuLIN7HEPeaaFhgczTSvdmm7J9vmd0OiRS9ft/RUUf72rt6UIJk4SuRnHNM1lce4RXMLpM"
    "Vy0Ml8CDZT2WT1ctLELiqM+dJm10gKAFopq0ked5dj/otCMEeP7aVQbl944dm2/NoyG/guaUYAIcjo6PpQjEWrX+eu0nyuDeEvNo"
    "mTiTAMPiStb7lQbUGpgL21V0efLcdpWGxsKIlGtHwAUvqKBhuBBwQaMe0OsR9SaYBi2gx6LGJobz7R8i52bh36V5gIa65AXfP0Un"
    "hERvot2I/ykHwEKkD59D0MEHfjkAFsIKh0oAYumtLRFdzJbBvWXwaBl3XxerJ0EkIj/JCBHuvRwbVetecNES8b3S/KFTNXq6GhCu"
    "dcYQtEQAklXWBvpt0Es2dOWa4JAHgdbgXaNglDQgg2QApOMKPSpTgyEmjsiWwX0lo3dOoHcNeeYcA70KnHXv9zyWFcBcIoh/Fsnm"
    "f5Ey8/u0rvMtKBe+tjx77au8Ym6f55YzqlRGoQQUiEAkIaWEJQVICjSnJFqbbBAljBJqcCCoHGeuvMQ1dDkeA4o9MDNKJT35TwMJ"
    "mseJwRC2paTdciuxbt3xZNuuY2Q1/Z3nzHzR85ybgNCAAt6YJer3JLCgmOE6wO4d9je/q3/HU49/+7bNbVYCzU1JIGkDrGlpkEjg"
    "8vk8nvnUK7h4cRp933IAG7e24qVXb6GYV/jyN+/CydO3MZ0vg4UEC4HNW9dh3YY2/K/Pfh47dm3G139DF/JFF69fyWL9hgyUYohE"
    "Cocf2IUbr99BU0sT2GK0Zpqwd99uJFNJuJ7CbMEBSYmtO9ZhZ8c67Nm3Gddvfh6XrkwiN7UFly4VceXKNL75Ww7AdfP43d85jePH"
    "c/h3X5XBVK4FZ88W8JVfYaHry5JYvzGN/Qdh9/aKbYDali+4X379uoML58vq9Clv8nP/YH/hH/8x/XuplPpjTxGa7BRm8h7yxTds"
    "2UI2cKR+OXVVWXUsOAZ94zMKYFQFTNmVtz9+CbYTucUpmhaIogEYyuaWx61qfWiwdgUjvHziROsukGwulBj7f+K/u9DjQ8dcCp9X"
    "Qt+6Rt1BeOPk8zFwXwE8lAAftYkbNUv7ad33a8rsTanvvXBWo+zfMsKhINdoIgvmTXJ0SCeBrEVkmMF1zyvVCEojVQvZMnikBD7q"
    "mJ5fexESR03eGZI2lgPSRg1WVE+Cia4dEI6Gs0y7yFqvXWPWPDxRSieqWYvD9qZaSWgVgSZK4LEiuDcJHk0wZywztm2FYxlNQI0x"
    "DxGiv0i7SvXUjobHwYG9MOCt0QsPuqJD95YTygDSoNEUqDdB1JlgGpRAn0XINPrmudb+NRDsHqrmTfDB7hBQQWDTHIStQ37lnFvB"
    "oD+3BSIAgzn8Mw+VI4KXske1dNG+N3QxR0CmehStP0nqfpL5gY9Ku21BAwH16nzUjpdZcyvkwWMW1NMW8JQ0hIqrPYJyITCFAtuo"
    "SR2j8Y8ydQlF5rEkVG8KNJqA1ju58mcO9M5vOXljCEOPWcB5K5k5L9ObPmu1bt4C8CPOzM23usWpL1fO7G7PKWxWTnGD57rklT14"
    "JE01oEYSCBpsUABIKRBpoIFBYEG6hF4pDaIbtMEHB4SwIIR0RLrllky0XbVSLWfsVNsXZLL1H0jI03Zq/S3PKbFXnjK/+8YuOb8n"
    "gYWp2QIEJ7Bja2JD95taW7bubQEmykDWAdgFWALSAtIK5Cps25JGvuhi7OWbeMfDO9Hbuxf/9LmLaG5NYf36JDZva0Y6LZCbnEFm"
    "RxoPPLgd11+fRHNLCnt3b8KdazncuZHFzRt3MJvfgfUAmlM2Nq5vwd5D25FZ34yzJ87hD57/U7z1q/fh0e49yN6eRHubQDYrcevm"
    "DF747BiakoyHH9wKVoyrV7OQQmBmqgApHEzlPOza1YS3vGU9EgmFM2dn0fN16yEEAwUXKHqApQDBSNuEjl3Arl1l8da3zqzfvz/5"
    "pvPn7QczGYXJO+0oFwUUu29Ypfyp/PWxZ5u3PsHAc/wG6TlaLroMPWYry5FxW4iUkPpBvKoKqryq2x9dqaAqKhZKAWP+6lQpVMkA"
    "gHYARxcObO+dZIlBTxAwIszdil/2O79r04GgA6AIlU0w9SfAExb4KT+QgSnnFEvXgQFdZq9vYgJujHtjtnE/NHN7V/WkjLu/j/QE"
    "wGPBHi0ydi4EBgAHPFQGHy0ZgkLPEK/OF9QxMK7AY5U3j/rHv2GtcQveB2DYPxNvpHCDgHEC+us92xxZe0P2OJYA9VrEwxLcJYJb"
    "pGUldMcY6FNA1jO34D6hZBGGUyYyLnM194Arfsz3sek1N9U1usdcoEyEFNNEkqjfBrUnmPqEBhiO+LfX96D99EkYR6sr5xRHWhwM"
    "mOD30/vAd5n9Kh8YvxRyD3gR8IDnrCUQpURWK7BDNXSx2yIese6+LvYSaBRA5l71nw2QJ/wJGMtpEfWrFlyQbmWEggUMWtqe9FjQ"
    "FYeCGtrWUndsIYxtFOaqgar0zjPxRgk8VoDqtEEjNrhHrkzvxnWFDMZU5HLiDSeswOw5RPKySKQvK7f8F4mWra0krR1eaWa/V55+"
    "wMtPHlbMOzynuInd0jql3FZ2y0lWXoI9tkBkJkGYKAIMViACKRbSIWmVpEwWCWJK2KlbJBPXAXkl2b79JNmJ16z0utNQ7g0uF0vS"
    "SsDzymD2TLvDl4bcM8ACka5UAFw9ykMj1MlWm5KUd3TiTRFTowcWoyUhsHV9GmfOz+DixRxmp/LY39GK3PV1aE0wHn/bA9h7YBtK"
    "ZYWZKQebN2awZcdGfPW/PwTFhLYNGRw6vAPf8E1fgaamJDZsbANA2LV3O7bu2AQ7qTulnhx4G7LZHHZ3tEPaFlpbLfzwj/0HTE5O"
    "I5X04JTL+Ja+BzE7XQBzEdMzBfzrv17FmbO30f1oG3bsaEI2W8BUzoFTdjFxroCXvlBAe2sS2zcCwmdU8vREKiJA2AQkiRheKZvF"
    "VXgboMG1N76CPjl7bfh3mreDwX0eMOaZ4EuBa6V3wXzrBks7gO5aaHsN6TQ/1X93DOEM7moZ5aq/V52KBP2wHN7YhD2hlW0PTuT2"
    "xwcWov90gokPc29+VjGo7meNlrf7jMceU1YQj92l+9mKfYrul+7/5RFVRUpXi5WaEUwV0MANKdjAoARGBGMIWNZIuecNS/SEDyqU"
    "TNvKrCEouwcky0AvA0MeMOHvq2KCp6s0Rld7z2j+Px9m8LDPGO8hyoixUNLn36TSWAn83hK4vWRaWmSNYJSB0ejNo0/a6HDIus8L"
    "n4msZxINL+DlqKhwGb2LO927iO2rsI/m7GQZ6Fes36ke+xK9KS4DKDLDhhqzgG4JDAoSA2BkEksLrHPQ52dIRcDWKFltnjU5a0iu"
    "yWtyqqpJHRUzXNLkomWQqS7TfBspXeqeTYCGbaJhm6ldAn2S0Cd1opm5i+0y40Y/RxFpc4BJklQVb0IUTChzpGWIQ4AhOqlCMaqm"
    "Es0d9dtoILOGLk7cI7o4psC9xi+MhZMk9D9p9eKgFfnTem2N4d7QI3vrtNu1zxebqhPAYoYF1W8DwxaQFSTG/EpCBmXNuq2mzew2"
    "trKmbYxeEBFBk0aDsxKqVwL9RGIIjIy9dL0LRoyrCAdJ/g2d6LJplVAAMA0hT0BYJ2Si5c+llZJ266a2cu7GRrc4tYnsZMZKtrQA"
    "yBTvXGhXpYJltW5hYVkMAKqcJ2fmFuy2zU6iedMtJkx7xZkZeE7Oat18XZK8VZ7J5a3URvY0k5BpoVCmouENToh3t4CFctlDwSkD"
    "jgdGCYWSTADUVphxWpXHbU7Zy+QLVru0qGX/vk3NLS3SLhbdlt27E49ZxBKzHuAowGIE81ssApICmZYEer92J9Zvb0Mmk8Kbu7ci"
    "1dKEzh3tSEqJ9V0tIJHA1KyLcorw+o0ZnL+Ucx1XFGcLTmlmulB0PVF0XeEU8mWvXCo7M9Mlj4VwLVsqz3GhlEeplA0SSjY1WZby"
    "ylLawmpuTtqJhEgI4abSKUqt35BOppKUSqcV0mmJr/iKLXC9InbvSGJ3ZxNu3ZpBW4uCZXlIpBXy+TKKeQWRIt3gOMshta0yaEsS"
    "KBRlyilbb7p82fmmRMp1XcebzU6VZrK52RnHK80CaoYgZhlluI4NgOA4yft+pOUPzF4dhr7Rqymn2vfPIbJchWM8UstJ1rPGtcp/"
    "K/4/z/1zrrqBqQYTfOfr9/f7ZFfVoIIDRJjp9W2Iu4aAAhD2wLrgITcSTEoKR/XcdXCz6v97ked02LCSM+YdvRkNRkvQs7RJD9Yb"
    "I1K9zOhlEv3M1GsRdyxAynYB+sZvKDrJw4kwns9AYRbqnggMjP5kPc2gHpCn6X2t7KfnVdyz+c6hG7n9dDnCMM8LJ7g+SFBmHiqC"
    "kYRCwhDWwfA0CArPbXQCgj/asrwAaeM8Z2LAjYB9ljkTog67sQYyuhTb5/+Ritghp4pnQtVM5sJWkiIxBJTfdjRIwBCT6GNGv03o"
    "WWT6j39rPuwnur5d9APqWfOTZ4USFBwOg/w1DH0jvAsR8kIiDTAQo8R6SkjK59/QfBVZm2jYYh42bSbdgtArgF4COgnUtYpAQ0UL"
    "Xq3RkL5P8m2XXznn27FypOXBJ1n0AXHFiIyJ5HkqE1Z/XxbSRdwlXfT9vwca88B9wdQbcwNv3X1bUdOf1huLMod+14nEKovZ7Vpn"
    "yzOAfJEYEmrCAvUKMzUCpKC4ct94lWxm9P1VhER7rm00ky9YX07oaRaA0HHwMJPoV4w+Gzjic2rU0LtjCDlNskFFpQEVfJ1brmQO"
    "fuP9nFp4ACbNz2nEcu8CC0RAqaRDsum8sITgZhC1SYva2ttTbdvSbevb2lObmppTG9vbWzc0NyfWZdrszLp1ybb2Nqst3YTWpmY0"
    "t63jVKZNWTdv3k7MTpZaHUcBCQGsl4Cd0PScwgJYQrmE/IwLKyGxa0czC2EV//mfr+Rv3irNFEtq5s7N4myh7E1fuz47NZUvT5fK"
    "aqaQd6dnposzZcebhaBiYbZcKBacguN4TqHoOJ7nuTu2rfeY2GXFmrCTGXaSkEha8ty525breTKZsKx0UyLR1ppKNjcn0pZEUrFq"
    "Sqes1lST1dbcYrVu2Zxq2bDBziRtam1fL1sSCW5pbUXrtm1W8+EHmlK5LFEipYNPafmdcxSqPjGcsoJNifb/+HV7vq1z99Y3e57j"
    "FotcmJpRs9np0vT0THl6dtaZKhScycnJ2WyxWJycyhXuuK43eetWfiqXLU5BiJnZGZUHXKdcVngjjbT0kyteJAhfjsNYrAyPFvjg"
    "yt+leZ6NF7xx4SiQwJjTVxqUhxpHHPSiciWvghMpPfW4cj72WmGplYEaggRMJ5/KjMnihu1bI/bWT/zKHJap+q0jiucGuXMDGQXB"
    "AmRSB0UYVYxRjwg2U6cFdEqqTB4JNMbgbNT7ReezF83N1gzCQPQeuBeAF5Cs6X0VZl8TRA09kwvtmRkDXvHnfp9tdO9chHeeCzKL"
    "M1Am/T66WkGBQfBIQIKD7/P1xIlMWSmYfmknMrqUFzgTbuRMiMiZIFMSyw22aw1Z76ovpypb5/O7VPSN88JketES5jKb9iNi/9Yp"
    "q4Bhj2g4oZPrXquKRI9AWZ30hrY1tI/6OfKRZG7GlJ6XA6B17ZOxKNu7P5Ehyj/gVy8UQUiyQJJCsj4bhvSTaEwyxiRoyCc9NkBD"
    "u7kpBYF6I/vUSUAHaick/rONRv45wcBE1HdFgYRoGbcXAfKiVQhO5LbUMXbSqeJPmI8b4W4kyAvpIhtddEHDeh/WTheDW2eELY0C"
    "CoqoJsfC3fantIQv5ojf9dtC6rHbC32WA0AwGz4KpSeasCZUdo09b9Sa1VqHqH+K+otq2xhWRxLIACBEehylOWPDHmg4qeOIbgm0"
    "S5pjf0ejeuePYvWBKF0dozDzJVSaH8v9BSwkAKwH0FYuq8TO7c3ptlZ784ZM8/ZNm5u3p5qT29atb9m4c/v6Tdu3bti8YcuGjes2"
    "bmzfuL7NymQEWlo8NKUdpFMOIEsACgBmABQwNU34i5FrmJ5RgC0w7SjM5EqYnUH5TtaZuT7pzNy85cxO3nZmstPujWyuPHn5Su5W"
    "fta7Xii4t2/cLNzJF73JmelyLjs7m2WUZvSHJ/ICxJYgtLWlwQoo5ssoug48OCBYePDwLkhLwFMKrFgDCwmCZUtcvXYBriqAICEh"
    "kUpZaGlKYnbWQb7kwAwqSQLcClgtbalUJpW2M21t9rrOPU3rW9rkJs/1tu7cldy0d29yw1iTt7GlVbVu28otW7d5ra1taG5ugdXa"
    "AqRT2jQ0py3r63t3b/vWd7x5G2bKYEei6CVQcGzkiwK5WUZ2ysXU1Gw+O3ln8s6tW5NXX79188rVOzdz2cLtUql8bfJO4dqNW4Xr"
    "TWlxfWrKy5ZKPKs0IW0JQBG66u++q9npzp2LT3Es95tMmJ/7Xj6Yvx7vZix3Q0bjJahrfUbipYh1MZY3pIzFSxDLGxFYWAfg6wF8"
    "FUPtfUff3m0dHRs2bNzYtmHbtnVNG7esQ1umHc3NrUCiGUALgDQ0hjYNqGnAnQbKDuAVAZXXPy0FTE+7uHHT5VuXCrOWfXvqleP5"
    "2dPnC7cvXS5duXmndPbarfz567cKF70SXxMQt+9Mz04DM9k3PbxXPbB/IxQT8gUPqaQFKwHMFCxAAba0IITmNGhqSkB5+vaJioSi"
    "Q7DthWcOJJMWvIKNlCVh2RLptI10kw0igkwIeI6Cq7jEhFJzyrqVaUsinbbR2mph2/YULl7O49jfXRZAOtOSTGTIwobmFrF94zqr"
    "Y/MWOrBzN+3bswfb9u0Tmx56MNGUSInEjVucUgXHxlQBKCqQIKRtiXRzGuvtZuy0m8zaUhOQbwKmdwA5TE1lMTWVxeTkJG5cv1W4"
    "enVy8tyZyRsXL+QuNzfLy9euedemp3GGGf8G4KwBF2KJJZZYYoklllhiiSWWWGKJZW2ABQbD81jAo+adW5N7er5ux963vHV/wk60"
    "ANMuULZ1/Vcur6c5oAQgaZr/CgCKABUBchCwFjIDJcaOrTZYevTJ3734d9eve7/rKvdKvuDeYHD2Ld0bcls3p1Sp7MEp6mHZU/kE"
    "XC8ByxJgvjcv3pkBKQmApQTJybY2OSlsTKzfKL4wnVX422PKAmS7JbAxmbIP7Nxu7WxpKb7p8MGm/3D0O+w9gAuUFMACoJJu9BWe"
    "XkNZ0nPwRAEQ+v+3WYS2zSns3L4BeCSZBjJpYN32/OyN7s/9/TX13O9NX752nf/JdcWUlLhoRkbHEkssscQSSyyxxBJLLLHEEsva"
    "AAsAbpHAZ6Wkv/zMn17Y9Gd/feWxb3/bpe/q/97ur3hk/xYb+TIA0gPOSVYNdDXdP2QIGcE6MQYDZQU0C3z721tw/sLUxk8OTRUU"
    "2//c3ppAdjoPIj9Bf8OJC+DWpg3eHVbq9Mkz015TU/qJb/q6B77ha968BZguAK5t1k2F/4wyzwSNjx7gloFyWQM4CQdoYpw6nefn"
    "h2++/Jd/Of0nN17nfxBCnLUTuM2MQnwcYoklllhiiSWWWGKJJZZYYllVYKGai4tAnuepmeu3SjOTucJNoOn0b/72F0689uqNn/34"
    "R76p96GD24FpD1BST3SwGLAkkLL0N1sSkDaAFDS/gkRIZ1bGju1N+MjPN3/FwX2Fj//Gr+PNN67L51qb0pevXHExk3dh26QrFu5z"
    "EcJUM4CxaZNCIgE1lXM2f9WbN7zz3e9++PuP/OeHdqfXtQIlCVAKQAJQSYATgEoAngWwBXieARY8/QMPEEozYSQII5+9Unrm2df+"
    "8IvjuU9kc4mrmRYr294OllLzYxHFByKWWGKJJZZYYoklllhiiSWWVQQWHEdVIwtQipEvaC7fmRlnQ+ee9kff/JbtW9dvbgaabSCR"
    "AJJNgN2kKQCQApjhei4KBQezszOYnclhdnYK+Xy2VCjMlIrF2UJhdrrsODMlS5adfF4kN29Uj2Un1Uu2LW87jleYngISqft/A4iA"
    "2WmG8hjrMoR0isn10JxMWd/76IPrf2DnluS+sydv5UvFO1YqkbaT6SZKNTWjKd2KdHMr0ikbiVQSSLToDUECgK3/yaQpx4UCJMG2"
    "IIt5ZWezXh5Qk6UyUCwwXAkwx4chllhiiSWWWGKJJZZYYoklltUGFlyekxQrgzW0tqQeeetXb/uRH3/PV7zjm7/x8HooG6VsGfmy"
    "wky5jKmZydLkpJO/dbs4nc3mZ3NTk7OTk9mZ27ez09nbM7np6XxuZqY0NZsvzZZL3nSh4OVn82q2tYXz27eTKJUplU7jplLM6SZ9"
    "w84eYFkE17l/N0AKQrkACCK0ZQjKA6SA3ZSxZs5fKHzm4584Xp7NeyKRsJpSzYmmdDqRTDenWlvbmlrb21ua169rbW5tyzS3tGVS"
    "mUy6ecO6ZFNru0i1tqpkS4uDpiSQTAgAEt/0TdusljbvP/3hpy+kX/iz3HPXb+BvbIliMhHuYyyxxBJLLLHEEkssscQSSyyxrBqw"
    "MKcVggAiJNMp+fDXvHXL0+/7wJf9py9/83acPX1n6tyJXOHKtUL+xs3inUtXpq5fvpa7lp0svV4oOK/fupm7npucvjU1U7xd9kqT"
    "AE0DMg8IR7dCJOBPBe7cbWP9ehuFWYZt6wTYfw4iglIE17l/s2IBgrTDigGhh1JMCUG//dIXp3BzMg89iReAri2wAU4D3CxhZTIt"
    "6XUtbU3rmltS7Zs2Z7bYCbk5057YtH1b65Zd25s3b96SWr9ps5XeshWpLVsp/Za3tK/btav07a1t7pd95g+LP1cq4C8B3BYCcc1C"
    "LLHEEkssscQSSyyxxBJLLKsLLFSLUoAQtGnr1tQPfsPXbfvK29cKt3/lF/757Oc/f+P0xaszZ27cnj3jOHxxaib3uucVrx/Yt3fm"
    "kYc7lfIUpACshIWZWQulIkMpAoOgQEiQhMv63y2LgqSbeW7J/huhhN9QVkb/r8esKw1StoWiAyQE4LH0BMEjQtFKYLI5ZV/OtDah"
    "pa0JzS1pbNu2Hp/7p1flpUtXWi3ZvLk53bI9mRQ7N25I79qxo3nfnr3pfQ8+nNjZ9ShvevzbU5uvXS0/+XfH1I3pGfyNZcGLj0Ms"
    "scQSSyyxxBJLLLHEEkssSxXiuLk+llhiiSWWWGKJJZZYYoklllhiWaaIeAliiSWWWGKJJZZYYoklllhiiSWW5UoMLMQSSyyxxBJL"
    "LLHEEkssscQSSyzLlhhYiCWWWGKJJZZYYoklllhiiSWWWJYtMbAQSyyxxBJLLLHEEkssscQSSyyxLFtiYCGWWGKJJZZYYoklllhi"
    "iSWWWGJZtsTAQiyxxBJLLLHEEkssscQSSyyxxLJsiYGFWGKJJZZYYoklllhiiSWWWGKJZdkSAwuxxBJLLLHEEkssscQSSyyxxBLL"
    "siUGFmKJJZZYYoklllhiiSWWWGKJJZZlSwwsxBJLLLHEEkssscQSSyyxxBJLLMuWGFiIJZZYYoklllhiiSWWWGKJJZZYli3WG/0F"
    "d+x+e+9qfO7VS/9ztPrPtu96vLdRn7UU2b7r8W4A7cv41bGrl/5ndp7PawfQXcfvT1y99D8nlvisvQB6zee3AwQiAEAWwBiA0SsX"
    "/8do5O/3A+g06zS4gjXqB9Afee+BJfxup/8MC63bMp6pt9Z6LmEPqiV79dL/HFvms/Sa9+wE9KaYvam5P3V+dj3vUvdzr6Z+Rr5j"
    "JDxTNHj10v8Yvdvncj5h5hXpIEU2eJXXovoMrei96/y8Ctta7+806kytwC4s9zkbYZvXxFfWeOc+Y4Paq+zPKICRKxf/x9j2XW/v"
    "1HacAWCkel/u5juswRnqvdvvsRp+HcBwVFcbZTeXuV4rOuuNePZG+8slrMWCNsM8V3+NMzpmzujoEs9oQ2zrfDazyvavxr4sO75Y"
    "RGeCNVmBL6j5bEvVhXnee7Xi30a896LvdeXi/5hALDGwsEJQ4cXQyflBNDXgs7/jsSsX/zhiuN4+AOCZ0NDW/107dn+HnyYcC4Oo"
    "P1mKsX1p7jvW9d0vmGCuWoYBHKlj3Y4ZJ1OP0R/QzoYy4WeSSWyCzz0C4KmdHd91AeBhZh4C+Llwnd4xeuXinyw3MBoEqMMkUj07"
    "dn/H4JWLf1yvcRwG0BNdjx2737EaKhvsB5EYBvjI3HWvR5/e8aZ69GcJ+1K9PzmAh5h5qM41rEuf6n1u88xP1aGfueUEE9t3Pd4H"
    "4EhkDfrNuVyqNPpcrrk0cC3Oh0BGzbUYXwKYNgYgs8jnYcfu73jvlYt/PGS+25zj5Zyp7wCACwCPRWz0agUoc+zNcvyWfmY+BmAE"
    "wPCVi3+SXSTIWy1fGexBjWRlEMCTod0BABF9jh5jd44BnGXGEZO09Eb9T+jvq/d1dd9hLc5Qo/YnosejRidGV2AbTAKJgZX4dbMW"
    "wVkiopfmP5uLvuvTRpewY3cYjy1VF5bgh+ZLEFds84nEAMBPLfb+O3Z/x9uuXPzjkTqey6zF8v3l9l2PD871uXPO6JPmjE4w46iJ"
    "aRc9o6sUS2HH7nfsuXLxTyZ27H5HN8DL1akF92WVnv2Cn1QTiTEAmbl/ZdHnnjc2X44uzBeLrtJ7B8+8gvde1rrEEgMLS5LQwQn9"
    "7ySMaq60C0RVf0+7r/jBd5IAgeo8DAyAexjoAbPvhAcvX/ij4TreMvhOIhH5/4u9I7fXWLPIuwj9OUTzvMvit6XGkA3qwKP6GUVk"
    "jSqkg8FPEfMAoMAr3Kntux7vI6KOqvfpB1BnoBga4cr1WMpKLPTp/v+G+0Ek2+f8rXn3YF7dbK9jTQbDgHCxfZnzphm9P2pgZ8d3"
    "D16+8IeLrWN75XfU1KfRnZ3f03t54jNj9Z7rRT4vs8wt6ffPj1mLo7s6v2fg0sRnskvd2Uaey7skq7wW0T3jrl2d3zN8aeIz/XV8"
    "Xmbxz0PVmbIiJ5WWeKYAgDsA7mDgCJifMUH04OULfzTa2CWP2hu5jOeseOYeBveAeXBnx3cNXb7w3wfX3ldy+wKgwihAXRV7SQJU"
    "caYD6WEwKKjSqba6MvizSh+8eu+wlmeocfvDHQAfZeDozo7vPgbwwOUL/31JifTq+nVp3rcaqFjUbkbWympf/llXy93r9uizLm2P"
    "Knx/nXaKh+v0l+3VezR/bDq/v9yx++2jzOjR+yHqOaM9C5zR9jlnNHi/RsVSgXQCmAh1gef5viXtSw2dangc2BHR40zFdwbft5ge"
    "M+qL7RfXhdqxaMPfO/KcMjPnb8zr35dsx+OsPwYWVhygjQH0NJFoB8l+IpkhkvoQ+YdqucpZVYJMJEciaFsPSEJ/lzAesh4joD+X"
    "wQCrDgY/t6vzeweZVf/lC384WjvgwLOA6CYSPeR/rzH+Nb7X3LzxSI1PHAZogkj0EskO/zNRcbD5WO3fD4LGYYCORB2Sfi7/GWWO"
    "IEZBNAZQu14/7tJLocDgDFhFVmm5RoH6/SA9fBcxUC+wQIQe/fzh2mrnH3VlvCKzWmVXQcIeDnSMqIf8JGNh43oM4CxYjS2yLyaY"
    "j+6L1A6GZI5IjBDEhNYfAKA+ArrCt2SzPyrDrJ7Ztef7+8BeX61AWd8UE4hkN5GVCb+vQp+0M2Me3r3naO/F888vEHTTKEDd+vNE"
    "B5FVEeiYtTkGqCUnfNt3Pd5JREeC/RaWOcfUp/V5KYlAcC47w3O04Lk8ZtZh+F6wng1ei+fNWnTVtlEMsDq6e+8TExfPPTe4yOc9"
    "DVAvkayyeUECom0c82gkSBs2GtwJEh11nqnK881sLBEDrHoY/OKuzu95gZn7L1/4w2xDvBZhGBATWm+snvnPS7XeoBNAxwI+JQNW"
    "T+3q/L7OSxOf7l/EV/YF+roKvrLSLqDLD3L1O0oIsp4HiTFznju1/TaBbsX6V/lgIcfA/DSAdhCtyTus4AwtAdgGAJow+9MLkp11"
    "vFsOuqqnZxE97mH2Rnd1fm/vpYk/GKvjfdr1c9PR2n5d5Ahy2X6dhHwBzO0g6iaSGYokszX2cFz7vTAeIbImAHVM/z/RU50ML9d/"
    "LhZvEtEL5gx11xlv6meP2HwS9ihY9QLo1sDNfM8e+MvR3XuOdtbhLzuJZC+R6KgRmx4D5r73jt3fOQSoHiJUx27HiOQIQWRB1A1Q"
    "X5AQL3xGu/0/08CL/yzUgFjKT3oR0XFACHuMWb2ggR906jUQi+3LBYAnqvalOxKTBb/f8GePfIQQ9rMM7gbQTaBM+Nw1gbacie2H"
    "a+sC2olk3wK6MB7VBSESYP+8ElUBSqsT/wqReBuz6gbQq+NfEfHvKwEXVJz1r0XmvdIe3ftFdu892inIPh84dv+mU2N3AHDs7Kln"
    "e6O/s/fgjxvjjgEdtEWUmdVj505/at7EZfeeo30k7M8SRb+rAtl99uypZwf0d7ynXZeL8QBY38gArA8yKzA8MCswe09cOv/7Cwbz"
    "uzq/r1MIe4zIyuj3nPOOAPD02VPPDta/bk+MCLKOhAm5zAHoPXfqkzWd747d72hnHdB3EVHgkIS/HsIGkXyaSA6dO/VrFQ5x36GB"
    "XjAPMbhLBx8cJrPAY+dP/8aSkkUT2J3Xz29BiIT//XV/3o7d72D/uQXZfnB4jCBGQBjTj8bdHCm9nMfsPRYJ7boB9JEf9Pnlv4xj"
    "505/qrf6Fzv2vquPSH42GnxX7WmOwQvuibl5MPtCwb7460JkgYT1PJEcOH/6N+YEKfsODXRrwMkPEDnUTeWC2R1X7PZeOv/72dr6"
    "+b3tJOwhQdZR/3tD8AKB3jO74xNnfqu7Lv3cc3SEhH3E1y2QyAG06FosoC9DROJJsx4QIgGhn3P8/Onf6F7OZ+7q/L52cy47FjiX"
    "bzt76tmRJac8q8ixsEpr0S2EPTqfjfIdv9GpJybO/vbwMj/vhXOnPtm30O917H3nCFXYtTn78djZU8+OGhvdCag+AANg7uAgWTc2"
    "WtvnC8xe36WJT4811m890S3IeqnyOWlee258yQCApyqTYoDNuoI9MHtvu3Du92rq2q49398uyJr07eQSfGWn8ZVdlRZQPX3u1Kcq"
    "fM7Oju/qZfZeDEEFo2NkPztx9rcHqmyPTmaZj3IUMAEfO3dqrr00dqGdSK7qO9RpTwaJxFONPEPGJ4yQ8PV3rj05e+pZqnqvIRhw"
    "OAousAaIweyOXzj7u911vM8oQD1Rv06Bb7dAwmqoX+/Y+84xIqtrAbv53rOnnh1a7AxR5AzNE4/lGNx97tQnJxp1bvUZssdIWB21"
    "9qieWKxj7zuHieTRSPxVBXgpKPbGmZ3eC2d/N1uvvySyIEJ78qb5/OWuzu/rZPbOhxUGfgxkPT9x9r/1z3tGwUcrfZKqOKO79xwd"
    "ZNNOEOqNzBHJYRCNAsia5H2Ijb7O46Ge94Ft1mBBL4B+AjJVwMJj507/+hy96tj3A2NEsmuBfXn+7Kln++c5c6MM1WMuD03cJC8Q"
    "SD87BzDZiwvEge81gB9Y25peAEepChQ5d+pTVPXd7URiFAEwP+9zv3D21LN9dfuWPUeHSdhHq3ThbedOfXKkcr3+yxjY07YjvFg7"
    "pi8FMbp4/EsAOPre88S/VNOed+z7gWGCOLqQrz5zcmg01MX3dJq8rQ/A0So7fuzsyV/rjVP/1RXrS+VFL557fmLPgXePC2F3ESUg"
    "hAzLTGugX+dO/doogNH9h98/TESjAEWCjdrI18Xzz4/s2f9ukEhACNsYoAqkLRt+xyez0D2wI/sPv7/f7z3UCKECs5+8Oc/t3vsE"
    "Lp57rmawfWni0xOd+35wRMjE0drvyENLWTciOUzCPiJEwjekw6ePf2yR4JmGiIxT8BNXHTTq9RD2E2dPDs37HmdPDo0eeOADvToB"
    "5i6svOCqPywftbRjFEkIYUHfhNXT6yoCJyhkEkLYT5w9+WzF8+8//P55krUwYTp9/GPR7xkFMKT3G8+FZZ7zv9+Fc787svfAjxpA"
    "ww+UK/Rp7NRrH11wT3Z2fGc7sxrV+0IIgRbbB0yeP3f6U/21fv/syaGxAw/8ZK9BvLvCJJDBwgUrp4uUM4oFeuQvTfxBFkD/ngM/"
    "cjSiT8ZJ+sCCB6Xcrr0HfnT43Olf719cP60hIRJHNOBjg0iOLK6fCyba/T7gIgJdsUEku/Ydem/32ZPPLPmzL018Otu57weHhUg8"
    "pfXP0g46ci5PvfbRkXvNZq7SWox17vvBfiETn51ro+An6WByntuz/4fHzp/5/43V8XkjQiSORtZ2URtHwtaAaWCfw4Sj2taYhGNo"
    "/+H3Dxv7eVTrqqncYQ/Mbodid3T3nv7ui+eHJxrnt54b23PgRyJ+pNqXVDxnFsDggQc+gBBcoErQTrlQ7AwanzP/mp7//Wzn/h86"
    "JoTds0RfCQDDBx74wChAPQveZpHop/AM64Rb/wzNY3uyAPrNex2d94prrg9e/Xeo7wwNBGeI7OA99Rn6ie6zJ391WbaKhDUqhH2E"
    "aH57Uv1eBx74QC80j0GmUifY6K/T1bn/3X0TZ35zZAFQYTgEFdbGr5OwRwXZXbXsZj3VXf4ZCvzd3Hhs7NRrH51opO00Z2hUCHuh"
    "WGzRZ79w7vf69xz4kW5/Debzl6S8LlblYdTBy0MkBwSZeE5YILJeqOUvieRAGOsKs8cJCJEYXu4ZJZEAsafTQmFBCHucKNF79uSv"
    "ZqviqWxlPFWh2xNV8dTI/sPvHwQwSkRdYdw1f4wuyB4hYXXpsyPnOzvDNc4ciJVf2QlB9rwAxNxYsKKyYKzq2Yf3H37/kHn2TK3W"
    "jAvnfje758CPjGhAxKp15pca2w8Iso3ftEFkHTt9/GNzzr8Qdhez1N+kz/ycc75Y/Fv13rXi3+7598saIbKOGn1d0FdrXfzkhLF1"
    "Iwce+MAoET0XD0BcW/mSWm0CZXWQLI2BTELIFKT5qSVnTnw8SyQHfMckzO8u/GUS0VtyIVKLfteZEx8fJrLeS8KGlEkImYaUTZDh"
    "P5/r2PdfuheJOCYItd4xjVOv/VJ2iWs2WplcJBZJYL97AKCjYemnXi8pUpBWGtJqerpW8BEm4b+SJRJ9RFZOCJ3MS6nXbyWBnQ8q"
    "SJnU+yGSfQce+Mn2Oj7DOBMLguynq0EFY3whhBVxvmbN9TvX3G8h7GMUBNXJhfbV7EG1PqUhZaoOcASDGhCIACwy4X/GBWmlBxb7"
    "gNPH/2sWRP1+Sa/WraR+BqsJ0kp37dn/w4sndVF9kgkN1siU0Xf9WUKmj+49+OODiwdevztKIJAI1mbZAaJmKtfOvSIRkCmjN6mB"
    "5RsfrUNCWCCRgBSJinN5r8nqroXIVtoo87n+eZFpCCsNIVOjew78SHcdazvhnw0SCZx+7ZfrOA80Edy2CjvQQbnAnpw58fHsmROf"
    "6CeyjpFIGBsdnnEpmzJSpkYa77fEeNSWVvqS9HwB45AOwPw9S1acLSmbuuqw+1iOrzS+rz/wlVLv7zzP2BvY1HD9L5w99ewC55cG"
    "QDIXvNciPni132GpZygAtYMzlBxYvk7QmD5Dep8r7Umqhk+1hivA9QqdaIaU6e4F3qVPtz9UgtJSJH39f3Y1/HoYs81vN+uNZwh0"
    "LPrcy/Cfy9mjCf19NWOxifpch8hG/FuoQ35caKUhrfSRvQffUw9QMUEkjL+0IYQ9tsD3dsO0K/hxr5Sp3LlTnxxdYI/7QfJC5Iz2"
    "VCaJFYBUTojkHFBBx1OVsXawVzrOmNc2C2ENkAG5NHCSWCT+kDV06qOjNRJxRHzGsflAhbnPnoKsjJHme/YxIeyh6LPX+P7R4CzM"
    "OfNpSJlaUuxz4dzvZUHRCze75nsHbVzCfn6+c75Y/FvjvYeFsJ+PxL+ZGrY4i3liRllH/HT6+K8Ma38dgtexxMBCQ4VNWWi0/DK8"
    "iVs4SDn12i+PAjxe0Q+6yLf5SWmYiBkjuYBynz7+sSECLvitA4FRNQG3lKmhxd+STVhV/Y5LP1QTZ/9bNuyTIxCJmsZr157vbwcw"
    "GJTZGyQ0kjTmxKLPHySxE/p2MLJXZC8/sBOWWU8/qEpAyGRGiGTf4p/kr6UACWt4ob8X/F1hRRKBBdd9KKInPYvpU1BtIKK3fAvr"
    "7s7O7+kF8GQIsFgh2GN06vTxX6krQDv92i+PMdTzvoMOdct3/Okn9xz40c6FVTT6LmECJH1dF4HTeGrvwR/rR10nLTzXKwgF+yt6"
    "oSP7pytV6tGVxd4Z4bkk+x52djSwamsR2KjqtUiG9k4HJhkhUsN79v9w+2JrG35enb2XpiIsIK8K7K0+T7TwngzqPlcZSfQNICKb"
    "uvYe+NGBxvotlWVmc2MkFvUlp1775SzAxxAFRKPgjUzjwAMf7F50h5iX5StPv/bLE4GvhGl5mmtRO+bolkx2HHr4w/0LApvsDQOs"
    "e3wX8cGr/Q5LtSdinjN08MGfbl/+CeIgUUKV/tb4rZEKwIU0oBP6gXTvfL+1Y/fb2wEargQVfH1q8v36YF3+Y4l+nWvaiqXZTa4Z"
    "j9VxSbSieDMai8mInUssyXcwz+f7k8H+mQT26N6DP95f71qE5LA1/14PgXS7gg/+iWTm0EMfXti+sTdU64xGOapIyJEzJz6RrR1L"
    "IfiM6J7X2i8doyOI0QVZvQvvyxJ1yrfB+ncWBXF8ACdMnBf6fB4K7bXE4Yd/rnfBSIfmPvfxl39uYjlaGtoEUfPv+ESXtGA1YEgQ"
    "WhkzLKjv0fh3gWfkyAWbqdytz1eDTZU21eEzYomBhWXE9h6YXdNrGhotEnLOoTrwwAe79x9+3+i+Q0+O7jv45KD+fXeY2TvGeoTX"
    "xMJxq2u+j83BFJHvkos95xBY6ecTMoJ8piFlumffwSd7a/+u6/fRIjDuMN8rltf5osznMRQWLAllHoAptYw6UR9ZFDI1dPKVj2Tr"
    "/l7lDDF72gnoqHr5gV1wY+SX/id8voT6kgBt9C+cOfGJiRrPCqWcYN2pInCyFgCsfmlE64qf6CygT8oLSHSoIumTiyn+QNAOEoAK"
    "ySDREEu8ZWVVNs9sgiYRDTTTkIsEmSrQT61PFcFeNMHUgMVzew/86MJJEJuzFnVAS5Ttux7vJgp7h8MkxI6U+lqZww//XP9KbQ+b"
    "hDYK9NxLYtaia9XWIrCN/loAFTcSFdU0yS4hk6MLBw5e5PO4/v1QRg85fAbU8AdV4O8oszceBCv+mQrsXHqgoX4rsl4+s7nvS1DD"
    "lyjlgpULsDLd5CICVGtgdbH1gf+dvq9ETV/Zuf/wT4zuO/Tk6N6D7xkMbbd7jDWB3shccxoS6VYk3GQ/98AjHxlYwCeMBD58kUkN"
    "q/0Oi58hLGJP7IwQdt/ydcKFMj4hIKLz9aKGj/JtZZj4RQAPmazpR4koU1lpFvHrIjW8DL+eq8evM3tVtmJ5djM8Q96cM7QyMLoe"
    "mx/9zuCCYgnxl4uIzkeAoWglmQ/up57be/DH+hZ/rjrspfHvIFGV2NvPLHJGRyPPm6tUJdkOnywQcnSBzzCxrKoAGPxS+NqP7IyE"
    "sUBjfTFDtUdAmQWePWqvEVw0+TwkNUCRLCv3WBgX0TzPrapindBvLjeGiNpIrvl3Aj3JnTnx8bFaMVgQ/3J1/CsXeO9fGmPl5haK"
    "f0N9DX11BJyax5Z/YGj/4feO7j80MLr/8EAnK2dUr61aFqF3LEsX60vpZZk9KPZAQZIcQdqqnBuz261UuSeqzKeP/8oQ6uxj4sAZ"
    "uFUJOS2aIHteaUQIfkaQQHQiA3FAsDKAGtwArFwocvU7+s8eGdu0vHXTQSqTC7WgUff6Q6Q2UrLvB7NkDy/le8+efCa779DACwAd"
    "ESYoXFlgF+nRMsGXUNx16OEPd5985SNjC4AKL5Bmtx6r7UzK5q/q/k2GZQJ6qiIonO93S88C3E0LlCUq9gB2QGyD4VXq0wKys/N7"
    "OsHqiB/Mi+rbS5G8sFSk+8yJXx3Zd+i9OqniSDLGEhAEAEf3H37fQK3bCGYHrCQUWRBCjYPRFbAck07WBBKR2xUe3XPgR3rPn/6N"
    "sZXo5yLI0QCqwCDyiToDJncFRaofS5yIED6jBJMLiMqEugGzmRssVWshVmMtHCgD9jF4nMBd4a2IXhMh/OCWu/YdenL47Mn5S0/9"
    "vfeDpPrts4gAzRw5TbRo5YNS5REBdLEQEKZcGARomy069h9+f9+ZEx8faYzfivgSVqCKG8fa9ij0G5bhxxIQIDAIx1/52bHFEjFF"
    "EuT7L2ZzDVHLVzo9rNwg4D1z4uPDi+kGIdqrbwfkvgx+5vDDT/V5XnGwqh8ZZ08Oje47+ORjAoBapO1pLd5h4TMk5toTqj5D1ort"
    "iQ/6E6L96DV0AgIkWH8/WwhJGAUEzx9TEIkBnWPKqlvIFfn10Yhf71wQECAZJJnLtZvh+bHmnKGlX1jUD2Zo/asENJb87JE1YPbG"
    "2beVkfGeQgEQPvE3D+898KO9507/+tiC9pL856qZSOeCyRZRH0ASDDxz+OHBfk8VB6pbz86eHBrbe/A9j8n5z+gYAcfM6y8QT5VM"
    "RSTAbJkQ1r9V54Vi51EhVK8AA3pS2/xJMADyL+Hq1ClW7iiRyIIYZ058fGLhZ5cQgirjbxKao6Hm7xVHBBJQZGeJxNh8+wYSUBAg"
    "csEiofWYVhDbB/mCPhs14vpn9RQuHltg3bX3FhaY58a/C793aXih+NcHK5hE8O9hFcVcX83s9inldOhYgDrPnR4ahZnYF0sMLKyK"
    "oQ+dlJ94W/OeSWa3j5WjE7pl3IIqdkHKBYsQGabwQRb83XOnPjmx9+CP54gowxAgaYXljkxY6JAELP3kgM2YGB108ArWzSQBbIHV"
    "/Inbrs7v6WZWHRXVCjIB6ffQC/vCa+MfmljyOnrFAYCGQITTr31kCWhjNLCTOUFWJgjsAsQcYB3Y9kMzgc8rlyc+07f4cxYMsq+g"
    "SICEBnWYFjf5Z08ODdQXSJImSqzQp0Vu6dnrNTcFBlCJBIV6QsbEcnRCqdIxIuoBSUiWAVuwCCZcqL5aAXPUmSn2RghqlMBP6uoF"
    "AWYBIgYJG1K/WwbgYQMuZJfjHBcBodqJ0BdhOc+R8KcMWMEtk770lD2HHvpw58lXP7KkdQtvSdxIkMwrOperIWYtjgZrIaxcOHEh"
    "JE5ayVoodkEsA4CBhd0LtkaZfHDBlHfDggiD5aN7D75n4typTw4uZPNUnSXril2AhbHRrgbrIueVF7dLowCe0kGTNKza/toQGNyH"
    "Jd5yL+xLHAPEGbCYGaDaYxCVKnX7ustkmUAPZjwaxuvT18iPn5jTvOc54ivrHuc1HjKcWyHjPQkQMxjUA+DFvQffc0x5xcGJs78d"
    "2H5/Wsc98A7LsCeyIfYk1F8JFnZwicDMNSe9KFXu1mE4B7ecOjbwWzvnJg679nx/Nyu3Q48bjJTyy6Tv13OvjX9obLX8uq4scrQO"
    "i+XbzdpnCFit2fYh+OOYPVpeLKbYASlhnj0xwuwNg9UziIy89tsSTfNIxoDxnfP6S3aNDV7EXzKPgdBDc0d1mzOKLjC/uPfge8aV"
    "Kg1NnPmt4UgMO1ojtq0LrFNeKSC7JLL0cy5i8yLf27tYHgBh8gE/TqtjXy6c+92B+nS7ZCoI9J5EP5sXjAOfHcICF5f6klJAsIjc"
    "4HO4LisFrZU779+ZOPNbA3WcZw1wsCb6rI5/eQXxr1/FwUqYfMoHGuZ+9oEH3t/Lyulg5fjVKNk4zV97+RLjWIiOB1OmN3ducnbg"
    "gQ/2MXtH/JGP4GWUzwSjIn0nppbkwJRXGlNeWd/uGlSZwpK0zKGHfrZ38WBKhcHUCsbScch8XhPhZuZe/xnnKW81c6WXLufP/ObE"
    "2ZPPjNZHyFYrsLNGzCjFyLx7MxtaP2//ioN/VdY//hoFfd/LL8+fs6+19IkXKvsz+xK0QVSUNIJIji7vfUtZpco66POfxe+H1N/R"
    "vbg+6fF3x7/4swNg9ULAtO8nQJU3ZF1CJEYX/rz6b6yrpB/+jGgdcPcFJXww88MRmdUu5MCy9i/y3kGf57037rc/yjugZ59H14JW"
    "vBZ6RFpYmnzylY9kmVU/mHPRpC7s1fTJmpJPzddDzPBH5oXlp3XZ5zm2MnpWebHzPqG8EliVTcDncyAEOtuwG5KobgfjAYORl3Ol"
    "Y9+7+lk5GY62Z0WqMkBiqP6kXAW/W8NXdjO8o9G/V6eMhEkRBboVzFMn8m/Te4jEix173zm6e8/R3uWs2yq+w8L2JOyJD+1JAGqv"
    "/AxVlggv7m9YOX2Kw3YIrnzXC6+OfXAOEEagXgr63HVlSWCTtV8fW84C1evXG2U3a58htWo2mCv2aAWxWMWzezjx8lNDDPU8R2OA"
    "QJcCf5kRIjm6Z/+72xeK5xb2l2ok9MXmx/eHwRkVIBJdBHquY++7xpZ6RheIL6DYQdgmygvavKXvi6raFzRMD3Rc5IbxcrBPK4sF"
    "q4FSRPW4ATq6EkBVqZK+gJw3/kWD3lsFAPF8n33o4Z9tZ1ZDoZ1QmDjz22OIJQYWVhdZqHa+FQe988GuXxo8/PDgCIDPVgbXS78F"
    "rXSAHCGOrB+lVuwE/VrRPmBTOtq58LezNhS88sTWd4i84GeZUTERllldIWDrMvkFetJWKTmKBnZDGlyQVeVu5PeCLbtfPNyvaCl2"
    "lbFvhMPiZetT51zyMr+k0aqf7G4u6j+meSWi/Z9+ebMFEnb3AqsVgCM+kMCs+pnVOCIOjmgOV0fXvkNPDtden/DzliZmcogmZTp2"
    "/vRvjAphvQBTSh6Wygbr2LfckxTYH24M4NR4mbMWY+FaiIasBQe6HAb1x1/+8BjD6/PBJkQI2wRVtFXNz7kRAANqac+wzGDvwrnf"
    "m9D2OUzeOdK7LcjuaLTfCm06agZsnft/qBfMQ/pvq8AWRezRC6+89L7hpejswr6SX/LLyQ1Im60zWBye239d8TkRTpwESCR6SNgv"
    "dux953DHvne1L/XcLfEdGnOGdOxQjz3pX/YZQsQf1PA3ew/8WHvHvh8YZlY9fnAejQ048Jm1/Ieo8h+JoF+cQKscuHNlIlFlNx/q"
    "+ljvA4/8fO/BB3+qd+/BH+vt2Puu3l2d39O7Y/c7erfverx3+67He3fsfkcvmNtrnSFexWdvhM3nyPn3/exr4x/qB6vxaG86RYF9"
    "mTD8NKnhheKJhfwl68qCXBRm8jkxKIjzokSydpc5oyMd+97V2Qgw1bdhlWu30h1TEX/BVfa0gUAwVGWstsI4MHLROTfGXObzMyKg"
    "6wqeT5kqmHnj34b6v3k/t//Brl8cAjAGUFdUP2OJgYW7CjgA6ADoKRAdCQ10OG5qpe5lGcZpNIp6+ocq5AyQnWu8SIsE4dQZJZIJ"
    "e7PNDQ2tpapVBHbj50//xtiZEx8fIcgLVP1OFLB+969seSI3YoxVuI3mZekTUbgvFX2+QeXGcnk3qqpYgtJSEfRO169TwGtf/FCW"
    "2e1j9nIhqZ4hARJRNvfUUZ9crTIhWd5p277r8V4i6oiQfOpAjORIMCO6IqghEETH4Yd/rm+p+8f3JJBQsRZ9C68FGrYW0bDbl9fG"
    "PzTKyn1CBcSKIZgacoMk54yhDO0LLesZlhv0sSFIrChLRVi19cAjP9+5erY4ePveBx/9xcFDD314cP/h940R6EWAMkF/a1AJQADw"
    "/AIJ5DJ9ZdU4UpGsK9G8eP75CU0qy3NsQQAmUZS0WE+LIZE4SmRNdO77wd5VfIfRFZyhWvZkuOYZ0sD2ss/QfGbloa6PDT7wyM8P"
    "Hnzwp4ZBmADoKCKVIUGSCMoBeNsrL72v1jt3I0KuG3JE+O2ZIntXjRbhRQAvAvQiIF4kEi+C5Is096fLB0x9Lp+14LZpdIIV3WzF"
    "bi+ze2GOv4ycHSGSR/YdrALj6/SXlyc+kwVzf5h0qrBAInpGo+OiRQpCJI4QWWOd+3+ob/mvqlZxT1ZbVABYcMO1ied/iZWCFitd"
    "mVWMfyv48Ob31UcBPEkQHdXTMmKJgYW76Jz8MYE+2YiMjCVMrto4ooVPk1dRrqYdRxCI1E7c6O4RwVHIaaB7zCI9eWuYHFUHdkOR"
    "/zzio/4c5c7Q5Gs9hx768AoSgdV2V8v9fOqonkgS9EquILAKke6q0lKTCNbPtF2RWE4o5fQqdnJ+CaQ/rGuhknj9LsvVsShRocxN"
    "nPnNYQA49eovDgPIBYRhASO3z2i/QiDq3jSE/eG4qLuzFq998UPDrMrPByXbhpTOL/M100wyUqaG9xz4kXatblYddIt1J5xLOgPV"
    "ZakVBG1rA/72APQUET0FUFd4vv2qMQmQOAbQ214d/2D/Ky+9b2WJYC1f6XPpyGTd73zh3O8NM6snwtLkCntcNX2gSc9DlykIkciQ"
    "sF7s3P9D/av0Dt0rWKBa9mREnyEObx79M9QQYDsSyOvE8SmAngLEUZ+AT/iggAb8cwTxPAidr459YGRhv05hObywKtsJ777NirQ1"
    "yjkj+AyPkGn7syIs8lGLsVq+m1fh88LPPP7Fn8ma9pYa/tKG1Pp8dO/B91T4S6rTX148PzzCUE8AqmqKj8/rkDDVhGl9Pq00hEzr"
    "M0rys537333v+clVbj9cNW0yYAvPd+bv/qKu7X5V/FnFOPjAb9SechNLDCysneRAdAwkcyKYkZqoa+b16pwlUwLoByIVN55U0zHc"
    "LViB/DLW6HhHv/RzTRLv+QM7UcEMrIait+xhj2kweqp/+ft1zyaLiM5HDoGe6G388l6Y5225YSw+gSRCO1n1/cdf/vCYUuUBxWUo"
    "dsLxQguUxEduz5Z0ArbveryTCEfC6hZzuxg68pFg4kS0f18nPkcOPfSznW8U4zd3Law1Wou5+nf85Z/rV6p8TClHVy4EIIaYl3PD"
    "9Hqb0Yu0lkY66OWs6lc3lWW0Fqc7PN8Vs8Nt/2dckOw7/vKHR1bHV+oqqIivXJIeTJz5zWFW7tuY3Vx0vNz8ow3TGmCQKb/0eqhz"
    "/7s7V+Ed2htzhmrYE14Le0IVJet+S4lOsBMgsgZPvPJ0/2vjH8oufDrDKpKw0k3eI6BCGAuJKK+T9CdW+JOPUkEcF63YC9tS6L6x"
    "03P95c+NKa/Up/mdnIAzgUAGSArA+GAMpSArAGPqefeJM781rJT7GLN7oSJuMmCTXvMEZDgSPXJGref27H939z22ivepl+Z7NtBc"
    "3cda+L2JaBwkLlRWnSXuzoVwLDGwUCVjr479ZO/xL/5MO5F8VlQEGon2u2ZEKoLWCGJdM2i9a9BCZLSiX3JIWMmYyxUHdsIaOXf6"
    "14PA6cQrPz/Byh3ngHQwSrpG9/Qt9Ars9rGKsuiAFI0aoJ8RMtQqUi2qA1ioJSdf+flh5ZWfZhMsMcJko7okfu/BH+8Wwag6sdT3"
    "6q/gUhHWUKWzdIcCrpNgkoN5uxVxLdyT0l9F2jj/WgQETY1aixpTDXSwPK44So44H+fGwLB/KxncpK6Z+L2u85FzUd23giszu5TT"
    "5e2y+mwYAC7RRWSNNPhbI77Seq+oAOGXXn569tSzI0o5nazcZwOuGnDI10NBG5ROWMLEJSNEYvBeeIcl2ZPaZ6hB/ocAUK6SFyFp"
    "1iylb7GF/cwDj/7C4meWGeFIxkgbRfBzdxOdV8c+QK998UN04pWfp9PH/yudPfUsnT/9GzRx9rfpwtn/RhfO/jeaOPvbJGTyWISw"
    "OHI26b433Cdf/cioUqUnQvLoqL+0TVtEEkKkhvcefE83BRwZ9fvLc6c+OaqU083KeZrZzQU2L9pGJBPBGQ3BhRRIJIbuvXjqfgQX"
    "GF+asth708CrYx/sJJKPkbBygR2XcStEDCzcdQkN7PGXPzxAJI9Fpgh034UH6o0GqpWJ2/KTtlVcv6wfbITVC5H0krnzLiRH3fsO"
    "/cTogQc+OHrwwZ8ePfjgT48yu+0B4aCKkGJqMGQZ/eL3ulpHS0XJHPnGgT1ci1CJaGIlTuPUax8d9FT5efYZlgNArbIkXohkJLG0"
    "lmTSiKJcHPqWfv/h948efPCnjK54Q2EffchOHdye0zLY3O9ZNalzLSLjMldzLU4f/1hWeaV+5ZVzITki5nBuSJk6KmRyIEwa1s6l"
    "cZB4VXPPBInX2Brs3BCIngjJDjWooAN7M1KWrJ4Hu355sIHfGfWVQ9pXRm6zlyFnTnw8e/LVjwywKu9Rynk+apupohoj6Z99857J"
    "o3sPvqf9XniHes+Q3+bjk5RGzlB/A89zJ0GOB+R6MtQLIZM+EDf8YNcvLbJ2aiIAyub369130WrVH+j69iE68vO+BBVq+ctfGlZe"
    "6fkAXECEnyas5MhImRzV/jKxZH955sQnsidf/YVBpcrdSjnPsvJy1aTiES4ko28pSJns2XvwPZ2IZWU7z/F7Lwgyjn9olEj2RXlg"
    "Hnz0I92x5sTAwr0kw9HpAXfXjcxHmrg2UxZ27H5HvQ5hTAcdJggJ4utg7ZblWAyzM+uftw8tMbDrEkL2EIkegHoA7mFWHRzpFwxK"
    "PQ1BFZYd3N2zVn90kYBsuYa3t+Ld57KIrTipUl5xwFPlcV0S785fEq+Zr02Zq1V3UrB91+P9enJI2JtLJHuIpNEV9ERZ1DnaQ+/f"
    "3pHsOPTwz/Xe74Zu/rWwzFqIu7YWZ058fEypUq8/1hRV4AKFpeuZMFlaGyboCrtYg5z71fEPZtfiWV4d+8lhXWWnA3vpl31rskNz"
    "Q4unHnj0F1YryBpq1AedeOXnJ45/8Wf7lSqvU+w+G+XCmQswBDfw3Q17h2VWci3FnqB6vOkqnKFXXnp/FkS9RDLnt3lInzOKzKhI"
    "iAzAI4t4tYnQY/hViWvr1xuDQYiAWDhof6D7v1ohKqePf6xfeaVjGowPW8iqx1AGgKMBWpYqJ/UZHVCq1KnYfZrZy0XHXkbPaAgA"
    "pu6hBO8+boVYQB7q+ljnG3NN6//s18Z/ZhTAhcgftcepbAws3DOHlqFGGf7MVFURIHbu/6H+3XuODu7s+K6+VXygxQzxRI0/D561"
    "QQhn/cDCwtKz/ATWLxWl7qUEdiJgr5aVvZQ8H0O/35NqHTn00M++kYzRaIP2t1raawAVvoys9MHPnhzKKq/Yq1Qpp2/5vDkl8VIk"
    "ISuIuuoNlKgfUT4QYfRFWPMQW869kY4AWP1rvaHbdz0+aH4aZH/mWwufBT7ah8trvhZnTnxiTHlhmW8150bQQxwhalsjWezcHFv9"
    "ZImiIMYASIxX7GEF9wgA5pGDD/1MA2zbPL4yAGorfeWe/e/u372nf3Bnx3f3RfS3b/uut/OO3e/gnR3fNa+dOP7yh7Ovjf/0gFLl"
    "PazcY5UAgzQ99X4/fapzsfWp+x30iLtF32H59mS+Cq/VOUOvjv1kliD6I2BhMNUhMjq25/DDgwO1l4kX8x9dDz760eXoVLdfBbGQ"
    "X29ceOcZQIfDUYNvwCtgpUp9SpWqWsgQ8pVEysT9tpD5ZGfHd3Xv2P0Oc0a/c3T+M/pz2dfGf9pUMLgvVIOAopIEvRux3G2f9CWS"
    "yXmjkXGlgS3fd/DHuzv3/cDg7j3fO7iz4ztiwCEGFtZeTrz81IRSzmNKlR9j5VQ7++c04zJ9djW+e8fut3cCyIQp25zS9fFXxz4w"
    "sZQE33ehD3V9bKkGvrMqgZz3ey9NfHoEHM4ln2+M24OPfnQZiRD1Ux1zaYkqArsLJKyniaynieTTROJpIvE0SDxNRE8T0fPzlUES"
    "iQb3ut59uTzxmVEw58KRUXOSw64HH/1o5xL1sx1AVwWoUDm+a/yVl94/0YjnP3tyKGturXOaF2Mu8zWZvuiFAqWqxLybCD0RvXpB"
    "64oV6EqoM/Q0QOPzgie6yuXoWgJR23c93gloxnciGm7A5y1hLcRdWYszJz4+rFTp2eoyX00c5hPTGR2gNQMWeufF1ahxwNriEdSc"
    "mWP9iPqLYE99AlfqADC4Cr4yq1S5lq8cAtFToNBXEonusC0rWvk0T/LyxZ+deHX8p3qVci5UjyAl4fNt2PPaL1rFd6g8Q2/vJKJ7"
    "8gy9Ov7BEYBf8M0zBe2KFWMnBw888MF544LLF/5wFPD9Os8/npWwAr++/NaTpdxkel4JPsEh+yDDG7Bn/ezJoaxXq4XMB2J9cIE0"
    "N1ENiepgz67O72lf6Iy+Nv5TfUqVx31y3+CM+vwLFPe7N0AmFgiAq/esjjjuHdVnfvT+XBauAtecQWPH33T8i09F8iHu07GTeOou"
    "tbd/yYgVL0FtOfXqL845aHsPvqdPqZIfBKxy0EqIFiGGLMYLlp5mqw9dFStDN5ZWpt7vM48TgDMnfnWBhJFHGHw0ZHHlSsNHNLCU"
    "gNsfHalv3WoHIKYsORLYyeFzp35twQD60MMf7iNQxjdLwSqH/eJDbxxN5iEGP6V1QYVcHVQRGC7lffsqg/dIiawfiDcoINSJ5a+O"
    "7T/8vgECPSdAIEGRslYLRGyqUBSorvnXNIDIaFRBsv/syWeytf72wYd+ZoJAzwWPTkGo5lfH9AEYXqPN7KOg+kaMrfzj7v5a7D/8"
    "vvYzJz6RXejvnD7+KwMHHvhgJ4GOMAAI23yrMLbYzA0nhTXbhyCgm4+zhEfW+pS/Nv6hsQce+fmnAXoqBKQ5YH/XeySe3H/4/aNn"
    "Tny8oc936rWPzvGV+w4+2e2pogHIRcQVyInAcpDI7Nrz/X2Xzv/+gs+jVHEIZD+jK5IiVQA6ka8RENOqvUNlTE+D0aqD5Z0hET1D"
    "/Y30P8xev/b5osPnSPBbMIgFCCJDJIZRu0pyYb/O1L+UM6/9OroW8+uNFKVKACsIEBRJEFugeVtM3wjgwjNj+w+/rw9EL1LgL2Uw"
    "WhUkQMxg4gjH1PznJwQAxaJ2XXmlIRbec4JsaLMsEBlfnI0zipXJlYt/PLGr8/sW2q5eLA3Q7q+ylPfnHlUB7Cdf+YWJ+UAYBveF"
    "bVwyVqhVlLhiIVBMrvOven1gvxxbLHDGF5T2RYL9wcoxgRUTFi4sFLRemvj0GEPfUM9bdrmE2wV9O0o9AeEf0QsLp4s8qG/GvYC/"
    "IDoiE6Cew48M9i4h6RmCP2fcMIPPH9iJwbDaQEJUjcqr8bDD/qg4BKzu+ki8UXrnI/syBFa5YF58hFvCJEYDS0xG+yvnh0dIIYmO"
    "vfLSTzQ8yT5z4hPDSpXeq+aZFGFGhdZ1+7V91+PtROgLg1rrhejkkBoA4zDMmfJHwOovF/785IGVvt9DXR9rrx8ICMajrug7d+x+"
    "+5LXQgcuIZAzdy3qInGsftfu+pKDYr8u8w0nuiC49bQCHVht2b7r7Z0AdZmAe74JOM++8tL7Jhr4lbV1oyoxOP7yzw0qLh/zJ5mw"
    "mdzi21FDsDa879CT7cszJkvxle7AfL6ShD1BQaWJDUHWojrjuYUxzytC+WSu/lg9DSZnl+SFG/AOvuzs+M52QDTAnoTj+xrdUnT8"
    "5Z/LKlXur5iGFIwMNHohrK79h98/uLBfV/P6dQL1HH7k6aX49UGdefqTTFZ/LJzyKxYCrpYIwH7vgwudS7WVZ058YlS3kDlzJkVU"
    "+kuxKKigKwMXr+L0vPyICs6oUzFOlSDH4kSjIXKscvR8xZ71LfGz+kMAGhfOnPjEfblH9VQe7Tv0nk5m1eVPa1qLOCEGFr50pHOZ"
    "/w0AsGf/u3uZ3aPsBwEL9nMvCC10LxDsDwDoIPIPgAlogpsGDLzy0vvqC/4rDFAQCBx54JGPLBoEbN/1eDtAIyETtAAgRhb6nUvn"
    "f3+CoZ4OgtmKMZkmCIQYOfjgT7fX8f3DRNRVMc98njFguzq/rxsQR/1AhcgaP3f61xcN6pndEc3QXTlTfAUM3e3zIB7RxLFzFfW6"
    "e5F9yTJUf1ACyl5kXwgE6jj8yNODdYJNfQB6QnZwnVyZ/59DBAWfT3Z2fFd7VSBXd0B6+vivDClVmjspIhilWdd89UGAMpGRcKN1"
    "Babsjfrz53W/biRoItl16OEPrxSI6q3zTHSEHCIrLi9d8lqcevUXs4q9F1a2FnN6qutKcs+efDbreaU+5ZXCMl+u1oGGubSa55UI"
    "w1GGfERsNIALAA82+Hx3LS2JKvcrr5SbO1LXH9dqZ4RIDK+WvTG+slsFvpIqfKUIWpeCn549+3+4b+GkpdDueUWdIHI5arMvvDr+"
    "U2Nr/Q6hMshBIpGhpduTkXnPEOq2J91zfA1V8ziEcvLVXxj1VPnZEJgJR12KcP77U/sOvbd3Yb/uzfHrCP16Zx02bEi3XvnrlVjE"
    "jjVoehG73f4kDh9U4WX4oIYBgkuTjqXEqSG48PFhpYpzWsgqbOWC9lIEXC36jL57YJEz2qnBvyICwmWt17lXxz842ij7i1XmElhG"
    "u3Akfl+U7HyFz84jlReGFcBYxwOP/sJAnXHcsM9JZi6IRu6rvK2SP2fRNVXKGQ6nDMm1bJmMgYU3suzseEd7lYEOnZZW0o4Hu35p"
    "3oBw994n2jv2vnNAqfIIKxd6RJSoqZw7O7+ncxGH2PPgox/tnifpGgDomWiJIJEVlgsSPfvKS+9b3AAwDzI4vK3iKnCBaOTgQz8z"
    "uO/QQPt8gIImQsQYkb6VM7eyF86d+uSiweiFs78zyOyN+0GTvhmIODSSGSI5tv/wT/TWAjSM0TvqJ4uC7JoBCJEY9ns1NZmbVZcz"
    "P/XaL436yHqYpKhIlYg8euihn12Cg6HeCrWKGj797ytxVov9bncd+zLC7D6tlBsBF0Jmf4J46uCDH+pfxBl1AzQc6kRYJUAQOYB6"
    "F+dW4Orv6DnwwAfrdranj//X/opJERHCqMXGaO7Y/fZeInqSzO26Jrerr0RTeaUxpfw+3fAmOFK+PLSIfvQt/J8x+MAjP99eY907"
    "t+96fISIji4GtNWvUytfC64IWMNbXSJrscS6L7S+BF0BU5+cPfnMRPWkiChwWX8iQr21EzMAwMADj/5CexWI2bmz4ztH/Cqu6Bkw"
    "FRs5gPrqAH6Xsk+dCyVbPE9Qdfr4xyaUKg8qVUJIelrdZ508sv/w+4Zr2Jt21CLb1WuUWchX7t77RL9S5VHtKxUIEhTxlSHRZiJC"
    "7pYY3nvwPd21A8PioE5YSkHSAn3rPO877Nrz/av6DgDQsfddvUTyyUpyxLrP0ERteyLqsSfdgSbMo/IPdc8FspVXHlSqdEEpTeyn"
    "3wvmksTWhH4yOTLfPhi/fiwkRfOq/LrIEFlj+w+/bzG//iQgA39dhx3rXiQJ7KvjDLUzq0xYaTHnsmWVElXqbcCz91Wee+o68MAH"
    "6o4lTh//lQHllV4IJkXU6y+JEFxuCds/p4N7D76nt7ZOFweVKsHzygh0jBWYeWiJNq92rD4/ML3UfVlxPFXv79Jcu7OiZ2fwsOYy"
    "i1QOcfhtBHrm0EMfHtx/+Cc6a5zDvu27Hh8LYwkBIpEjEkMrVPbuRfxpZ0P2izAfKe/Ag12/OO/nd+x7Z3fnvneNsnJ6GJ5eI1Mt"
    "F8vqCfEbfDjqjt1v7wXQTiQGiKweIZOQMg3LaoGUTXocjrmJUMqFUsULnluY8LxZczvigtnrCY5twPqsR5udO/VJAoC9B9/Tqbxi"
    "p1KlTmY1AKBLiASkFfkukdS3Hqyg2IHyisdcNz/qubO9nip2K1XOgJXpSUuYWeRNkFYTpEg+/9oXf6buALxj77sGpZV+Slot+nNE"
    "EkRSu1XlwFNFeG4enpcf97xCllUZSnntgApI+cKxfklImXzs3KlP1YU6d+7/oXYpm0al1dQlZdrMUpfmvV0orwTPK8DzZsc9rzii"
    "vNIEs9vJ7HVqghUz3UHIyJisNIRIHDt9/GO9Bx78qW7llXuVlx9Qqtyh2NXJkUj4s82fJbJHAEyceu2jQaK7Z/8PtzNUt7kV6hfC"
    "OqpvzFKGXdyQ/zH7z5nzvPyI586OeF5h9MK538tGA6XQmFKfELKfRCIjRUrvl9WM8N0FmL2c8kqDnlcYc90ZnDv1a6OLJ/FoN7o7"
    "KITdJUSqtj4p5wVPFYc9dzbrubNj58/85rwB7r5DA0NSNj0pgxGNQrunUCeOeV5hyPMKoxfPPZfVz/L2Xg0I0FEN4ujbcilT5j2b"
    "ckKmeo9/8WfG5tWHff+l0/OKncxuH8BPElmGyT/tn78LzDyoVHni7MlnFtWxfYcG2qVMjwmZ6tCEfRp805ia9/SrYx8YjOqinixR"
    "7mP2+gBk/NFben9SF4RMDBLERHWP9Z797+5mcDuBOklYA0SJLil9fUmAyAYRgVnpBMErjrtuftTzZkcmzvzW6M6O7zI6jV4i+ZTW"
    "zzQsq9mc6bR2cFo//HNxzHVnJjyvMKG8Yi+z08msOgyIFrnlS0KIxLGzJ5/tXWLA1qsTe+ojomWshegkIcO1kCmj44uuRTez1w1w"
    "P5HVQ8KGFCn9vTIBQLzA7A0pVcqeO/VrY4u9y/7D7++XMvWckCkDPFrwOQVeeel9VAugY1btAHULIQeJ7EygwxXnVer9UOULyiuO"
    "ue7shOflu5VX7FHK0SCKr8Ohjc4Jkeh9bfynx1bqswxBZyeAbiLRT8Lu8m2grztCpCBCe/6sUsURzytkTx//lbFwjd43KmSqR49l"
    "NHZInxGdoHtFeF7hBc8rDE6c+a2xnR3f3W30tZ+EdcTXC8tqhpTNy/KVCABfO/CV+w69txesXoSf1JI0usNQqvysUqXhiTO/NWbA"
    "9j6ABklYwRpIq8nsVXL8tfGfqgho9x58T7fn5TuVKvcDOCLIgpCphr0DkVgHUC+z16dUqY+Vk2H/okH7nwtCJAaJ5DLsiWV8RXCG"
    "LrhufsTz8iMTZ35zdGfHd/cyu+0Aa0BDJLCAvxlXXmnIU6UJz82P+ZwP+w4N9AqRfDGw/8ICgSI+oATlFXKeWxj0VHH4wtnfydbt"
    "11UJnlswMUVxRKnSBCvHt4F9ACr8uo4rUhAieez08Y/1ht/z7l7lFaHY6QXwlN7DWnbTvaD9an7CdWcmzp361IQ5653MqtP4z34i"
    "64g+r01GF0zsZ/yG8Z9DnjuLhfznIuc2iAmIqI/IenJhm++amCA/5roz2XOnPjXmA3vMqhtAnzn/GWlGN0qZBpGVA3hAKWdCeYVF"
    "n1X7y9SokKmu0FbP7y9DEPV7egHxohC2OTMpCCHBzGDlPO+p4lDVGR0gYfUEcYE0+iiTF4hk96tjP5mtM97pNPvVU2u/jM17wVOF"
    "/4+9f4+T7LrKg+Fn7XNO3burRlLP6DKj7pmxZdmSmTYYCBIv0wrkw3bA03bANiSOWsnPEMCg9oeN3xjzqSUBXxxs1DIGnJBEPeFq"
    "G9s9TnzJG0A9iSWDA7gHS7ZlzUg9mpE0kiypq7vuVWev94+99zmnqm/VdenL9H6gPK2Z6qpz9tl77bWevdazZvxGabHRKC4snP34"
    "Qu+fS1k/l/X3o2sP/YSZu6NEYlKI2HB47RkzDnpfkXkpazO+X55Vc600v3DuP25qrl1/5I5xx0l+NrRp8UCEU/mtFfh+CX6jdMb3"
    "K4tSVk350/HIgRxMG1rhJO548vHfnelgvo+ZwL+N/TQvZW3K98vzZo0tnPuDxY33QBoTwrlrbVsX7NUmnoL0S5rY8kcYPEygSJmZ"
    "6Zbk3nb2sek5WPQFl7V4oyYVHoymShuWDkF5QfTsjEAQw0Ri2DgUxH7IOwY15eYU3YsQdO4ECfcu4kb0NB2mDrepbzIJgAkgcZzI"
    "OU7CgWAXIAkm1ieS5jTHzRM5k9/4h1/d1MI//8R/njr8yp/PsWzcCaEzB+Ao1zs49XTB0jvGwocEIBBRXA/quD0I4d3RLqkAAAtn"
    "/8PikRvePcayPsPknmCdbmdS50m4EOyBOX6MWR5TgTwBLILsirBlV6wpdVb/2zSpsVP3gWg7JQ9E7p1E4k5meRqRNEcpq6PM8sFQ"
    "eFOf45ELZhdgVzOiwWlkloR3O4nY7cSN2xBRzSWiUWY8SMGRka61NgZsRd01ZQG6L9TM2PBodRoRQUqYuQtnlflEANEJAp3Q7226"
    "1uYT3+nJV9z43nkSzjTYyaoNKRBBgxDecZaN40wNXH/4dt3izw/KcQERjrOIgcg9TeRMfPMffnXNjV1yY4Ih7wpkMvV9hKe9zjBB"
    "PqCdnQ2PnM89Nr149FX/33GA5giUlYIggtNqXo1J/yyCGmmdDk6eTv91h4mcBwDgla/5v9/z+Df+XcDc+7I6DWaVtssSwgGkFCBS"
    "2S20UnTtmBDeMWbvTrX8vXlI3d2FRKSmdYXYZeSUSBwnco8LcgDhQUoA8INyJFOX7oh4J60VRwF81pzsm01282PhNo8FcTtjMQ2J"
    "42EtefDs9VoUJwCcIHKa1uxaOPutD8+88tXvGwXRnRCA4LbEdIM1FcwHEsF1N5/gqRIhaPHYsPxEFZgJ45SptXCGICZ6QSpozETX"
    "fpNdaZo/pEXYcKc6CQaO3PBLr3vi2x+d18HSBJGYl+RkwSrDzjhZSmCNwSxPMMsTI0d/5pSU1RPKDnMkGyla6rT5vVIEe0h4Ki2E"
    "O8qBTdE13BB6DuFOgO8cOfouhC1G2ZzWmSwFgPkMIJvmyStf/f5Rv1H8WpDBEi1T6dE9EDmjAD5rTmOlAIhZdyiJQQhvmITbnj0R"
    "gKSoPQmvSs+3YSG8O5m9O4ePvus2KasPqu05uoaEyRhrmcN0DEYgEjhlsoTOPTY9d/RV77mbyLkLJCBYRIT9XAiSgJBZduR9DHlf"
    "1B6rff0Xw30dQg1rmGUBITwwx9S+DqkvN7qvi2AsHRHXe7vXYgbFg0ZYMiSf1rKbNKzuU4Dg3A3d9USXMt6lSMDoWFGz70dktCba"
    "2j/bsK8Phl1Zmn3O4NqDE1ftEyhfI7B7eo49GIwXohmsAkQiC+ABIglq41rVfvmecYDmAcoKIYJMlbX1JZo1voQwWTkAE93O4NtX"
    "rFFTHsN6nSodkfFHz/xKO4Fzk78T2p+Vz0vbvBMEcUKPR/Dc230uG8ypLEhoX62t/ehBtZ8gkr3mRPaXFX7gnQRxp/73Tc+1p554"
    "YHbkFf/mDmb5gMk8ZeLQvyaVXUXCOyZ0hoqUBFBY7hvqm3h3d0IqNN/3evtpgCxA95H2ldu473kA2UDnI0oONPnWiIg4i6DECtq/"
    "J47EM3DCFtXC9i3oJy77UggyKV0RxkqnLAaK4s3pO+Y9nu5D7elX1AE3fYCjzpLTYhDdyJ/R7zGLQQRBNlEsOIV09EuI+HkhYneT"
    "8Ea+9fW7Olr4Tz7+e5PMjbdI9s+z1AaolTRwwu9Vp8jhz0LETzsi/ronH/+9TX//E9/+2OLj3/z341LW7pCyfp5NeyeiJudCndYk"
    "mr/XiUM4sfNCxG8TIv4eM9amxjUkh5zgBFe94uH7SKxImVLObCNIoQ9qTXVJQLS3NSHazmy1MgwRMaitveNDJ6Z5vzKERTtGLaLI"
    "HC05EE7LfEJkcxRtCRie/daHZ6RfG2VZO8myEYi7Nc0JJx4QOiZlmYK+8TEzP+94/JsfGvvWI1ML66bvBZoOFNR5U6THeyi+176x"
    "P/fYb89LWZ0IhKKkv47CtR5L/YzUfagX6SwVrfieW22+NOtwyJXOWFhfHaR2K5sQy6pgxNWnRKHtURufaFXsD5xzM6fNszAnVuqU"
    "Lxmsk07sYfisux2LFTWe64yFF2Q2mDZn6j0R4UXhtrk2FFSaby3U3IhopWy0psyzUM6VEzj+1DRfRJRcDU9Zgwyn2GkhYnc89uiv"
    "j37z678238Ndq3ntCze43khZXIRcNES5AyLKhTb4owtS1pVoX1ASoR1QEa51x4lDOIlck/ZBeLLT4V7pBiVsjrYZ4a86OYT6QWeI"
    "nJPh9cRX0WDwQrsKR4kIE8a+ceYDiy1zNGdE+QjR6+vdPQRtbc17IvNi02sIyp6Ete+8xhqKrfju6BqiyJxoTb3WZYy5Ztt531TY"
    "GrAR0UgRwf2rZ5BYZV//HbOvv0VyZF9vOoiI6/FabV+Pnxci/pZwX/dWtfuhPRQRX6rVbrbaHAfNJ7LN5OXqcyHaYUh02f4y6m86"
    "TXsbotcefUoR0jKyPppfwlXkFrnNLz1f29sv71uQsqZLyGpt2MoIwQCRBzn3R/em1gMf8xzV+nQAiNMAjX7jHz4w37nNc9Z4XhQh"
    "W5229ozW5yLW2Yub92NnE9fuREty1ee3zFUKriUQGu9oni2c/fgMy8brmBtnTClVVMxYtWGOh/Y06mOLBByROC+cxFuePPvxqW73"
    "qWhctXI/jQb/FJBUG983ZaOC7OEaaPWtw2555r6D/TqyRgJiOOLTWtiMhU4n/gJAp5snpzsXBvtixQGpYfwUi86jgMjB1KgSBQ6I"
    "SiN3I0ZTzAJiTG1SZpN258JFJnSqV0TwSLWmAqvNYYHJWQCwQCTmzz023RNH9dxj07MAZl91869NgGlcwBtTTKATnFoBApJckHIy"
    "8gDPgmhmM1kKa+Hb3/j/zwCYufG1d08I4Y0TnDFAZCmiBk2kWkAx+3mwnAPRzJOP/96sOoV63wKJWI6EAwLpMaGZgCFVqZxz4abn"
    "jQXZCCybrp/B8ww+ReAcWJpHP49Imx19pp4D0SixE8wF5thC80blzAN8CkAuyJZQhmyByF1omVujAOUiJ1GLG2+EmAk1JoyD680T"
    "OYsRxxWItCY1ny2Et+HcefybH1oAMHHjzXdNkfDGCWIcoONBDbYhAtiF0RUB6AyRmCfhzT7x7d+ZbXcOMPuzAI/pU/JFInc+dI6c"
    "USInB2KQlAubmVtnv/WR2Vfc+N73qEwQglDmrGVsaV51M3FypALcBSFiC2r9eiOCvBHlsEgQ02zLhc8wGMSsW8IBAM1F/t20W1TP"
    "l4JsnHlNLJxiUI5NjbYwwYtrThgXEGmLRKbto3AhOKZSlNkZY0SyeCgMcklsVmmb5gE6ReTk9HrpcCyCv11jLLDKWMTnGEKfzIp5"
    "ErFFTbbkiJxRZTd9QLTR0SWaDSMrk0Q0CohjggCCk1/n/meirTVJuAtqvWrnkmgsGuCpZ6SdIBEDQHPaGZ8ncufOPfbbi33ZtQhz"
    "kbU/L8hdVHuOcbJpNBq0UkgWLzbvScr+v+LGX74f5IwqspTmWLVqzBE5o4JiOnNB1UGTdFTbVlVbPReUh62saw3JV/YA8AggRpr3"
    "ykggQlGbRJFnzPPffvQ3Zm+8+f83DRJTBIxBeNlA+0U6hgzJk/BmSbgzj3/j382tbmfqC8z+6TBgi+73PboHonmw2kOE8CClWABh"
    "Qe3zndmTgA4I27dG7IkHwf48s1wAcIohcgy5SBDzisSImXvLAc292Smc6zMrx6oxIWVtmojAghZA3oLeU9U9CAYg59fZ12cBzDbv"
    "66T39bDDEpML5kaewXMAovt6jkQsp4Ovlu+hUyCRM9kGwuwZumxDjRaPAopEi5CykYxCdxbwxwK7qciYBSJ3ocX362j/XN++ilyQ"
    "ci28RSHc+easEh5Rug5N2SkzkWtfAOi0JkgWhb53tf7dURJODgwI8CK3rPcN9sv5V9z43jsI9EDgp67dYnAewN3aFi48/o1/N/Mq"
    "vUYFMA4Ri6zRemSNunNCeNOPf/NDc5u0eS3+jiHVvLlQlJkMWTcaqvu72Ph5RZ9LUNa02pwagdECUJ0smp7LOtd+PyBGKSDJvYif"
    "40RP7/XnRwhN4S50uk+c+/b98wBGX3XTB8eZnHGCOw4yYswehBPxG2Tg28+BaPaJb39spgf71ClA5MIDG091/CFnAc32Vt23Odwh"
    "Z5E2eGZmTEOSyVtQn+22xG3clLWg50MOwCiTALMRLnaDDGjtfy3Aon+R9+WusdDeCd7ewmu+6zdHQBhRp/XmFN8Hs7+gA87+fz94"
    "JDzB8cGysSXfbbE+bnzt3SNgf0TKBpjrkPok+Ilvf3Rup17zK1/9vjHhJCHIwze//mtze+l5dWu/Lwf7pzU3RoWTAJGz8M1/+KC1"
    "I7sYr7rpgyNS1kfCrgm8cO7b99tnuhv8CrD2K3RmhmwsPv7ND83b0dlR++WoEImcELGO98tX3fRrI5LrI6yFr+0a3TFrMAfCKDMj"
    "EFBXPtxl6V/v9fjVEguWWLCwsLCwxIKFhYWFhYWFxTb6Pxb9gbBDYGFhYWFhYWFhYWFhYWFh0SkssWBhYWFhYWFhYWFhYWFhYdEx"
    "LLFgYWFhYWFhYWFhYWFhYWHRMSyxYGFhYWFhYWFhYWFhYWFh0TEssWBhYWFhYWFhYWFhYWFhYdExLLFgYWFhYWFhYWFhYWFhYWHR"
    "MSyxYGFhYWFhYWFhYWFhYWFh0TEssWBhYWFhYWFhYWFhYWFhYdExLLFgYWFhYWFhYWFhYWFhYWHRMSyxYGFhYWFhYWFhYWFhYWFh"
    "0TEssWBhYWFhYWFhYWFhYWFhYdExLLFgYWFhYWFhYWFhYWFhYWHRMSyxYGFhYWFhYWFhYWFhYWFh0TFcOwQWFhYWFhYWFnsP9ySH"
    "RgCMABglIAcAtPJtiwDmASx+sPzCvB01CwsLC4vVQMy8tweAyM4CCwuLXYlu7be1fxYWewuaSBgnYByKTMgSDJlAMD+vZRlYvU6z"
    "IhrmPlB+fnaD75tC5PMin7v4wfIL0/aJWFhYbIf/Y2GJBUss9N/hyAGYJnV6sUjKcWhyMNaZLfNQpxobvQ8AxrCO4xJ93yrvmfzV"
    "Hp2Y3JMcmgAwoe9zcZ3rmcPGY7DePY3qPyc+WH5hcYNrGtXPYG6Vz2vnOta7lhHzbLmNa+nzXBsFMKVPyOY2mAtr3fco1j5hA4Ac"
    "hWM/86vlF2bavLZp83trzY0erYONrn+t9TD/q+UXJlfbWO9N7TfzZxHAPHU+n9vBiH6td/3RZ7Cp59CyHta6n82Mdzvjv+pavVfb"
    "RgC3RwKkM9G5ob97UV/TRvNls8+gnbFe9/f12t8Ix9f4jpMfKL8w0cEan44GlC2fu6Bf7a6tdu+hnfuJIh99Ztz8DOf4Mjmlvyc5"
    "NEHABIDjIngeBAHoF4FI/UyRf29+NmyIBTAAyQCD8xKYlcDU/11+vul53qvmwNcIpu6Wgs838+r95ecnOr0fvX8HdrpP/spm194K"
    "O72Je1kAsNBjuz3/az3Y67V/GNjyHnvOwWe38blzHyy/MNfDObHYsv57NRei9mrTfmvEfq7ln643H9odz1EAU7vVvlliwRILlljY"
    "4aQCqQDvWNThWOvkYqNZw2v83PpZa43+Ou/LMzD6Ky0OTAf3O0nAfaGT0+zw0Br3udp/U5vXzioQGXt/+fnFdRy/B9Zxwta9jo3G"
    "t2Vz7dih6wWpoOdatnWubeQEcJvzZbW/Y+CO95efn9ng2maEDh5Ju9WiwzWw3jpY79mgvXs5+f7y8xNR+/0bilSYwwbjyh2M70bX"
    "RJt4LgDu+JUNnkO784Q3Md6bvP6mtfqbyaFZBk4YW+G0zAsC6ZBr8+Pbzns2M1c2YUvXeQ+tcp18/3vLz7cbKI2QIoKyIjJmG52E"
    "o4t9g9Ydg/ZHrfU5RgLpMwzMMzAH8NwHyi8sYBfgnuTQGAEzBAybdeQA6kVmLpu/0zaPNNGwyjORYDCrn30wfADS/Mw4LcGT7ys/"
    "P6/XzSSA+yjy+YKa144EbpssPTfXAUnyQCtBsoat3DY7DZXZMb7Wnr/avWAN36tbu82b+Nt2765X3vMm7dvd7y8/P9X6l/cqUqHr"
    "OdGLubDKv+VZ7Sfzbc7vcb1m29r7eHPX0voZeQAT798g88gSCxbtwmosWBiMEnBM6M0/6nRQi4PBGzhkUWdsI2NH6zh+axjELCsW"
    "uCunzpAKAgTXOFaBw0OrGO6Vzma79xT5rGMSbIK/1X5/wny/a55D5JravY6NrkX/3u33pw7M31l6bnrLyTxgXABZ42y6q4w92hz/"
    "jeZR9L8keALAugGtAG4XUUc74ni3eRLW83WwBjF0O9TpY+TaaRzgLNYZV97EfN6MQ7iZdczqumd6MU9Wux/uwfUz+Bir05w5tVFS"
    "zpCIZl26LWnjHPxuu6Tk5p7BZubKZok32uC71LjS6Ca+b2S1Z+dExmwzZEsn97CZsWueP9RKKIDBkMAxBo5Jxu0M4N8n959ndVI/"
    "82/bDBi2mFDIQQUnJ1r3FU/PX08/Fw8U7PvRvXAVuwMJQBIgWZEKDU0uNJjRID7eAH1tOnXgfp8xJcFjMPus/p5wHSsyzueO7M6E"
    "aCFEzDWLyBXvADt9fL09f6N76aXdjt5jGI9tnhowZ3GEnmctrPjMNQjOtfbuCXQxJ7r1rTawV1kJHscq2Wxr/O6ksZ9r+YLtXHM7"
    "46mvbRLAriMWLCyxYLGDYU5mldNBiGmnw404g+1t1mG6ZPMGttbGRBs6jdTi4Po9uF+z2XgAYkQrHJ61GOG17m29e6LIpi7XGT2z"
    "aXhA0zMQ+hm0O8YbXUs4jnzff0xdM/8zpWfntnqumQ0zep9Oy1zbaPxX+8z1TjZl2+tAXU9MX5sDwKX210C762C1Z9XuKQivYcxZ"
    "n2y4+tpjkflDqzgg7Vxj+04mrbmON/sc1pon691PJ/ey1vW3rtU4EWTERsa1nXRWOK28Yt5uRDS0e92bmSvrOe3tnf7TKnaXN/1d"
    "rc/OJVrT6eA2A7x272G9+1nvJDg6l0wgbeaDZBVU+4poGJbgO33gzo8kD5zxwdPtZOJsEakwSsAsAcNmzrqaUIjaNjOP3SYb3Dxe"
    "tMrzYTB8AnxWY9EAo05AnRk1MGrMd9aJxyVo2OxtHggJCueB0J/VUOTDpvag6P5t5pcb+dydZKc3Wjet9+JFnoXogd1eze5wF4xA"
    "J+uvV3sJ1HiOrLXGRYvN2cyc6Odc2Mj3W2vvi86J2Bq+4Frzod3r3Oy1WVhYYsFik068cjaSREhCaKMWPclbe+vi1RxEWp9FXeko"
    "0rqOpNykg7ueo+lqUiEJgQSFTpZYsSWsdHpbN+d27onBaGzwDMw1JSCQ1NfkUphGvNF1rH8tUSdFXUsdPDuTvnZsovjM/FbONUdv"
    "mAkQkiSQCBzc1d1+XidIo3XGfLMbe/O8UNcW0w75xqcem18Ha1//6u5auA5WXoFLBGbAIeg1vNa4clvzqJ3nuNp8X+sZ0CadmHbn"
    "Ca82R2hzGQCt66R1rSYgIMEQOihL6CDJQ5jVZa5DRsZVrjpf2rMpnYx1d89r3QynTRMLQtuuOAgpEkjqsXOx0tFfj4DZ7D2gjfuh"
    "NUmelaSCNIE0AkIBjcifPgMN4mM+6IHp1IEpnzH5y+XnZreRVJggYFoAWdFCzMX13mL2u5heT54mHwRUlpZYIziKkoNSj4HJWmiA"
    "UQdQBaMKiRp42Ne/5wCI6TUTh2iyp7UO9vMoaZWM7JVq/6Y1Sxl7Zac3WntRO93Y+F5yq92L2fd7YbdV6Ur3WWqrndb3opq43THW"
    "mUOrEgumPG1zc4JXtUO9mgvRJ7eZAzGxxvx2I1nE682HzVznZq/NwsISCxabdOKBBBHSEEiTQFw7z2KjjavFODf/GzcFbusFwViD"
    "hDC/Z05HuoU51Y1DIEUCae1wxYPNvP17a/eejAO2XlDr6NOKFBHSEWfcOH28wRi3ey2GoKmBszHwzB+mrx17Z/GZxa2Za2qMPR0s"
    "qrlGeuxXzrX1xr+deURoP9PFCeaFGn8TEHkt5M5Wr4N27iUGAusTx43Gldu4xnae43okINYITnwtmNiredLJvWx07a1rNUUEX3+n"
    "IW1SxtlbkVa/yulXh/Okk7HemEBeO1OM1nCi5Qa2a839RAeTKb2eksF+sjLFu90ylo3uoZ37WWvt8irPUEbIIp84ckrfHFA31En9"
    "cJ34sx9NHThVZ0z8cvm5LbGpLaTCA0H2YQsRltT2LNGSReJEiIV2TjhZ73xMCAgXs2ZqYFRBqOmxkRFiIR4hFlyoLKDOiAU1h2L6"
    "ECRDAsnI/t0rO93p2qMIMVXf4P4IdMyhlfcSWyODryO7Tavbyc1kqRF1b382a49X81vWIqZdfaLfyZzodt/eaC5s3n6qPS62ii/o"
    "tsyJduzmev5Frw7rLCwssWCxqiFzg81aOc7GMFObhnmtv+N1HD1sQCyghVioc4+IBW2ok9pwpzYgFta6r3bvSQKoMW9AdiBIUU1B"
    "PYMErQxeuh1fjjiBDvMxIsxAtR/bGhJLBxhxvXFGA3jaxPi3M48o2Dw3Ny8SREgTrZgX7Qo/9XIdtEMseCBIcJB1tNa4diN4iC7X"
    "sb72Y72cJ53cD23wc+tajYMWGzpASmjbmNbzwl3T+ee253CngmG0yXXX6iC3W4LWToDU+inmtDzcTwRSkdR7YGXt+EZzsN172Oh+"
    "2gkuWrMXOOKES0TIBWI0TAkAYE7rT9TACx9NHRj7pdJz81tEKozqTAWVAq4JBHNQYPb0hA7wTar4aoKKtMYZbDTEimboSCZFLhAh"
    "DkYcjLoeH0O+m7LDoMRP2yung+jU7JUedHafJh0TJIKT651gpzfa88M9J8xUDPd9EQTEvbLbUbvEvHlmIEyvpy0Tbmydf2v5f6aU"
    "spM5wX2aC032cxN+a3R+R33B+Dp7Xye6NBuNqYWFJRYsujPwEcMcQ5iOHwPBWSffrdUmdaMzTBukAvtMECS7vlcR3dAj5R9x7WiZ"
    "6+jk3miN+2kwQ9D61+ToE6SYPpk16d8uNlfjv9G1SFbMv0cMR8mVnfhM5uDUWwsXp7aCWBAI09zjwYmaCOoIO5lbtM48Ym7vxICA"
    "kwK43Zy2xoP0XfVc1nXaulgHG11/KxrMJ1c4VtC1ukTrjmv0OrnHz3Wj69fP4WSbnzcSOFht3A/36PqJVq7VGNEEMeYE4ZiHsE49"
    "Wj61sg6a+jJPNjtXunXmzTU6m7zQlftJ+Oxag0nuRERuEwTLZj69mWCg4JkFHRG03oaMiBb6pIiXGjFqTKiCUQFnK5Bzv5e6evLn"
    "S5dm+kwq5AiYE0DW1XMyoUtQTKaPyVaIU3Omwmp6CtCtVCNjMoKgq0SUXNABG6m9VOo9OkaKWDDZHtEMFldrN5H+fXQm3jjvgI6r"
    "vRIr90raGXbaZz4jaH3BvlBjYY19vwu7zasm/tPmF0U7vlsPpRzX8gslAy7x+j7dJudEN/thu3Nhvete20fSemerzAlBm7vu9fxs"
    "yYBHlliwsMSCRe+DvQUC7tbGOecQRh1gxAUNmxq1Nfci6t6xX8cmn4fqADGnDCIvSKb57u+XXkdAjoCcA4y6oDHjqDjRTZI2Tqvc"
    "4J7yUL3Q5wVhkXltJ4OUUv6cdjRGHGDEAY4b0a1uNu4VgYJOjRRMIJJgFpDAXZ9KH5z/yeLF2T7PtTnT0kyn4I65RKMukI3eJ3Uw"
    "t2jl3JljYIGJwUwb3td7y89P/F7q6kUBGg2UpUEjLtGwu1FFe3/XwenIZ8+/aunc5CqB3AIYpzVpM+qAsqZ+ukkjgtDXxEdaff0q"
    "J4Z4/sb8E5Ntfs4iAadFk5o9HTf3Qz1ykFu+8zwDC0It+iCwGi9cXPx05uAYqe45JggbEaAxAYwTKNt2anAP5kknAfNmf6+VyNyM"
    "BofZT8yY6BNxZWsJIwI0TFt87+2+f1XRWFpJOkiQFnMMywDqzKgTo6pP7WOgrAf5wB+krpl/V+nZ+T6uuVkBZE3WYUKXnmRaiIV4"
    "RJSZVrYzPg1geiR/dlU7eTZ7NAdgDCqzrWnOR9skOqTIBJdVRgIHgV+zSr8A4GNlhmA7+JXy85MfS10NAYxG2meOOKBhlzbIZunR"
    "+qON7fQiESZek39iceMg0ghcIsjo8FqyoTqz27QmydCbedffdu2r+S1rxcACNKnJ6FEBGnOA42YPN3NiC/ft06w6QCyq62ZIbl+g"
    "VLeaNL7gmJ7fzb4g9eY6JfE8euBTW1gE82yv9wElIjsL1sGZwSMjcdCES5iEbn/T6/q6NciEaQZmD+fPLmzVvf794OFcHDQZI5qk"
    "7u/1JAPTh/NnuzbYjw4emfCIJgVwrJfjb07dasyogFFiiWWW+SWWY28vPr3lG83XB4+MxYimne7v824GZno5d74xeCTnEY0RMAng"
    "+Batgw3n0Hr2e25wJDdAYjQJGo8RTYiW4LeP171ugNItHhk8MhIjGhPAJIGOAV3X/J4EMNvp9X5j8EjOIZom3aq0T3PjjCZo5lfR"
    "bchBtcY0z3UUQLaXz1iXTp1+Zf7cWC8+79vZoyMEjBMw1cd95X69h8wBwLnsK6LjNKZ/HjO94tsdr7V0GHydBVY3IoYsUQajzIwS"
    "y3wJcvRfFZ/t+X52T3JoXACfNTXZCV3aN0ACGShyISpkZ+r2I5oreQATm5n/jw4eyQnQpCBMOi3Pr3VsWgPR6HPWpQJ337h0bqpX"
    "4/Ht7NFx3XrwxE6x0+vhI8kDnCJClhxcQQ5ymhBaqwRyL4MB1MH5G/Lnchu9d25gODdAYioBulOV8/Z9LuQBTI7kz8706/4fHTwy"
    "7hFNdekL5rV/PX04f3ZxV88HW8JhiQVLLOxePDp4JEfArEN03Omf8wwAJ0fyZye2816/PnhkRACzDuhYtOVTm/d6hoHxfhAijw4e"
    "mXFAtzsUpsp1M/7G+fMj5EJBkQtnlliO/XTx6cVtmmszQt+nCdREe/eZZ2CsF2TOBoFkcH20uevbzMY/NtLGfbRrv7+RPZoToBlB"
    "ONHn9Xt6JH92bKvmyjcHj84JwnEz/ptcE6cZmOjVWv2HwSNzDtCU9dSreTGSP7vpj3k8e3SUVAr7GIHGABzrlFjqNbHQsq8sOETZ"
    "Xs9LBva14zg/lj06rvvGd0QYrmjDCFUeUQejyoyyJm0LLE+/rfh0z9fGvcmhBQc07AGBjsIAHAxociHVoo7fMie7splnBo+MuMCM"
    "AB13W/al1jFaR8ukp8RCxE5PCdBdYvP7yGZwR7eB5EeSBzi9CrEQ74xYOA1FQC6sIRw7AuB2oOcE892ss0pbvncUIfE5QtoGdfq9"
    "Rhvqlflzbf/63w8eHouDZlyi4X7ufQy85XCfyPQW/zQnVCnQcAe+YN/8U0ssWFhiwRILm8bfDR7OOcCCB8o6a6dT7pqgZD387eDh"
    "URf4mtdSi7rBvZ5nYLSfLPDXBg/PuKDbTZ2q6HL8o4JkNe0EF1hiieWpE4UL49s1/n8/eHjeAx3bzH0y8Lp+kwp6boy4wJNG+KwX"
    "z6HlPu4+nD/blqO9Wfv9D9mj8y5wrE/rd8ucq4hNGneAz3qRZ9HmPfWcwPzKwMiYR/SgF+k/3ot5wcD5w/mzIz0gYUYEYUJlemwu"
    "S6BfxIJ+hlMu6C4XCGxtL0jTw5skYx4dPDIpQFMOIdtpIGrsKYPRYKW7UAWjzBJFZhQg3/IThd6Vmt2bHJoQwAOu1k5IQ5EJWVMG"
    "oeuyY5GWe9SH9fq1wcMzXmRfanfstCjo3a/K955Y+Fvtr7igrNsHO90LG/Kbyf1jcdCDGf3MriAneHZtEgtnAMwwMNfO3vdY9ugY"
    "AQ9GO6v0Ishul/h8TGUqjQmV+bfpU/dOiIWIPzfngbK9sjGrzOXXHdkC/0Pfz7QL3LnJfe+MJhEXcZnAEgs7E8IOgUW7+J6lJxeL"
    "zDMl7SzVOexl3YvlzUpjYEfg9UtPzheZT5b0qVOdN26JxsBUv43265aenCixPF2BRI1Zt/nqvHoyFFLUgn8gJEFIE534TObg1HaN"
    "f4HlVIklove5wTw7eXiLNvXXLz25UGB5pgSJKiTqzL1eB9P9uvYiy/GyXr+1Hl+3vvYtdVqWWM4XmVHSHU6i63QdnGfl2PYUP7C8"
    "MLfMMl9iuWJ8u8RCL67v1UvnFl6VPzdVYR6pMp+qR9ZVL+dAB89wtqjLBmqsAnLZl4rw9XHT0hPTZcixCnM+als3MzZGpNAIr8XJ"
    "2FOBDBEyED1d2wRMkdZVMALEKRJBF474OqQCgNO9IgFft/TkRJHlyQokqrz5ceuTnV4ssJzb5D6yGVvX8/1xE+dcZwDcNpI/OzqS"
    "P9t2GUaZJSoc+jRqPLpba5v53Vflzy3ckD8384r8udEq82115jMNcNCudLPi2Jv056bKEX9ObqLFbTtjoAVOtwTLLBeL+iCopknM"
    "Dfa9vM7Ou2xIBQtLLFhcJsizP1dgCeU8y3YM2maM8+wOu9cZc681NG9Gq739cB9r65occcjxIst8RTvifpeBQbRLQ1CjC4E0xF2f"
    "Sh+c2I6x/6Hl87NLkPkSGxJr/SBtq+fOIsu5ZZYoc9sbe7tr4PSRPm7+P7D05MIS+3crZ7u35IJWzR/Zyudw2/L5hSX2YdZpHRsH"
    "pv10sJbYnytAzYt6j+ZFr4Oz1y49sXjT0hPjFciTNeaeE2MdPMP5JVUqgDLUM/SBrpz+Tn/vu5eenC+ynKjoAKTRYQAiEBK2sWiH"
    "BqLhL2YOjfdi3O5V7SWHXSgxU6Mcn9JkRtiabvWT2V4TmN+/vDBRZD5pSLVGhJjZvj1czi/r9ViFagvaIzt9vpfp5E0lShtHzvdr"
    "QmFus99TYIkiS5SgyBa19tGzAHszuGnpibkbl86NVphPRufLegRDN9kFty4vTC+zPG1813qPCUwGj2/V2L3MPpbYx7ImzeobjJs+"
    "9JqHhYUlFix2HrEg55ZYogjFfPfCCdSG78yRHcamvqlwIXKv6xvvrQxs/8nyU4vLLOeLOjhs9OAkxtTpuQTEodIw00TIEE1/In3d"
    "6HaM/zLLuUKbwftWpt/ra1ssrLEOunRY+775L7GcNqSIIW24dw7W2FY+h5n0tSNhUKrux18/EDx9uAOHfBPzYr6gHfeqdpa7Ddj7"
    "5fCPLj05UYQ8sxNOmZfYP6PIIbPWu5uR3dzDDywvzC6zPFWGbMrM66QVXZRciCPIJuhJAELABOlU6KA9tO4IYdLonXXSo/thM29d"
    "XpgosDzTTHrztmUu5FnOL2s7XWUlqun3Zo73jlSgZnJhg04Ld4/kz052+l2LLJHX9rLSstZ4m+zTdy09MVEGn4xmEvTLDi2xnCyi"
    "2aeQvSGawMD4I4NHclvkf4wtazI98D/Wfo7nD+fPTtvoxcISCxY7Ej9VfFoFVE1pWN2HJVudQt0uCixPm1Tr+jqbMPfQ0WhzY0GR"
    "Jco67boXJzGiiVwwp18imyYx+yfp63LbMPbzRaggrbZOkMYqLXSrr22uwAyTUdFYf2PfUevgxPKFxWXIkwVWznZI2nQfAMstJhYK"
    "LEcKMA6WOoFrqOtY6xon+nk9RebFYpS0AcPnbseV+2lHJooRgmm7yIUC5KJxkmv6GfrY1vKMyYK2r90EINFgMVJq1itiYdyBylaI"
    "kco0SxAhTiLSUnJ1UoF1W8Q+zanxQiQjqtuMuu7Wo1wsmgBsgz18M5Bov3Vgu3ME2PBE/tRIm9o7axML6qS7wBzsq/469nIriAUA"
    "+B5VSnOm3GaJ56ODR0Y72vsKF+YLLE+WWg6LepSxl5WqFetWzOvjJSjB7VpwOLA9e56FhSUWLLpGieXpig5K6j1yHLiHG3WP71UF"
    "77y+k7TV118EIwhse+iIm8wFL3LCliYxnCYxuw1jP1dqI0jbDlKqDKnrVWWwsXeb8qtV5beEoCqynC0Z0iZIWe7Jyc3wmcEjI1v1"
    "HKrMoxU9P2pmjoAhV58np/uthl2FnK+Cw9PAYFw7G9t+B2M/vPzU/DLLkyb7abvKIsq6K01VZwms9Qy3ioz58cKFhWXm070IQKKZ"
    "C67KXsj+74HhsW6u797k0AiBhl3zmbr0IaaFQ11dAiG2YV7908KFhQLLu4sR0nu7CKuyPp02hFU09b87O9ebO2nulNEsZNiSuZDv"
    "hS5MgSUKCH0a5Td0t9Z6hSWWE1GtlQ3WW67zMeApczDWy/IYva6m+j1O/y65f9yUG4WaNGuOVV8z9CwsLLFg0SPnOXQCA+d5B5/K"
    "dXmvc1GHt7FKcMvbcP1lXVtnGOvwGXR3HauJOaaUmOPxz2YOTm/5PNPEyXpB2naQUnUGanrsoyesPSDYtoRYeGfh6dkS8/lyZHx9"
    "7k2t7VbWmjbAow1wW4HfVjh9dYYKYEwGAHdP+PXbsiyznAp1c3peGtPeuGlNg5oWlAtT6LdvXyiwnC3obLVuAxBjV11SOjZxoq6I"
    "BQJGBACHAA+EOARiRFAdSYzq/fbNqQLL6WJEyLSxDXNKrUcO7HQdnQly9nnsRgMigdb9zulekKJls6ea7I2elGr1ZkR+tPCUyiaI"
    "lHj2g+T858WnF0osTxpypd6jjD39HIe/MjAy1s85LcETMhDeDMd/jRLdSVhYWGLBYqejoZ1PVa9oVMU7dxt4h99rTTu8jTUcXp0C"
    "Pr+V11ULHPGog8A9Gc+VYo4CaQikIO7888zWiTneWXpurh5J9TNBmtwBpJSZ9z4Qnvr0QKRvK++kAjlrTorrQepp98QUgbZsjjAw"
    "xgB4Y2Lz/JEtOLmR2kb44KZ5IXewnfvJ4sWFAvMpk/0UrUPfqmv2OWx722DosqLtRYnlXJCV1IOsMHMKrTMXRrpcZ2MCgKsJ4Jgm"
    "LLygAwRt0Jq3vyKr7yg+vVhkOV1ibqeePdc/O43ATvtR8pF3BtlHkXtvbv9Ird830xO/QZcU9rIEoJdYVoRUUOLZL5KzDJ4qgVHu"
    "UcaeIYc0oTfVr/G5Jzk0AtCJqJ9m5soqrWRPWsFGC0ssWOwKmLQrn3vnBO5Up9tnEySoe21E7jV6zTfkzy1u/XUhuK5epzJGxRxN"
    "p4gMCaRB05/cQjFH4xDW9b22KrRv17zRHRCCE4NAWZt39ul0FFXm6SpkE0HVTb1thJA69pWBkZF+X/+vJ4dyAIYJgKD165T72cKz"
    "1TZyENA0BzI7GSWo0hjjaG/HCXOUgNkJa/xdpWfnyzo7zyivdzsuBJVl0ANiIWc6T7hAkKngguBQW+r5w48OHhnr75ziGTOnjJDp"
    "GmRV3/YTDuxzs23bSQRwG9kKp470qIRLRuyR2bt2kml6W/Hp+QLzmX6TnHcUn1kos7y7wpGytS6yFgwZpMtIj891Weq0zvdMGRvi"
    "6Mwkh9SrJZjL22wFC0ssWOwacES5t7W2q9M64p3qd3NwMh0GtbIl+OJtuq5oKhyj96cPRszR0+RCkghpEtkUidk/3SIxR4mwDZUR"
    "5ZOrlKJsB7HAWKlg3bXDuoU383PFZxdq4DO1oJwGXQlQRgN7l3ojULcBxg0BJoyTBTTVKUcc6pmttRncZCd2so0DgArzbFmfLlcj"
    "bTt5C8fMrKdoau92j1mV+XRFZ6zVe9Ta15xsdhlijArd+SEgFBCcmLbVlq/fZNtE8ZmFEstT5YgGSoO3vktEP4iqflz/WsToTmvD"
    "3W+UIGfWIzk3ysZpe22Dp8vM+Wqg6dB91oImDREHTfV6XO5JDo0I4Ha1zk2mUrj+o5lKDEzvtC5rFpZYsLDYMNhure/aLSe1m70u"
    "GflTrnJqvt3Pop/XYph40y4tGYo5zm0NsaCIBB/RzABe4TRu19zALnBY10OdMVONBE6NLsfUpHo7W6BEbdLBTdmOE7TXIwhqGtNT"
    "R7fIyWLsnBP3zeBnS88uVqDaBFYRlrltx4nmTiJh6jptfCNh0M3aU9FlaCQiL4dUZplD1G53AfOeY38zMDLVz/FThFXY7cPfhr1z"
    "qwnbzc+H1cnQyPXPYQ/BkJyVlky6lkc42u33/Ovis4sVyOleEV/RElKP6PhfDVw/1uO5MhWWUqkspVigqULRrL3zW5WhZ2FhiQWL"
    "nge1O50Y6GXwuNZJFV+2dx9ulqosQvVI12KOxz6bOTizVUGGZG4J2nbG3GPe3XO/Dp6po1nMy+8ycBLq1ObYwwMjo/2dmzRmMhXc"
    "4NQmPLGlcH7MbLXN2I3zosY8W42o5+/EGuythg+er7fUpMteCORSd4ERRUkFmKwdtKGu0AyH6K6/Grh+om9zCjxXjbbF60H71U72"
    "b2B7RJY3YctWbTvJwPmjfe5ks9Pws6VnF6rg80Y0uwGslrWQ6xGJMV1hmQ/b3Hauh2NIQ1evyTjEVK/GJJqt4Or2snGTsUCqHMpk"
    "6zEwZbMVLCyxYLGrA2/eQ/e5V+53VScWiiVPkEAKAmmI2/st5hgdc7mDHMOVrQx3J7307tKlxRrzqVqk80Y3J9XRueJS/7IW7k0O"
    "jRIwLCK1pm6k1jTipOeP5M/Obse82M75cE9yaPKe5NDcvcmhuV/Xr98IX6sGtQ1gvobI6V1Lp5CtJmh2BrGARV9r6zSCtOyedN+Z"
    "794mh2SCCAmLNrMVKPh9F/TA5zKHJvsxfj9furRQZT5vOs/UW+zLWqf0W2m7txm5VlKh5Vrn9qJfWWOer/awBGktvKv07GIVPF1B"
    "c0vrTrMWon5SjOj4X/Yoa4GAaUJY+hSPvEzGgiYUzxzOn52BhYUlFiwsLHmy88mFZjHHNAlkIB7op5jjbs8I2A2og2eDtpncXdvM"
    "aKq3i/7pLBAwERIYqt7Uaak1xQ4IhreLcCJgXADHHeC4Azru6VdMveb+fXL/yEpigefqzKdrzKfr4NN15tMSfJrBpxm444b8uT3n"
    "sBo9IR9h54puBQCpN883cOCiWTqb+X3TqlIHKvd9Mn3dzH9OX5Prg32Zr69vX+axdzHaTPc0iznyHh0bM2ea2mL2yReIZi1Ue5i1"
    "4AE90Vq4Jzk0JoATQbaCbi+boEgpBAXZCpPWo7GwxIKFxQ4nFSyiTmyzmGNKEQxz/RZzDNLL7QPpOX6udGmmDs6b0+pelENoEavh"
    "fpVD6MA5qDdVJzl6jkZObeUePGXX4zMq9ElWDCptNknCvLJJEiuIhcnSc4vvKj079rbi02P/ZPmpse9fXhi7aemJsVfkz40d3aOn"
    "YBxppxzV1pHdP5+ekQthm0JqOwPAZBa5wdwgpEjcnoKY/4PUNWO9HENfZ8LUVwkSGTh5Q/7cng2GCFhc75kxeE8SCw3wXHMrbbS2"
    "Q17s1Xf1OmvBiLP2KmuhNVshQeoV19pXIZmO01vRUtnCYiO4dggsLC5bnNYb8IkeOkJazFF5hZIEfCDrq5TNUTvkuxN15tka+Hbj"
    "/MfJBFGbV+BuEbGaQI9PUVQZBA2LiLPlBaKRYVo4A2eO7sE+3veqetysHn99wqVO0Zww2LNoi1hALire2yrK2QVB0O28XGy2yZvP"
    "WCAQHGLEWJFOOpNgmIEH/yB1zf1lyKlfKj3XdQD37tKlKQBTdjatigmovfPYGvNvYS8Ois9Y9EmVIJlW00wmC41Pvnrp3HQvv6/C"
    "PB2DnEyAslUwXOKmvaQTH8klIMZBh4iOyIV7k0MTAjimbDkQJ1WKaoiFlmyFCbucLHYCbMaChcXl7RhPMHCmtTVoV+J8CMUc41rM"
    "MUN0bHYLxBwt+kQsgKdrEYG1ekvf904cK619MN7razVlEC6ZlyK6PGp2BPeqMjYBY+aEKw5ChgQGSCBHAjly9Mtu/W3az1GguStQ"
    "j8pbug0YuyUmghIKL2LHB0ggo153piAWPpa6etLOgv7hV8rPLzIwxsBtDL5NArdJ4Daf+TYffNsr8+f2JLHwy+Xn5hvg2+qtL8Zt"
    "r8if63kA3Zq10OgiayHaUrabrIV7kkM50wkiyFaAQAJKRDuarQDg/iN7TOTTYufCZixYWFy+TjEO588unsu+YoLBcwCyQHMf6E5O"
    "3KIn0jEiSAjVEpJw+6czB+f+WeGiJRh2GX6+dGn+v6SvOV8DD6tWg4DPDIe6yFogwGUa/srAyPgPLC/M9jBwHg96eetUf1cLODrN"
    "+gqze/FZEjBmTrgSpALGFAkkdc9zAGiAF+2s31bbPNdLYqJzoVV11hkDASQAlgAJY9+zLvi+j6eunqyCp+4sPWfteh/wi6VLi9ij"
    "Io3r4RdKl7Z0TKrM05UdlLVAwCQBw672s0ymQtJ0hAizFfKwGUEWOwj22MLC4jImFgDgaP7sfIMxUWdo8SzWNcPdZi6oYC7QW1Cd"
    "Ivoq5mjRPzQYM3UtYFXjsHd4990heifieG9yaCwsg1jZy9sJ9RVOHt2jLbcING6ELGO6i0uaBNIITqPxj5efmrczvi0c74Ndzt+Q"
    "P9ft+C9wi53vVMU+Ksqb0vNjkAQGycGg+u/hNMQDH0tdvXBf6sCEnRIWlyN2UtaCzlaYNJmhMZ2lkNRZCzH99zpbYdq2l7SwxIKF"
    "hUXfSYXoZnjj0rnZKuT9VZg+9d0r1m8g5jhin8LuQg08Ey2H6EbEMVoO4fawHKKpDAKqG4SnyyGciEO3V7MV7k0OjROQFVrxP64d"
    "0gS0eCPUy2Jj/IZqaRrMZ2PvqIMMnhZ0PTffV35+ztj51hKNza7XJnKBTGmbIheyJJDVBMNghGD4bUswWFyGqOoOEVVNsNd71CFC"
    "69xMbeJ3pwWQdYFAfDcQbSRDpAMEnD+SPztln5yFJRYsLCy2gFxo3g5Hl56cLLM8XTHBIyPIXOgi0APpAC+uT7xSJLJpErN/lL42"
    "Z5/C7sG7S5cWauAzIbGApp7zncwN3R0i+5WBkZ6QC9EyiFik3ZaLpjKI80fyZ/cksaBOuULSJaZfJnXWI1UiYdEWxg2hEP2zmzIy"
    "TQbM9Ma+45REtHNF5+15ww4rar4koEjigQi5kNVkQ6aZYBi308TicsFOyFq4Jzk0QsDtUR2rJAhJCCQg1H5HwV5nSQULSyxYWFhs"
    "H8rg8RLL8xWWqEH1FZddZC5ET/K8FjHHDIlpO+K7C3Xm6TqbnvO8Ws/5TTtWWiCu6wDk3uTQBIGyItIJIiQWmtSx9ySpcK/qd37c"
    "0c5s2IZTd8sgU1Nv0eb8nSBdY+2ELd2COd0hGXD+aI9awknwnI/mNcrd3W9gyxW5IJBCc2mEEf6MEAyf/Vjq6rnfTh0YszPG4nLA"
    "dmctEDBjSv2i2QrxIFsBJlvh9JE92gbYwhILFhYW24DVNsLbls8vlpjHS2BUWDap/3dPLqhUWpNynSZx+6czByftk9g9aACzqhwC"
    "injqQTmELlMY/98Dw7kuA71xpdmAIG27tRuEJham99pz0zW5M6qFYEi6xIJsjsAZtWiTpAFoWBBMdxM4pF4iMr87sMk9s4cSmJEM"
    "TQByU0lEL8gFTwcy2pY3lUbk9M+aYDiehnjwd1JXz3wkeSBnZ4/FbsZ2Zi3cEyGHo9oKphuEzVawsMSChYXFjsMbCk/NF1neUQKj"
    "AnUy3UsxR69ZzPG+T6avG7Ojvjvw7tKlxRrzyRpzQCx002LPEE4uKOui86yFe5JDOQGcMGn+sSbRRkSdrTNH91jbLU0qzBkFcQ9h"
    "CYSnX44Ogy2x0LY9mzFkjKM1PFyT+dG5ysLpXpbovKf03KIPPulDifIqO97LzAXdeUV3F0mCkNatS7OR7IUIwXB7mmjho6kDNuCx"
    "2NXQWQvntzprQWhyOBTeDbtBGG0FTaKfPNKjzCcLC0ssWFhYdI0fK1yYKbI8WWaJKhh15r6IOaaJkCEx+2dWzHHXoAGerek5UWdo"
    "rYXuSCfV/rBzYoGACax6Gm96ee/NbIXfSA5NELAggGNupBwpesrlriyDyNtZvjbuTQ7NCGA42tLUi2R+iM7YmTwDE71fq5hpaE0U"
    "H2HmAvfgsylCLhhNk/gqBEOWRIRgcLJpEnf9Xurq+WlbHmGxS6GzFqYqkEHWgjmA6VfWwm8mhyaM3fEIqgQCqk1wwux3BJutYGGJ"
    "BQsLix1LLkyUmM+UmTW50Hsxx2REzPGP09fl7KjvfPxc6dJsHZw3HSJ8MGS33SGI4AInOi2HEMCE0Q0wp/DmVH4PdIPI/cPgkbGH"
    "B0bGvpg5NP5H6Wunfj919exHkgcWBegBR2WDBKJ75pQrHhmfljKIeTvLV8c9yaGZqHCaPmFsamkqOnCcGJg43IdMmneXLs3Vwafr"
    "YNShCEC/wwBovTVsSBY3UvNtCAbVljLMXtBdJI6lIR78WOrq6ftStjzCYvfhXxafmakwn6/orIUGEIikdroPrpW18JHkgZwATYto"
    "tkKUVNAZU3qfu/vIHsvKs7DEgoWFxS5BAXKsyDJfYRNE9lbM0aiLp4mOZYim7YjvDtSZZ1RbUiXk6PemHAJeB+UQ9yqV7GNO8BnQ"
    "gZ5JVQ9S008evTz7eR8j4EH1os+6oLtc0AmPkDWBb1B6ROqV0oFftCbXlkGsSyiM3JscmhOaVPAiqcjxCEnjdjCODNxxuI9dShqM"
    "CbNOa1pwtdtyiM0TDIQBnb2gMxdMicSdKYi530ldPWpnmcVuQxU8VYVExXRK6jCzc6OshRjRpAfKejAijYpUSEY6+rgq6yyPPagh"
    "ZGGJBQsLi12CnyhcXCxBjpchUWGJGkdal3VJLjgBuaDEHFMkbv9M5uCUHfWdjxp4popQZ6EREfnsZk50Ug5BwORqooReRGNB4PLt"
    "BhGteTeilQktqqdJO6RVjTsGSCCjtE2QoObxsViVUBjXWQpPKtE0QgwqDTlJQtsuRd6EnUc2RS7ccbjPyu0/U3p2oQa+u6qDn7ru"
    "9tMPcmEtgiFJAimTwYCmzAWVvUD0td9LXT1pZ5zFboLJWqiaTklAx/vgWlkLf5K+biQOmjSlRqaULamzFmItgo1HLk/y3OIygmuH"
    "wMJib2O8cHHuc5lD7yHi+xwwBANEais0teudbaJoEnNkFvCBuz6VPjj/k8WLs3bkdy5+oXRp/r+krzlfAw8rckGlWDsE8CZPbQNh"
    "TwIc5hNfHhge+cHl8wub+P3xIFuhRZQwIqR3/kgfT4V3ArngESHGyvGUJOBoYU0nkh1kMhcS2nn1tLbCXsxWeHTwyFiBJZYg8ZL0"
    "scgSRciRCvOIBI8CGCMgG5TrIFRiTxEhrdrmItUinNYmSZNnYPLwFrWDe2fxmalPpQ+OVYmPx5kRI0UQ9zNTxdh3Yw/U+iZ4xPDA"
    "iIE1CSg1CSjv+4PUNaMV8OQvli7Z4MhiV6ACnopDPhAHwQPDZXS8D66WtZBnOdEAZUmzgAmdqWDK2Qw5TGqPm7ZPxGKnwx5kWFhY"
    "4M2FC9OlPos5JoLTVZr5RPq6UTvqOxt1xrRKrwbqXaZYG4dqs+UQ9yaHxgg07GjxPJOx0HyCfHlnK5DuRODq+06RwIA+FTbK/Pt0"
    "CvqATqGNa7KhNbDkvTWFHxREDwrgQQF60CU86AIPxIC7PNAJD6RLSRQRkyKV6WGyPjK6rCRJQs239rMVzjAwdniLe8xXIMfLzGcq"
    "JtOI0VOthfXm6FotKgcibSoHycGA6hwx97upq3PWwlrsBtweaC2ojE6jZdKLrIUExHQSdLvO6AxK2ZJaeLclW2HSPg0LSyxYWFjs"
    "GhRZThaZzxi9hV6JOYqImGNKizmmSMz8iRVz3NnEAni2roOUeqSfd1cijmouTGzi9yYE1AlRUAZBKsgzKf6XezcIcxrsAkjokodB"
    "TSrs023/BslBhoTKVoBATGdzrJZxtFfIheaAF4EgWkKTLylNGqSIAiJhMHjp8dSkghcZz3WQB/CekfzZ0cP5s/Nbfb/vLD6zWGE5"
    "VmE+U23SzMEWkgthi8qmDhIIx3YAzrEBEnP/IXWNtf8WuwIV8FQVWuS6h1oLcaJjSRLIkMqOSmsbbrQVTCca6nGrWgsLSyxYWFj0"
    "HW8rPr1YgpwoQubLbFqYdVerS6uSC4SMqrudsaO+c/Hu0qWFKvOpkFhAVyKOBNWqzwEde2hgZKTN3wnKIEwXCM9kK4Tnx6ePXsYq"
    "2dH1E0MYrOlWrtoZVafEcQpEvjouY7o8xkwRAQ5CQiFlSISIHkVUaDAXaZuY1e9JBqQC1hvP8wDuZmBkZJtTlbUNHytBnjEnrL1s"
    "QdkuwdCkv7Bq9oI4liaa+wNLLljsAkwUn5kpR7IWeqW14Gl7brIVBnRWZ5JEk/AubLaChSUWLCwsdiPeWrg4X2I5UYZEBVKnwHMf"
    "xBwJaRInrJjjzkYDPGvU5k05RKdzISyHAFxgfKP335scmiBQVkSEGk3rv5YyiJnLP1AOT97jFArmJSLK4R4pssXZ46RC4NwQIuKC"
    "KishG5SOONinsz6uIIF9wkGWHC046CBFKhXZoyiJ1YQ8gJMMvGUkf3ZkJH926vAOEVV7S+HiYpF5rAQ+Y8ratpJciNp8oUtImrIX"
    "ApLBOZYhMfefLLlgsQtQBU9Vep61oNZGWpdhpRDJkgrt+Mkj25ABZWFhiQULC4ue4ETh4myR+e4Sc6C30G2tbkguRPQWlHr9XZ9K"
    "Hxy3o75TiQXM1sH5WqRDRLflEPr0fbKN96tsBQq7IcQIOoAOHLT85aqvsDJIQ0AceJGXCXyjpSF7HWbMTE/4dOS0PKfLR3IRcsF0"
    "MkjrLIWEzo5Zh6SZHcmfnTi8Q9OT31y4sHjb8vnRIsuT5W0mF8ycjVOYOZJBQDAcy5CYtjPWYqdjokVroRdZCyqLU+i23CIgNFva"
    "S07Z0bewxIKFhcWuxo8XLkyVWZ4yYo6NHuotuATEddq2Sue2Yo47Fe8uXVqsMc9WdWlMSDJ1Xg7hqHKI4YcHRtZ85vcmh3ICOBEN"
    "DmOR9pImRZSB2aOXf/utPIDTBOSjJEM0PX+TZMLIXiAWSNuaWCTdOJqOP0ChQGPGCKYFtc20bjkJA7efy75ixwfEx5fPTxRZ3lEG"
    "51UwFBIMW03ymIwbI5QZKUm5/RPp68attbXY6ehl1kJ0TZgyUZN5ZoRiAUwfuYzL/CwssWBhYbGHUGCeKOoezlXInqiMN6XHQvc/"
    "J5FNryHmSPb4ddtRB8/WEPbxNic1HessQJdDECbWed8EQHB0HWosUgLhRgK+vVAGAWB+JH92bCR/NjeSP0s+8DofuMMHTvpAJ+Up"
    "w3uBWBBRcoFUFkISIngpkbRQKC0WtHZrL/uDwXc+lj06sQvIhZkCy9Ey+HSNm0ni7SiNcKCeRxKh3kWGxPSfWTFfix2OXmctBP4Q"
    "QkFiB6aNMvK4jEWJLSyxYGFhscfwk8WLi0XI8SJkvtJDlfHVOkWkSRxLk5i1Bmrn4edLl2brwPnmcojOymNa2ieOr0csGD0GT5/i"
    "xIL09OCU/vzR/Nm5y338W8f4aP7s/NH82Zmj+bMTNeZ9deb7zUn0VnUB2E3kgknFd9E8jzzqvJTEjG+DefrvBw+P7vSxGFs+v/C9"
    "S0+OlVi+pwrO1xlbXhoBNAs7xigqRCqGMyQm7ay12OnoVdZCuB8226lIFtrkkcs/G8/CEgsWFhZ7CW8tXJwvMk+WEeot9FrMMR4o"
    "3dPxz2QOTrcaKFs3vv2oc7OIY7fPX7VPpOGvrFIO8ZvJ/SMEOma6QXiALoPQJzphGcTMXhj79cb51UvnFm9cOjdZYb6jymGpiiUX"
    "AABnmh33la8OS0mizyXrAzMPDgzndsOAfP/ywnSR5WgZ8mRracR2aC8oMd+AXLDEgsWORy+zFqLkQsvrzOH82Rk72haWWLCwsLjs"
    "cKJwYabI8v6S1luod8HQr3QuV4g53vmp9MEJ8z4XBKG9flsWsY3EAnjaZCzUddaCRHcpoForYaL13x1g0hAIXou+gtFY2ENlEG2t"
    "s+9aemKmDL67AonqOrX0nQbRuxEj+bOjDByWwGkzV00A3eMg+hh2kcDaLcsLC9+99ORECXxblfl0NHthO9pSRsjl7P8cuH7CWluL"
    "nY4qeKJXWQtr2PxJO8oWlliwsLC4bPFjhQuTJZZnyixVcNlfMcdpI+YYFVIjSy5sG36hdGmhBj4TEgvost1WkH6+IpBwQeOuIRKi"
    "aetk5gGBgNNH94ColQqC2xvh1y89OVVkPl9BtDXo1gr17TQczp9dOJI/O+aDT6rguTcn9NHTRZ39cOd/yxwa301j871LT85919IT"
    "Y2XIO6rM57c622U1cjm5TnmUhcVOwUTxmbkK8+leZS204PThPVDiZ2GJBQsLiz2OInisxBzoLfRSzNFbKeY4+8n0dbkERKT1ElZ2"
    "k7fYMjQYM6ocAkHg2unpb6QcIvuVgZEgmPgPqWvGPMKwS1pfQWcrxE0tPO2tbIXNYon9qQJLlLXYZjfPaDej9X5rzJM15jPVHooX"
    "khYXNSRYHDTz55mDud02Vt+99OTMzUtPjFQ0wRDV6+j3vImSyx4ICRIn/mrg+pxdyRY7HUZroQLZ06wFtu0lLSyxYLHXwMCCrd/d"
    "e/iJwsXFIuRYCRIVVptpL9Jnoz2dE6GY43CaxGxaq7l7kawFi+1BHTxTj6Z/guEzuhKt0uUQAbHgESaashW0yJtRzNYbVp6B2b0a"
    "JK+HNxYuzCyzzBeDNrHcNfl3OYzZTUtPLJbB41VwvgKpSZfOyYXo/PV0m7gkUTYFmtmtYza69OTMTUtPjGi9ji0jGMLuHWrdJyDG"
    "rLW12OnQWQtnqsww7Zh7kbUg7dBaWGLBYg9iwThv3KEDbLE78RYl5nhHKSLmKHso5ugackEJeh1P6dZw8YBcsEKO24V3ly4t1phP"
    "1TjSHQLdl0O4QEAsxCHG47r9X9DXO6Lcr6ml2aNWLXtNFFnOlFiiHJALKzOLHh08clkHb6vNx9cvPblQYDlRZkalB0K0q7XOTZI4"
    "8bldVhLRimNLT2w5wRBorgCIEVliwWJXoAJeVMLWsqvywKjdYutJW1hiwWKvYy+m2u5lvLlwYabE8mS/xBx1SixSpNTCU5ps8AgR"
    "vQVLL2wH6uDZmk6zbzC6am/YWg7xPzLXT8SJsnFd+hDXZTAxWwaxOWIBcq7IjLI+SWvYLhEBfmj5/OxyixBtNxkdK1rngpAimvnM"
    "LiyJWIdgeE+VOd9PgsEQjS4RXGDUzlSL3YCatrFVDkvPurG11pe2sMSCxZ4mE7AHjCABY228Lb/ngheWkyXmM2V9et1rMceYSolF"
    "koKTQMRMr3nLKWwbfq50aaYOztd0xkqvyiE8ovEY0XhCn/wmSCChMxc8CjtBADh/1ApbrYt/VXx2tgKts6DLVvwe6KHsrv1p7Tst"
    "QE4Vmc+XWjI6uulwIhCWRKQgsimImctlLI8tPTFdBo9Ume83JST9aFFpxtEFWWLBYlegrm2seXWzHxrYUgiL3Q7XDoFFtwQDB/9H"
    "YFx+qepttGib32vP/W3Fpxc/nTk47gDzgkVWEAcaCN3MAaFH3CMGsQooDYtvWhDacohtdqaYZ2vg2+s6aI0T62e0uTySoByCAJf5"
    "9gQIPhGE9spiZEQbAZeCLJUZ+wQ2RoX5dBzyeBWEBBgxYnh21QAA3lq4uPjnmYMTxOJBBwynS9sVEqKMGBMkAXXQif+WOTT+44UL"
    "s/24h3uSQ9OkT/ZX2Z+mfrX8wlwvv+/1S08uApj8u8HDMx5jxgMdcyPj1os2phQSNVk7Sy12Axo6e68GoEFhJx4OZnQH/rRNWbDY"
    "5bAZCxYdGT9EAr4e2cGR3UIwWPdc4Z8VLi4UWY6XIZUyMveylZvOXKDmloOO/jf7DLaRWABP1yKn4d2IVkVPe2NESEIEGSpJCPXc"
    "I9oatgyi7Wc0X408o0ZLCjsBub08Pj9RuDhXgjxVhkS1xXah43kcCo4miZAimv5sH0oi7kkOTRJwpwCOO6DjDui4CzrugY7H1Gus"
    "X+P2PUtPzn/X0hOjZci7q9wbjZ1m269K3f5+8PCIXcUWOx0qEwwqi4cBn7nrbF7LK1jsdtiMBYtOsLAawXA5Egutp0I2oG3GeOHi"
    "3Ocyh+4W4LsEMYgBorAtJHU25hBAkAGjfuaAULDPYXvx86VL8/8lfc35Gni4DqWz4DPDoc1nLYTPm+Dp/3C0MfFWdgM5dTR/dsE+"
    "gY3RAC80FMEA84wkA6wG8gyAuTaD2DECHkTLuiNV/jX2gfIL87t1jIosJ1zQggPOusQQrMqspCay0Ok8JiDOAg1guK5ax032eE+6"
    "LxCOBHTLS/XfGmP9HrvvXnpy6m8GRmbjRHMeU9YjaFtNXdlngnoGDtOI8TMsLHYyJJozFaxOgsVeh81YsNg0TLvJPWJAs83EAjUF"
    "uBrze3k+vLlwYarE8lS5R4JoUXLBvJzIqbUlFXZA4MqYqbeIVnViD6LZKZ4WbUzoFqNx3XbSDYmqWTvy7cEHZhvMd9eY767rVwN8"
    "tw++m4Gx1yw9sdjm8xk1OhiOFtHUgprZGGjut5L7R3brGP2L4jOLJdMlwnQ64c73teYWlEBCtaC8879lDvU00Df2MKY1HdIQSJPA"
    "AAlkSWCQxPGtGL/vX16YLzKPVcD5Kjd3H+lGDJOsY2qxa3xhXtHJwZIKFnsdNmPBogemNVIb1nnUd3yn3dlvJIdGjZMT/TMa3Op7"
    "X9zrs6DIPOGA5xzwMUGAYFVz3G3ZgiURdiZq4Jka+K6mVHumjoQ1ja6Gqdl29LG6oDDFnID8kfzZGTvy7eE9pecWoE7LuwIBoyJC"
    "KrgUknwAslJlmi3s1nF6e/Hp2c9kDp72gOMuBFxwV+VWoUaMyhBJEqEBmvlM5uDoWwsXe7JPECjvANmYac1LYTteByo1+9OZg2P/"
    "rHBxrt/jd+vywvzcwPBYEvS1BAkwa32cDlsDW2LBYvd6wpZUsLCAtd8WHWKe10j76uak4szgkdxOukkCRsLsBFovzXN+r0+Inyxe"
    "XCxCThQh8+b0r9vWSxY7F+8uXVqogc+ExIKqM+2k7WgYTJDuEKFeTkgqADZbYbts4KghFXTHAwyoU/HgtdtRYjlRYs6HHW562YJS"
    "IAkxnIKY6qHTNu9qLYcUCWRIYBAqWyEXZi2Mb9X4jS2fny/AtPCUqHP0JNfCwsLCwhILFhbr4P3l5xdN+lc0cOzGETNO7A671bHQ"
    "UWzOVmjJWli0swJ4a+HifInlRFm3IuyVmKPFzkSdebquSyEaXfbwDktfqOUViDZO2xHfWtybHMoR6FhAKhBhUAeu+8jBFeQgR86u"
    "v89/UXxmocxyqqxLewJNCvS2JOJzPSqJ0C0Z4RGMSCQyuhQi+BNibCvHcJnldAESZeaAXOiyHG7BrkALCwsLSyxY7BEwcFpy96RC"
    "izM2trPuksaIwpNUQepFzeOAG/Ln5uyMUDhRuDhbZHN6pcgF7lJvwWJnogHMqu4Q6LqHN2GlrkYklfr80fzZeTviW2z9gDEBwCEg"
    "DtWxI62zFLIkkCUHA3R5uBBvKz49XYY8XYbUWgvdZS2ouUswmQWqZIFmPtODLhFmrXhagyTQJQEhSUL/ScceHhgZ2arxGy9cXCiw"
    "PF2ERIXDTjGd6a4Qblp6whILFhYWFpZYsNhDxMICQ9WRyoiATSeuWCSoGN0p93dvcmiEgGNBkKNbHYpIaYQeh/N2NjTjxwoXJkss"
    "T4dijghakllcPnh36dJijflUzQjfwQRjvSWSbLbCthEL4w7M6XjQQhEpTTCk9Un55YIS82SJGcZuNbo8dY9qU8RVK9XhJGiqF8SC"
    "Id1c/XzMMzJtW/WfE1s5fgWWc0VmlMEBOWNJZQsLCwtLLFhYtOPszzPCgFH2xoE4sZOc6qAjQaSdl4iQChpz23SJuZ08PwrM40Xm"
    "89WI2rq0TuZlh4YScUSdFYHUQO91NdjqK2yjDdS6F6YLAYQ+HRdIQCB+Gcmr/vPi0/MllneHJRHck5IIl6CyFoiQJNGzkohoS9/m"
    "l8qUcIAtJRYqzAsllqiwbBo/3vR659N29VlYWFhYYsFiLxELjHlDKvise6SHgUBHTpIA4e8GD4/vEKd6sqlXOAy50FwOweDtIhaO"
    "7eT58ZPFi4slyHGVGiu7dtItdiZ+rnRptg7O12AEOzsvh1iDVDh1NH92wY701uLe5NA4gbKCdMYCoE7EdVtQj1TAfLm1lXpb8emp"
    "MuSZSo9O3aOBfgyEZA9LItZqcRdp0Tv8lYGRLdtPK+CFKiIZCwD8zsbPrncLCwsLSyxY7CX8cvm5OQlocT6TtdCdgKNuL7ftxMK9"
    "yaEJAg0bUsGFaeVFQas1Cu91bruvd41OFYBqBbdteEvh4nyR+Y4SGJVI3bIlFy4v1JlnamyyFrjj7hBrEAuzu2w4RlZbn11idBts"
    "yqQKTgGXVJq9SbkXXTeR3dkoM0+WWKLMUneJ6DzbKqob4vW4JGKj79XPbnLL7ACUkGvNZHxwZxkLO2FPtbCwsLCwxILFFkMCpyQQ"
    "tJrrNmhUzhDdvpWiU624JzmUI2BKQJ3IedqpVid0K3pzn3lF/tzC9pIKtF4AM7zdc+RE4cJMkeXJshVzvHyJBfBMVZ9S1o2Io7IP"
    "3SJ/JH92ZjeNBUWIBQJ6FYBnt/Ie7k0OjQnguNFXcGGEApsztugyJRh+qvj0XIn5flMS0eiSODftJ/tRErGaOKJ5NooIx/H/NTA8"
    "thXjJpnH6hEbYMZsM+O2U8h6CwsLCwtLLFhsObHAs74mFUxtteTu2s056jW1jYHBtACGjVMd0y8vUhJh3GkGtiXo+c3k0CgFIpIr"
    "yYWoq/8Pg0dGtnue/FjhwkSJ+YxqRWbFHDfA2G674J8vXZqvg8/Xuk+Bbg0yZnfjAyQA1ON4++tbuI4JmCIQHCMCGNg/9XKAyzhf"
    "QaECOVUGn4+2zu1DScR0P+egQ0HniOmtGDMJ5Fj7AcYvkJsfsfPbTdZbWGwzRuwQWFhiwWKPEguYbXAozKdOKbvpDKHSbD2i2x/c"
    "olOWKO5JDk0QcLu+hoBUiEcca6dJX2F7iAWz8dAqr5VjujM6bRQgx4os8xU2tfi7Xswxt9oc3quoM6ZVGjSaUqC5O/syvQuHYrR1"
    "PnQ7L/Tvb4k9vDc5NEk6W8HTdjBOqtNAjNQpeJ/m+o5ypt9ZfGaxzHIiKkTY6H1JxLEvZg5N9YtYMOUQMaJjDw4MT/Z7zBgY42Dd"
    "c7D+mTeVsTC7W+2/3bcsLLFgYWGJBYsuMFl6blECJxv6FFrV0HceUBidBUcF9LNfyBzasqD4nuTQlAAeEJpE8ExvcBKIa+faiThs"
    "DJw8mj+7uD0jT6MA0Jy10OwgRIKasZ0wV36ioMQcy1rMscbd63JsJ6glgOxhSviudCrq4Nl6azlEFyKODJw5mj87vwvnRc6kvlMP"
    "yAUKN+qJLbCBowTcJ/TJuqdJVfNyQFoHpy+hyHCvg51HB490tX+8o/j0XAl8qoSQXDA2q9NnaUoivLAk4q7P9WGfC8ohtDZGDDT1"
    "xcyhvtmWX08OjSAiKEydr/vpfgdpPZq9o9iF6Ne+9ejgkd1KtHSL4334zL06lhaWWLCwAOrgqUZTbTV3VYuqShCAGFE2TjT36czB"
    "vm7g9ySHcvckh2YFcJfQdcQxoqClWlI71a52ts1GzNtYrgFgnCg8ARMEiDVyr2kHiGEGF124OFdgfk8pkl68i8UcR/qR8r5bHdZ3"
    "ly4tVJlPh8QCuhJx3MZsoK4dTWMlzPrsUebC8a8Ojoz1mVSYE8b+6lP1RCRjwdX2uddT/jeSQ6N9CPxWDSo3ixLLiTJzvtzSJaIb"
    "coEiGXFJEJJEM5/uQZeI1Zw7s5/G1X46+9k+fI++rylCmJlBWuRYaBtJ7a35073uANMnzZNda6ehiU+7b/XEbuVWrm07lhYWlliw"
    "6DqgqINP1qMBhQ4YNxtQREWnPAAJiGwSNPen6esm+0QoTBGw4AAnDKkQJ0IChDQE0kRIasfaizhKAE4e2aYWePcmh0YIOGYCFhER"
    "lFzNcSJg+G93SAtPAHhz4cJ06fIQcxxtDYR6kfJOwLG/Hzyc2422oAHVHaIWUYTvlDTajcTCb6jgvCm4CtYldTMvVImYA5p+cGC4"
    "53ND28GvCSDrQJEIcRP0QiABoUrBqD9yjQSMhWRM+A09cNS7tnthSYQScqzpkoiusvLQXBKRgjiW6oMOQlTXwQMhAXEsAZrpw/wZ"
    "VSWE0VaX4bOk9tf8VB+W5RhtgtzYBLLzg4d3YwA41ut9a68Gw9Q0luuKaG/2c4/vVh/AwsISCxY9QZ0xVWPO96K+moAgVTSuUkWz"
    "KRL3/VH62oWPp66euC91oCuDe09yaPSe5NCMJhTucoCsq7MSEiSQhECGBNIkkNSvuE5f1SnAeQYmt2usCZgJnDd9iigC0oNWDUgE"
    "MD3Xh4CkUxRZThaZzxi9hd0m5vjrmtyhyNj3jFxQmSiTu9EONIDZOjgfijh2Vg7BwKntKzPqChPRsqTW4KqbuaFb8R5zgbledBPQ"
    "xOrkvcmhBaHsYGBzExBIadtnMhb6la2gZ/0kWtZShMTtpoxk/G974KC/vfj0bAnydFmXRDTAXenDrFYSkSBx+6nMoZ4H/S1ZC0iQ"
    "OHEqc2juD9PX9mQ/0F2UZgkEocsuvIjIpwO0dlJac80fyZ+d67GdzhFwvLVUsEcEMAg0sZuMUz/3LWxBqdYOxHhTZk5LaWrHc4t2"
    "VqaphcVm4dohsOgWP1t6duG/pq+dqoLvM6nQLhOIeNMnXOEpCxBjIAmCTwSGGGbgAWJ+4P7UgdN15rkGMC+BxQ+Un59bi0SAqlcb"
    "I2BUnYwha87DgnZq2sFLkkAKhLQmFtL65E61mQzuY+rINgQ92oGbNm3gHN2lwrSDWy3l1GxSDtOwVgbfEZv/24pPL346c3DcAeaJ"
    "RVYQB+PL2PliUibtV+g5FP7Z3clYeNpNkw8PjMzesrwwv5vswLtLlxb/IHXNbBV8e51U1kKcjIjbpk4uZ3abDdSnthMiYlecJqez"
    "u0BGBGudjsVBD34yfd3pPMuZEuTcnaXnFtq4vhGotPAxbQePh4K5QfmZJhUIGf1Kmq4QfcpW0GKRwyJS2uWsU9rV/pgRlK3nnti9"
    "EssJDzTvEmc9MASbtd7ZmIQlEaqTUhKEBtHtn84cxD8rXJzooa1a7XuONyDmZtLXTkwUn5nvcs7PmC5KHkKRz5hu09zmyVW/yPpJ"
    "oIlgb9JJ6sGavPMrAyMzP7BL7DQB01FSIUoudLdvEQh87G8HD0++funJ6b3g896bHBoD6HaicBwdQs90dQRo+qGBkdlblxcWYWGx"
    "y0DMe7ujPJHVxO0VPpm+bjZLzomsDszj+gRjs2kxSiBLnWRXIVFmRgESRZYoMiNIo9cnotE6fbmBcx6chlEYmMfC7AikDcGgnWwj"
    "2qgD31OH82fHt5pQgDoJnVQOnDrhSkMgSwJZcpAllWVhxjvStQI+GBVmFFkiz/LMIvuTbys+PbcT5sts5uD4IInPZkggBRGozm8m"
    "EJMA6uC7X5U/N7UFz2KEgGkHOBGHQJIIgyRwBTnIkYOMPuHtZM6v8rzyiyynF9mfeXvx6TUDx27td6/t3++lrh4fJPHZfS1j4rU/"
    "JvmR/NncLiMVJgQw7YCyycjavEI4GCSBNMK1iS7mRY0ZFTCWWOqXjxIzypCoMZ/xgUUZ/EaQKTICYJiawoCIPkuEWNWdCpAmTa7q"
    "zAWTseW0BNE+gBrzba9eOjfXwZiNa5t23JC6GRLIkUBO27RkYBM2Dx8qe64MiWWWp19mOX2icGG2y/1tcpCc+7KkxiW61qmL59pg"
    "oAK1ty2r53p6GXLiXxefXXXdfzi5fy5F4nir7Um22P/W7zH7aeR7UIC8v8Q8/e7SpYVNPr9JAqZM+Uxcz/sB/QwHW+yhs/44vOdw"
    "/ux0j+30lAPcHtNza5AE9pGDfZ3ZpFXHs8qMIiTyLO9+Wfozb1vHTm+zfRonYNIBjvdj39J2AGVILLE8ucj+9Hjh4jwuQ2iCdkIA"
    "d5lso4y2Wfv0vE/BaNJQR3OroX2AAst8nuXkIvuz7yg+bQmGPvg/FpZYsMTCDscfpq/NDZIzlyVxbJAEEtrAih6RC2U0EwsmLbWB"
    "ZnLBtLhSzzd6EhyyyyZTQbWTFJpYUCd0Ce1Mx5pJhTMMjPU7W+Ge5NAY1IliTv95LNSeADx9jRm9iWW105RA2A6OVnEotYONvHIo"
    "zxdYzpXAC6Z05QPl56e2Y878t8yhqQESdw203IPYxDzpJbGgx9+QUTmo2tERfco7THruGEd6kAT2CQeDUGRaouUZbBYNHUCWdQCZ"
    "Zx95lmeWWc5VmRdq4HnTG/5Xyy/M7TRiAQAeSF+7kCMxnCMVWKcg4K0SmK7hWN1/OH92cgc7lSNQAmgt88KUUxEGKCT9BrsMkKPO"
    "e0PbvBJLFCBRYPUqc6T0JGL7osn6gW4BtZAKkfmc0EFHStX9qzII/exWs+EbEQv3JodyHJwaBzXJOdLdA4xNi+nvM+OWI0fr24gN"
    "g9L17EKjmVTFIvtYZnm6CLlQY15oqDGa/9XyC20TDp/NHJzLkjg+EAkgnA4Dsug+Z0ijAis7vcwyX2A5UwZP/2JL0L9ZYiH6PVVW"
    "wrlFPXeW9VwqM5+qgmfrzHPvLz+/sI5tHCf1GlYZAKQzXcyepPalAdLCxxvv/ydH8mcnOliLo9Dq+ZF2rCM6M/EY6WuL2mlDWKUj"
    "gTR1sR4jwXRgpwss58rMizXwXKTl5vwHyy8s9tEumX0KegyiNirITHIBJPRa6+W+pfdgEwxjUY1FfpnlXAlyvsa86IPnI+WxCx8s"
    "v7AjSRhDFOtxRHR+UYSkNd3DUppYyJKDHAk97wW8Du19lLRSPoCPRUUknymwnK+wXKgjaOc6/at9nFeWWLDoFLYUwqJneGfxmcVP"
    "pK8bi4PmYuBjggDBKg1zsynuYQonAyxAxDrFmBEDKWLBZC1ERCMDYoGin9PcyjLao91kK5iWajH9d24LqYAtIBX09T4YFWJ0IkGA"
    "R4A5cUhTc8cKZ5VU5SBdnxgea0E2IjQghiVwO1iiSkBD2eZtIRZ+vHBh6guZQ6MOcIJIQOgSGnThrPdu/MOQzJxKOvo5JHTglSAR"
    "pIo7EdG5zr+f4BDgMKtAFQI18DGf6Jj5bMlBZs6OZEXrzLM18J2mLMonbvv0Ru7QMgjTNcGUUpknHRWqiwfdZDRZqdem6IFwnPke"
    "c0rGLAAd8MegiNYaGJIBP1J+0mxPwzaYDgWlFRFtBVPvT4FgoyEVNnv9/y65P9cAz4XEaFh2ERW3NDYtpYndBKm/axHL7WQdh2MW"
    "EaOsg45LFscFSa3tAnwouf+O95efb2velZgnPfDXXEg4EXvVbUmES0CcAUnCEORZAHcS5J0fS119vsq80ADPvL/8/Ewo2Nv+d5rv"
    "iel6MyYR0E7EBIfkCZf5RJUkPpI8AB98RgYZMDgeKqVQc2mOtoUpvSelDEHcntjnGdlhCQSptpTHxRp2WujnHtrpsDyjV1ohggCX"
    "je8gkAAf80kcY0gI4C6fDaGD2wDM9dE8jbb6Dc0isqH/kITRTlm5b6HLteYCem8kVEHZBugEM50gAnym6OHP3djerlob3c9EtFQs"
    "Oo6hT6UOpYwOVzDnu7T3Ub/PBZt5hTpI+wACQtt5CYx/KLl/7P3l5/c0uWBhiQWLyxxvLz69+JnMwTEXmHNYHHNIubebTRk1xpw1"
    "uUBMcCDgEiOmneiaruM2re0aBEheKapluieYAMDT1+OR+jlKMjgRoUbt1J4BMHZ4i3QVQofYEAahjkJMnyCaE0VTbuJFCIi1N30V"
    "PPisHFfok0uXGXXaXta3yDzhgOcd8LAgCWL1nPtR093u+BNCYUyHQnInGtyl9SlhcwDZvZMW1isrJ60BATDgkM7SIXUyvVNRB89E"
    "iYUGGB4IUt/bWmDgzNH82fkd6mxOC00qmHngkBGoo6C+PAXSwodhxlMvApkwOFBEKyLrJK6JVkOyht04mjMWWssfTPcdY/tiEWLV"
    "ayZWO7n+0ahQXOt4BTaOgLgesxR0dgeoIzJjrYDdY72OdDAtwHABNAAtxIgH0Cah9c+LT89/Mn3d3R7oLg8MN6IP00lJBAV2m8AE"
    "JHTQH/ybWvfDLuRwTQenMURLxtobp+j3eIGYjdB/r8bDA8MDdPYLHfObMmDCb3EiBL3JdEmbPQlhmYGDdbUMusoAbAryzJyicO80"
    "XTdUBo7Q3U3WJuE7JfrMGKRAik5gCUGiyU77fe55FN2zAsHMyPoVgb8TkkCpVfYt6oV90mR4Hepwh6BIcjUWtCtEmqPZrVG7FZCy"
    "ejwNAZvW8yzMcO1ev8MhqMMgTQb5eoN0SGU3NYghgWM+eHInkzQWlliwsOgJ3lq4uPi5zKExh3hGgE8Qm3ZrmycXEDjCyoFzWDnX"
    "Me30NKIpwAAkrdy4Wjdek15rshI87ci61HyqZ8ofDm+hWGOUVDCZFObELWgDp2uhE4G45NoBLUXGL8akMzlESDZokmY78ZPFi4uf"
    "UWKOc0KLOVIXznq3428cJE+TOl6E4Alaoerg0dTPRx3pbp2a5hNMNQrqOiRMx4WdTCz8QunS/H9OX3OmDj5mWtA2mOHQ+iKOO1m0"
    "MZpO7JrgO5LKb4iFZHCK1Xxq28trMOSC0HYwJBWgHM6gHWIzsWCytlrLIFyKCsGuagc7vlZjb8NMsIj91d9tSkhSkaDU7TBTYnWS"
    "DkGWB5E5CaSA9Gps8nPfVnx6ajZzcDwGOuaB4TA2nNvtkckAiMAMEInIXiDhgVDVO1u0TI86+B5AP2D9Pa4mFGJ6XKJdXSQDksK5"
    "FIh9alI+rp9Zc/lMuCetRyp0s6+GgawixlbaaV3mSCERH9fX3KuMBWOnmYFkQFqFGURR27cVtsmJkITRte0gPEhJGLKlhQASXX5/"
    "q4/BIAgWen1L1KFKcUxm6c4nFkKb7rWMZbQ1eZhtJdrN0tnEeCoB8xQIIKEOl/TarEf8XwsLSyxY7Am8uXBhEcD43MDwFJG4C4wg"
    "UNssudCUkkasgjsmdTpHtEK8sTVngVZJZzfOhRM4aCtaBd0/sg213hQhFVKaQDCn4iaAjUV+9iI1rLTRRhk4k4DDAnFSWR/VHbDR"
    "v7Vwcf5U5tCkQ/yAE1FdRxfiaJ2OvxepG05ETnBN5khQQqOfQ2xjR3qTTmKYtQCEAaRx+k1AtJPRYMyoLjGq/jZGFJQp7UZiYUVa"
    "fUSHRa1JBMRfkGa88altRwGoyeISILisrkmfvMOP2MI15xY1Zy+YE1+nB4RCa1DvBsK4oRiuBxPgheRdvCVbQvRsLa1u95Jg1CPE"
    "9GZRZp70IB90gaAkwuuyJELoaD9GBMGAiAT9cTDK+pPTJEaFnm+tSvQRnARw+3rkAhFAbNoWq4A4YbIB9dj4LSRmtCwvSn4nIlkv"
    "G+xJpxiY6Jasp4gtTup5FW+10xEyPh7p8NRrOw1StZ6CBLyInTZzq7YlgXC4jpI64I3prDdzUOHp9P3YKvtWz4LxSDaMA1YHF0Ro"
    "RDJL6zvcd6VIhqghYmIRQUYnINaafQCPuivfWm1uxTSp4OgS4ESE9GvovdXCwhILFnsKY8vnp+YGhmeZxAwzjoHQUYqtMbSsHRYm"
    "NXkVmaBOedTPq4cuQY0vRZ2r8AQG4W+d147P3HYFMCY9OK3LHUyHiljLyaJD2JBUWM2ZFExBSUljB230JwoXZv575tCoAO4UJECs"
    "Tlh5C0siTNuouBYjS1Eo7ulGSKnoKZnb5nPYrJNmykEEIxAaNdk5tR3uUNTBM/VI+9kGGD6r9bcGqXDq6Da0cd3MUzEdZFK6Y4LR"
    "BIgF80A7pCs1WnoaRESJVkfr15gaZoY5MWwmF2jFK0wdJ/SmB/tq12lqrjO6tjsZGS9z8u2gOVuiV2upNf1faQkYuxeUQXS0ln6q"
    "+PTcp9IH7/fAd5qSCKfLLKtoaQPpAE0Q4MFBHBIxfZ0ZElnWzpspAVhlPU0BmGFgFkqvoemazLjE9H6sCCqBuB6XYM3qNpXcREyF"
    "5T9RotWNBKprjMF7RnrU/UFogswE0kZzyBB9bouddoO51js7HRasKNaKGPqEPjxRrm9BRmAQhFLYMSoV6XwRXWtuH9eaObSBJqzM"
    "WJg9y2hhbXfpZbtzK7D1mryKUUiIGg0Pp2lu9c7et/oADod+obFb9R2QbWphYYkFi+0iF+YBjP7NwMiEhJiOgbLmdGezm1rU8TXi"
    "ZFGxRl7z95qF9VZxoPMApkfyZ6e2fVMzJ+YtKaaeTsXv5GSx2clWTrCrg5HaDtrof6xwYfKLSszxuIicBG6VmKM5+QnHXwRptIHm"
    "gv5TEIJsl15mVURLgKJCez4zJNGuSIF8d+nS4n9KXXOqCj5RIw5OP12sThTt5GwFaMc9EOwCqZpyHcx4kZOsXp/8t0O0MqCDSwqy"
    "tXiNORW1h73oub6+nQ6zrxIkkImcLkcz15wmkqP3a6nV7plsN0kUOOidoAI5FQONe+BhV2dZdUuERq9XEFTpHxguCTg6syxFBF9/"
    "l7tKMMPA+cP5swsAFs5mj46wEjq8nSLP3pyscqRExnyXTxTR6uAmkiqa8eJEdGg2KJ85rcn6hV7OL0NqJKBsdKola0FEgsR+2Oko"
    "uRDaacBnlSZvgulq3201BaVNRlAwHVlrTnQsImut1/ZJBPMk3Bs97WP4FHbuqvIuIBagA/lIC96ELkdYyweIHlj12gcw61NG7Jbp"
    "IGVhsRPXkIXFluD7lxdmSixHypB3VJnPR1MtOzGPUeVjI1oUsPEtr0DUCCtOlM4DuJuBke0mFfRGko8qwMeDNE+dRqwdBadDUsZB"
    "mBoZo6DNXH4nzZMieLzEnK+YNnocOrj9BgFnjMJ1DFFNC9Jq2roMJaK50I9SDUJrW8Dweam0cjqz09d7HTxbhxZYZUREBVcgfyR/"
    "dnYn3wsBi47ORDCkk5kTQW15l+uzm3mysf1baQ8Fus5QyDN4YfXrogVByAd6MUY5v6X7hBkzc41On9ZS1O55FOngoZ5jR2vpncVn"
    "FsssJyosUWV9yt8DWxUVj/OoqRXoAgAkQPfHImO2yjybMz+8In9u8ZX5cxM15tuqzKfr3FwuExULjo5LEgIpnTWXoeZXEhGNH20L"
    "15jzpxm4bSR/dqyXpIJ2XBdDu6gDQN2VItXSCcIF9TSjbDUnutVOJ0I7nU/o59ZP20T6GZhSh0RkrSXXWGv93Lei5RdBK2/dPSFF"
    "YnGH2/p50doxR1+7ybqK+gACvSmBWM8HMOsz1mS3BJIk5m1kYbHTYDMWLLYUP7C8sAh1OjlzZvDIuAuMu4RxB8j2Oh13A5wCMDOy"
    "8wKaMQJmBWhYb1h5FzRvVNyj6MJ5PW7GmEFnXOKxnTQAP1G4uPjZzMExB/iaqTXeKjFHAo0RMCdAx8J0X4JHlHdA82vNzT6RHiPQ"
    "fbOj+TYMnAFhbKev9Z8rXZqZSV87XQVna5FyCIdWjN3MTr8X3YJszgGORQNUXQpzXoAWaGvmRMfY4HpyAI6h/fWVZ/DYa5aeWDVo"
    "+uXycwvTqQNjQo1ZVp/mnvFAi+u1ZuU+rSFgzWy3M9TFWnpH8em5T2cOnnIhT7gs4BDnhbYTXQQaOUTadGpNjTtenX9yBgB+cPn8"
    "5P8aGIYERs2YtbzmWj/wpqUn5gCMfW3w8JjLNOEBt0d1YVpbqHJLBswqdnKtjJc8gFkGZvpcTjgBYE4Ax0Ih0qDD0+m1MnH6tCab"
    "npf5XwHkiTD2mvwTfSUW/m35+fn7UgfuIOABgjppN6VzsWa9ktMUGYc+2qccgGOiec8yWV8nX5M/N72Tbf37ys9Pfix1dU4At4eE"
    "LU4bUnaL55b5rhwBx2Ay1AAI4jtenX9iFhYWO81f4j2eSkNEdhbsADw6eGTMAY05hDHVQ7jnJMMZAHPa6Zo7vKPruS0A4HOZQxMD"
    "JB4YiNTPtp48SeBMjXnsxqVze/J5dmu/+23//iB1zUyWxO05cpDVJ54mPdd8sw8cPtrjE81+4GOpq3ODJEZz5Cy8uXBhYS+vzbPZ"
    "oyOvyJ/b02OwhWOde0W+t/bta4OHcx5ozAWNO2Rag67QG9r03np4h2ceXc74g9Q1I+8qPbtgbYaF9X8sLLFgiQWLFnxr8OiIIIwI"
    "qNMkAo1CsbbtOD7zABZZ/3lkm4QYLbrH5zOHpgdIjGYiKvyR2tBFHzzRa6fbEgu9w++lrh4bJDGVIwc5TSwkIAIFbQYWjuTPTtiZ"
    "bmGx7XvumCDkhM6EiCg3jBDQGhDOM7B41O6tNjCysLCwsMSChYWFhYWFhYWFhYWFhYVFL2DFGy0sLCwsLCwsLCwsLCwsLDqGJRYs"
    "LCwsLCwsLCwsLCwsLCw6hiUWLCwsLCwsLCwsLCwsLCwsOoYlFiwsLCwsLCwsLCwsLCwsLDqGJRYsLCwsLCwsLCwsLCwsLCw6hiUW"
    "LCwsLCwsLCwsLCwsLCwsOoYlFiwsLCwsLCwsLCwsLCwsLDqGJRYsLCwsLCwsLCwsLCwsLCw6hiUWLCwsLCwsLCwsLCwsLCwsOoYl"
    "FiwsLCwsLCwsLCwsLCwsLDqGJRYsLCwsLCwsLCwsLCwsLCw6hiUWLCwsLCwsLCwsLCwsLCwsOoYlFiwsLCwsLCwsLCwsLCwsLDqG"
    "JRYsLCwsLCwsLCwsLCwsLCw6hiUWLCwsLCwsLCwsLCwsLCwsOoZrh8CiG8z9/o0AAFrvTdT0owMgA2AIwPX6dR2AKwGkAaQApAlI"
    "6t/z2/hYrHURG10XtXPZxO19f+QvaYNxI9r8PVE390G9+a62rrvta+aeXC91M87U3jPdmvHlNa93vTHu6rrXGcCu5veab+K21i61"
    "YXuojTdRmwaB2jV4wZgyNvErHX9p29e1LnhTz31rwdjkcLZxh+38Anf/Wdzu7618I3d/mZGPW38MuZPr5hWfvup7uMNrX+uaeTPX"
    "ueIjuK3v5zVumtf4Ya1r4k2MB/Ma17iJMVj7+7jtsW//+7jD+9vo+3iNsW7n+bbznbzm813rezf/3bzx3O/gGtZ4kq1jRFAHwgyg"
    "CKAEoArGEoDvMHABwAKAZwG8AKCw4glE/uu2yRdtEGNhiQWLXQ8BIA5gAMAVAPZrYuEqTTik9b8ltevr2yGzsLCwsLCwsLDY43AA"
    "SE0aFAGUAeS1X10FsARgWf+dsD60xVbDEgsWWwkCcBTA6wC8Rv98CMA+qEyFGAAv8idpA2phYWFhYWFhYWGxlyG0X1yPvKpQ2Qs3"
    "AzgP4AkAjwA4o39mO2wWWwVLLFhsFaFwJYBXAfghALfqn/cDSGhDKSLvjf5pYWFhYWFhYWFhYRGCEZIGEkADwHcBeA7AowAOA/gK"
    "gG8AWLTDZbEVsMSCRb/hAbgBwHEAYwBeC+AaAFk7NBYWFhYWFhYWFhabBiE8hBM6pktAZQHvB/BqAN8D4C8A/G8AZ2GzFyz6DEss"
    "WPTT4F0JxZ7+MIB/on+O26GxsLCwsLCwsLCw6Jv/fSVU1sIwgAMA/icUubBoh8iiX7DEgkW/jNo1UITCj0MxpgehtBMsLCwsLCws"
    "LCwsLPqLlPbBcwCOAPgcgNNQAo82e8Gi5xB2CCx6DAeqheQ/AfBTAN6kjZklFSwsLCwsLCwsLCy2DnEowfRxAG8D8I8BXP3g9JU2"
    "BrToOeyksuj1fLoewI8BeCeA74dqH2lhYWFhYWFhYWFhsT3YB6V39i+hyIX9D05faYXSLXoKWwph0UscAvBGAP8MwPcCyNghsbCw"
    "sLCwsLCwsNhWONpPzyA8WP4fAL5jh8aiV7DEgkWvkAPwgwDeCkUqXD6ZCkT6j+YEHwIAZjBYV6qtVq5G+v8p+JzIR4JZmh/6ds0U"
    "XGw717tXQFpPmfSz0X/LUOMTjFE4dgShfo6+px/PbieMCwhEzQcZzGwGKDIupN/b8j5wpGFs9LNYD1d0jHmL17K5ZhGuk+DBcmRd"
    "ctPfXW72DLRawqLcQXOamuZYMzY5fygqnB7OXWr5xPB5b9P8bL1Wil7cNl6TxTavV21D9ZolEpGpIPWeznp/X2cNR+1dxGiHfkif"
    "51br9/MWf7+FQRaqSxsBeOHB6SsfvG3yxbodFgtLLFjsFCQBvB7AGwC8DpdNpoLZzAkkHAjHBQkndHJZgqUPlg31ZxCMhJsokVAv"
    "4QQvta0ymH2w9CFlQzkELHvg0IcOCDkuiASEcHRArL6D/QaYfaAn37c7HTUVVDogx1E/CwdgBplnylKNj3725jkqZ0iCmcGyAbCv"
    "gzG+jMZFgEjPdRN8sgRJHwxfjRMA6HEBOdphZEBKgH2QWQtEIOGqzyGhf1cCsgFIXzvBfR4/ihAJwgGEq6/JCe6RQNoxl2D2QbIB"
    "5gYgG+FcYN7dz5lIB6sCRA7guM3kAkt9v2ZOb6N90Neqno+rnls0ypY+wMrurnudrfcsjA0XmrgwpIVa++r5S7222/j8npMo5p7V"
    "y1Afag76es34NgC7/DcpPT31PiVckOMpmytcfchBIbEQ9UNkHdJvBHM5XArNtt0clEgpwZG5zj33C8J7IbMfmL2FEaw3s+/yXvVL"
    "thZCkwv/CMACgO88OH3lP9w2+WLDDo2FJRYsthsOgNcCOAFVu7Xv8ok/NaHguhBeHI6XgHDjyvFjBmQDfr0Kv16BbFQh/UYQeJlA"
    "hoQL4cbguHE4XjII9gEfslGHXy+DGlXIhiaL2e/JNZPjBdcrHA8khCIxGjXIRgWyUQP79cj17i1SgYQHcmMQXgLC0c8UAMs6uFFT"
    "f0pfvdf1wvcQAVJC+lXIRhXcqKpgbNePowm8PQgnBnLNuLh6XBpgvwqWNRV4Q4AcD+TEQMLTTqIE+zWwr8YEYD0XYyAnDghXO8EN"
    "wK+CGxXAr6kAnvtBLmhSkBzlkOvrIDeu/nTigPCCZ6+87IZ69n5NX19V33ddXfeuDuoMwanHwUsAIgYiUlkmMrxnyJp6JPC3ZY2G"
    "wVQccBIgJ9EyFyuAr59P8Fx4zXuGuWdXfRaECyJDeCEklcyz9yuRsWiA0ejj+o7OUy+cnyIGhgDA4TX5NZBf09djnY/Le49yQULv"
    "PV4Cwk2A3Liyz8KNEAs+2G9A+jXlhzQqkPUKpK/3eJYgEMhxASeufYJ4QCqq31M+DNdrOuuhl/tK6JMIN6bvIxZkXUi/BlmvwG9U"
    "If0a4OusSoutwBBU+fIygDKAb9ohsbDEgsV2Y78mFH4YqqVkT4VgXEcik65icJARSySxVBB46UVGYyuStkhtxk4sCTcxAC85CDee"
    "gXBiAEvIRhX1yjLq5TwaVQJQgfR1WiIBRA4cNwYnnoaXGICbGIQTSyoHkhto1EpolJdQrywDKMJvSH0i3ummajIVPDixlLrmxKAi"
    "NIQAywYa1SIa1WU0KsuQYLWJs7+HpispZ81LwIml4SQG4cQzICemHKpGFX6tCFkvqQCaHIhYCo6XgnDjABHYr8GvFuBXl1XY1WCw"
    "3OVZCwSAHAgnBhHLQMQH4cQyKggDwH4Vsq7GBbKuHF8vBeGlIdwEQI4KyupF+LUC0KgCJEFCf14sAwhPBUmNCri2DFlbgqyRdiRl"
    "b4cvOPF2FaHgJtX16mshL63+zhAjUMGlIT1kowSuFyFrBXC9AK6XIRtlgGvqtHy3lUiYNGoR0+MwCIoPgtyUOh1nH9wogWtLkLUl"
    "cB0AV7E9WQukTlWdBMjLgOJZiNgAIHRjIVmDrC2Dq3k1cbmyMltsjXsWsSwolgE5ScCJKVusHn747OslNQa1vPqeRgXw+5hZo/cK"
    "ODEILwXyBiBiAyA3qdYV+2ouVtWaYZb6evaS3d5LpIIJwhNwvDSc+ACc+ABEPAMnllGHG44HIqH5sAZYkwN+rQi/VkSjsgy/WoCs"
    "l8GyDpBQtj2egRMbgBNLKbvHUvkh1Tz8yjJ8iTBDqxdzXe8r5MSUHxXPwE0MQsRSKgNDSvi1EuqVPFBZBteg9tLdnh3WAYQAUikf"
    "uZxAaiCDYlnghUtFVMt+f40tcBQq2/ipB6evfOG2yRet3oKFJRYstgdzv3/jIIBboVpLHu01qaD2WYbr+EgmgFhKoFITINoCh0qz"
    "7I4bhxtPI56+EonBA4hlroDjJQBmNKpFVJdf0My7RN2vA5J0BrgqRRBeEl4yi/jAEBIDB+AlB0DChfRrqJcWUXWfV26tTgWUsot7"
    "I+gMizjcxADimSHEM0PwklmQ4ygipLSI6vLz6vr19zHtndRDU5YivCTc5D54Awfgpq6A4ybBYMhaAY3yIvzKEljWFUmTyMJLZCFi"
    "KQAEWS+jUXoRdRIAq1IW4sauHsLghMxNQsRzcDMH4CavhPCUVIqsFyEri/Cri2C/ChIunHgWIrFPBerCBTcq8Csvg0rfAdeLYLBy"
    "jpNXwkleqQIlSMhaAX7pBUXS6DRc+H7vAqWm098EhKeIEhHPQSSvgJPIgWJZdd3Oyi64AfFRXYJffRmy8jJkdRGoLoEbRaBRAUsG"
    "dtm6UQFLXAXYySGI1H6IeFYF7LIGWc1DlpU9ktLXZRHbkRlLKqPATan5lToAkRwCeSn1fOolUPkFSBKQJgNG1tu6Zyd1ACJ5Fcgb"
    "AHlJnbVAYbZCvaTH4QX4ZXWqK8GKeJG1PsU6Qt9vAhQbhJMcgpMaAsUGQcJTRGblJUA8p9ZPUKJjiYXLjlTQRKjwUnASg/ASV8BN"
    "XwkvdaXap+IDEHodNBstCb9eQqOyhEb5ZdSLL6JeegmN8qLKqiOC8BJwU1fCS10FN5mFcGJgv456JY/acgw1hiqTlHWdRdYTilDv"
    "twm4iSximasQH9gPJ5mFcOLq+8t50NKlCElS16Wae20CMByHkUgwUmkPDRYQYksaNggANwL4UQBPPzh95ZcZWPrHky/atBELSyxY"
    "bCmpkAZwE1RrydcDiPVnr2XEYw2kkgKxTBqlSgOO42NLEhaiQfrAVXipksOpP7/QtJn/3L86DOnXVSqfST+ED4AgHBduLIlYModk"
    "9lp8/i+X8PSz3zGuM773e67Ed91wALJRg6/LE4h0Wj0QigoGQozUJDdm6ifNaa/ZxBUZMoBY5irU3f34TzPn8PDDT+FHf/Qo/uU7"
    "hsE624IbKo2YWKrP0GXyzTs6NdNFKzTUWjQlQIDQdcvULI6m6tQRikthbXGpQPAyKiYY2YDBAFP0VMMIBLbUTVPz96rShjicWBpu"
    "8grEBq/FXz1UxCc++VVkswn88uT34MC+FBpuAuzXFDGUHoKXHsKX/p8FPPTQU4Bs4IPvu0E9d9+UQ9RUoLm6v7DKvdLqNByhjWCV"
    "1qfw2g12I2ONIABLw0nm4GWuxmPnY/itj3wVAPAz7xrF949eByrHwY0KyInDTV0FJ7UfX/nq8/jC57+Jr3/9OXz6T25TgWk1BkBC"
    "xDJwM9fht3//ieB0+OB1SfzEm67VwZrSqZBgXT5h5nOHwokBqRCD8JIQsUFFbKT2w0kNwUkfALkJfOHzj+HLD/0dHvn6c2gVB/zB"
    "H7web3rTK3Hza4/CqRXgl56HX3oOvvMdyOpLYCKVpeLXW555i8hgqNAamQhriV+KVR5j6zrhTcyriMgbWD1fN6FO6+M5iPQ1+OtH"
    "BB7+m4vBb97yfVfiH732gCKOGmVd0lLXhM9qn4sgw8rUem9K8DIipAkjMguoTAIvDYoPQiSvgjNwPT78u09G9D4Y7/356xXx16iA"
    "/ArIr64SaLcE7KkD+OtHPDz81SfXWHgh3vtLN6rSHemrQMev6/npr76GuljzpLPMhJuGk7gCTuZauAOH8OjjdTz00FP4/Oe/jc/+"
    "yXF1LQ39bBrVNa5DtNjBcP5tvK5ar89sCEactVnwT5lxGYq1blgiFNGRIA5q7CMbj9YF0B++0ec1iSq3XLsRMgxOvikUDIyIBoJb"
    "74Hbe75r2dlNzYdWu6VK9EQsrUjv9H7EB69BbOAaeOkhfP2R5/GlL34NDz18IZiv5tsOHcri5puH8IY3vhKHDl2L2vJzqC0/i1rh"
    "BfjVZRW0xjLwBq5GInsQl15y8cUvnsXDDz2FO3/h1ThygFUZRa0M2ag0T/OWcV5V1JdDIeNoGYPSporBjaXhpa9AIncdkvuGcell"
    "D1/64lk8/PAF3Pnzr8LIfl1eWC+D6hWQFOrAo5u9dLX3UzgPojaMo6K9gcD11sbVREDMk0ilHKTSGdQkwXGXt+rr01Dt4S8AuATg"
    "SQAv2UjHwhILFluJUQC3APgB9FFXwXN9JOM1JOJJuLEMEqkqEokKqhX0ndEmEhCuBzeWRiy1Dy886+K3P/y/dYirBN8mJ78fteLL"
    "qJdehqh4EdVmdfogvATc5CDiA1fhz//8q/jKV54Kfv+X3/uD+N7XHUa9lIdbLShiQW9ugXMoTLAuIIz4kn6PEmKsQ7IfBGWKDInB"
    "jatr/tRnnsFHPvxlEAh//fDTuH74rfih790Pv17RtcmAb9Jt9QuSdfWm/v5A5I4CjT5ERQ7Bym0LTr2NwJSj74P1ybS6XtYCZBSI"
    "9yGy2TsgIUJRPS2YaEgV1gKBLBt685faVzTimBGhQDBIC2SajBDj6JgTobI/iDvu+GPV8QGEC08t49OfOgEiBywbcGJpPHae8MO3"
    "fSS4zh+4ZRixzAHIakGVTDQqYKh7M04XA6BA4FELUhGHgYQRkwsEITkUgmQ/4qy1kjxGC0GEInREIGblIEu/+ftWdZSp+RqEUKdk"
    "sQyceBZu8kq46f24/Y4/xIULSyAQHn3kO/i7v/vXIBKQjQqEm4CbuRpHj34US0vVYE57mWvVOGg9BREfhJu5Gr/1W38cEEW33Ho9"
    "3vG2H9fElgpaqe5FxqqhxBNlVGQUbSx4LdQnPEUqxHNw0/vhpK+FO3AdRDyHj3/8q/j4x/9PcF9qHYvg+QOEv37oeXz4Q3+Lg4cG"
    "8Ou/eRxv+qevUCn5ThwNoZxQyVK9Xwt8BuKAOkhuFgXkQAgS0g+dYCG0AKargliKaD1oAUyKKr4HpFooMqmCeRkJKrWYZkSgMjgJ"
    "1dkoTmo/nPTVePhvvoUPfeihYBze//5bccv3Xg9ZeRnk5EGiCI6q0GshxfBzQzKEjPjbCtHDtYjKiEhhoHeg7p+cGCg2oLMqDsDJ"
    "XIcP/fs/bnpGv/Le74WovgyuvKxKbFbtcGGC9hiElwbFc3j4qxea7rn5zxDXH8rhbePXqbXdKCtNB1nXadqRdRQILYbP2+jvcNOz"
    "ic6R6Puhno2XgkjkIJJXwc1ch/G3fQkPPXQhWDPuwHXgegGyvgyuF0D1cniqTKzGxjxzM6f0PDTCj+b5BH82pbuLyDOOrgdWRBpC"
    "YddgrKVU2Vp6rSq7tUoae1CWFAoRQtvpYM2A9X5ibLUicYIx5FU+TwsRsr5v9fma6GIf7Ov9zGgeCaGFQIWyE/p90PuDlHW9r3HE"
    "VDqBjQy5QWNn/WbiItAGccJ9WpMloZji6hotBE0qeEl9sn8A8dz1iOeG8c3HlvFrv/ZnePjhi6vMW/Wc/gbfwZ9/4hymfu2v8aNv"
    "GMEvv+/7cOMrj0K4SdTLLwHSh5MYRDx7EO/6udP40pfOBXPrXT/7vYgNxNGoLqlyiHoJ5Ne0bYG6F+FCkAs4brjHBkSQVGPd1JmC"
    "g7ktvBTcZA6x9BASuYP4mXd/Gf8j8v0/8zOvR3wggUalAL9WgmzUtG1V42poMeVD+E2ilGZOisBfIP2IZIuPot7LpEW4ydXCzU5A"
    "LARzRjZ05obO6NwiksFxGMlEA8l4DE5sAPGUg2T6JZQKdUh/S0iOqwF8H4DHACQAPGTDHAtLLFhsJf4pgGPaGPXJ0EokEzWkkzW4"
    "IgFwDImkg0y2gErFR7Us+0cqGEdQuHC8BNxEBkBNn3s4ILggOHC8JJx4Wos6uiGbb4gFNwY3noKXzOpPdSIvF14yCy85gEYlozYy"
    "Nx46xMZRMun7wmyEauNkvwa/rsWaGhWw9JVQoxODcONw4hk8/NDfBYETwcU3H3kRP3LbTfBrZRWUCxfCKyqCwq8pcUdZVwrpJCCE"
    "EVyKBffH7EP6dXCjrtImwRDmtMWLa0HEmLoW7YCw9JvFpfxQ+BDMEVIiBseJQXhxTRR4KvCNEio6XVNq5ycqkqlE+bRApg7Wzfea"
    "lFAnllbEQjyDf3hsWY+NeibffCQPEUvD046MkxjEUv4pEHTQAwcCnjqJT18Fv15UmgPC1SemUeX6BrhRg/SrgF9XDrKZF05MiXI5"
    "XsSxrmmRtpoOYvyVGSF6TMiIYBknjxnQY6J+XznmtCqxIIJrUEJx6lTXiQ3CSV0JJ3kVlssxXLywHIzL0xcqePQbi3jNjVdC+DVV"
    "Cy5cLC819HvUGIIIbmoIvq7bF/FBFShqB7hp/DJXq8DbiYMbBXXv0lcn5VrcUZEPtfa6mAQiYSr13UnthzNwCN7gMC48U8M73/mf"
    "8MgjL4AgIOAGazj8UzSdXF+64ONfv/Mv8KNv+jbu/90fRiYDsKzB92sgboQnecLT4oCeDpJN8EVhpwW/qgUH6yEZ4Xh6viZUSYbw"
    "IiSTJsIC8kCfvgaBUBXwa/rz9PFiIHYYD4UKddBNwgXclCoHSavSAuCxprlPcJT2gqv0B6DF40ywj+Az4+q/TUBtgkG/qspEfCXK"
    "qQQgI10Vop0eRCwU9TSfae5fxCBiAxDJK+Gkr9HdEYQOpBz17NwkyEuraxLu2ifFOtgzGTlqDoqW5+5EyCWFT/7pE/ipn75J64Dk"
    "QfWC0lqQDRXIm1KbQJjUUwG4EcH09fORDZ0pFXm/iAeBtXluwkupUo301RDJq4I9yFwfQOrfq4vg2jK4UVbdVbTtVHMpEZlPXih2"
    "aVT3tbAq18uR6zNzR9sVRz1bCjpxICQTIkGzIhb8wJ4rsUv9mdyIZNsITRRHPttNKvE+J6aIKoTkhxESZPPyawEpbIJx091DCCVq"
    "qD5PiRqGIrL1ZvFCCvVWAhKPWYv1VpV+irY3gK+nqhF8NddKgOTARvsNndGj5zaRp/UPYhENBE0462xG+PVVhDfVwQG5MTjxDNzU"
    "lYhlr0Ni3wg++ednceedX2qaC6LJbomAaDDB/F9+6Xn8xZdOYfK9o7jzl26EcGNglnDiA/BSVyC/VGv6PALBy+yHV3oZjfISnFop"
    "OLAgciBcpfegRBcTWgza1TZJ6r29oQh/PScDnQbhwvFSqgRi8ABiAwewlK+2zG2B2MAB1Mt5+PWy8mPqieCwgfXnqbmmha6DgxRX"
    "X58WpRSOIhYCMcua6roFKP/JjUN4STiuFrbW69CsEdmoKhHJmhKTRCOcQ/3sVkEEJBM+0ikfrqvWTSyewmAug0qxgeWlylaUhjgA"
    "DgP4IQApSyxYWGLBYqvx/4ESa0z3KbJHPNbAQKqChFsPTkFi8SSyuQyKhRJqlVqQwtYPS09EajPSHRYUseCA4EEgBqGrPxzPdF6I"
    "nuKRbvXoRdT1TWAV0y8Pbjyj0/IHQcLR5ICrHUMnOLFXgagbZA6w78Ovl+FXi6gHJw1lCOFCOJ56uTG8/R3H8D+/9AQEYiB4+NE3"
    "3gA3MYj44AEIx4EbS6NRK6pSjloBjWoBfr0C6NN9x0soZ8eIVhKBpVJxbtSKqoMCM4TjaZIlAzeeVuJQblxlWQCqbEALI/rVZTRq"
    "BXXirwkRlR0Sh4il4MYH4MTTcDztKEdaY5nA069rZzbIQlAOg/CSimAgRzk+0e+tFdR9adLF8VK45dbrcPBQDs9cKEEghje96Ubl"
    "hMQyLTSTE5Az5rnHMgdUajIIIpbWDqYITpyVEGQBVC1AoqROGPV9OjEtxOUldbcEH7JehqwXIGsFlYHelJIZSZX1kjq7IAPyUloM"
    "VCqBxVoBslZUZAY3IgEdIid3rhbTSisxQ+2cO7EBOMl9cFNXIusm8MY3vgpf+qKaOzffdA1uvnlIxd1eMjIyjnYSPQh4euzS2qlu"
    "QHiZ8EQuMvcBwEntB4kYnHhOiSX6taDOnWsFyNqyetWLWv2/jrXFBCk8nY5llJZC5hp4g9fjkW8u4c1v/iMsL9UjjrkXWYfqv5vJ"
    "BZUpwGjgL7/wIn7ix7+AT3/ujUjG94GreRXYmWDLS2kxSBN0m9N30qRCRWlO1Arq9Jt9fUqdBHkZdZruprSYoHJyYbpQ+JF7DgL4"
    "yOeJss6CEErx3Uur7IrYgNLHcBI6kFfkkYgNQCSuanp+Qo8FwdOClvEwYGZWP5vP9TIgNxWSFjpwVURQEbJeVIFvvQAOnltDk2oi"
    "6PQQfF4sA6E/E05cn5qr7xPxfYo80AGq0GvPzB/VKcJkK6yesWCyO9Sr0XLPcf1yI0GaIvn+9qESLjxVxHUHhiDLL4Kri+p+9Km2"
    "CuSVeCnFBkGBgGlDPePakhoLv6JIWuFCuEn1XNwM4KrOFGreqjIVQyxEbY55LgDgJK+ErC5C1AqKGDCEouMpPQovo0QfvZS2m16Q"
    "saC6nGj7Ui0oDZF6UX0Oc5jREhsAxdIQTiLomMIR24MoWezXtdBlAbK2BL+6rEQmGxVFvEkTnMcVcRJL62vMqO+IEF8BGdAoQ9aK"
    "8GvLOiNMCRAGJAghtIHegNZO0UKzbiLYQ5XYbEhMQGeqqa4gaj8O3lcrwq8ugSp5pSXTqOlA1FXXHBtQBIZwFandqMCvLoGrBS3o"
    "qkl419jlQWVT9XyQ9TIalSWgVtCCybK5bEdn3Ak3ASc2AC99FeKD1+GTnzakggjmbNRuHTo4iGcu1gJyQbM9YKiMwN/58LdBcPGL"
    "v3QEYIabyEZssRt8HsGBE0vDS1+p9IVqRTAkhPS1EHQabmJA7Q/xTHCIEpBWfl11mdLkj8oQ9AOiXbgJxDJDiA9e3USYBTYHAk4s"
    "hfjAAV0OKiD9WpDRZ76jUS2iUVmCT0XIBoEZquNWLA03MQg3kYFwPDCgyktrJfjVoiJ0AH3YkoabyCoRyVgKwo1pgVQJ6dfg18rw"
    "qwU0KgXUK8to1IrwqyVFUvj1SDlRbxGLCQxkGkglfAihsnRcz0Mml0Wp0ECxUIP05Vb49VdAlTZbARcLSyxYbDluAhBHHwQbVbaC"
    "g0wmhsFUGa7QjinqcN0BpAeySGd8FPINNOr9tH8mW8CknYcbooMkHCQ1a+6sSMVVaZHhKSqCszIXDuJwkIKAyk5w42nEkjnIeAZC"
    "6CyIWDI49VCBs6ezBjx1cOI34NeKqJVeRq34ImqF76BRzoNZhtkFwsEb3ngD/sdf3oH/54sL+Ml3vAYHD2V0UDwENzGAWNpsngXU"
    "Si9DFF9Eo7Ks6peFp99zJbzUPkUWEODXq2hUluCU8/AbZTUqbkKJTaX2wUvl4MYHtHMVtrTya1pcqvQy6uWX0Ci9hEZlSTsRAiKW"
    "gpfMIZa+Cm5qnyIzvKQmNAxRUIOsl5XTUC8qIkYokUylnp2B44aBr5T6/ZU86uVFyFoJIMA1QT2Av3rwX+ETf/ZNXH8ohx9908iq"
    "2SvmlEggAQeJ4KQxlj0I4cYVaWFOhqHaVspqAY3Si2josgwpzX1m4CavgJsegqNP9FnWIWvLaJS+g4Y+wWP2taihXmWRwNlNXQE3"
    "NaSECJ2YIiZqRTTKLykBxVoJLGu6jD8kO8wJu4il4SRySqBRZ3CQdvzNPfzXP3wLPvGn3wDBxRtWGRcV7rkAhJ7TEcLBS7ZIc7ja"
    "mU00vU8kchCJXEjG+ErxX1Zehl9+EX7pO0DlJcjaMtBQwcyq6vykT+xdo6twFdzMtVgqihZSwZAJCeQGB/D2n74BN918BQ5en8bT"
    "T1XwNw/l8ZeffxFLS+p7JBpg1PH4I1W87c0P4r9//mYdxKXB+gRfJK6Ak7gCFBtQQXcwX6HaadYLkNVFJQJZL6gyByeugurEPoj4"
    "Ph1cJ4Cg3Ee1PVQnwKY0RgU1XC9AVl6CFC+qz5N1feo9oD4vcSVEYp8KeL108DxXz8tyIfSzE4hFTuETYecMN60+L3GFyniIZZWQ"
    "IrlBdo4Kppchqy+ra6u8CFl5GagvA42KCupJZxrEBtTnJK6ESFyhCITYgL7/NUoaIHRQFZk/uo3oelsQG1HGRhmytoxDBwdw663D"
    "EPC0DY/j6ad8PHvBD0gyRSj5+OiHzuG3fve7IBL7ICvfAdWWdCAuQU4iyKoQySHdtcJV87e6BFn2dJgHgBv6eWfhpIYgElfpzhSx"
    "4H7J8SASVwRdWBDcbzy0NwCc9NWqe4dsBBkYcOMQ8SycxJVqXONZNc6mha6eh7JWgKzm4Vdegl9+EVR5WXU9kQ1tVwbgJK+CSO6D"
    "8AZVMG3ELTVBQCKSCdGoKgKg8hIapRdBpRfgV14EqkKNk4DOHsrASeTgJK9QeieJnMpk8tJhRxZA2/YiZCWPRuVl+KUX4Zdfgl/N"
    "q2vX+wS5CTjxrFrj6f1K6yWZU0SacAHZ0C0XS6pUTTb0yXZC2Tk3qTPMJGS9BL+SR6P0Aqj4gvrOWgmAVIF+Igc3fZWy08ID+3X4"
    "1SXUiy+ErUD15zvxQbipq+CZ9zue2vcqeUA8H2R5+IZoi+oDaT0nJzEAL3UlirUkfu2DDzaR2Q7ieNvbX4M73/daHDwUCjg+faGC"
    "2T97Hr/34afU9UCC0cANN8Xxr3/mJjieaGqpqzK2wrllsvFiA1fDrxQg61UIx1WBu5eEm8wilr5S7VnJLBydrRYSC7Wg3bYp91BE"
    "QwPMquVwTAtPqnsWAUHiIBl8fzx7DRgMJ5bUByyxgFjw62XUiy+jKhyY0hNmwIkl4aX2qWyI9JVwYkltdsuol15GvbQIv1EBkVDk"
    "SWof4gNXwUtdAS+hCKDAV2hU0agWUS+9jFrhJVSL30Gt+BJq9BIa1YImUPvQCJMIyXQCA5kyYo7u9iLrEJ6DVGYf0tk64i+WUS4W"
    "t8KvjwG4HsALNsSxsMSCxVYj0VPbKlSdnHBUi8ZUKo5c7kUkYzWIQKRPbSiel8RgbhDVqovichWNuk7HY1/X4fXI9NPK/4gSCy4y"
    "kdNSWsXBNXWX1OIsJuAiHZ7cxlLw0hJCePj2uSqKZWgBRx+33DoMAHj44fP40hcew6OPPgcAyA4m8YY33oA3vPEGZIauQCWWRnX5"
    "Ofi1kspu0OTChQt5LC3V8AO3HsTTF4ogEK47lMbTF4p4+sKydkJcZDL78Irrc6i4cQj3O5CNGoQbQyx9FRLZa/H4U8BywddBs4er"
    "r7wCB/YNwK+rk1s3noGXvgJe6ko8+uglfPGLf4tHv34J+SUlMnb9oRxuuXUYb3zjDcgcOIBq4TnUltIQxRe0IwclODmwHy8sZ3Hp"
    "ggOgBqCGm24+gEcfuYT/+B/+D/JLFdx66zDe/o7vwsHrrgNLqU6iSODhh87jC1+cx6OPXDKROG6++QBufu1+vOGNN2DgqiE0Kovq"
    "VEQ4gbr2I488j5tvHgLBwTceWcRrblaB7lK+hm888iIefeSlwBFykUIxH8NXH3oRADCQdfCam68Ds8TyUh2PPPKcTkmNYyAh8MpD"
    "sSANGb5Ky3ZiGbjpIVTF1fjWYz7geIB0cO1QHAcGnUjacg3wI2KekXpxN3UVvv10CsWap0pmIHDwmv24OpdBw42r08NViAWVXaKC"
    "CC9zAM++nMbFc3UADQB5ZLNV3HzzAQDAQw9dwKHrs8G4/KNb9wcz+ysPXVIp3vA0WabWw9889CIAwsCgg9e8NttELKhgLtEUKP35"
    "n57Hw1++iPMXvgOJGg4eSuMdP30zbr31VRDFSyrY1PXNkk3d7GqtKaNdLbKqDCJxBd75NkMqGOc8AQcp/PL7vwf/6t+8AoNZr+lT"
    "3vrT12D5N3387oeexR9+/DkwfEg0kBuUeNe/GYFw45BeGsR1xWXEsijIq/DNb0CP4RJufu0B5PNVfOhD/wsXnlrCa197AG/60RH8"
    "o+++HqKmxLjITWpSIYcvf/k8HnroW/jyl88HNuS1rz2Af/qmG3DrD14PAPjyl58yoSXgJ/CPRq9XgXotrgPDBERin0qlT12NpQLj"
    "85/+Nh566Dyeekq1ZcxmE/jBW6/Hm/7pK3H99dmgJEQERGcsIMzITUKAlV5F4gqI1NVwUgeQX6rj83/+bTz00FPB5xKAW3/werzp"
    "TTfgta+9UXVUKA2AnARk2QOLkKg02glO6mqI9NUQiavw9a8/hy984e/0PYb3b641nD8tdjewq+sot2kyRtaWQOXv4O1vHsFP//Of"
    "aCKmxo59VZ+bekE5BMPH3OdrWPrNBtKJfRCxQUj3ZVCjooghN6mJgqvxTP4KXHxel1xIB68+mkY6qUgw0vo35nk7mWvxzfNJLJdD"
    "reObb96PbDqh19xT2vbUg/XiIoO/1vYGYHzf9xxUlVb1Qd32NaPKRlIHcOHCEr7whW/h619/DhcuLAXjc/PN+3HrDx7Cm970Sjj1"
    "A2gUnoVfvKTIrkZF2ZVEDu7AQfzNmQbIcQDUAdRx661qDv7pn35dP3f1ucPX5/DGN70Cb3rTqyASL6DhqYDdJ0e364UqOUteCTdz"
    "tXqlr8bScgNf+Mzj+PojzwfiqQTCza/dj5tv3o83vumVGBy6Bo3lS6gXL4EKz8EXLqhRVpkBXgZuej+8gevgDR7EM88DX/jE4/jC"
    "F74dzIUfvPV6vP2nbsKhQ6HNyuer+LM//joeeugClvLVYOzf8VM34zWvehVEbAB1Nw5RXtQEfQJeZj8uLeXw7Hl9eMAxXHNVAvsz"
    "jtYLUiVA5MThJrLwBq7G84Ur8exTqmUqSxevGkkhlkEQgJPJ4uGQ3jNlTI6XghMfxBc//ziWl2pN+84tt4zgtz76/Stm+XWHEviF"
    "912PH3njEH7tl57CY4+WcMNNcfyXz96Agawb+EPfeOQl5JcqWM77oMjc+tYjJRBeBsD47tFrwbIOJ55WZYPxDGLpIcQGr8bFi0V8"
    "6ZOP4+GHn0I+r7IAstkEbrnlIN7+9psxmI3jwoW8nncEwMNNN+3HYFYdoDz6yPNYWqpgaanetGc8Fvn+77vlWnjJHADCt75dQD6v"
    "xLT8uoPXvXogLMNkBjMCkerUFdfja99SBxwA4DdcfM/NV6Cy9JwShBSq7DQ2eADxzBC+9KXH8ZWHH8Gjj7wQrJGbbt6PH7jlIN7w"
    "hlcgPrAf7uLTEG48LMXQugvdMAuB9pYjIMiF48XhxVPYd0UD6dSLcB2doUgq09D14shkr8AVB4DlfBG1ahW+X4dsNJT+g/T7kbUb"
    "Qx9LnC0ufxCz7ShisXnM/f6NvGYMvk6Abn5MDeQCASshBBzHgeN58GIJuLE00ilGNv44ko2vqxTIeA5I3Qx4+wG4qNUElotAoVBH"
    "tVxRWgOygUajAZaqHrmYf3HD66I1iQ4HXiKDxMB+pIeGkb32Jvzt37+Md7z1s/AwAA9ZeMjiHy79CMqLz2D50mMovvgUqsXvwK+V"
    "4HoJeKl9SO27DpkDNyAzdBRve8sn8H++8hI8DMJDDr/43tfg5957WNX0+TW48TTe8ZZTePgr5yDRAMB4+rl/i8lf+jw+9YmvRwTG"
    "KHDGDh4cxG//zhvxfa+/EuWXL6BeWgTA8FL7kB46ivs+8teY/vDfwUUKLjL4pfe+Du9+34346sPfwb94y/9EA0X4KEGihq/87btw"
    "1cAyqsvPgRtVCDeB+MB+vLCcwfe9/mPBdwICf/7Zn8b3vm4A7NdATgxeMouHH76AD//W/8JXHn5qDXE0wsBgHO/62e/GL7/vFtSL"
    "L6C69Czq5UWAJZxYBvHsNfid/3AWH/6tLwf3+7a3fxc+9YlHgwASAO776Bvw9nfcHDgsv/bBv8BXHj7fNDaI1E0PDsbxrp99Hd71"
    "s9+DTEoJNTkxlWZ97dBvw9Hjc8st1+OPT/0QAOBvHnoB7xj/InxUdUgXh4sMXAzobBOJ774lhT869X2K/HnoIt46/ieBIOUtt1yP"
    "T/7Jj6Dy4lnUl56GXy+ChAM3NYTEvsP4u8fieMv4HwfX+95f+b9w588cQvXlc6gvPY1G6UWVrix95eS5STgJ1bEhtm8EH/0vz+PD"
    "H/7rYGxvuukA/uqv/jnqhWfhVxZVMEcOlotqqQ6koUtHXNVCM3Mtbr/jv+GLX3w8FNL62dfj13/jhwEA11x1vybB1Ng88Z23BAvm"
    "+iv/GD7KAFiV9CADF4PBafLrb03hjz73PcF6uvbK39cO8iBuvXUYv/+H3413vvnv8egjL6KBZTSwDB9VSNQASNxy60HM/OEJDMQK"
    "qOcX0Fi+AL/4vMpm8HWpDkUIPMeD8DJw0gfgZkcQu+JGfOLTT+IX3/2FCBmYgos0fvtj/xd+4qcPKbKiVlCBn3BBTeUvwKk/eRkf"
    "fPdF3HBzHL/xuwdx42tT6vuLlyDrBeUgJq7AX8/7ePOb/zgIEn79N34E//5DD2F5qRbM2Xf81E34nY/9KLhRClLfH/ryU/j5X/jv"
    "uHAhv4YoG/COn3o1fud334CrrviIOf8Gg/GdF+6Ev3wesqLWO3kZOKn9EMkhfOhD/xu///tfxdJSLaIdEK7BwcE4/usf/TgefugZ"
    "/PaHvg4XaXgYxOT7X4Nfev8I/OWnICsvqpN5LwMnfQ2WyjF86ENfxsc//n8iehnNnwsAt9x6HX7nd38Uh6514Rcuwi88A668qO1E"
    "HCJ5BUT6WjgDh/DIN5bwgQ/8RUSkcKW9eMdPvRq//ptjeNXhB3QgMggPAzj70o/ALz6DxkvfhL/0FPzyC+BGacVJIJELmJajySE4"
    "A4fgDo4EOgb/8/Mv4Bff+YTO2Ijrch6hs1VquOdjQxj/qX2ov/goGovnVDtO2QDFBuCkr4ObO4qP/H5UEBI49bm34/tfU0Zj8Qn4"
    "5Rf0+zNwMtfB23cDxt/+F03CjKc+9w7cequaj1dd+WE9sjE4SMPDgF5XCRAEJGp4/MUfhl9+UZXjODGIeBZLBcYHPvAX+LM/e3TN"
    "sVR2MIb3vf/7/1/23jxOrqrM/3/ftbauqu509qQjO8EkOsomCTO4oRAGFERJVNRRWRxQ0FH4fl1mc/kOyzjjHnRm3ElwAYxjwoyD"
    "qEOCsoyO6UDYId1ZOr3WXnW38/vjnLp1q7sDITKL/s7HV5uQrrr33HPP8jyf8zyfh0svfwlhdZ+seOJVMQwLKzMHu7CMeQs+07WG"
    "Pvb4lbzt4tu5Z/uebiJPXXPFirl8/ZvnsnhBhD/1FEF1L5FXQWBguQXs/GKcwgDVVobrr9/GTTfd/4xjqFBwufTyP+CD17yMsD6G"
    "Vx4iqI7IdAXDxEwXcfJLcXulBsF737vlINeD799+AavXLKVUavHKV3yT4aHStP1Bfu6SS/+Av/rE6XhTuwlqo1Kg1sngFhbz9196"
    "ghtuuCf+7Ac/tJr3XbKI5vhjeJV9skqOncbtWUSq/xg++w97uDHx+VtveyMvObZOc+JxPLWuh349rqZiGJbUP+hZQHrOUWQXruTv"
    "PreTT99wbzwObHrYeNsrOGX1nC7iTEZx2HFEQqUUctfWCuet61WaAc04WmPd+T9m+/bdas1uj69iHDUg8Bkc+UP8ygFCr4Zhu9iZ"
    "PmoNixtv2MZXvvIfz7Cvu3zv1vO5444n+PSN98Tr1PdufSOnrV4KwIXnf4df3LM3QRAWZtx/x/7T46d74/m3sf2ep9W6Z/D0U++m"
    "un8XtfEnpJ0jwMn2kp17FPmFy1l2xE1d73Z439W0SvsI/aY6JOnnoUfKvPMdtzM8XJkhgNlec/MFl3df8mLe975V1MaepDr6OM3S"
    "PrzahBSXDL2u4j4HoTTjD+R65ydEJm1M28KybSw7jZPqIZ3OUsgcICN+hRmUwMlB7nhwXwCmSxBY1GpQq7Zo1Cr4rQah3yIMfKJI"
    "9k3o+1Qn9x0S53EoLp+AA6+8enyB9nQ0dMSCxu8Mlhy5SOkS5KTBaUudAstKYTkZHKuF4wdQG4XWHhANEKrEluHiZOdQzBXI9hkE"
    "gUcYSAX50PcwhIdlhQz+cvvzz8R15YqnnvO327mSFikMNf0s9ezdQmqy0sIH3ncHt97ySCftYtpmuH84Yv35P2TTba/j5JOWYloO"
    "UdDCcjsh0O3vJA2pU1bPZenSPE8Pt+KTyu9ueoj3f+gUDNMi8htYToZUYSG3fOXfu8TTVqxYwOrVy7qe7JZNO3j/Vf8cR3V0i0x1"
    "BMgaZcFnbvhP/nXLbr57++vJ9rlYbpYoaGE6WZzcXODxLnGn79/yKKYyrNuGw9lny5PMoaEyF77+e5TLDZWvaXSJY7a/Uy8L/v6G"
    "3/APN+3kn75xNqetWTrtnRqJfkq+MSsO92+HjMtokxSCCCtRZVWeALtxuVEDBzvTi+XmCOwURugpB1jqVmAEXf1qYGKlCzIXOw6n"
    "n60+nSxP9+Y3v5S/vfGXsQDWQzunGN7TYOnSxTIaQ0QYlsud//YYpVKTS961QkZBGCZWqpdyNeSOrY8lxD0tLrvs5MTzOHH++cx+"
    "MVW/0NUvMhrBwJo2N4w4P9hh7+6Qt5/3II8OhlhkEASKjDGVYye4d9sUbzhvM7duPo9cz2KEXycKGhhhCyPyVSkykeDZpDCX4WRl"
    "3rWbZ8OG++IooXb7/vKTp3HhmwdknnRjDBGfguYwlQ5BG697syx288pzCuSL0nA33R4Ie1U+t6sc1D1d4pR//pG75bskE/fbOWuP"
    "l6dVSjNg4807ee+VW6Twadc8SQpJwvc27mZ492Z1raijtm6lMDPzZei8YWKmeinXbc597T8yOHhgmkCl3SXUVi/DhefdwYqV81U6"
    "QFY51mq9cHIqWsHGTPez88EKb33rt1UlDTsOz+4WopUOxr3bpnj1H32Pz3zh5Zx99pFgWERWSp7q2mkZSdIzwM2bHuLKK7c8iyid"
    "fP6HdmyJ29hu7yGhXWI29BFGA+FXiFolIq8cEwtf3fC06lP5TIVCmlpZvWtcNlxX5vw398t0FbcgtSNCT6aK2BlMtwgMxc8h37el"
    "dBekXoUwDKUzIHUjOmuOGa+LHXfdidcRi1RM7LXHUrxnZPrj7wzuGOG88zap6ixWtxin6tM24VovR/zlRx7gnrsP8PdfeDn5Yhaz"
    "OSVD0FNqXMdrkmzfBefdxs6dE2oNNmY48A/vbHLmy2/jxz+9gMXzFGHXKiEwsTJzcAoDPPRokyuuuJ2dO0cTY8iaMTbBpF6O+Lvr"
    "B7njR8Pcuvlccr1HyvSt5pR69jm4xQFFKmyddq3u673rbXfxvR+s5eorf8K+oRYmqcQe2hHt/KcvP0qlLPj0Z07HMG0iv45hudjZ"
    "ucCTXe/XwJLpHE4G00oRRWGs8WOle4G9M8aDlcp3i+0mS2wyW2Rkd3SkQz5+9932hKnEXeU180WLc9+UJ2iWiJQQouVm5b1V1JiI"
    "iYWMGltZDCwiVcTbyc/HVmRrudTigvNv4cGdo106Q91jCxpluOiCf2HFij41P0U8r5JRa519IH3Q+0/fewWy6okdpzqmCS1HRcSk"
    "pV5CKj9j3IJKr1CHHzt3jnLhBd+lkpgn3SK+ZmyjfPZvd/K9W57ga//0UoqpXEdD6zCwcOkinFQarB5MJy/XgjhCJYdtWTjsxqxN"
    "Qn2ntHVDVfbMlOROT6ZIutfC95WAZegTBi0MIe3dVr3Mww/sez5NXVN7KRqaWND4nULeHsJJp3Bz88CeJ3MjrRSGlQWzKPN3fRUO"
    "L1oQNYBQKqc7czGs+dhWD3Y6hKghVdJFE+F5mKICwfh/VZBPwiixn+M3jRlGTedwzUwYnDam+sxttzylQn/NWQ0imZMd8Z63/5yf"
    "3f8Gcvn5BM0KppN61liS935oJddcdTfgSgd+0xN84EMvI11YFJcUBPjOpp3x85o4XHLpKV3X+e6mB/mzq/5VbdBGLHBZLPSwcuVC"
    "dg2WqJbbxo/MAX10p89Fr9/KLbefTU9xiTwhMR2ZV5m4hql+2k4umJx51kAcXvnB9/47tbKJSVqe3GKxdGkvK1cuoFoOuXf7RGzE"
    "CSL6iylWrJw/w4CZfR81YmPewFZh9Jn4dFNGMUzPXU3JUprq74apKi8ozYu2cKJhZ4AKxA6gfD4p5JdSpTqntSkWoZM/A8uKrFix"
    "kId2TsZ9dM+2/bxp/XHKIJa44W/vBwSXX3F61+W2btlFUml/5YpFDCwrxL9vk1/TFfOTBJvUV0gnnL6M+q09zUpx43e5fyjkwJCn"
    "+tCMT6QkKRPEBvejgz7vv2I7//itlxM2JzFbJYRVgVCpsSdnlqEqDdhS1G337hI7B0djTQWLDKtWLuad7zkSEXryVLVVkiUx3R5V"
    "aWNmdlebXOh68sy8WLAtaeB3C7t2BAHzhRRnn3Nkh4S7+WGuuvInysgWXQKKUtAs6QxKIUGHoiKsOqX8zFQvok1CYXDeuV9j5+DY"
    "QQQq3QTBh+rfAId8/N7a65npFqR+hNNDueTxunO/x1S52rUGmLisXLlQVZopJ64raJQD3n3xNv71Z2tZsfIIQjsDQRPDyWBmFvCj"
    "LY8pUmF2UboOmSWf/5HBEIcCJinliBxqFp4qwapKfYrQh8iLFeV37pjknm37sckTqXv/3bf6uey8ijpBtRgZEtx3d40TX9aPWS8S"
    "eaW4woRhp6XWRNd6peaLle5U1hChCnVPy7SnBMHcFs/rzLm0mgup2PlqkykyYqF7Xg3uGOP1591KpRzGQnjdY6mzbib1I+7cOs67"
    "Lv4p39v8WkynRzpfsShrkjx32LWzgU1PF7HbcbIN5VhGfODKX/DdzWfKsHE3B4aNlZ1LteFy8cU3MzxUid9tUjA0OTaTbXx0Z8Ab"
    "z/tXvrv5tfQUlxG4PSAEVmYOe/aHfOQjP+kSImyT/Z3rmTTLEete9zPKZQ+bHkVgGl1zpP0Mt28a4aJ1Y5x62kLCZkmt1c6M92vi"
    "KK0GWX2DUIkt22mpQxST653xYDpKELVdZjMuo9g+RVaih6qSQaGQnqbnlOX9bx/i2o8P8PKze8gXO9ocM4d9GIsWt8WNkyuxqcZX"
    "Z93Oqnv5Ce7aplzyuPD823ho58SMuT99bAG0yhEP3FPHoaD6WXSN7Q5Z5ipNnoPfv7NnuIk9WmoqGCrNEwGm5WLNOm4780Suj/Du"
    "d2yhGs8TSwlg9rFi5XyqJcF993TbCnMKOZYO9FDZT6daz2Egbe0l7TiksnMx0w7CykhRXSMDTh6MFIgUGAFEVfD2q/3FAqsP7LlY"
    "Zg9WClKRsoVFAxH4GGEVvDFqQeX5NnR1KLuGJhY0frcweWAv6XREX9+T2G4P2P1gF+WfznxwFoA9F7KrIJgCby8YLphpcPrByEJU"
    "g2ACggmM9p/+BFEwRbPRAvr+C5/AmFH7/Ll8E4yDOP1GR11fqZYXCxkuuOgoXr12CQB7djf44g2PsW/Yi4mFVtnntlue5u2XHhuX"
    "p0wc56r/dZfTu2DdEXz2hkGGh2XO7Mgw/HL7CKeuXhCTCndsfYw9w9VY5G3Z0n7euG55fI3hoSofuurflVMYYWAxsHQOf/nJ0znz"
    "7GXx3XYNlvl/H32Y+7ZPKl0Hn8d3enzmhkE+9okT4/t1etbuEsk8bfUSLlh3JLsGK5y6Rp7W7Rmq88D2KjbZWIfgxs/+EReuO7qL"
    "G/j89Y/zhRsep6dg8JVvnEqh6HZVS2gTItPr2S9dluWqD72I4aEKt23ag0kakzRLBvK8bp1sw8JlRpcpJE/gpRBcR9zTjhWuDaNd"
    "vcDuUseWp4Fu57Oq+kenokOybFy7xJvPZZefzAfee5dyQlL8eMsIb1p/XNyiO7Y8wd6hOoKIrVse5ey1xyaIhcdi49oixaWXn9g1"
    "EtskwXTnB+Dqa1YhiPjM9Q8l1PVTvOeahRgY0/qF2NhvR86Y2CwZSPOWy/s5fpVMK/nl3RN8bcPTVMpKy4OAn26tMLy7zqI5fYRu"
    "D5GdwfBrCMPslFnEiEvDmcrZGxwciY17acTmeNflxwMQ1g8QNScQfl2SOHaa225tMDz8cJzG0om86Y4gkJoLPqesKXLa6fO7TuPM"
    "xEncsoE+3nX58q4Qb4Dh3TX+4sO/wlIEVDuaY936F3LJ5S/khat6ARmi/9UNQ9y7bVypvEcxsZCUD5MCfnDDdb/kwcGJxGmiS1+h"
    "yMc/dRqnnb6ApcuyDO9ucOvG/Xz1S7uplIOYAJouoiarAcg16B1v/TEVlRMtr5viQ9eeyiWXr4j1KcqlgK9t2M1nr3sSGSMgBS/f"
    "dO7d3POfZ1MoLpbvyrDYvbvElVdsSZwYSidj7drjePflL+S00+dNe/6JBHHjKFLvOcj7CJGIbFE6CMoZ+/KGQQJqsUNy/vp5nHR6"
    "imNXVnlssHNi+q0NJU4+fbEURmxNIjBkBQ/TkUR313qVks9mOp2yo4YZl0jsOED2DPE8gA9dc5okazfuZmTIjJ/3imsWqbW+W6z4"
    "/Vduo1oWygGT5NyaNS/gkstXcNqaeRSKDsO7m9y6cT9f37CHctlX48nngW1N/u66Qd5/7UoMMyGomlgT2iRqsZDl6muW88JVBcDg"
    "wR0VPnf9U4owlvPiP7Z7/GLbKC9bM0/qkFhyHL33XbfFpWvbzv+ygX7+7JqX8pq1SygUHSWcOsXnr3+aPUONuI2P7fT4q4/8mr/9"
    "/Ck4iSisLVseUKVuO+N35YpFXHL5C3loR53bN42qdSSiVQ5wSRMhVf3fsO4FvGzNfO7cMsqdWydV/8sKMF+7aYiXrVkgIw+MJInq"
    "xBotJu1yku013Yz3XOOg46FT0Wm63SCEkCVkQ48oaBC2Kpy99hj++mP3dd23Xnb4q6sm+Kurxjl6heDYlYKFAwYnrymyZCATCzoa"
    "louVyqsSjU11j4g3XPQCTl3dz/c37WZk2FDPkua8i/pZPOB0rX0AH3zfNnbtLKmxJdfsZUvncvWHXsKZZy2W722oye23jPDFG5+O"
    "q1F0KlOILgf/TeteyOo1y7h1025Ghs3O/d80h8XL3Blju/1e2/3Z2UvbfS61uQzLTtC7Thzpk8Qvtu9n33ArTnUycdn0/XM4dXVn"
    "Da+UA75449N86yvD5AoGG756MlF4QJW3ls9zOKnjkwf2kXKht28PuZ7HMOw+sPrBLUIwV9m8CyB9JPij0i0zc5JwsHqlrRvWICrL"
    "A7NgHPxxjHCCyC/RqNYol3SQgYYmFjT+f46RsTRp1ydoVekrjJHKDGE4BbDmgN0H9iJwB+Tmbvepmsg5iCLwxyHaD94I+GMQTkEw"
    "CeEUvlejXE0zVc799z1Moob6b1siw0ickNtk6S0U+fptq1m+Mt/50Go4f90A7z7/QR7YXlHGvM9dW0u8/VIpBtl9PXNGiHEbb1h3"
    "NJ+/8cHY0L99035OXd1Jrfvepodjp9AizZvWrer6/udueDDO/xUIBpb28qO7Xi+d9wSWryzw9dtP5qq3Pcxdd4zFDtq3vzzCOy+r"
    "sWQg1+XQtQ0EmxzLls7jW7f/0Yy+2rO7hU2OEAtByAtXzOkmFRSuvOZoLli/lId2VDlhZUEJMIXxSUbSeUwa+UsGslx1zQp+uW2U"
    "H2w6EJ/gLRlIc+k1fbO+O4t0bFDZcci2oQzK5AiZKQbadg6S46nrAKFdNSFoErWqhK0SZ689hj97778rIa4cP91aplzyY6fvHzY8"
    "GJM+X9nwnzGxUC61+NetuxMn+jleu3bZDGJBKA2FNtkVEwvXvlC+/+sfjX9v4nL5tbOTeZ1TU/lz/MosX918dJxiAHDKml7OXLuQ"
    "d5z3EJWyrIke4XHrxv289wML5Slh+xR4+kyLnTdZc35wxwE6JQqls3/qmjky71iVAiQKMIwMhp3lO5sG2b5tOJHGYiWIglT8bgQB"
    "IU3ee+2RMbHQNmg7ehR5vvPDV7JkWXrGmvD31z1KXUXYtAmov//8H/LGNx/Z9ThnnjOPM8+Zx/+54nFu33ggPgGcLYR6aHeVv73u"
    "14oAkuH0q1Yu4fs/PEuNA6GIsgzvu/ZIXrN2ARef+xDVctRFvkwnj+65e5R7tu1PRKak+MznX8Wb3nxU1+cKRZv3XXsUAwMF/u+V"
    "T8ROYbPc4p82PMnV1x4fV8m4/rp7qJSDLkLjM59/xTM8/xPcvnEsXhc77+LQV9ROmUtZ6cJ0C1LIb+MOLHKYOESkeP16Seq8+fIM"
    "f3VlPSYbf7qlxp7dHovmz8FsThDJOncdolCtIW0Cy8BKOKXy3DZJJLfTVNriecl+/8C1LwLg3m0Vxoaa8fycbV59b+MwuwarKvJH"
    "ng5ftO4EPv2FU7uc1iXL0rz32iO4YP1i3nvxY+warCMIsPD4xoYDvOtyv0vENKnYb5NnxYr5fHvziRSKHXPx1DVzuHD9Us58yY54"
    "rgp87twyxcvWzIuFcbdv28MdW59KnPanWbduJX/xyRO77rlkWZoLli3kzLXzeMd5D7Nrp2xjhM/mTVO8/5o6S5dlE4Tpk11r59ln"
    "H8dXvrFa/nIdXHXNMVz4ikfYM9RU1wkQBNx610s4YWWP2vuW8s2bDnDDR/fFURI/39pUy4kVz5vkftQWOTWS63RSRNQwYke4ezzM"
    "IjSVWNtFFMgKEq0qQWOCRfPm8a5LX8Q3vjw0rRyu3Ose2VlncOeU1Ke5sUaEJwVzV/bzmrMHuPCiIykU5xE0y3H5xwvXyXl77/YJ"
    "Roe9+J2cu66Hl67uTl27d/sEd94xmojAs1m5YgE33/qq7vc2kOaKD76AV581n3de8DCVsh9HVckUhs6YecNFR6kIrDJjKgXTxOaP"
    "1+V56Wp3lj3DUYS71TXn44pborszO+8pgzWtCvqunZWuNfeNbzqhi1QAyBdsrv3ro3nVWfPJFywWLbGpHmiXmgzicprPFWNjJpYl"
    "8Fot5vaXyWWHMe0CeEVJHDhzwD0CrByYKUjNl4doIA/VxBi09kM4ruzcSQgmCPw65bLN+IRLrW5pYkHjfw30SNT4H0Gj5VCupdk/"
    "UeTAVIFGIyLyx6H5JFR+A1P/DpNbobpNLqR2DsyM/Hv911C6C0o/hcq90NiF8PbieXUmyzkOTBQZL/f89/EKM/mFzn8b7YoRzyWe"
    "wY7F5t5x6fExqRC0qrIedvt06+NHduW3/+f2YNYpnswNZZrz8I5Lj6FQyMYG2j/fMkGlFCjn0+POO/bGJy+9hSJ/cunxHYa/FPCD"
    "W/Z1hZu//0OnzCAVkvjE546hUMjEbXYo8I2bhma0uXPNNBeu7zgycbWEOLKhYwTvH4Jdg9VZ77t4IMWr1vYnrhFMO5lup7ZYB3kn"
    "ZiLqw+w2CkWU+JwTRyDM0OCYRcU+6dhNd95nHr6KuC566FUImlMUiynetG554gQ0y51bxtXpeJ37tk8qQyvNvdsnGN5dVYb50/Fp"
    "qEWGs84+ekaFhI4xKw3b2UerNSMsGoAokiXnusZhx8H6xOeXKVJBSKE3XwrvLV+V5fz1C5XTJUUjH9kRYMShxyoMNtmH7VNAdZJl"
    "GHZ8Gp88eV2yLCXLN4YqHF6o3HorRUidgDohTSI8pfsQxs5NhKdOPMNZvAMzEd6b4ay1L4hJhSTKpYDbNu7vOmX94LUn88Y3H4kQ"
    "IUF1D/7ELvypR6ToH/A3XziaU9f0xwrqjhI8S+Jff5Scgyl6C7189VvSARB+laD8NMHkI4SV3YigwfJVWb75wxfGp8fxKew0c+Cf"
    "NjyWGJ8Z1qw5cgapkMT5b57Lq9f2qxBnObdvv3mq6zP/8qOhrvXi0stfIkkFEUkxxsldBFOPSJFE4G++cBSnrpmTaOdzJBZUuV+Z"
    "ttAjtRLS/WzY8EAcWRERsHjA5ZTT5Tr7inPS5AqBEtCVKVy3b5xSJTf7MJwemdYQRyAkyxCnZxA0s60mxmyRIrPMq+kpc0l8bcPu"
    "rvVmzZojYlIhrI/iTTyMP7aTYOpJhF9jyTKXT33+yNhBtsnTLGe4deP+GSfF7WtaZLn62uNiUiHyq7LEKbIizhXXLJ02V7tPvb+z"
    "8dFE+HyaFwzM5y8VqRA2J/EmHqM1Oog3+QSRVyFftPja5uPVHpFVY77I12/aM61/7Glz7ohuJ7Fo8fp182Mn0yHPaasXx6RCG69a"
    "25cgBGWfzEYYm4l95tnW6ec6HmQ0Wojwm3EpS6+8h7/4q5P4k0uO7bpq50+ziww3sKiUA365fYSPf+wB/vCkzXxv01PY6SJ2uqAq"
    "B83c05gWxdjGbZv2JRz1NC9YOjcmFYJmifr449RGHqIx+TRR0OT4lRk+8ZmjYoK7Lcxoznp2aXdFryURBd4MoqATufDs7kx7H7Sn"
    "6bDIg5FO+sX926vsHWrOepWTVuc5fkWWyG/EegZE4WGnQni+SbNlMTbpMjKWolKzifwyeHug/jBUHoCpH0ub1ntKRjmZGQir0BiE"
    "8s+hfDeU74P6LvD2Efh1JssO+0dTjE85VOsWGhr/W6AjFjT+RyCEQRBaVGoWkZD5hnOiGrmUh0kLqIEYh6gXUkukERdGQABhRUYp"
    "iAoIDxFCK3Ao1TOMT+UpVTKE0fPAmYmD/se0w1IrEfbaObXoODrPZdE3ExtqipPXSBXoZmkffn0SISKcTC+ZvqUcvzKjDF87EWo+"
    "0yh6JiM1X3R49dmL2HzLSHyC8YNbDvDWSxdz2y271YlBgInDa88+inzC+bxv+1TsdJrKWN475PHFG55KCDu1Q7c7Ick9BYtauSPo"
    "9+jg9BDI7vzwk5USdtCYJGhIR8XO9LJ4WUad1MlnrJcd3vTKnSxfUeTkNQWOX5nm+FVpjl85zciwXCV4xTRDzcR8FiNQJJ4DEcka"
    "5YaJnS5OM0TdgxugCbIpmQ7xrJodQiAiX5bP8+tESqDrtWuP4PZNI/F1frKlzPnrF/K56x+P81dlmorJ31//IDd+/hR+vGV/nLdt"
    "4vLG9UfOOnaS/ftsfZIM0Q9bU1K/IG0pIkDQUX23Wb5KOt5BeZioVQbTwsr2Y2Xm8cpzCnzrpvH4eWplSRQYphufFMuc12ebuJ16"
    "7bEzaiQFOlUOfhQQ4hHhJXLfLTU+O+KV7VQiE7pzeJWeRtt5euEqdbochUR+BcOwMN08v7x7Sp3iyQiHQiHDuy6XjkNYGSas7ZG6"
    "D4aJlS7LfPLsfK64dhHvOO+xRD569xz+1y0H4lNUA4v1b34hS5dlEUGdoLKbqLYfETYx7CxWUMcqHsXyVRlesTbPT7c0ZhURBLjn"
    "7rFE+LpLX7HAZ697ctpaI2aEULdD8sFlZMiTkUKrerjn7gNUVbSGPLHP8YFrZWUXWUFiGKGeX6TngBCY2QX8308t5g1nPBY7bM/p"
    "PMQwlc6JLENqpucABhtv3tG1pv/J5S9IrIkmZ5zj8MONbZIy4ptfmuSKa+dL8cWwJUtJmu404tFKvJ9ECoxhzOp4Hux9diM66N7z"
    "0GCly/m65PITFKlwAL/0NFFjTFaGcXqIggZOr3zv563rZfOmUrwn3H93k3dc3rmujF7pOHSvWivHc1DdQ9iclG5aZg52bhHLV6XV"
    "mLbieZDEL7aNx6KPJmn+7JqXKFJhCr/0NEHtAMJvYLo5hF/D6T2SfLGHiy/vZ8P1ozI9DIsH7vam7RFtMlY6kWeePVPA/viVqa6+"
    "PmFlcRbC2eG4FSke3emrZzYPQvI4iff17GZz93gwnt3QiCKisCW1huqTeLbUEvjYX6/iXZf5fOumcR7bCb/a3ha5tVU6VQ4wiWjG"
    "qQgCQbUccc1V97F0WZaXrV5wkD1MHHRs3bttMt4bDCyu/tAfxKRCY/xJvOoIUeBhpXqIghbZuUfzirMLqi/DaalvM0e/UGtv8v5B"
    "s0zkt7BSORV1aSRK4qroQmPa3Jq1z50ZqRCnrp6nIvdk2tDIsME5pzzIyafN4fiVWY5bkeK4lS7Hr8gklg5HpfPYGJYV23niMPQW"
    "hIBWy2Ri0gX19VwmwDFbSkOsAtEUGPNlelWkUv2imkyDoIksvx3itQxKNYfRMZfJKYcgNLQigoYmFjQ0kmg0XUbHCwhhYfU3yGak"
    "eaMKxauNtyZF24w0WAXI5CDsh6CE16gxWYfxyRzVuvv8kAqx46HqCj3DRmJaLobtSKVf05LCe6aplH8dTNt9Tnc1Ehvq8StyREGL"
    "VnUcrypPMUUY4mb7sFI5AupxePDBT76SKs4qV1yF91lulis/dBw/uGUf7XDazZsmeOuli/nmTXuwyRIhQ5ff+6EXdl27HR3QiRxI"
    "c9ON+7DJxgamDB3vlBHshKen4hD6X22fTQ3aTahISyPCr0/g12QZvChosmjRkbz10qV848tPdInUPbYz5LGdU0R46gS6xUmr87x+"
    "/ULOX7dYhblaXYaWGTsH5kFc51CdWPugTq0jvyZLSBoWIp2nnVtqTFOmTj5ZJ8e2/WM+68lk99FWJEMz/ZqKWpjkrLVHsHjgN4wO"
    "Sef9rq1l9uxusXnThCIPbCDCwOYHm8Z5/zUN7tpawlZGabGQ5dVrlfEpAimc2uWgG13PIoSIiZF22LtQocby1KlFpCIQjLCFYdrq"
    "dxYQcfwqSfREzSnC+ihhqxTnH1uZeQgiQhqxg9PJ/ZeG3XTdgnadcUQoNShEmHAo2toHNrt2NFn+ogyGk8HwXEQgHUThV1ixsg/i"
    "tI+0OiGXY7RSgocHG4l7RhQL2YMQC505FnllhF+VIn5ungcHp1Q0hAwRXrVqHoWiLU+Bm2NE9VGi1qQkTkSE4eSwsvM45fQ8EU11"
    "3ZnzfNeOmlJ7l0b1WWuXqv4dJ6ofIKyPIMImppMD08J0ixi5RZy0Js1PtkzNEHVso1oOFYEiQ9jv2lLh7i1GHJ4s54RHRCt+9zPF"
    "Ky0qJTmOHtrR0UMxsFmzZkBGVQR11db28xuIKMCws5iZfpavypIteNTLRlf/PvtCqkQ9rRSGk5fEQqafm2/+DUNDlTj9w8TlDW9e"
    "3PXVt1ye47aNB2KSoFqOuO3mCc5/cz8ibELQiPUtuglcOyaV4592iHwXmdgR+5w9gU6oSBl/hlo+wC+3Tam1SMRr75lqDoeNCaLG"
    "GGH9gKzG4eZlpYNUESu/hJNOT3H7ppYaszbVsjnNaXfVvLFjAi0K6nKuNsZle0WIlZ7D8SvThNTUnJlJkuwbClSFGBObLKetmadI"
    "4jGC2gGC6n5E0MD0cqq6SRHT7eGkNRlCWmoO2jy2s5t8bpMK7Tx9GVEh4vXYtNP0FCGiXQHAjaMuRBQggqas8AL0FEP1OecgY8uM"
    "+yJZCaFDGhnqYCFZ0SE5HsxDsDQiqbMQeIR+jbBZIqiN4ZkOixbP59pPLI1X40cGPR4ebLF3qMW920sM766yZ7imInDCONJKEHDt"
    "e3/Fzx44a5a7ddJDxCxe6Z7hamIvTnOK0jXyamN41RFa5RGioIWdzmNYDk6mD7dnHmecneXhneOJ9A1z1meVa0fQJdYbtmqyfKZl"
    "Y7nZWFuG5F4aa5ZI0rszx6YTfN2uzfIVeU45bSH33TPWpR3y63sCfn1PuctWePlZvbzytXN43UULcLO9eJkifn0K064RBS2MaPY+"
    "OxR4nsnEhIsQJswNKRRsTKURgZGSkQqRJ4kGbHD6INMHwXyISgTeFFNTVQ6MGpQrtiQVNDQ0saChMe1MJjJotFwqdZNCMUvKFFgW"
    "IAwwe8Cai4xUGAWjLhdfdz64ixBBGa81SrVRoVIzCJ+vhVYIeUIshAxTjMJZP7Z3yGPh4ix2qkcy7Z50OGwnjZXK4aR6sFMy32/n"
    "zlGIT7GNg5IKbWMGTPJFC69WImiWCZpST8G0HAKvjpXK4VNCkMWKS/3NzuJPD3sMWjUpAChClgzkecVZ/fzsjjICwaM7m3z7y/sY"
    "GRYqpzTgVWctYclAZpbTtM7Gn6wMYGAnnPG28xmqslLEofUyF9WahVjoFs2L/IbMP22W5Kl9FGCl8nzkEyspFE2+eMNQwpm0Eqcy"
    "EYKAX24/wC+27+OrGx7lWz9YPS3sXyT6POGwqpJb8kl9jGmGvgiV0rypxLcQ6jnb+blKubtdDcK0pbiXZc+i5m1yKAodQkTSsGnr"
    "LDRLkF/Ma9Yu4ps3jSgCweCqi59QIb4Q4ZAvOCpKxObKix/GoaBCvQVvXH+E6uM6IvKwUgV1ChbMMi6RaQSq/REBBr5yAvzO74UK"
    "HVWRITIawOkyyCKvKvUOWmUMy8Z0exBBA4GvxnVOlS7LJebMwU6BlbBl5CGCJmtOH+Dvrv9NV8TOXVsqLH9RGjPVKzUWhNStiFpl"
    "/uqjJ2Bl5krRzGn4wnX7eHxwpMtBWKFEFttuTqeCRufkXwQNWc5SRIgoVGOnSVugNU4viXyZnhM0EEFTntiHLflvUYBhOvhU4vky"
    "nQSQ4n2yb6240kY75aeFCJvy2oaJCJpxKtHyVSl1XUNppEQzxmRbl6W7LKUkSsOEE9OeE9Lct+K2mhjcv63JKafnqZYNLHII2qJ7"
    "6cTzt+RP0JBOQ7vdoY9h2xy7Cv5jW+05RiyYUojSzmK4ecz0HAzT5aYNDyQiBlK8af1RXfoBsm/SvHSNyf3b6rGD9M0N45z/5jmY"
    "qT6EYcfEgpHQTYnD1U1HVo6wZJUH+Xd3FgI5MY6VwGV7XrVJm4jWbLumImtFnM8v16xQzoGwpd51E0yHKGjE733xMpuAmnJ50zOi"
    "tCQp3B0dIrwakVeR0UWGgWG5RF6VQrEfnxIWgSIqM9Oule7aH9opQnK8y3EZ+Q0wLLmmhc2YkA6oqtk1M13ESFSAaI9HqZ9SwzBM"
    "TFvm0/uUMXGVoSvUuiP3PllmNktAHZ+qGuOpWfdQun7aPq4d/9D+c5Y3fDi2hxCRLCnoNzCaZSwnI/cM0+a4lQ7HrXSBPJcxN7ZD"
    "vnTDCJtvGYvJhQifA8Mt9gzVWTKQnebYt9O72oT/9NElhS7bkRFLBtLyfCdoEfpNQr8unWxV3jpSaW8RLUJqCbJSrfdRmFhbw/je"
    "kmiVVY6iKIiFEttzoC1Y2+5H03ZlaXI7hRBC/nfXXtoh7Kfji187ic/f+Cjf/sr+LhtDqDK+7X678459/Nsde/nlPaN84tPL8esl"
    "vPokQatK6DXA8H4r09LzTaq1NPmiRc5IYVimCqTLgqMqDvlTIJpgZaVYuT0faBBE+6i29lKpVvB9TSpoaGJBQ+MZ/fggdPCjFBEC"
    "yxBgpWUpSnuu1FYQvhSzMVJysXXmgTWH0AQvCAjD1vPXHpU7L0tABTLPbhY8sL3KuRfNIZXrJ2hWECIk9OpYdopUz1zcnn7sdIGh"
    "oRKVcgu7Kz/YiDf6ZzqFi0Jf/XjxfwtVMs2n1BUJMDtVMdNpDf06YatKFHiYdoq3XXYEP7njvviE+MaPDSdEGUPefpnMrQ496eBY"
    "bj4+dYAIkxSFQpaVK/tjFWkZreAQ4SLik0oTsLHi/FN3lhbPPMEX7dNoVY4rNBuEnqwp/74PvZB3XHosP9g0yk+3NvjVdm+as955"
    "/l07S3zyo7/hus+dOAuxMH0QRF2nh0ZsCCk1/3aYZLuCA5H6nN3lQJt2RjrNCFUeqwfDchnaXZrptD/7wJQGdNAi9GtErRJhs8S7"
    "LjuBr980RISHicsjO1txGO7565ZiYLB5kzydfnwn2OTVaVXE+esXgwji8ovCSmHYGUUGmDPUuoWSo5N/94kwY0M12S9CiC5HyYxL"
    "Syol+ciXEQORPHmVhFFIREhAmXYaRnx/o/vkt6tTolClibQQfo2VcUnRTnTINzdM8Nb3zCFfnCcra4AqyebLZ1ch3kxzEDbf3FFG"
    "b5fEO/n0/DT3wUnMs3aqTCCJAcOSf8cjpBWf7MYOnepvw8lhRD4YFqadlf+mqjMElBP36XayCgWXqbIXh5u3IwQMK63Kb+YQhikd"
    "bDsbl9Uc3DFGQCXhBESzkJJ2LDT4wpV99BVz6hRWEOIQYiNIEal3ZKrTYUuJXoIpnRKgWEgrQdBAhbK7M57fDFvScXXabZWO3rZt"
    "T2NTmFWAdnaGVmkrWClMJycrOqT7ufvu3QwOjiac0hS3bRznnzc+EEdZSYenqdYrR71xl0cGfXbtkBoVkWEk2jFLaLblYKQKGEFd"
    "Ru2kihhO/pmndhRiWO0SwoEiFZx4Xk0/9W0Tf2Yc+SBJTNPOyrHk9EiH18mpMrbyPezeXcKnrOhdaxY6xu0iRuX6G3Tp20jSy1d7"
    "UDlOh5hN2V/+aWORYddgneUrs5h2GtPNyigaw1LlGzOYliIe1BrQTu+Z7vAnSxe29724faYl924CAspdETbtdUeSWQE4EFAjoBKT"
    "srPvoTP/3XSyWG6PSnWSfz8sqEpBpuVg2CksN4eV6sFK5bGcrIr4Egi/qcjT9v7jYqcLYJgsHnD5+GcHWDKQ5qYbx+hE2XnsHfJZ"
    "MjB9/IRqzfZn3f9E/O+yIsbDgw2OX5HBcjKyfW4PpuVguVksJ4NpS0JpqlTFT6wp7X0wuWdE8b29zv3V80dRGK/vnUg4uS5VyiG5"
    "XA9OpijftQAnXcROPfO8Cv0GpmmRL7j8379+IW+75Ch+ekeJn21t8et7gsQbTtoLAbd/Zw+LB1zefelc3MoBGbXQqsoDGcLfytaN"
    "hEkYZYjags2mLUtLOgshrIMxDJ6ydc0CpOeA2UtkCoJwijCqz0oIaWhoYkFDIzkYbQPbMjANFTZt5sAsyhKTkTo9CavQGga7AHYR"
    "w8hgWTlsJ4VpeUTh85dsJkSkSAWP0G+yYsXCGc7oP2+a5NyL5pAuLiSKfEzbJfSbWLaL2zOXTFGG2H76hrvpDn83OGl1jzqwa8k6"
    "16qyQvLcIHZwRdSdjqH+3j4dMEkRzSpwNLvTGgWeDD30W3i2y6mrF3HcihSP7fSU4+Mqg9Xm2BVpTl7di9+YImhMyRJPpsvJa/oQ"
    "N/rxyVa9DF++7eiuWxrP5iXPbmlNOx0SiY8aHbE+JWaI5VIoOlx82WIuvkx+6uHBJnuHPO7cOs7tm/ZiYBBhIQj4ty2j8LlpJ5vT"
    "WywiGR3QJpm6Qv7D2LA0Q0++VUMZf7Eh1Nn0rXQRO9sv37HpYmdlWOnQUPkwTrRUJE3oI3xZmixslVi6bBnHr8jw+M4O8SE1Hhwu"
    "WL+QxQMuWzb5iWeVjsnxK1yWr8wS1seIvCoYBmbkY5BRxmVSJ2M64ULixDpIEC4upptHREFcRlReq91HoquP43EtRGwQB9TUSWz6"
    "EIw4FVUUSlIh8ioU+wc46+wjuHPrVPypajniug+P8IkvLMbOLyU0XQyvBFGonP+oK0oF4AvX7WXPUFt7QaYanLe+MIvj0Z1a03YU"
    "iQKEYSCCFi9bM1/1gyQH7ttWo1IKyRezmJl5Mh/ezkgjO90vIyiArT96UvWHE4ecJ3HCqiK/2NZUprHLnVumePU5fZiZuVi+jHIS"
    "QQvDyWBl5ymdAdiy5VECanGO/vR+LhRcSuVI3dfhymsX86pzCoe9np6wKqfuI3O379/WZM9ujyXL0liZ+RD6RFZKjsH0HMzMXMBk"
    "+9171fNbhIcgchrPadOWoo1uHjMlRRc3bvxZV962JEDScVpAd7m8UBGkUfyOv7lhgk9+YUnsSM1GLOzaUeeU0wtYmXnKi/Ax3B7M"
    "dC8ApdJBCPDIQxgGhunExEH7R/ZT572/bM3crrQrE5s7t5R51doCVnY+UdCQKVphK06psbLt8fS4Sl+QzvniAXvaaG6nTpndc14k"
    "1wERz9vOXE3NGEMDAz0MDVXitLafbCmzfGUWKzsf26/L/vUbGE4GO7eg08YtTxBQj3VLTlndOwv5bM8ewdK1jtSxVCRP3DYhVNPb"
    "0VQNQurxPjobrTDbTmZn+qST6TcwnSx2dk5M2D1HZkHl8aewUj3Y2X7c/CLc/CIefiLEIGLFyjyRCIm8OiKqy31PCEK/geV2KiCc"
    "tCbHl2+ciCOnZkuRbNsZnZSJmfvwoqUue4cb8di6a2uZ41dkcHNzCVtynxCBh5XO4+YX4ObknrZ162OEGARxJEk7YiECQjDNeGyb"
    "01Ih5HMYmCqyp5MKISMKHh5scNLqHlKFBbLEpBA42TlYTppyufUMhF1AJCIsdd0lA2neckmat1wif//IzhYPDza5645JfnKHrEAj"
    "bQWfO7eO8adXH4Gd6sG0U3JvMH67SAHDAMsysR0T0xRgCDAyYBWRET+SXEa0wN8vIxnsPDj9mHYW281gWRZh8F9KLOhwCI3Dhq4K"
    "ofG/YyCa4NgC1/GwrAislNRSsHLxaXA795igDK2npIJuWMVxUqTSKRzHeo4VGJ7F5xVChiN6TYJWjUIxxamnLen62H/cU2Xjl0cx"
    "TItc/xHkFxxLfsFx9Mw/lp65R2I6ae7Z/jTf/c4OSOTx9xRcTlydJwyahH6jSw15JsEhko3qZuOVfkGknN7Zd4dZ8hxVmKXfLOHX"
    "J4lCj7ddepQ6qfPVd6Ua/MWXLkVEgcyvrI3j1SbxG1MsX1FUDmVH4O+fN5WetWvv21bm/m2V5/Qq2qc6hmVj2K46IcphOlmGh2Ze"
    "6/iVaV5xdoFPfO5Ivnr7ixLK3zkaZWfaItjOBze6SCVUVIischHFuaH3bVfPaJhYqXxcWq1QdLpIhbbqtGmncQuLcQsDuMWlCQP0"
    "wLOciR2sPyJ5yh40pNZCcwoRBbzz8mPj8dDO41++osBJa3IsXuZw8upiojSkzDN9/fp5IELCVonQq0hDWVXMSIaidjtAndSgZAip"
    "IGTvbjmOzVRB1YI3E587mBDd9H+L1Glt+0QrPIQjIFWK068RtaYImxNc8p4XJd6bvPfmjSU+fMXT0pDNzcfOL8PqWYSZnYuZ7o1P"
    "dQG+f/NePnvdo4TU40oRILjs2uIz2GDdBEwcku5XWbFqTlfZSAOTv/nwPumk9CzBLhyBXTwKu3g0dvGImAC47rptqj/aFSu6o6de"
    "s3ZeXGnAwOIHG6fYtaMpHZXCEfJ6vUdjF47EKrwATIdtdw9x97aniGgmxky3ofqacxYl9EJsvrVh8lnHZrkU8I0vHaBSmvnOTjm9"
    "QL5gd4nJXvdhWZHAzC3CKh4p21k8GqtwBGZmnnr+7YSJdkYEz2q5G4aJYabkab3SVti9u8SmjYMzKgp0qmI409TqzS49BBObH26s"
    "z3g2g27dj69vGJH/7vbId1o4AqtnSTzndw52O54nrMx20lWCRjwHOuRGxJ6hmY7Ty9bM7SK2rvvwfiqlEDNVwFF96fQdg917FHbx"
    "CDAdBneMsmXrI6ovW0T4nHR6bsbzHDQ1S6UISs+87Zgnx2Z335y6pr8r7PwbG8ZlG90enN4jcPuOxp1zDG7fMbi9R2A6WYZ2l9m0"
    "8Tfx2BT4HL8qNQux0HlHs80/ueI047Wke3wnUrJUKldnjndjybJcYoUW7NrRUIRxL6niAG7vMtziQKzZ0Hm/xiH5Z4YiFkwnjZUq"
    "4OTm4RaWcOsP93PB+d/jDed/n+9segTDsLBSeexsP1a6V0Y1uN3CxN+8aV/8rG2iZPFAapb3S7wuSv0Ypr23eV0k/81fnqRSCrFS"
    "eTL9R5GbeyzZeceS7T+KTJ8UPv3Kl3/F0PDYNJtEpZ9EAVHkTxvb3fe303nlwEsCIB/vpxKbb5kAINUzn2z/kWT7jyJdkIc9d2x9"
    "vOsJFy11E7aljeXIdX3PUH3Gsx63IsW5FxX59FeP4K///ujYVrDI8fiDEablqpQLW1XX+G2JBQPHMXCdCNsUMkXKyoOZVxF+kUwD"
    "NgyIGuAPy2pp/hi2bUpbN+XwXwwdDqGhiQWN321YFjh2hG1HYGXAngN2EUwHEUX4nocXGETtIBtvDJpPQTCBZRvYjoltGxjPG88q"
    "ZFh26CkHvIxXn+Jdl744dpPam+an/3w/N90oy2E5mV7ShQW4uTlgmHzly/fyJ+/4bldJQwObiy+VAmt+o6T0DrxZDaNDWf87jl10"
    "UOJ5utsqokDmSrZq+PUpvOo4b1h3FAuXWrGBaGCyZGmWc9f14tXG8Gvj+PVxgsYEfn2cfMHk/IuOSOxBBn/7sQM8MnhwkmTXYI2r"
    "3v4g7zp/J+96/SPsHZrtudvOeZJIMaTwnOVgOVLTws70ccumQU498av81Ud/Qbk0e7rKkmVuwpmWJcy6F8H0zPz40FcihA1euLIv"
    "4RjLFv5g07jiFpz4VH7FyrnkCx0dgb1DLb510wFFLmSws3OwVNjm9m27uWPrY3RHZxzi4FXaANKRrhM2y4TNKV67dllXWUQDg7de"
    "Pif+2psvL8bGbls9+9z1BcLmFFGrjPDrKsS0TRoE3REGqBxulR8NxH3Tfk9fuG5fYuiZsxjyB1ciT477zmlaeEizQIgIQg8R1AmV"
    "KOTqNYt552XHdqmlG5j8cGOZi8/dwYM7Shh2SjqeqWJMKgztrvCut/6MD1x5Nz4ybDykRkiTS68tsHiZJUmn2FAWiZPuZNUQ1Vd+"
    "jcgrU8jbvGn9sV3z8gcbJ/nGl6QjYmXmSWKh8AJMt0ip1OSKK/6ZwcGR2AhvP0cSZ54zL/Fe5f/ece4T7NrRwLDSWD1LsItHYfUs"
    "wTBdduwY4a1vvS1eO+iabx28Yf0Skqkk92+rs+G6qWckFS4+90E+9ZGnOP+PHuL2m2cSEWeeM4dOhRCDn2wp8+ErhuUcSfdjFY6U"
    "pEJKViK44oofsW3b7riN06OBDnrYpqIVTCePkerDTPWxceOOhKBnu5xiOo4CMROVaNpl6eTvnK7f3X5zN3l69tojE6aUwd4hLyav"
    "ME1Q6RylUosrr7ija84vHsiQL1oIr0LkVaXYJzJapKMRI/h/Hx6aQWi8af3RXZTk3iGfPznv6Y7jXnwBTt+x2PmlGFaKwR0HeN15"
    "m7r6Ml+weNXawiHtGQefr8FB96AL1i/qGpu1csQ72210ZBvd/uNxisswnCylUou3XXwbpXIrrhwgiLj4srmzEubP3MbudeRg40Yo"
    "HZ4OkdMh35METnve3XVHiV2DijR2e7CzczFV1MBXbvoVw8NVwDxopMOsW7RpyTQ5N4ed6eX7m/dw1fvuoFxuUS63eP9VP+Hdb/83"
    "HhycwDBtSaqrE34593w++dEH+dc7niKgEqfyLF7qsnjAiUsVA7xs9YJENIpg86aJGWPrwnVHJghvg2o55NILdktywc2R7ltGdu4x"
    "pAqLMUybO7Y+xl/8+U8T76x7LIigReQ1FGkxP+G7CjbfMhnf30rlYs2E01Yv7Or3H35nks23yDXFstMxWbBz5yh/8ec/T5CABiev"
    "7oxp006BYXHrLU9zximb+eyNgwd9FUsG3FjA1yZHb6HYOdwR4rBLTk4/RLMdgW1HGLarbN1eMNOIKMRr1Wk0AzzfkktAUAFvCPwD"
    "mGaI7djYtolp/pcGFdS1V6JxuNCpEBqHi+D5HD+WBY4rsOwUWP1gzSGKDLzGFM16k0atRtSySVs5Mm6dlB1geaNg7ce0bVwXHMeg"
    "+TyutUJERIFH4NWlgE91nNecfTQnn/YI/3mPHxsqBiZfuXGEb3z5Cf7orAyLlllMlSps3foQw8NT6hMpdUKWYmBpkbdcsohWdRS/"
    "PoUQIt4ku8szJgykOHyTONSzs+k+u7M2jVVARBEi9KQYEQK/Pk6qsIC3XXYU13/scSxlYP3xul55plObwK9PEjTLkrm3HLzqKFd9"
    "6EX829Y9tMrSSKiWQ97z+n2su6zAH6/rYfGAo04Kmty+aS9fvOEJ2rnq920f442vKLPtsZNkmS3TkUZA1ylzx/iSp5Ayf990c3z/"
    "tt28/31bMHD4hy//il9sG+UD15zIqavnxeKMuwZrXPeRJ2MhKgOL41Z052R28nfNbmLBbyCiENPJcObZA9y5dSQ2cv7ivbvZu7vF"
    "Wy+b3yX8dtbaI7h10574vdzw0T3sGqxz3rpelixzGRoqs23b09xw/b93KefPVu7vmcemNBQjv0HoVQibUxTmzOWCdUvZvGkSQcjC"
    "AZtz13dIlJevzbBwQLBvSE7dl5/dQ75o4k1OEXoVRNjCNG0pIgezGuMiCojCJkbkYzo5TluzgIcGywnCZYJKKeLaTy1mybLUNOvZ"
    "mEaYHQrZkHTUn8m4k1Ecwm9I3YnGKEGtyAeufTH3btvOE4NBYr7aPLCtxuvOuJejV8Kpp+fJF02mSk22372Hhwan4vB/oajMCJtT"
    "18zlPdf2SyfQr8pxmJmnnihQ4ydKEJMBIpKVJzAsosYoH7z2RH78o1E1XySu+8hefrxllLddPofFy2RKwuCOEf7mup8zNFSJNRk6"
    "5KQxjThL847Ll/H1DXtiIqhaDnnHuY9x7puzvGptgSXL0uzeXWLjxt8oB9uMRVYPRmy97PQ5nLl2AXdumYgd3C9dN8l9d7e45lO9"
    "XafIt968n89e9yR7hloYmAwNBfyfK+ssXnYCJ58i+8JMFXnvtUfwLz/aR73cGVubN04xvLvK69bnWb4qiyBicMd+/ua6uxkaKifK"
    "fyZFaEmMAzHDUzOmiTaWSk02fOn+rvKMb1x/FDd8YcWzzrU3/tEQjw12xAy/vaHCxe/pEHYrVs1hYCDP/qFOW36wcZI9u5u8Ym2W"
    "5avSbNnyBBtv/jWlcjNOuzCweMflSxBBg7A5gfCqMnXD6eG15yzlX7cOx/d4eLDJ2897jM9984h4Xr1x/VH844bHusr1PjzY5IIz"
    "HuYtlxdYvirFkoEMu4dK/OhHj/Dlm+6PVf7b/XnltS8gX7RmmXMziW0x/f/FdDJwJjl16po+Xn32fH6ydaLTxp1NXvOSh3jL5XlO"
    "WpNj6UCa3UMltm17mps23E+lHGCSit/12y9byuJl7ixtibqIz3ZalTDEtL10ejJXotpTwsHt+pQQhF4N03JYOpDjhBUFHt7ZjO/8"
    "rtc/xVsu6+XE1RkWL3MY3l1m06ad3HLLTjVezWnrungWZkGVpzZtKjX42Efvoruyjc2P79jDv92xnxNW9PHClX0MDEgy457t+/nl"
    "9tFYx6Ktd2Hi8oFPLJLRhtVRmTqQ6+fMsxfz2Rsfju/+yM4ml5z/FB/8xII4PfPU1fN59VmL+akSdJafa7H25IdZf2kPJ67Oki+Y"
    "DA2V2Lr1Eb7znZ1de1m7ekusqxC0iKIAw3Z52er5fI4Hu+5/6QVP82cfny/vrwjpCy86ls/cuJNmudNPf3n1Xn5wyxjnXpQnV4z4"
    "l61PcMt3fqP2cTe+/3kXzY33ccNyuO2WvVx79b0IAj7zt7/ix3fs4aoPvphTV88lX7DVuKxz/Z/vTtgKDq86q0Dg1wn9ptK2Cn9r"
    "csGyDVzXxHZcSSjY/QiRwm+Uqdfq1EqjBPUWruXQkw1JuyG2mMCwRjDNHhwbXNfCtEypSfH8wwdGtYujoYkFjf9u7AIWAcXfdhyZ"
    "JriOIJWysJwCWAWC0KBRHqc0VaFc8mnWG0SRRcopks85FHN1csLHsfZiYOG6Lm7awawFhM+TzkJbvDH0GviNEs3KKHamwIavvZK3"
    "X3A3T+4M47r0Bg6NssMPvzOKT4mAKiG+MuJMRSxIBvwzX3sJ6VSN+sQIQbOiyitlYumw6aeHIgqV0RR1CI/fYkORDo8vdRb8BiIK"
    "VNTCKG+46Ci+cMOjtMotcgXBukuLeNVx/PokfqNM6JUxDFndwEuNsGhBno9+/KV89KqH4tD5StnjKzeMsuGGYUJqBNTjE5S2A29i"
    "01NI8Y+3v4igWZZGXFvtWZ0ykagiIMKwk9tvmBimxd9ev73ruR7aOcblb/85Ji4nrOinUorYN+zF5S3b7+k91yzqHn+4MwQ0I79G"
    "2KrIe1k277/mD7hz69aud3PTDSN846Yh/vU/XhoTGR+45iR+vOUArXLn/f1w0yS3b9qLxxQ+kwRUu0rddcqFmodOEAkldhg0VTpE"
    "idCr8pq1S7h9034iPM5bP1NMbP1leW746F5MXM5Y26+es0Tk1WSOv5WKT+o6p+OJsRg0pPK6EASGyQeu/QO+u/FJGopYMjC4a2uF"
    "e7cN8plvHcmpa+Yok9CKT/DajrGIq0dEsd5CWxBueqSEsk4V4cRM4060oylaUr2+MU5oZ+npTbNp8xreet6veHzQS1Q5SBGR49HB"
    "Eg8NPq3GaFsh3ZhBdixfmefz3zqWqDlJ1C7j52QxnHx84klCrIxQCcQFsjRhJALCepYli47hLz/1Uv7PlbsSURQGD2yr84tt+9QY"
    "KRHSIMJLCNSlY8FBI6ExIMIWhpXiY586gV/ePcEjg2H8DJVyxDc3HOAfNzyCz5Rak5pqLliJsprdpQKFX5VEgJPjxi+8mPXn3stj"
    "g510l/u31bnwjClC6gTUVLh5UuzNwiTkgvX9nHxKRFgfkX3hV1i6dDEf/dSx/J8rHyWK0w9k9YV7tu3HY5KAMgF1BP4sz5/qiNSK"
    "QKrNTxsnhqH0FawUhiMFAn90+yOUy93Xu3D90k4/+nVEUJNj0nQxnZ5YOPKtl/fyl1d2hFb3DQnu/FG5S2/i77+whnXnbUu4iib3"
    "b2vwi21j+EypqBcr7muTFCtW9vP2yxcRlJ8maowR+XVJLFhp3rT+aP5hwy4eGexEYT0y2OLMl+zgE59foiIB4B++uYZzzthGKyZq"
    "HPYN+fy/j+zGZ1LtRTUiWjGh0I7SuHDdEbz98kUyVSfyMd18fII/PWKsa67KgRefgCfJ7SRpGAVNTDvD9Z9fwVvOe4BHdwaYKkS/"
    "VhZ88fp9eHEbq2qPIB6TFmlWrJjL//3kUUq0V17PsJz4RNzo2ieVWCoiXsNmXTpDX1UfOHhkXejViFplWaTXsPjzT/4Bb3n99i7i"
    "bsMNowTU1PudIqAWl8hNVqyQekDRdFZk+uKlCH+ffFZw2+0X8YbX36oqvqTicQsmj+xs8PDOSiJVTYo3y1nvK+2CkD++KM8ZZ6Vo"
    "Te7Gr0tiJwpbLF9xBK8+ayE/uWMifp5HdrZ49/mP82cfn8vFl8q0nes/ewqve+XdjA1HcWpFrSzYcOP+ae+tU7pUtrOzVoFB5DcJ"
    "vBqR34Qo4NTTBnj1WYu5646prvtfcsETfOCv53LxJQsRIqJQcLnqgy/iuj9/LEEKG/zHPQ3uvWdUje8KFhlkLRo5rl//pqWctLpH"
    "vsPA48Boio9c/ZsusumhnRNc8Sf3YOKyfMUc9g15qq/dhLiuyblv6sWrjkobxW9IckEcfpaAYcgDsFTawUkVwSwSRSb18jjliTFK"
    "kzVq5SqB7+E6DvkeQTHvS4LBOoBpOqScHlKZFJZdJ/Cfd2LBB/YCj2sXR+OwfTrdBRqHiR8CvwRVE+q3JBYcF2zXRRhpWk2PqQMj"
    "jOwbY2ykwuRElVotoNEwmCqnGZ3IMzJRZKKSpVmrEjX3YRs1XFeFhz1fUQsCojBQqRBVWtVRGpN7SDt1vn7rH3LsilSilrilwud6"
    "sMnjUJjx84Kl8/n6rWs45jiDxuQwrcoBWcaoWZFCirHjNE1HwW8oFe4wDkWP/MazkgcHN5rqhEFLVprwm4ReHb9RwquOksuGvP6i"
    "xUS0OOPsHLmch1cdxW9MEbaq8rteFb8xRatygObUMOe/cSmf/MyLyBaiWOtBTAtdbleQaBtDi5a6fO32l3LMMRF+bYygMUnQLEmV"
    "/q6Qb3U25TeIlBK5CFtEQYvv3no+L1yxYFqaiTwh2rVzij3DlS716YiAc9f18vK1+RnLYFsR2lBGc9iqErTKMu2jsp/lxzls+Pof"
    "0VOwEpEUJiesLFAoOoR+DRF5LB3I8xefPDkRut5R1rZUKoZFDpseXjCwAJtcXOYsLs8Vn8qLZx6cIiIKPSKvHf4/xmvXLmPRgENE"
    "i7deNpfIr+FX9uJX9hL5NV63vpdMoUW60OK89XnC+jhRs0TkV1X5t2ac5jDbCWTkVYlaZcLmBGFthFyqznc2n8mSgXT8vAYGhWKK"
    "E1YmwlHjU2flvCqnu61y3q740b73zIAEX5aiC5WDM6NvVAhunA4xSVDbT1DeTU+6xrc2v4S3XDYnzqGWJeiyam4W1U9evZ+OE2uR"
    "4p2XH8e3fvgScm6JoDJEWNtP2BwjapUQXpl26b9khEcU1Dv96VeJmlNE9RHCyjBvXLeM6z+/Kk5ZQRFeFhmlA9LT9bN+/YvV33Nd"
    "5R6jlrpmdQ/Cr3HzD0/h+JVuXEa0nWM92zXnFOZw+pojsemJy0gaWLKfm+NE9f2E1WHy2RYbf3gKx6104xx0oSrBJOd2u+Rku6zs"
    "hz95NH/z2WWE9RGi+gHZZ9U9BJWnuXDdQv7m88cl+qz9/OkZ7bTp4Zy1JySePxsL7LUdYkkuRInQJlPmKpuW/NMwuf66bV0lJpcN"
    "9HHq6UVE0CIoPYU/8RD++EMEE/LHn3iIoDKEiEJeeU6WbCHoSjH61oapDvksIk47fQE3fv7ErlSNtqChTU79yL3BpodVKxfy7c0n"
    "EjVGZd80xoiaE5IQq48Q1vbzvc1ncsLKfNezGdicuqYvHvNLl+XYuPlUFg1YidJ8llprcrP2p00Pb1p3PNd/YSVh7QBBZZiwNkLY"
    "GFdX9dU63Zn/ImhIh1yESijVT+hBzERQO0BQ3YdfHqIn6/PtzSdy/IpUPP+6x+b0dsr/Xr16Gd/efCphs4RfHiao7ieojyVIz7C7"
    "jX5dEa0NIr8+I2pBLiN1qU0TNIi8+kFPn8NmSe5JjQmC+hgvWzOPd1x6ZNccN5QIqSRBsmp85li1YonK0c/EzvVBGIUuUjQKPUKv"
    "RtCY4PgjLf7trjezevUytS70YFPApReHIjYFNXenp+s4GNj86QeX8VefWUxz4mmaU8O0yvvwKvtplffSKg1z/WdP5NVnzU9o6BiY"
    "2CxfmY+J60LR4YtfP5HjVqTjPe+Z1pS+Qh9nnXVsYk2RpVZlqewyfn1S2Qx7uP4zp/CqWe5/wsoe/GYFrzqG35jinZcs5/w3LUnM"
    "K1NVlElPG99yXr3mrGV84jPH4dXGaJb20aqOMm9OlVv/bTVLlma6okDatsLDO0uUy0017luxSPOf/918Vp3o01IVIUKvrqqDid/C"
    "1jVwXBPHdRBmmlbTZ3L/Xg4M72Z07ygTo5PUa008L6JaMxmbcBkZTXFgwqVSbuDX9mFSJpU2sW3rv8KuHwN+ATygXRwNTSxo/Hdj"
    "C/BTYOS3Wmlpq+RaCByarYjJsQlG9o4zdqBOtRbMqPTQbDlMlHIcGCswPuXQqFaJvComwfMn3tg2SkSoBBxreLUJGqW91MafJmWV"
    "+O6dp/KBv17CgqVG7DzZ5JST0otLHy5z6C8s4KoPnsStd76co4+JqI0/RWNqL63KGH6jhN+s4KuNd7ozF7SqhK0aod+Ky06Gfoug"
    "VSNozc7p+PUJ/NokoTd7mpzfKBF6DRmeGLQI/QZBs4xXG6dZ2svFf7KUkAbvvqpAs7QXrzomyQ9ffcdvEbTKeNUxmqU9NMaf4vVv"
    "mMv3fvJS/uisTOwwtHPaO2X6TAqFFO/90HJuv+sPOebokFZpD171AF5NRUXUJyAOq20b1BFBqyz7wasTtCoE9UkW9DX5t7vezt99"
    "9jUMLJ2TcAbbJ7B2vMTlCxaf+NzR/PXnlkojpzpK0JhKvumu/guaJcLGFEF9Aq86QmtqiFe/upcf/PQMXn52MY6++NNrlhI0p+Rn"
    "G5MIEXLhuqP41u2nsWigra5uKGMoG5NOf3bNy/j058/AJo+lHEYDU0WnhJ0qIM8QdtkWmIyCBmGrTFAbxa/s4dVn9XPem/rIOBP4"
    "5WFFLOzBLw2Rscc596IsZ5xlE1T3EdRHZcRC2+D261LE0a8xPQ1CRkZMEramCBsTBLUR/PIQy4+1+NHPXsnFly2K3/sV1y7uShFp"
    "G7ztkPuoOUnk12V5yMhXhECDyKt0n+7Fhv6k0oBoSUdytn5R9d9F6BF5FcLGGEFlGH/qCXL2OB/+1JH84+YXcMbajGpTCpseHIrK"
    "YO/DpQ9HGe9nrz2OTZtfzkc/tZycNUpQepKwOkzYOCDb3yoRtaZilfOunOJWicivSYfMbyBUe8LqHoLSk7zhTfP45uZVnLgmHUfL"
    "SGIyHxMdLr18/JNn8HdfWI1DQRnPWRlhE7akU1ofIawOE5Sfosct8cOfn8oV1y4kVxBxv0sDPK/WpF5evPIF3PrDczj99GU4yiCX"
    "ToApHdzGmCIW9hCWn6InVeaHPz+ZP712HrlCEGtvGAmtgDa595q1i/n5r8/gHZfOI6wME9X2ETUOEDVGier7iarDBOUnecNF/fzg"
    "Zy/mxDUpNUes2IHqvI9ePv7JP+Ifv3WGamdeOVIpGVXhVyFsIkQwbTwY8XhARNz9708yNFRNVIJI8a7Lj0YEDYLyk4TlpwjLTxNW"
    "niYoP01Qfkr+W+lJwvKT9OQjzjjHSoh4Ch7Y1mL4qQZRfZSwupewPsqF65ay+WenctKaXLz2mcoBkgSWHFuXXLaKmze/jJ6UIqrq"
    "I5JUaE0RNScJ6wcIq0Pk3Cm2/uxVXHnNMnoUR3fFNYtYvMQkrO0jKO8mrO3jhBNcfvCzl/Kea+aRK7QjwtKxM+rEY7uXIwcW8Q/f"
    "fDk3fG4FQUk9b2UPQW2EsD4qHfPpJJkv91cRNmUkTugjwqYkGf3qrHM1rB8gqO7HLw/hTT1J1i3zg5+dyHuumU+20HYk3bhv2vPP"
    "oZcjBpbw6c+dzs2bTyNrjeFPPZkgFkYJG5Ox89eOrJCRV2W5dqnUsNnWiLAxSdgqE7UqhF6FoDFTByQmalvl+CfyG3zsky/i/378"
    "aHKF9v7UJhbkut5XmMPfffYMzl57VGJdT2NgqGgsFZU1IzFDauZEfoOwWcKrHqA1tZsFfS2+e9s53HLbqzlt9VIctTa07Qo3Xq+K"
    "8eHFhRcdy533/yGXv38ujfHHaE7txivvxa8ewKuM4JX305wcwhUjfPHrJ/HJzxyr1oqIl59V5KRTs+ozT9Mq7eX44x2+dtuLWH9J"
    "X1wlpfPe8vE8Pf20Y/j3+85n5coFatxlZYSMQFaTqk/i18fxKiM0p4ZwxQG++LVT+MRnjkncv8BLTjTxKgdolvfRmNxNY2qI//d3"
    "q/jMV09g4VIrQZyl1Vohx05/YS7v+7MX8bmvvojm1DD1sadoTA7RnNpLo7SXIwfq/PS+P+ajf30SA0uLcWTFTFtBCj/+7T8dyVnn"
    "W9THn6ZZ2o/XmCLwZDWO3y5iwcCyLMCi1QwojY9yYHgPY/snqZYbhEF3BILvG5TKNgdGUxwYtSlNNfGbJUzDxzSfR0NXmZvAbmAb"
    "cK92cTQOe5wLIXQvaDxn/PRLywvAi4BLgD82YM7BR9msf43hOAbFokHfnAxuJk213GBitEmtHj1jOlsm5dNXrFHIBxhWH5V6jvFx"
    "n2YrjJfKZ6QZniW4IZawsgxVszmDk87j9swlnZ9HujCfdH4+lpvlge1V/mO71Cu4b1uZ41a69BTh+BU5TlpdpKcnolkZpVU+QLMy"
    "glcbJ2zVALDcLKmeuWT6lvL0vhz1ZgrTsIn8gJUvrFOfeJpmeYSwKasf2Ok86cICsv1H8OsHwXayMjw6iHjRi0P8xhQobYDRySwj"
    "B5DlrITB/Dkevbl9NKaGpXPdqoIQWKke3J5+3J55uNk+fvazBmeckcFvTOFVRvFqklwQoVQnNy0XK5XFyfTi5OZKwcr8Atyeeewd"
    "9rl/W419Qx57djcQ+Cxa5rB8ZY5XnT2fKPDwaqN4lf34tTFCr90PPbg98xir9LF/zMI0XIgERx/h4UR78KujhF6yvfPUPedjuT08"
    "NFjivm1TVMqCXTuqLF6WolC0WL4yz6vWziNoluT9WhWIAgwrhZPr5z9+bWBYLoaAXNrnyIFxvPIegsaULNNnO9iZObj5hTg987HT"
    "vdz/iwYP/6bORW+zCVtlRNDCdNI4uflYqc5J/Z1bJnhksMXDgy0WL7PpKcIr1/ayfGUPt23cz8fe+4SKWMhy2TXzuOT9KZoHdtKa"
    "fBK/OkLkVTp1y2cMTkPWrXdy2Ole7NxcrOxc9o+6VCoGxx0TSmfFb4AQsu56usi+0RSVsuC4o1rKUB+XDr1hYrp57J6FuMUXcP8O"
    "A9PKytDzMOIPVlUIKkMEjQkImqoqRhG7ZyFWbj5Weg5798K3Noxx7cfny4oIIsK0M/zyl2W14Rj0ZAKOXTaGXx4irB8gCpryOdK9"
    "2D1LaBgL2fW4hWHK0oL5jM8xy0YJykMEtRHpzPt1GQo/G0uJiWE5GHYGy81jpvuwMv2y1GJmHlZmDpVSyH1313l4sEm5FPDQjgon"
    "nZ4FIpavzHHK6UUKRZuoMUHYGCWsj0qH25uC0JPXd4tYuUXUWcSux0ww05gCFs/3WdC7j7AyTNgYA7+KECGGlVFtmYuVW4SZW4iV"
    "mcuuHXV+skXO7V/eXebk0zP0FODMc+ayZJnUXrn37rIi6SwIPV7yB+OEtb2IlqwIYlhpee3cQszsAipVm/vurvHwYIvh3S0EAYuX"
    "WSxfmeHMc2T+8Z7dLfbs9mLSb+H8Egv69hLVR6TDKIQsVZiZi5ldgJldgGGlufNHUryuXAp4cEeZU07P0lMwOfOceSxdllYkwohy"
    "mMcQXgURelL3wM3LMphZ2U4zM49dOxrcd3edSjnk3rsrnHR6Wj1//7Tnb5cc9njJi0cJy09JsqIxLiNuIl+t1y6G04OZ6cfKLWZv"
    "uZ89Y1lMMx2fVi4/3iBn7iOs7pHtbZVktIwIwbBkCkWqFzM7H6tnKbVgAY88bMREqYh8jj26Qs4ZR4RNDMOSJSUzczHjd1qlUhLs"
    "2d3i+FU2iwccTjm9wJIlFmF9P0F1H2Ftn2y/V5aCoKaNGbd9kXyfmX6qNYdvbhjjre9MkXUmiZoTiKAFponh9qjxvYBqxeTebXUe"
    "3qHG9WCFk9ZkyBcNTlnTywmreoiaU4S1/QTV/UStSaLQx7BcrPQc7PwS7v+Ni2HJviIMeMmqEn7pKcLqPrlOAKabx8otwikewb07"
    "DCy7B0NY5DMBx7xggqC6n7BVBhFi2FmsTD92zwLs3AJMO8O922rcv60ez72TT88gCDllTS+nrOkl8qqSSKiNENTH5bsxTMx0L07P"
    "Qh7dXaDaSGEaFiLwecmqGn51L5FXk+tSupeGmM/DT1qYZgpDGCya5zOvMELQmJDj0U5j5+bz2O4eqk0X03DktVbW8Sp7iVplMG3s"
    "3DxSfUdiZ3pBSJHSn2wtsW8o4v5tDU5ck6KnINf1JQMp/uajT/LtL0/GzvWXb1vIi15cpj6i1vVaZx8TbRvDMDGsFKaTwUoXcbL9"
    "OD3zcHLzcXLzsNNFyqWQ+7fLOV0phezaWeOk1RkEEcevzHLK6gL5gimJ+sqI2l9HCRoloqApyRw3i5Ptx80vxC0swu2ZR62Z4dtf"
    "HuePz3eZ2zeFXx+X0RymrELh5ubi5uXYuuuOKvuGAh4ebJArRCxeZvKKs/pYvlLqPewdarF3KJDzJBIsWzaOFTyNVx4haEnS2Er1"
    "4BYWkC4sxu2ZR72V5uYvT7D2dTZzesfxKgcIlK3T3ufTxUU4mT7uuqPMo4Mee4dkxMqiAZPjVqY5eXWeTKpOs7SPZnk/XnVcHqwY"
    "BnZaPkO6sIBUYQGWm2PXzgo/2TohU5a2lzluZZZCweKk1UVOXl3Eq47RmNxDfWovrfJ+vNokQauqoiaDbomOg3nqs3zAtk3yvS59"
    "/TlSmR7q1QYTB6aoVn2icDa5bnkjyxIUiwG9xYh0toe6l2V0pEm1XWZTPGNMzHT+/WDYDdwOfEvAk6+8enxMezoamljQ+O8kFkwk"
    "mfBa4N0GrIGDFBh/FmLhoF8xDuEzz/gPzwexIG1ZwzBVRYI0diqHkyniZntxs7042V6cdAHLzWI5KQzDlDoIoU/oNQiaFZlqUJ/E"
    "q0/i12U+fBS0pBHkZHAyBVI9c0nl+rFcWcs+9Jv4jUlaFSny2E5/sJwMTraXVH4eTm4OlpPBAMKgpUL4q8qhS8nqCW5W5qVGPoEK"
    "M/Rq4wSNEmHb6bRTstxTOo+dymGaDlHkywiBZpmgWZVihkKVojQtTNPFcjOylnW6FyfXh53pw8kUsVI9mHYa07Kl0KAqbxm2KgSN"
    "En5jUqU/lBGhF/eDnSni5uZipXpkm0NPRRiMETSnZB1vBKblYmcK0qHO9OJkemXpRzcr600bVuf02lfPoCIRpKMdYlgudrqIlc5j"
    "Win5eb8hK1/UxwlbFaLQwzCtWK3bTsv7GKYt37HflHnupoWVLspykimpJP3LbWOcumbuQQfjhWfs5NGdXhxp8bffWMjpL6/THN2F"
    "V9pNUBuVp94HJRaQDo3tYjk5aeynejDsjKwzHjYRXj0mgwzLxXRycfUDETSJvLLUJAhaGIaB4WSx0r3Y2XnYmf6uz4aNCYKGSgFo"
    "E0xODivdK52wVA+mlZKh6ErHAyHLaRmWq8rFhjI6ojFOUFcOXehhtB2ktCQArHQRw0pBFBL5VcLGuHTuWyV1euphHKwMZYJcMC0X"
    "w85iunlZ/SHdh5kuYroFlUefxjCduJStTNFoxJUcomZJOl+tkiR5wgaGiDoOYHoOZnYeplvAsFx5oqWiEyKVLkHQkFEYpq3aUsBM"
    "92Km++X3U0WMOKffVPnrUqOByO+UmxVhIrViInaoiXzVnrx6vj5ZCcHNy7FgqsiR9juJPJU+oM5LI189b4moMSbJCr+OEJEcM24B"
    "I9Wr2tqL4ealMKIlw7yFCCBoEfkVGanRUo5va0r2Wfv5DRPDzkhyIdV+/j4Mt4jp5MBKq7UzTLTVVxEshvz3oEnkSw0NSQhMIrwq"
    "UdBQKTKydJ+8T0G9n/mY6TmyzYYpT9ubU/L7jbGYqBKRJ8eAYSl9hpxsZ2auJFdSRVkGWUSyv5pT8ruhTN+RYpEFrPQcjFQR0+2R"
    "Y9gw5bgImgivLKMSmpMy5aQ5ReSV5XxqkxpWCtPtwUyp95gqyHkoQAR1mfvvdUhew0mr+dcn/3TzGE4Gw3TlXBChVOX3VRpTY4Ko"
    "OaGigNT6YrmSVMzOw8zMwbQyasg0CBvjBPUDcZSRnPdZzFQfVnY+VqZPtU/IiKfGuCIr65JQMx3MVA9Weg5Wug8rI8em6eTidUHE"
    "baxL8dXmJEF9QpIgXkWOBcOWVRgyc7CyczHtLBiGbGNTRlHFBISTlQReuijnZejL6IPGhBKqlcSylS5gZ/plyWDDVM87RdCcQkQ+"
    "lpPDzi8i3X8sVqqH8pTHnqEmJ6wszOrEVUohrz3xIeplK9Zb+OEDi5iT30vjwEO0pp6Wjrtf7xALAlUi1VKEaBrLzcm2pXqxM33Y"
    "maIs4evmMJ0MZrvfVGpk2BbxbZTwGzJiMWhMErYqhH5dlhA2JOlmuT1yz8zOwc70xuWSo6ApbQL1HTAwnQx2uoiTm4OT6cNKSTvH"
    "MK2OgHDQIgpkqqZhGLHodTtl0isfwKtPqPEQYNppdf8+eU1XjrXAbxDUpW0QenVEFMnPZou4uX7cXL/a53Py+VGpql5NRVxO4FVH"
    "8WoT+E21p2FguhmcdEHaadk5CXstJ0Wz2/Za0IpttVZlDK86Rqs23lW5qxNNeHjEQtc/i2f43TRi4Rm+8nwRCzXg34BvAD8TMPXK"
    "q8dD7eloHA60eKPGYeHl79kV/fRLyyeQYVPHAMuAo34vH1bI0Ecp3COIopAw8FSpxhJ2aiwmFUy77UBJgz30VapBq0rQqqm0ho5m"
    "gjT82gJZEWGrpq5hIMKAwKvJNARPlgKUzWl/PsRvVjBtV8rNKT0IqVMgME0b30ljWS6GZcclJoOW0nQIWop9F0SBIQmJSKZ9SMdc"
    "GXvqR26qnXtHwkN4UuBSBC0Cr4Zdm8RLd4wfw7RUXwRx+cagVSX0a0RK0ElEgTRUgpbUDPCbWG4aDKtT+aBVlZ8PWvIdmE2iSOak"
    "hioSwXIymE5GOhbK8CHyiYKm/FyrKg3X0MMQAsNyCL0qZiODadoyJDVQ1/SqcVUIydrIcP2wVcW00ximTTtVxjBMLLcHK13AMG12"
    "Do7z1x+5l3u3T7Fm9RF86Rsnk0+kBVRKIdd9ZJhHd3pdugMnrkkTeQeIgkZc9vHZiF9BBKFPREMRKS0MVa5LRAGErVhvwzBtKRCn"
    "fk8YEAXNuHKBMGRLQmmxEXnVzrVCX4U+VxB+Iy61GIZS88L0qhiNtpOuxMpE576YTuw0itCTzqBXlU58FIAwwZP3FpGHaE5Kh1hE"
    "nbBr9XmiToWHg1pORiSfKaFLIoI6kVfGbOSk8KKdkQ6kacXEAm0BSEUuCL/eSWkIWyAkWYJpqxYIROQR2ROKbFLOv6ocIcIWxrT0"
    "ligK5D38GmZrAsPOqbYkCY5AlbQMElZjpLQomrJtXhURNiRJYJiEQRMR1IhaUxjOqHR0Vak1VLh1fE0RdjIGojAu1SnfryKjRIQI"
    "TPkMfk0SBW6PIhXSirAwOmU1w0anXUFN/l3porSJBdkGnyhsKed8HMPJYViZmKiQQp7J52+/1kgSLfHzy7bKsZioBKA+R1Anaqn2"
    "eWUwXen4JEqAyjaqdIr4Guo+QUO+YxEgghpGIyvHtxByznj1+BnlsaKD0Zoiak4oAi8DltPdR0E9HvtS10SVeI1zt+U4iYQcv3g1"
    "zGYGlCOF0teR80B+R7QczFYZw5mQZJmTVePalvtIFHY0TXy1jnrVzvtBQGhDFBBEPoZXlqQEKDHUqiQf/c4eFLV9nigg8spqPWx/"
    "vhaTlUKNTRE0EJ7UPjHrkvw0nQyGkRjzoUcUNuP2yT6qIdoOnWlJ8ify1dqUAgyiyCdS+wmRL8kGpeRvNsblvIxCRaRWCYMGRJLo"
    "k2lkVUzbRWBIUWOvochOGxT5Ydpp7tm2lw9ceQ8jwybvunQFH/7EcV3Lzt4hn6vf9jT1shEL1S5aarNowKY+Uon3OmYTXhaqZG2o"
    "0rnUfhk2qwSNSSy3B8PNykMERZwnDzBE2FLEvXy/gdJDEqFMoSSK1NQKVUUon8ir49cnVTlGQ+n1NGJbQyBJ4aBZxm9MYrs9klCy"
    "XbXWiY4QdBggokiZM+rfAy+2X4JWVaa9iZBIpXWGXq1zfwylMdFQoostSSxYDoFXI2xW8Krj8tDDSWNaDkIYyj5oJu5TUc/ejPc9"
    "028QqQMerzaJne7BciSpYFgOhmlKm0KJWQetKkGjIkmG2F7zu+yf30M8pYiFu4HJV149HmkvR0NHLGj8T0UuWMCpBrwDOBdY+HsX"
    "sRCXrzLkqa4py0JZtotpu5hWSkYqWA6mJY05QwglyKSqL7Qd9NBXRqTMtzQME8OwMG1ZatFqO+OGJBqi0Iu/1zZIDNPCtBxVRUGS"
    "BoZyJEUYxA6pDK90ME1LbZ7KoAg8otCTznKktBBU9QPDtGQZPcNIGA5hnFuYVOGWpyyq/ep02LRTmI6LYacwTRvDNGMDVBpL7edp"
    "SSO5faqtSm0Ztiv7wHZi0kW2uaWclCA+wTRU2UtLVZOIT6iVQS21HwOiyO8QJKE8rTVA1g63XVXC0pT+qJAiWqLd58oBaz+jEV/f"
    "kgfjhoXlpLEyvaSKA9x8a8Bf/vkvla5CR4zutNWLOeX0OezdHfCTLVNUy0kRM4fLr1nIpR/I0Rx9iNbUUzINolWW/STEQSMW1IBQ"
    "71i1y7RiR8wQYZwTahhmXFFDegeRqrQQJCpuyD41rFQc+SGvFSo9BElUGLHDq9IOLFeeyBu27C/RySOWKv1W52glCiHylEPlKafT"
    "UEr+LoadlmUvFUFHW9gx9CTpEEnnyzCefe8y2tELpiXJDduVTpflJpwvS35OSKJIzgtPpnK02xipUmOG1MzoVB6Q18HsjFcUcdD+"
    "Hm2DVA461Ra30xY7Lf/bTJSmU2SEEX/XULXUQ/m7SF2/PUYhbg9WSj1jSr0Ts+OYi1ASHV3EjCJUIl8SUaEnnWkhn5U2MdS+rp3u"
    "vGs6Wh8i8tT3m919RhQ/Q9fztyNZLEVIme0850iOTREoY77dLcnnV0KfkS/XlvY91HwwDPW+4/5wEwRLJNMIEu9IJCoeiFmuYVhp"
    "SRyoa0gyRjp0oj0XDFN9Pi2dP8sFNR9isihsqbUo0Uci6vSRXGzie2M6ib5pX0cREWpsCNPEMF35Y6fVGuXGc060CbP2mPZbqt1y"
    "TxFqLTTid6zarUgVufa2x4Uaa4Yl72Gn1L1NpTfbJpna62eUIBddFUGUBsuV64Zhx2NelrJVbWyT2WEnukY+Z6eN8l0YHTHJUJHf"
    "KmpFjjEndsAloeWpPVLIvVyNQcOwEIqEad/PdLM4uQW4c47iTz/wJP9yx5NK9LVHaSr08bLV8zlhVZ6Hd7S4645SO/xAlYh0+fTX"
    "F3H6y5s0DjxEc/Jp/OqITJ2LK+9MP2Y2EGq/kQS5jWml5HiyZVtN05HvC4NIrTdde1w7giAW2+yMLXnt9nVl/2DJSjlyjffjcH9p"
    "F6g9Uu0Hpp3u6lMRyTUlCjvrhVACxG1ByshvRzSoeZbY6001vg3DIFL2kgg9oihQZIipiJ0UlpOWbVA2kqBdCUiRMH5TEkVB+x13"
    "9j3DtOVzKFvBtFLKdpPjTyDUdZSt5jUJg2asa9Xpw04Uwe9RxMIw8H3gH19x9fgO7dVo6IgFjf9phMCvge8gS0+eA+R+Px9VKGdb"
    "YESRDKf0m3LTajt2pnI6EBBFcrNun5pG0qBJOuhtgzj05clDZFjKAKfj0LWdi7bzFwlCEcq60H5DGqLJ0zoVqtdx/A11TWVUq3YZ"
    "QqgTcSVGFUrnH8OTpzdxhYJOO7sc2rZYntE2LjyMoIHhWdLpN6zOx5XTJgkGeSJpiDBRN1y1KQoQZhPDNzsGpyr7aSgF9rajIcII"
    "I/IhaBGabVLEUv3fKRnYCa0OlaMjFHElT2MxrKRZFzuu0jBRG7sREQl5shtfv20giQjTzSJCn1NP7aenYFApBxixSr7PL7ePcd/2"
    "dp54TFMBgmNXZLnsmn68qacJmpPqZL4V53IeUkRNFHZCxo2kCrnoGBIGXb83RLJEnIgdibiUXNAgqWguRNvZE8oRkv1CqE5XDVON"
    "M2leJpi5hKiqHHOGmNbHSaIjbKla5manfYpQ6nz+0MtygjKA24SG2ZAOjYpUMAxZFUSO8XbZtzAuZ9hx/DqmmyCAcHp7O3MsvgYi"
    "7mf51URbhHKO/ap0kma5RlwlpMvQFPF8QSRETkPpvBpBC2Fayjm1Zv2uJHPoJhemtTuWNA1VpEMor4tnJ9pLYl0J4qiI2fps1ncR"
    "WGBW5byY9vziuTx/8jPx6a+KmglbiPjaSXJrejs56DXid9wmLNX6TsJxE4aBYbQQQRPD71SkSJIiIkqsRbO1ve2UIeS9Q1+2Xc2r"
    "mHSKvycQkQGGjzCaGH5NjesEoaRI7DZZRRgmBC/b7zhBLgUmhjBm+W5irAm1v6lUsXbfdvYfeTLeKVcZYhg+YdjE8Ovx3AOz4/gL"
    "tcaq/uncs11y2FARRb4irNvPJzpRLrEDbQDNRP939hgh2n1sQCDTsMCMZzYCdZJtK2FZn9eetZQ77ng8rm4kCCiV69x5xwHuumOK"
    "pA56ezf+44v6OOO1Ls2xp/DrE7Kkb5tIfSaXVHT2fUOR6oYv1ytJClgxSSfivm5X61AHC2HUTbZ1XVuupWEUYAQmwjDbO61cQ9R7"
    "FmpMy3TA9pppxwR1PFYTwpQz5pCIYic/ds6NqCM8rN4/hkEUrz+RGteSqIjaDr9XVwc3lkq5ICb52vZVpOa0JDzUGzUiDEVa4Cs9"
    "nwQJbxiKoFFrnyQ3wniOCvEc9pvfPUwhhdg3AY9od0ZDEwsa/1tQR5aeXKwiFk4FVRPs95JfEAljxpCh6Mpwlbac4u3FNEMxaWQb"
    "06+lHG/8mWET6ntGgmwAI869P6TIC+NZaOu2IS2P65L69s9KtrQNIek0qMocgXIwjWkUvhBddc8TlI38tRFhRLO1d1pb2kaFgMiQ"
    "p1EG5oyHlffvECjdzz1THNSY7X5tX6f9jAmH2bQcotCWZTv9Gscfs4Dv/+AC3vm2Lewb8rsdN6KuJwaTV5w9h09+/ij86gh+ZR9h"
    "Y1IaoCqS4xCZBTV+pj3FtBP9Gb+fVeE0lGNahM+QbCCm3VqdShscpDOZ9twHe6dthymY/d7iUM9kDnbqo5wdESDwYsJDxK4AHTKN"
    "JBkgZu1v2VfR7CKSBzkamtEWfAhNxQOa09qAIiCf6ehLdHO8IkIYAUTyueiqkiOv23YZOVjEh5jteSPprEVGwnEzEstTlCAonuk9"
    "TX9+Tz6/oNt5Tp4OHvLzT38/dPp4+rgX4hDa2XZoIzBmu8a0NghUv/iI0FTrT4IcE0kS9VnGcnJ8Gc/27G2nLojfudyBjEQPRjGx"
    "Jf9BzDgfSI5lIbpW5lnHmiSVD+Inz7iH6DjB+J11Whhde5xof04R6LMR+xghST5SdPWZSFDE/sG7No4O6bQ//qZQqYyWp8oxV3jD"
    "646ht28tV7/3Z9TLXS1KVHJqX8HkPR9axHs+uIDW5JN4lf2EjSlCr6aiCMQhr1nJfVXEBK0RE1yduddtZzzjPdqRWWovEzPeG529"
    "KiZDAwzhxfM+XldicktwEOnBTt7MbM81264iEp9rHyyIECM0iILO/TvvUXTbUdPDCbrstRBCiEjOz/ZwTVwrJp9+r1EBtiMFG+97"
    "hdZU0HieoFMhNH4r/PRLy5O+7RHAHwMXAS8FMtMdjN/tVIhDuLZxaM95sKqYz/RMxm/zHMbzc69Davcht1k8L+01fpt+Ng7tnRoH"
    "uYphWlhOBitdwOmZj1tYgltcSsMv8N1Nj3Hbxr08ujPAIoeJE9/hlWf3cvHlizl5TQG/vBevvAe/sleJI5aV9kF3GT3jGRpq/Fbj"
    "m+d/fB/0Q+KQ5u6hrBOHUlnWOMQF4ZCL1MZ9euj7pvGcf3EY7Xo2J+U5vPf/ZpaW59idh/CEh0YO/9bXEof6PTE7t/LbNZNprv+z"
    "h14/l3aLGVc/OEd0GG0/WJvFc2mneAbS8hnufzBOR3St67YULsz0YecW4BYHcHuXUW/l+McvP8ztGw8wMmypMsEynL6nYPKqs4v8"
    "6TVLWLgowisNy5/KPvzaOKFXlToXcUTQ7G0RB+dwD9L/4pD7/tDvJ57hfvwW9xOzkAiH+n4P5Z7isNIQntu9f+dTIYQiFe4Gvgf8"
    "8yuuHh/V3oyGJhY0/rcRC+0/jgTOAs4DTgL6NbGgiYXfT2Kho71guhmsVAE724/To0qEZediuT0A3LetFIeOn7wmDyCrVNRHCWqj"
    "sgymUvmX+df+jKNATSxoYkETC5pY0MTCfzGxIJSOkuVIscJ0L05Oln60exbg5OZh2hnKpYBdgw0MDPJFm+NXphFRQFAbkxFo1RH8"
    "+pisztCsSsHSOBLtuTr6mljQxMLzQiwIIdgD/ALYDPzkFVeP79GejMbzCZ0KofF8W4lPIUOrRoEWcDpSe8HS3aPx+zfgZYlCGaJJ"
    "XLYqbJaxa6OYqTymk+UPXuzE5cFak2NEXk2WP2uW5I9XUarmntIT0ISvhoaGxv/Eqi5EotoOqLK3DYJmiaA6gpkqkHIy/MGLXJVO"
    "EdAcb8pSjc2SIhNKhK0ykd9QpEKo13WN/0mEwBiy+sNGpDbamO4WDU0saPxvRwTsBe5UZMIUcDJwNODq7tH4/bJB28KXHpESURRB"
    "i8irEDZk2U2jrb6tyjDKsnNNaXD6daKgESugG22dAbQBqqGhofE/t66HUvgzLv/YIGxVCOrjmE5WreuqqkAUIgKPMGgQebJEbdQu"
    "/ayqL2lSQeN/EC1gF7I8/A+RaRD1V1w9rntG43mHToXQ+C/Bz7603ATywEoMXgOcDZxgdCpGPFuWgk6FmPYPOhXiuff1f3UqRPwd"
    "sy1WqSpFWI4spaWMTyOu9qFU9yO/U4JLlY4TInzGMHudCnFo7/a5rhGHer/uPtWpEDyfbdOpEM+1mYnL6VSI2T5x+KkQib+o6guo"
    "EtOytKajSuw6qqJQmzD2VdlHLy7Z2K4aIiIxexufQx/oVIhDuadOhZj2rwZQBv4T+GfgDiF4/BVXj9e0l6KhiQWN31WCIYPBscAf"
    "An9oSFHHI3mWaBlNLGhi4XeKWDC6b2i0yxjGJeeMrkogsixf2Il4UPLZz+Qsa2JBEwuaWNDEgiYW/huJhfb/x1VQDFXuUJVpTFZy"
    "iSJZMjFSZRMT5R7FQbxJTSxoYuG/kFhoAk8ADwA/Be4BHn35VeOB9kw0NLGg8btNLmxYbgO9wIsNeCWyHOULkNoLKUUymOpPWxML"
    "mlj4nSUWZlwr8eVkvxykjKEmFjSxoIkFTSxoYuF/GbEw43dGouxwoj/Eszn6mljQxMLzSiwIZJ3ZEAiF1FGoI6MUHlNkws+A3wA1"
    "TSpoaGJB4/eNYOgxZLTCscDx6s8BYA4ybWKeIiA0saCJhd8TYuG59IsmFjSxoIkFTSxoYuF/P7HAYTremljQxMLzSiwATCI4AFQF"
    "jCAF1J8EHgEeBZ5++VXjde2BaGhiQeP3Ej/fsNwECsBRwCpgObAE6AeWIYmHnCYWNLGgiQVNLGhiQRMLmljQxIImFjSxoImFWb9S"
    "A55E8BQwIWTqwyDwMDAEVF5+1XikPQ+N/07oqhAa/634o8t3RT/fsNxDhmodAHoAD5gEqmqhXAhkdW9paGhoaGhoaGhodKEO7EdG"
    "KOxTNvUeYFzZ0p4mFTT+J6AjFjQ0NDQ0NDQ0NDQ0NDQ0NA4bpu4CDQ0NDQ0NDQ0NDQ0NDQ2Nw4UmFjQ0NDQ0NDQ0NDQ0NDQ0NA4b"
    "mljQ0NDQ0NDQ0NDQ0NDQ0NA4bGhiQUNDQ0NDQ0NDQ0NDQ0ND47ChiQUNDQ0NDQ0NDQ0NDQ0NDY3DhiYWNDQ0NDQ0NDQ0NDQ0NDQ0"
    "DhuaWNDQ0NDQ0NDQ0NDQ0NDQ0DhsaGJBQ0NDQ0NDQ0NDQ0NDQ0PjsKGJBQ0NDQ0NDQ0NDQ0NDQ0NjcOGJhY0NDQ0NDQ0NDQ0NDQ0"
    "NDQOG5pY0NDQ0NDQ0NDQ0NDQ0NDQOGxoYkFDQ0NDQ0NDQ0NDQ0NDQ+OwoYkFDQ0NDQ0NDQ0NDQ0NDQ2Nw4YmFjQ0NDQ0NDQ0NDQ0"
    "NDQ0NA4bmljQ0NDQ0NDQ0NDQ0NDQ0NA4bGhiQUNDQ0NDQ0NDQ0NDQ0ND47ChiQUNDQ0NDQ0NDQ0NDQ0NDY3DhiYWNDQ0NDQ0NDQ0"
    "NDQ0NDQ0DhuaWNDQ0NDQ0NDQ0NDQ0NDQ0DhsaGJBQ0NDQ0NDQ0NDQ0NDQ0PjsKGJBQ0NDQ0NDQ0NDQ0NDQ0NjcOGJhY0NDQ0NDQ0"
    "NDQ0NDQ0NDQOG5pY0NDQ0NDQ0NDQ0NDQ0NDQOGxoYkFDQ0NDQ0NDQ0NDQ0NDQ+OwoYkFDQ0NDQ0NDQ0NDQ0NDQ2Nw4YmFjQ0NDQ0"
    "NDQ0NDQ0NDQ0NA4bmljQ0NDQ0NDQ0NDQ0NDQ0NA4bPx/AwCZ9Vf9h/iWvQAAAABJRU5ErkJggg=="
)


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":
    # Keep Qt Quick's RHI backend compatible with the OpenGL-based 3D view
    # (pyqtgraph.opengl). This must be set before QApplication is created.
    os.environ.setdefault("QSG_RHI_BACKEND", "opengl")

    print("=" * 70)
    print(VERSION)
    print("RUNNING FILE:", __file__)
    print("=" * 70)

    app = QApplication(sys.argv)
    app.setStyleSheet("""
        QWidget { background-color: #0B0B0B; color: #E6E6E6; }
        QMainWindow { background-color: #050505; }
        QGroupBox {
            background-color: #111111; border: 1px solid #383838;
            border-radius: 4px; margin-top: 10px;
            padding: 10px 6px 6px 6px; font-weight: bold;
        }
        QGroupBox::title {
            subcontrol-origin: margin; left: 10px;
            padding: 0 4px; color: #BDBDBD;
        }
        QPushButton, QComboBox {
            background-color: #1B1B1B; border: 1px solid #383838; padding: 5px;
        }
        QPushButton:hover { background-color: #272727; }
    """)
    window = GroundStationGUI()
    window.show()
    sys.exit(app.exec())
