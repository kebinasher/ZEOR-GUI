from __future__ import annotations

from .config import *
from .protocol import *


# ==========================================================================

"""Ground-side receiver decoder.

This module is the Python counterpart of
``firmware/ground_receiver/ground_receiver.ino``.

The stock receiver sketch does two things with every packet it gets from the
E22-900T30D radio:

1. it validates the frame (15 CSV fields, team-ID match, numeric sanity,
   valid flight state) - see ``validatePacket()`` in the sketch;
2. it prints a human-readable ``====``-delimited report block.

So the bytes arriving on the USB serial port are **not** the raw ``@`` frame -
they are the pretty report.  ``zenith.protocol.ReportBlockParser`` parses that
block back into a sample dict, which is exactly the same structure that
``parse_zenith_frame()`` produces for a raw frame.  That way the GUI works

* with the receiver sketch exactly as supplied (report block),
* with the optional one-line ``RX,...`` echo patch (see the README),
* with a raw ``@`` frame when the GUI is wired straight to a radio dongle,
* with legacy ``CAN,...`` 20/22-field payloads.

Nothing here invents data: a field that is not present in the received bytes
comes back as NaN and is later rendered as "--".
"""


from typing import Any






class ReceiverDecoder:
    """Streaming decoder: serial bytes/str -> (samples, monitor lines)."""

    def __init__(self, team_id: str = TEAM_ID, strict_team_id: bool = True) -> None:
        self.dispatcher = LineDispatcher(team_id=team_id, strict_team_id=strict_team_id)
        self.decoded = 0
        self.rejected = 0
        self.frames: list[str] = []

    # -----------------------------------------------------------------
    def reset(self) -> None:
        self.dispatcher.reset()
        self.frames.clear()

    def feed(self, payload: str | bytes) -> tuple[list[dict[str, Any]], list[tuple[str, str]]]:
        """Push one read() chunk; return decoded samples + monitor messages."""
        if isinstance(payload, (bytes, bytearray)):
            payload = payload.decode("utf-8", errors="replace")
        samples, messages = self.dispatcher.feed(payload)
        for sample in samples:
            self.frames.append(sample.get("_raw", ""))
            self.decoded += 1
        return samples, messages

    # -----------------------------------------------------------------
    @property
    def raw_queue(self) -> list[str]:
        """Frames seen so far (used by the 'Protocol echo' console filter)."""
        return self.frames

# ==========================================================================
