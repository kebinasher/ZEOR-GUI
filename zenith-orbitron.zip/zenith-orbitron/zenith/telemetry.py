from __future__ import annotations

from .config import *
from .protocol import *
from .protocol import _finite


# ==========================================================================

"""Single shared telemetry data model.

Requirement 8 of the task: *"Ensure that the different GUI components do not
maintain conflicting or independent copies of telemetry state."*

Every decoded packet is pushed once into :class:`TelemetryStore` by the GUI
thread.  The graphs, the numeric readouts, the CSV logger, the map tab, the 2D
simulation and the 3D simulation all read from that one store (or receive the
very same dict), so they can never disagree.
"""


import math
import time
from collections import deque
from typing import Any, Iterable




LINK_LOST_TIMEOUT_S = 5.0


class TelemetryStore:
    """Ring-buffer history + latest value for every telemetry channel."""

    def __init__(self, history_len: int = HISTORY_LEN) -> None:
        self.history_len = history_len
        self.t: deque[float] = deque(maxlen=history_len)
        self.history: dict[str, deque[float]] = {
            c.key: deque(maxlen=history_len) for c in CHANNELS
        }
        self.latest: dict[str, Any] = {}
        self.meta: dict[str, Any] = {}

        self.packet_count = 0          # packets accepted since connect
        self.rejected = 0              # packets rejected by the decoder
        self.expected_lost = 0         # gaps reported by the packet-count tracker
        self.first_wall: float | None = None
        self.last_wall: float | None = None
        self.max_alt = NAN
        self.max_accel = NAN
        self.sources: set[str] = set()

    # -----------------------------------------------------------------
    def clear(self) -> None:
        self.t.clear()
        for dq in self.history.values():
            dq.clear()
        self.latest = {}
        self.meta = {}
        self.packet_count = 0
        self.rejected = 0
        self.expected_lost = 0
        self.first_wall = None
        self.last_wall = None
        self.max_alt = NAN
        self.max_accel = NAN
        self.sources.clear()

    # -----------------------------------------------------------------
    def push(self, sample: dict) -> None:
        """Store one validated sample (called from the GUI thread only)."""
        now = sample.get("_wall") or time.time()
        if self.first_wall is None:
            self.first_wall = now
        self.last_wall = now
        self.packet_count += 1
        self.sources.add(sample.get("_source", "?"))

        t_ms = sample.get("time_ms", NAN)
        self.t.append(float(t_ms) / 1000.0 if _finite(t_ms) else NAN)

        for c in CHANNELS:
            value = sample.get(c.key, NAN)
            self.history[c.key].append(float(value) if _finite(value) else NAN)

        self.latest = dict(sample)
        self.meta = {k: sample.get(k) for k in META_KEYS}

        alt = sample.get("bmp_alt", NAN)
        if _finite(alt):
            self.max_alt = alt if not _finite(self.max_alt) else max(self.max_alt, alt)
        mag = sample.get("accel_mag", NAN)
        if _finite(mag):
            self.max_accel = mag if not _finite(self.max_accel) else max(self.max_accel, mag)

    # -----------------------------------------------------------------
    # readers
    # -----------------------------------------------------------------
    def times(self) -> list[float]:
        return list(self.t)

    def series(self, key: str) -> list[float]:
        return list(self.history.get(key, ()))

    def value(self, key: str) -> Any:
        return self.latest.get(key, NAN)

    def finite_series(self, key: str) -> list[float]:
        return [v for v in self.history.get(key, ()) if _finite(v)]

    def has_channel(self, key: str) -> bool:
        """True when at least one finite sample for *key* has been received."""
        return any(_finite(v) for v in self.history.get(key, ()))

    # -----------------------------------------------------------------
    # status
    # -----------------------------------------------------------------
    def link_age(self) -> float | None:
        if self.last_wall is None:
            return None
        return time.time() - self.last_wall

    def link_ok(self) -> bool:
        age = self.link_age()
        return age is not None and age <= LINK_LOST_TIMEOUT_S

    def rate_hz(self) -> float:
        if self.first_wall is None or self.last_wall is None:
            return 0.0
        span = self.last_wall - self.first_wall
        return self.packet_count / span if span > 0.2 else 0.0


# ---------------------------------------------------------------------------
# packet-loss tracking - port of checkPacketLoss() in ground_receiver.ino
# ---------------------------------------------------------------------------
class PacketLossTracker:
    """uint32-rollover-safe gap detector (identical maths to the .ino)."""

    def __init__(self) -> None:
        self.previous: int | None = None
        self.lost = 0
        self.duplicates = 0
        self.out_of_order = 0

    def reset(self) -> None:
        self.previous = None
        self.lost = 0
        self.duplicates = 0
        self.out_of_order = 0

    def update(self, packet_count: int) -> list[tuple[str, str]]:
        """Return a list of ``(level, message)`` warnings produced by this packet."""
        messages: list[tuple[str, str]] = []
        current = int(packet_count) & 0xFFFFFFFF
        if self.previous is None:
            self.previous = current
            return messages

        difference = (current - self.previous) & 0xFFFFFFFF
        if difference == 0:
            self.duplicates += 1
            messages.append(("warn", f"WARNING: duplicate packet count {current}"))
        elif difference < 0x80000000:
            if difference > 1:
                missed = difference - 1
                self.lost += missed
                messages.append(
                    ("warn", f"WARNING: {missed} telemetry packet(s) missing "
                             f"(#{self.previous} -> #{current})")
                )
        else:
            self.out_of_order += 1
            messages.append(("warn", "WARNING: old or out-of-order packet received"))
        self.previous = current
        return messages


# ---------------------------------------------------------------------------
# CSV logging
# ---------------------------------------------------------------------------
class CsvLogger:
    """Append-only CSV writer; missing channels are written as empty cells."""

    def __init__(self, path: str) -> None:
        import csv

        self.path = path
        self._fh = open(path, "w", newline="", encoding="utf-8")
        self._writer = csv.writer(self._fh)
        

        self._writer.writerow(csv_header())

    def write(self, sample: dict) -> None:
        

        self._writer.writerow(csv_row(sample))

    def flush(self) -> None:
        self._fh.flush()

    def close(self) -> None:
        try:
            self._fh.flush()
        except Exception:
            pass
        try:
            self._fh.close()
        except Exception:
            pass


def autoscale_ranges(xs: Iterable[float], series: Iterable[Iterable[float]]):
    """Compute (xmin, xmax, ymin, ymax) ignoring NaN/inf (used by the graphs)."""
    xs = [v for v in xs if _finite(v)]
    ys = [v for group in series for v in group if _finite(v)]
    if not xs:
        return None
    xmin, xmax = min(xs), max(xs)
    if xmax <= xmin:
        xmax = xmin + 1.0
    pad = max((xmax - xmin) * 0.05, 0.5)
    result = [xmin - pad, xmax + pad, None, None]
    if ys:
        lo, hi = min(ys), max(ys)
        if hi - lo < 1.0:
            c = (lo + hi) / 2.0
            lo, hi = c - 1.0, c + 1.0
        else:
            p = (hi - lo) * 0.15
            lo, hi = lo - p, hi + p
        result[2], result[3] = lo, hi
    return tuple(result)

# ==========================================================================
