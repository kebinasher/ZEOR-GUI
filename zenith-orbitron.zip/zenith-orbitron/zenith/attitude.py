from __future__ import annotations

from .config import *


# ==========================================================================

"""Attitude maths for the 2D/3D simulations.

IMPORTANT - honesty about what is and is not transmitted
-------------------------------------------------------
The flight software reads a BNO085 quaternion on board but **does not put any
orientation value into the 15-field CSV frame**.  So there is no real
roll/pitch/yaw channel, and the GUI must not invent one.

What this module does instead is *derive* attitude from channels that really
are transmitted:

* **Roll / pitch** - from the accelerometer triple.  While the vehicle is not
  under thrust the accelerometer measures the gravity vector, so
  ``roll  = atan2(ay, az)`` and ``pitch = atan2(-ax, hypot(ay, az))``.
  This is a genuine function of the received data (it is exactly what the
  on-board BNO085 does with its accelerometer), valid whenever
  ``|a| ~= 1 g``; it degrades during boost, which is documented in the GUI
  tooltip and the README.
* **Yaw** - the *rate* gz is transmitted, so yaw is obtained by integrating
  gz over the real packet timestamps.  It drifts; the GUI labels it
  "integrated (drifts)" and it is reset when the rocket is upright on the pad.

Everything else here is plain quaternion/vector maths used to rotate the 3D
rocket mesh with the derived attitude.
"""


import math

import numpy as np

G = 9.80665


# ---------------------------------------------------------------------------
# Tilt from the real accelerometer triple
# ---------------------------------------------------------------------------
def tilt_from_accel(ax: float, ay: float, az: float) -> tuple[float, float, float]:
    """Return ``(roll_deg, pitch_deg, quality)`` from a real accelerometer sample.

    *quality* is 1.0 when the measured specific force is close to 1 g (i.e.
    the gravity estimate is trustworthy) and falls towards 0 as the vehicle
    accelerates.  The simulations use it to fade the tilt out during boost.
    """
    if not all(math.isfinite(v) for v in (ax, ay, az)):
        return (float("nan"), float("nan"), 0.0)
    norm = math.sqrt(ax * ax + ay * ay + az * az)
    if norm < 1e-6:
        return (float("nan"), float("nan"), 0.0)
    # quality: 1 g +- 0.35 g is considered a clean gravity reading
    quality = max(0.0, 1.0 - abs(norm - G) / 0.35)
    quality = 1.0 if quality > 1.0 else quality
    roll = math.degrees(math.atan2(ay, az))
    pitch = math.degrees(math.atan2(-ax, math.hypot(ay, az)))
    return (roll, pitch, quality)


def wrap_deg(angle: float) -> float:
    """Wrap to (-180, 180]."""
    a = math.fmod(angle, 360.0)
    if a > 180.0:
        a -= 360.0
    elif a <= -180.0:
        a += 360.0
    return a


# ---------------------------------------------------------------------------
# Yaw integration from the real gyro spin rate
# ---------------------------------------------------------------------------
class YawIntegrator:
    """Integrates the transmitted gz (deg/s) using the real packet timestamps.

    The flight software sends ``GYRO_SPIN_RATE(x;y;z)``; only the integral over
    time gives an angle, and gyro bias makes that integral drift.  The drift is
    real and is reported - never hidden - and the integrator is re-zeroed
    whenever the vehicle is level and stationary on the pad.
    """

    def __init__(self) -> None:
        self.yaw = 0.0
        self._last_t: float | None = None
        self.drift_warning = False

    def reset(self, yaw: float = 0.0) -> None:
        self.yaw = yaw
        self._last_t = None
        self.drift_warning = False

    def update(self, t_s: float | None, gz: float, level: bool, spin_rate: float) -> float:
        """Advance the estimate; returns yaw in degrees."""
        if t_s is None or not math.isfinite(gz):
            return self.yaw
        if self._last_t is None:
            self._last_t = t_s
            return self.yaw
        dt = t_s - self._last_t
        self._last_t = t_s
        if dt <= 0 or dt > 5.0:          # gap or replay jump: do not integrate
            return self.yaw
        self.yaw = wrap_deg(self.yaw + gz * dt)
        # a level, non-spinning vehicle on the pad means the estimate is pure bias
        if level and abs(spin_rate) < 1.5:
            self.yaw *= 0.9
        self.drift_warning = abs(gz) > 0.5 and dt > 0
        return self.yaw


# ---------------------------------------------------------------------------
# Quaternion helpers (used to orient the 3D rocket mesh)
# ---------------------------------------------------------------------------
def quat_from_euler(roll_deg: float, pitch_deg: float, yaw_deg: float):
    """Body -> world quaternion for intrinsic ZYX (yaw-pitch-roll) rotation."""
    r, p, y = (math.radians(v) / 2.0 for v in (roll_deg, pitch_deg, yaw_deg))
    cr, sr = math.cos(r), math.sin(r)
    cp, sp = math.cos(p), math.sin(p)
    cy, sy = math.cos(y), math.sin(y)
    return np.array([
        cr * cp * cy + sr * sp * sy,
        sr * cp * cy - cr * sp * sy,
        cr * sp * cy + sr * cp * sy,
        cr * cp * sy - sr * sp * cy,
        ], dtype=float)          # (w, x, y, z)


def quat_normalize(q) -> np.ndarray:
    q = np.asarray(q, dtype=float)
    n = float(np.linalg.norm(q))
    return q / n if n > 1e-9 else np.array([1.0, 0.0, 0.0, 0.0])


def quat_slerp(q0, q1, t: float) -> np.ndarray:
    """Shortest-path interpolation - keeps the 3D model from snapping."""
    q0 = quat_normalize(q0)
    q1 = quat_normalize(q1)
    dot = float(np.dot(q0, q1))
    if dot < 0.0:
        q1 = -q1
        dot = -dot
    if dot > 0.9995:
        return quat_normalize(q0 + (q1 - q0) * t)
    theta = math.acos(max(-1.0, min(1.0, dot)))
    sin_t = math.sin(theta)
    a = math.sin((1.0 - t) * theta) / sin_t
    b = math.sin(t * theta) / sin_t
    return quat_normalize(q0 * a + q1 * b)


def quat_to_matrix(q) -> np.ndarray:
    """3x3 rotation matrix for quaternion (w, x, y, z)."""
    q = quat_normalize(q)
    w, x, y, z = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
        ], dtype=float)


def rotate_vector(q, v) -> np.ndarray:
    return quat_to_matrix(q) @ np.asarray(v, dtype=float)


class AttitudeEstimator:
    """Combines the two derivations above into one smoothed orientation."""

    def __init__(self, smoothing: float = 0.25) -> None:
        self.smoothing = smoothing
        self.roll = 0.0
        self.pitch = 0.0
        self.yaw_integrator = YawIntegrator()
        self.quality = 0.0
        self._init = False

    def reset(self) -> None:
        self.roll = self.pitch = 0.0
        self.quality = 0.0
        self._init = False
        self.yaw_integrator.reset()

    def update(self, sample: dict) -> tuple[float, float, float]:
        """Return ``(roll, pitch, yaw)`` in degrees, derived from real data."""
        ax = _f(sample.get("ax"))
        ay = _f(sample.get("ay"))
        az = _f(sample.get("az"))
        roll, pitch, quality = tilt_from_accel(ax, ay, az)
        t_s = _f(sample.get("time_ms"))
        t_s = None if t_s is None else t_s / 1000.0
        spin = math.hypot(_f(sample.get("gx")) or 0.0, _f(sample.get("gy")) or 0.0)
        self.quality = quality
        if not math.isfinite(roll):
            # no usable accelerometer triple - hold the last known attitude
            return (self.roll, self.pitch, self.yaw_integrator.yaw)

        level = quality > 0.6 and abs(ax) < 2.0 and abs(ay) < 2.0
        yaw = self.yaw_integrator.update(t_s, _f(sample.get("gz")) or 0.0, level, spin)
        if not self._init:
            self.roll, self.pitch = roll, pitch
            self._init = True
        else:
            a = self.smoothing * (0.35 + 0.65 * quality)
            self.roll += (roll - self.roll) * a
            self.pitch += (pitch - self.pitch) * a
        return (self.roll, self.pitch, yaw)

    @property
    def quaternion(self) -> np.ndarray:
        return quat_from_euler(self.roll, self.pitch, self.yaw_integrator.yaw)


def _f(value) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return float("nan")
    return v

# ==========================================================================
