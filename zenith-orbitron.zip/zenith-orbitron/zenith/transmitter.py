from __future__ import annotations

from .config import *
from .protocol import *


# ==========================================================================

"""Rocket-side payload: the exact frame the .ino transmitter builds.

Why this module exists
----------------------
``firmware/rocket_transmitter/rocket_transmitter.ino`` runs on a Teensy 4.1
that is bolted inside the rocket.  There is no way for a desktop GUI to
"run" that sketch, so this module is a byte-for-byte Python mirror of
``buildSensorString()`` / ``transmitPacket()`` from the sketch:

    '@' + <15 comma-separated fields> + '\\n'

It is used ONLY for:

* the unit tests in ``tests/`` (they build a frame here and check that
  :mod:`zenith.receiver` decodes it back);
* the **Hardware-In-The-Loop self test** (GUI -> ``Tools`` -> ``Run HIL self
  test``) which pushes the frame through the *real* serial port, through the
  *real* receiver sketch, back into the *real* decoder - proving the whole
  chain works without flying a rocket.

It never produces a value that is shown in the GUI.  The GUI only ever
displays data that arrived on the serial port.
"""


import math
import time
from typing import Any




# Transmit period of the flight software (LORA_PERIOD_MS in the .ino).
TRANSMIT_INTERVAL_MS = 1000


def _triple(values, fmt: str = "%.2f") -> str:
    """'x;y;z' with no spaces - byte-identical to String(v, 2) in the sketch."""
    return ";".join(fmt % float(v) for v in values)


def build_frame(
    timestamp_ms: int,
    altitude_m: float,
    pressure_hpa: float,
    temperature_c: float,
    voltage_v: float,
    accel: tuple[float, float, float],
    gyro: tuple[float, float, float],
    gnss: tuple[str, float, float, float, int],
    flight_state: str | int,
    team_id: str = TEAM_ID,
    packet_count: int | None = None,
) -> str:
    """Return one complete wire frame (ending in '\\n').

    The argument order mirrors the 15 fields of the protocol exactly; see
    ``zenith.protocol.FIELD_NAMES``.
    """
    state_name = flight_state
    if isinstance(flight_state, int):
        state_name = FLIGHT_STATE_NAMES.get(flight_state, str(flight_state))
    state_name = str(state_name).strip().upper()

    # NOTE: the order below is the order of buildTelemetryPacket() in
    # rocket_transmitter.ino - accel/gyro come *after* the GNSS block.
    fields = [
        str(team_id),                       #  0 TEAM_ID
        f"{int(timestamp_ms)}",             #  1 TIMESTAMP_MS
        str(int(packet_count if packet_count is not None else 0)),  # 2 PACKET_COUNT
        f"{altitude_m:.2f}",                #  3 ALTITUDE_M
        f"{pressure_hpa:.2f}",              #  4 PRESSURE_HPA
        f"{temperature_c:.2f}",             #  5 TEMP_C
        f"{voltage_v:.3f}",                 #  6 VOLTAGE_V
        str(gnss[0]),                       #  7 GNSS_TIME
        f"{gnss[1]:.6f}",                   #  8 GNSS_LATITUDE
        f"{gnss[2]:.6f}",                   #  9 GNSS_LONGITUDE
        f"{gnss[3]:.2f}",                   # 10 GNSS_ALTITUDE_M
        str(int(gnss[4])),                  # 11 GNSS_SATS
        _triple(accel),       # 12 ACCELEROMETER_DATA
        _triple(gyro),        # 13 GYRO_SPIN_RATE
        state_name,                         # 14 FLIGHT_STATE
    ]
    if len(fields) != len(FIELD_NAMES):
        raise ValueError(f"frame must have {len(FIELD_NAMES)} fields, got {len(fields)}")
    return FRAME_START + ",".join(fields) + FRAME_END


def build_from_sample(sample: dict[str, Any]) -> str:
    """Re-encode a previously decoded sample dict back into a wire frame.

    Used by the replay tooling (``tools/replay.py``) and by the tests.  Any
    field that is NaN - i.e. a channel the payload never transmitted - is
    encoded as ``0.00`` so that the frame stays parseable; the decoder will
    mark it missing again on the other side.
    """
    def num(key: str, default: float = 0.0) -> float:
        v = sample.get(key, default)
        try:
            v = float(v)
        except (TypeError, ValueError):
            return default
        return default if not math.isfinite(v) else v

    return build_frame(
        timestamp_ms=int(num("time_ms")),
        altitude_m=num("bmp_alt"),
        pressure_hpa=num("bmp_press"),
        temperature_c=num("bmp_temp"),
        voltage_v=num("vbus"),
        accel=(num("ax"), num("ay"), num("az")),
        gyro=(num("gx"), num("gy"), num("gz")),
        gnss=(
            str(sample.get("gnss_time", "") or ""),
            num("latitude"),
            num("longitude"),
            num("gnss_altitude"),
            int(num("gnss_sats")),
        ),
        flight_state=str(sample.get("flight_state", "STANDBY") or "STANDBY"),
        packet_count=int(num("packet_count")),
    )


# ---------------------------------------------------------------------------
# Synthetic *reference* trajectory - used only by the HIL self test and by
# ``sample_data/`` generation.  Clearly named so it can never be confused with
# real telemetry: GUI shows "HIL" / "replay" as the source of these packets.
# ---------------------------------------------------------------------------
def reference_trajectory(elapsed_s: float) -> dict[str, Any]:
    """Deterministic stand-in for the sensor suite, for bench testing only."""
    burn = 3.2
    apogee_t = 12.5
    if elapsed_s < burn:
        alt = 0.5 * 95.0 * elapsed_s * elapsed_s
        az = 95.0
        state = "ASCENT"
    elif elapsed_s < apogee_t:
        v0 = 95.0 * burn
        dt = elapsed_s - burn
        alt = 0.5 * v0 * burn + v0 * dt - 0.5 * 9.80665 * dt * dt
        az = -9.80665
        state = "BURNOUT"
    elif elapsed_s < 34.0:
        # parachute descent at ~6 m/s from apogee
        alt = max(0.0, 700.0 - 6.0 * (elapsed_s - apogee_t))
        az = -9.80665 + 3.0 * math.sin(elapsed_s)
        state = "DESCENT"
    else:
        alt = 0.0
        az = -9.80665
        state = "LANDED"

    pressure = 1013.25 * math.exp(-alt / 8434.0)
    temp = 30.0 - 0.0065 * alt
    voltage = max(3.4, 5.05 - 0.0006 * elapsed_s)
    spin = 6.0 if state in ("BOOST", "COAST") else 1.2
    return {
        "time_ms": int(elapsed_s * 1000.0),
        "bmp_alt": round(alt, 2),
        "bmp_press": round(pressure, 2),
        "bmp_temp": round(temp, 2),
        "vbus": round(voltage, 2),
        "ax": round(1.4 * math.sin(elapsed_s * 2.1), 2),
        "ay": round(1.1 * math.cos(elapsed_s * 1.7), 2),
        "az": round(az, 2),
        "gx": round(spin * math.sin(elapsed_s * 0.9), 2),
        "gy": round(spin * math.cos(elapsed_s * 0.9), 2),
        "gz": round(12.0 * math.sin(elapsed_s * 0.3), 2),
        "gnss_time": time.strftime("%H%M%S.00", time.gmtime(elapsed_s)),
        "latitude": round(13.0827 + elapsed_s * 1e-5, 6),
        "longitude": round(80.2707 + elapsed_s * 1e-5, 6),
        "gnss_altitude": round(alt + 6.0, 2),
        "gnss_sats": 9,
        "flight_state": state,
    }


def reference_frames(count: int = 60, dt: float = 1.0) -> list[str]:
    """``count`` frames of bench-test traffic, 1 Hz (matches the flight TX rate)."""
    frames = []
    for i in range(count):
        sample = reference_trajectory(i * dt)
        sample["packet_count"] = i + 1          # mirrors packetCounter in the .ino
        frames.append(build_from_sample(sample))
    return frames

# ==========================================================================
