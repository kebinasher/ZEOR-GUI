from __future__ import annotations


# ==========================================================================

"""
Static configuration for the Zenith Orbitron ground station.

Everything the GUI, the graphs, the CSV logger and the two simulations need in
order to agree on *what* a telemetry value is, lives here.  The mapping between
the 15 fields of the rocket's LoRa frame and the GUI channels is declared once
(:data:`CHANNELS`) and is reused everywhere else, so no component can drift out
of sync with another.
"""


from dataclasses import dataclass

# ===========================================================================
# IDENTITY / VERSION
# ===========================================================================
TEAM_ID = "INSPACe-Rocketry-032"
# The Teensy multiplexes both avionics streams on its one USB serial link.
ROCKET_STREAM_PREFIX = "{Roc}"
CANSAT_STREAM_PREFIX = "{Can}"
VERSION = (
    "Zenith Orbitron Ground Station v7.1 - E22-900T22D / USB / "
    "BMP390L + BNO085 + INA219 + GNSS"
)

# ===========================================================================
# SERIAL LINK
# ===========================================================================
# The PC is connected directly to the E22-900T22D through a USB-UART adapter.
# The E22 UART is configured for 9600 baud, so 9600 is the GUI default.
# 115200 remains available for older receiver-Teensy setups.
BAUD_CHOICES = ["9600", "19200", "38400", "57600", "115200"]
DEFAULT_BAUD = "9600"            # direct E22 UART -> USB adapter
LORA_UART_BAUD = 9600            # E22-900T22D UART default, firmware-side only
EXPECTED_USB_BAUD = 9600         # direct E22 UART -> USB adapter

# Frame sizes.  The CURRENT payload sends 15 fields; the GUI also still accepts
# the 20/22-field "CAN,..." frame of the previous generation.
EXPECTED_FIELDS = 15             # '@' + 15 CSV fields + '\n'  (rocket TX)
LEGACY_EXPECTED_FIELDS = 20
LEGACY_GPS_FIELDS = 22

LINK_LOST_TIMEOUT_S = 5.0        # matches PACKET_TIMEOUT_MS in the receiver
SERIAL_READ_TIMEOUT_S = 0.05
SERIAL_WRITE_TIMEOUT_S = 0.5
MAX_LINE_BYTES = 4096
RX_BUFFER_GUARD_BYTES = 8192     # runaway-noise guard (same idea as the .ino)

# ===========================================================================
# TELEMETRY CHANNEL MODEL
# ===========================================================================
# `frame_field` is the name of the field in the 15-field '@' LoRa frame that
# feeds this channel.  `None` means: the channel exists in the GUI (graph,
# label, CSV column, ... ) but the CURRENT firmware does not transmit it.
# Such channels are rendered as empty / "not transmitted" - never fabricated.
@dataclass(frozen=True)
class Channel:
    key: str            # key used inside the telemetry dict
    name: str           # human readable name (Serial Monitor, CSV header)
    unit: str
    frame_field: str | None
    color: str


CHANNELS: tuple[Channel, ...] = (
    # -- time ------------------------------------------------------------
    Channel("time_ms",   "Timestamp",            "ms",  "TIMESTAMP_MS",   "#FFFFFF"),
    # -- barometer (BMP390L - the only barometer in the @ frame) ----------
    Channel("bmp_alt",   "BMP390L altitude",     "m",   "ALTITUDE_M",     "#00FFCC"),
    Channel("bmp_temp",  "BMP390L temperature",  "C",   "TEMP_C",         "#00FFCC"),
    Channel("bmp_press", "BMP390L pressure",     "hPa", "PRESSURE_HPA",   "#00FFCC"),
    # -- second barometer (DPS310) - present in the old 20-field CAN frame --
    Channel("dps_alt",   "DPS310 altitude",      "m",   None,             "#FF8A00"),
    Channel("dps_temp",  "DPS310 temperature",   "C",   None,             "#FF8A00"),
    Channel("dps_press", "DPS310 pressure",      "hPa", None,             "#FF8A00"),
    # -- BNO085 ------------------------------------------------------------
    Channel("ax",        "Accel X",              "m/s2", "ACCELEROMETER_DATA", "#FF5252"),
    Channel("ay",        "Accel Y",              "m/s2", "ACCELEROMETER_DATA", "#69F0AE"),
    Channel("az",        "Accel Z",              "m/s2", "ACCELEROMETER_DATA", "#40C4FF"),
    Channel("gx",        "Gyro X",               "deg/s", "GYRO_SPIN_RATE", "#FF5252"),
    Channel("gy",        "Gyro Y",               "deg/s", "GYRO_SPIN_RATE", "#69F0AE"),
    Channel("gz",        "Gyro Z",               "deg/s", "GYRO_SPIN_RATE", "#40C4FF"),
    Channel("roll",      "Roll",                 "deg",  None,             "#FF4081"),
    Channel("pitch",     "Pitch",                "deg",  None,             "#00E5FF"),
    Channel("yaw",       "Yaw",                  "deg",  None,             "#FFD400"),
    # -- INA219 ------------------------------------------------------------
    Channel("vbus",      "INA219 bus voltage",   "V",   "VOLTAGE_V",      "#B388FF"),
    Channel("cur",       "INA219 current",       "mA",  None,             "#FFD400"),
    Channel("pwr",       "INA219 power",         "mW",  None,             "#FFD400"),
)

# Non-numeric / meta values carried alongside the numeric channels.
META_KEYS: tuple[str, ...] = (
    "team_id",
    "packet_count",
    "gnss_time",
    "gnss_latitude",
    "gnss_longitude",
    "gnss_altitude",
    "gnss_sats",
    "flight_state",
)

NUMERIC_KEYS: tuple[str, ...] = tuple(c.key for c in CHANNELS)
FIELD_KEYS: tuple[str, ...] = NUMERIC_KEYS          # legacy alias (CSV writer)
ALL_KEYS: tuple[str, ...] = NUMERIC_KEYS + META_KEYS


def channel(key: str) -> Channel:
    for c in CHANNELS:
        if c.key == key:
            return c
    raise KeyError(key)


def available_keys() -> list[str]:
    return [c.key for c in CHANNELS if c.frame_field is not None]


LEGACY_ONLY_KEYS = {"dps_alt", "dps_temp", "dps_press"}


def missing_channels() -> list[Channel]:
    """Current-firmware channels that are not transmitted.

    The old DPS310 channels remain in the protocol model only for backward
    compatibility with legacy CAN frames; they are not shown as current
    missing telemetry in the GUI.
    """
    return [
        c for c in CHANNELS
        if c.frame_field is None and c.key not in LEGACY_ONLY_KEYS
    ]


def missing_report() -> str:
    return ", ".join(f"{c.name} [{c.unit}]" for c in missing_channels())


# ===========================================================================
# GRAPHS  (id, title, y-label, units, [(channel key, legend name)])
# ===========================================================================
# Eight graph tiles, laid out 4 x 2 - identical to the original dashboard.
# A tile whose channels are all unavailable keeps its place (layout preserved)
# and shows an on-canvas "not transmitted" notice instead of fake data.
PLOT_SPECS: tuple = (
    ("alt",   "Altitude",               "Altitude",     "m",
     (("bmp_alt", "BMP390L"),)),
    ("temp",  "Temperature",            "Temperature",  "degC",
     (("bmp_temp", "BMP390L"),)),
    ("press", "Pressure",               "Pressure",     "hPa",
     (("bmp_press", "BMP390L"),)),
    ("accel", "BNO085 Acceleration",    "Acceleration", "m/s2",
     (("ax", "Ax"), ("ay", "Ay"), ("az", "Az"))),
    ("gyro",  "BNO085 Angular Rate",    "Angular Rate", "deg/s",
     (("gx", "Gx"), ("gy", "Gy"), ("gz", "Gz"))),
    ("euler", "BNO085 Orientation",     "Angle",        "deg",
     (("roll", "Roll"), ("pitch", "Pitch"), ("yaw", "Yaw"))),
    ("vbus",  "INA219 Bus Voltage",     "Voltage",      "V",
     (("vbus", "Vbus"),)),
    ("cur",   "INA219 Current",         "Current",      "mA",
     (("cur", "Current"),)),
)

HISTORY_LEN = 300                 # samples kept per channel (unchanged)
LOW_VOLTAGE_WARN = 6.6           # volts
# Serial Monitor (QTextEdit at the bottom of the dashboard).
# The receiver prints a ~25-line report block per packet, so the monitor is
# given a large minimum height and the biggest share of any spare vertical
# space; it grows with the window instead of being capped at a token strip.
CONSOLE_MIN_HEIGHT_PX = 300       # floor for the monitor (was 160 originally)
CONSOLE_MAX_HEIGHT_PX = 4000      # effectively uncapped
CONSOLE_SPLIT_RATIO = 0.38        # share of the window the monitor starts with
CONSOLE_STRETCH = 1               # splitter share when the window is resized
DASHBOARD_STRETCH = 3             # ... versus the dashboard above it
CONSOLE_MAX_BLOCKS = 5000         # ~3 minutes of receiver report blocks

# ===========================================================================
# MAP TAB
# ===========================================================================
MAP_DEFAULT_LAT = 28.6139
MAP_DEFAULT_LON = 77.2090
MAP_REFRESH_S = 2.0
LOGO_HEIGHT_PX = 150

# ===========================================================================
# TAB 2 - LIVE MAP  (unchanged behaviour)
# ===========================================================================
MAP_TAB_DEFAULT_ZOOM = 15
MAP_TAB_FOLLOW_ZOOM = 17
MAP_TAB_FLUSH_MS = 400
MAP_TAB_GPS_STALE_S = 10.0
MAP_TAB_TRAIL_MAX = 5000

# ===========================================================================
# TAB 3 - 2D FLIGHT SIMULATION  (unchanged behaviour)
# ===========================================================================
SIM_ALT_KEY = "bmp_alt"                  # telemetry channel driving the scene
SIM_ALT_FALLBACK_KEY = None
SIM_USE_RELATIVE_ALTITUDE = True
SIM_BASELINE_SAMPLES = 10
SIM_BASELINE_EMA = 0.02
SIM_HISTORY = 5000
SIM_FRAME_MS = 33
SIM_SMOOTH_TAU_S = 0.25
SIM_VIEW_TAU_S = 0.5
SIM_MIN_VIEW_M = 100.0
SIM_SPEED_WINDOW_S = 1.0
SIM_SPEED_MIN_DT_S = 0.15
SIM_LAUNCH_ALT_M = 3.0
SIM_LAUNCH_SPEED_MS = 2.0
SIM_LAUNCH_CONFIRM = 2
SIM_DESCENT_SPEED_MS = 1.0
SIM_DESCENT_CONFIRM = 2
SIM_APOGEE_DROP_M = 1.0
SIM_LANDED_ALT_M = 2.5
SIM_LANDED_SPEED_MS = 1.0
SIM_LANDED_HOLD_S = 3.0
SIM_STATUS_COLORS = {
    "READY": "#FFD400",
    "ASCENDING": "#00FFCC",
    "DESCENDING": "#FF8A00",
    "LANDED": "#40C4FF",
}
SIM_MAX_PLAUSIBLE_SPEED_MS = 600.0
SIM_GLITCH_MAX_CONSEC = 5
SIM_TRAJ_DRAW_POINTS = 800
AUTO_G = 9.81
AUTO_IGNITION_S = 1.0
AUTO_CLEAR_TOWER_M = 5.0
AUTO_APOGEE_HOLD_S = 1.5
AUTO_CHUTE_RAMP_S = 2.0
AUTO_MIN_DESCENT_MS = 1.0
AUTO_MAX_DESCENT_MS = 200.0
AUTO_DEFAULT_MAX_ALT_M = 1000.0
AUTO_DEFAULT_BURN_S = 3.5
AUTO_DEFAULT_DESCENT_MS = 12.0
AUTO_DEFAULT_DURATION_S = 120.0
AUTO_SPEEDS = [("0.5x", 0.5), ("1x", 1.0), ("2x", 2.0), ("5x", 5.0), ("10x", 10.0)]
SIM_PHASE_COLORS = dict(SIM_STATUS_COLORS)
SIM_PHASE_COLORS.update({
    "STANDBY": "#9E9E9E",
    "LAUNCH": "#FF5252",
    "POWERED ASCENT": "#00FFCC",
    "COASTING": "#40C4FF",
    "APOGEE": "#E040FB",
    "DESCENT": "#FF8A00",
    "LANDING": "#B2FF59",
})

# ===========================================================================
# TAB 4 - 3D STL SIMULATION  (unchanged behaviour)
# ===========================================================================
SIM3D_FRAME_MS = 33
SIM3D_ROCKET_DEFAULT = "full body(1).stl"
SIM3D_CANSAT_DEFAULT = "cansat.stl"
SIM3D_ALTITUDE_TO_MODEL_UNITS = 1000.0   # STL geometry is millimetres
SIM3D_BAY_BOTTOM_MM = 700.0
SIM3D_BAY_TOP_MM = 950.0
SIM3D_DOOR_HALF_WIDTH_MM = 83.5
SIM3D_BAY_OPENING_HALF_WIDTH_MM = 78.0
SIM3D_EJECTION_DURATION_S = 1.8
SIM3D_EJECTION_DISTANCE_MM = 1170.0
SIM3D_CANSAT_DESCENT_MS = 12.0
SIM3D_CANSAT_VERTICAL_OFFSET_M = 1.0
SIM3D_SEPARATION_ALT_M = 800.0           # descending 800 m crossing

# ===========================================================================
# FIRMWARE-DERIVED CONSTANTS (mirrors of the .ino files, for validation)
# ===========================================================================
VALID_FLIGHT_STATES = ("STANDBY", "ASCENT", "BURNOUT", "DESCENT", "LANDED")

# stateToString() in rocket_transmitter.ino - index -> name used on the wire.
FLIGHT_STATE_NAMES = {
    0: "STANDBY",
    1: "ASCENT",
    2: "BURNOUT",
    3: "DESCENT",
    4: "LANDED",
}

# Colours used for the flight-state badge (2D/3D tabs + dashboard).
FLIGHT_STATE_COLORS = {
    "STANDBY": "#FFD400",
    "ASCENT": "#00FFCC",
    "BURNOUT": "#FF8A00",
    "DESCENT": "#FF8A00",
    "LANDED": "#40C4FF",
}

# ==========================================================================
