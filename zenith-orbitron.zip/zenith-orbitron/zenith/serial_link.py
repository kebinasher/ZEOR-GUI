from __future__ import annotations

from .config import *
from .protocol import *
from .receiver import *


# ==========================================================================

"""Serial worker thread.

Requirement 9: *"Keep the GUI responsive by moving serial I/O to a separate
worker thread and communicating with the main thread using Qt signals/slots.
Do not update GUI widgets or 3D objects from the worker thread."*

``SerialWorker`` is a ``QThread`` that owns the ``pyserial`` port.  It only ever
emits *plain Python data* (str, dict, float) through Qt signals; every widget,
plot and 3D object is touched on the GUI thread, in the slots connected to
those signals.  Nothing in this file imports or touches a widget.
"""


import time

from PyQt6.QtCore import QThread, pyqtSignal

try:  # pragma: no cover - exercised only on a machine without pyserial
    import serial
    from serial import SerialException
    from serial.tools import list_ports
except Exception:  # pragma: no cover
    serial = None  # type: ignore
    list_ports = None  # type: ignore

    class SerialException(Exception):  # type: ignore
        pass


class SerialWorker(QThread):
    """Reads the ground receiver's USB port and emits decoded lines/samples."""

    line_received = pyqtSignal(str)          # raw text, for the Serial Monitor
    sample_decoded = pyqtSignal(dict)        # validated sample dict
    message = pyqtSignal(str, str)           # (level, text) -> monitor notice
    error = pyqtSignal(str)                  # fatal port error
    state_changed = pyqtSignal(str)          # 'connecting' | 'connected' | ...

    def __init__(self, port: str, baud: int, decoder, parent=None) -> None:
        super().__init__(parent)
        self.port = port
        self.baud = baud
        self.decoder = decoder
        self._running = True
        self._port = None

    # -----------------------------------------------------------------
    def stop(self) -> None:
        """Ask the thread to finish; safe to call from the GUI thread."""
        self._running = False
        self.requestInterruption()

    def send(self, text: str) -> None:
        """Write *text* to the port (used by the HIL loop-back self test)."""
        try:
            if self._port and self._port.is_open:
                self._port.write(text.encode("utf-8", errors="replace"))
                self._port.flush()
            else:
                self.message.emit("warn", "TX ignored: port is not open")
        except Exception as exc:  # pragma: no cover - hardware dependent
            self.message.emit("error", f"TX failed: {exc}")

    # -----------------------------------------------------------------
    def run(self) -> None:  # noqa: D102 - QThread entry point
        if serial is None:
            self.error.emit("pyserial is not installed (pip install pyserial)")
            return

        try:
            self._port = serial.Serial(
                port=self.port,
                baudrate=self.baud,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0.2,
                write_timeout=1.0,
                rtscts=False,
                dsrdtr=False,
            )
        except SerialException as exc:
            self.error.emit(f"could not open {self.port}: {exc}")
            return
        except Exception as exc:  # pragma: no cover
            self.error.emit(f"could not open {self.port}: {exc}")
            return

        self.state_changed.emit("connected")
        self.message.emit("info", f"listening on {self.port} @ {self.baud} baud")

        try:
            try:
                self._port.reset_input_buffer()
            except Exception:
                pass
            while self._running and not self.isInterruptionRequested():
                try:
                    waiting = self._port.in_waiting
                except Exception:
                    waiting = 0
                if waiting:
                    chunk = self._port.read(waiting)
                else:
                    # pyserial 'timeout' already bounds read(); sleep keeps the
                    # loop cheap without busy-spinning.
                    chunk = self._port.read(1)
                if not chunk:
                    continue
                try:
                    samples, messages = self.decoder.feed(chunk)
                except Exception as exc:  # decoder bug must not kill the link
                    self.message.emit("error", f"decoder error: {exc}")
                    continue
                for level, text in messages:
                    self.message.emit(level, text)
                if chunk:
                    self.line_received.emit(
                        chunk.decode("utf-8", errors="replace")
                    )
                for sample in samples:
                    sample["_wall"] = time.time()
                    self.sample_decoded.emit(sample)
        except SerialException as exc:
            self.error.emit(f"serial error: {exc}")
        except Exception as exc:  # pragma: no cover
            self.error.emit(f"unexpected serial error: {exc}")
        finally:
            try:
                if self._port and self._port.is_open:
                    self._port.close()
            except Exception:
                pass
            self.state_changed.emit("disconnected")


# ---------------------------------------------------------------------------
# Replay source - plays a log file through the *same* decoder, so recorded
# flights can be reviewed with the identical code path as a live link.
# ---------------------------------------------------------------------------
class ReplayWorker(QThread):
    """Feeds a saved log/CSV through the decoder at a chosen speed."""

    line_received = pyqtSignal(str)
    sample_decoded = pyqtSignal(dict)
    message = pyqtSignal(str, str)
    finished_replay = pyqtSignal()

    def __init__(self, path: str, decoder, speed: float = 1.0, parent=None) -> None:
        super().__init__(parent)
        self.path = path
        self.decoder = decoder
        self.speed = speed
        self._running = True

    def stop(self) -> None:
        self._running = False
        self.requestInterruption()

    def run(self) -> None:  # noqa: D102
        try:
            with open(self.path, "r", encoding="utf-8", errors="replace") as fh:
                lines = fh.readlines()
        except OSError as exc:
            self.message.emit("error", f"cannot read {self.path}: {exc}")
            return

        self.message.emit("info", f"replaying {self.path} ({len(lines)} lines)")
        for line in lines:
            if not self._running or self.isInterruptionRequested():
                break
            samples, messages = self.decoder.feed(line)
            for level, text in messages:
                self.message.emit(level, text)
            self.line_received.emit(line)
            for sample in samples:
                sample["_wall"] = time.time()
                self.sample_decoded.emit(sample)
            if self.speed > 0:
                self.msleep(int(1000 / max(self.speed, 0.1)))
        self.finished_replay.emit()


def available_ports() -> list[str]:
    """Best-effort list of serial port device paths (never raises)."""
    ports: list[str] = []
    try:
        if list_ports is not None:
            ports = [p.device for p in list_ports.comports()]
    except Exception:
        ports = []
    if not ports:
        import glob

        ports = sorted(glob.glob("/dev/ttyUSB*") + glob.glob("/dev/ttyACM*")
                       + glob.glob("/dev/cu.usb*") + glob.glob("/dev/ttyS*"))
    return ports

# ==========================================================================
