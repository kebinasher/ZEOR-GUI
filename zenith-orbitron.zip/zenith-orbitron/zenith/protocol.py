from __future__ import annotations

from .config import *  # constants shared with the flat build


# ==========================================================================

"""
Wire protocol for the Zenith Orbitron link.

This module is a faithful Python port of the two Arduino sketches that were
supplied, and it is deliberately free of any Qt / serial dependency so that it
can be unit-tested head-lessly.

--------------------------------------------------------------------------
1. What the ROCKET TRANSMITTER puts on the air (rocket_transmitter.ino)
--------------------------------------------------------------------------
    '@' + <15 comma separated fields> + '\\n'

    #  field              example              notes
    1  TEAM_ID            INSPACe-Rocketry-032
    2  TIMESTAMP_MS       12345                millis() on the rocket
    3  PACKET_COUNT       17                   incremented once per TX
    4  ALTITUDE_M         12.34                barometric, AGL vs pad baseline
    5  PRESSURE_HPA       1013.25
    6  TEMP_C             28.10
    7  VOLTAGE_V          7.940                INA219 bus voltage
    8  GNSS_TIME          12:34:56             UTC hh:mm:ss
    9  GNSS_LATITUDE      13.0827000
   10  GNSS_LONGITUDE     80.2707000
   11  GNSS_ALTITUDE_M    12.30
   12  GNSS_SATS          9
   13  ACCELEROMETER_DATA 0.10;-0.02;9.78      BNO085  (m/s^2)
   14  GYRO_SPIN_RATE     0.10;-0.20;0.00      BNO085  (deg/s)
   15  FLIGHT_STATE       ASCENT

--------------------------------------------------------------------------
2. What the GROUND RECEIVER emits on its USB serial port
--------------------------------------------------------------------------
The stock receiver sketch prints a *human readable report* per packet
(``printTelemetry()``) but never echoes the raw frame.  Both forms are accepted
here, so the GUI works with the firmware exactly as supplied:

  (a) the unmodified receiver's report block::

        ========================================
        VALID ROCKET TELEMETRY
        Team ID: INSPACe-Rocketry-032
        Timestamp: 12345 ms
        ...
        ========================================

  (b) ``RX,<the 15 CSV fields>``  -- one optional line that can be added to the
      receiver sketch (see firmware/ground_receiver) to hand the validated frame
      to the PC byte-for-byte.

  (c) a raw ``@....`` frame -- when a LoRa<->USB dongle is wired straight to the
      PC instead of using the receiver Teensy.

  (d) the legacy ``CAN,time,bmpAlt,bmpT,bmpP,dpsAlt,dpsT,dpsP,ax..gz,roll,pitch,
      yaw,Vbus,mA,mW[,lat,lon]`` frame of the *previous* firmware generation
      (20 or 22 fields), so older payloads keep working.

Every decoded packet is returned as one flat ``dict`` using the channel keys
declared in :mod:`zenith.config`; channels the frame does not contain are set to
``float('nan')` ` (never 0, never invented).  Two derived values are computed
from received data only: ``accel_mag`` (vector norm of ax/ay/az) and
``alt_diff`` (bmp_alt - dps_alt, only when a second barometer exists).
"""


import math
import time
import re
from typing import Any, Iterable








# --------------------------------------------------------------------------
# constants mirrored from the firmware
# --------------------------------------------------------------------------
FRAME_START = "@"
FRAME_END = "\n"
EXPECTED_FIELDS = 15
RECEIVER_TEAM_ID = TEAM_ID

RX_ECHO_PREFIX = "RX,"          # optional receiver-side raw echo
LEGACY_PREFIX = "CAN,"          # previous firmware generation
LEGACY_EXPECTED_FIELDS = 20
LEGACY_GPS_FIELDS = 22

FIELD_NAMES: tuple[str, ...] = (
    "TEAM_ID",
    "TIMESTAMP_MS",
    "PACKET_COUNT",
    "ALTITUDE_M",
    "PRESSURE_HPA",
    "TEMP_C",
    "VOLTAGE_V",
    "GNSS_TIME",
    "GNSS_LATITUDE",
    "GNSS_LONGITUDE",
    "GNSS_ALTITUDE_M",
    "GNSS_SATS",
    "ACCELEROMETER_DATA",
    "GYRO_SPIN_RATE",
    "FLIGHT_STATE",
)

NAN = float("nan")

# Sources of a decoded sample (used for logging / provenance).
SRC_LORA = "lora"          # raw '@' frame straight off the radio
SRC_RX_ECHO = "rx-echo"    # 'RX,' echo from the patched receiver sketch
SRC_REPORT = "rx-report"   # human readable report of the stock receiver
SRC_LEGACY = "legacy-can"  # old 20/22-field CAN frame
SRC_HIL = "hil"            # hardware-in-the-loop self-test (never real data)
SRC_ROCKET_TAG = "rocket-tagged"  # shared-Teensy {Roc} record
SRC_CANSAT_TAG = "cansat-tagged"  # shared-Teensy {Can} record


# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------
def _finite(value: Any) -> bool:
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def _to_float(text: str) -> float:
    text = text.strip()
    if not text:
        return NAN
    try:
        return float(text)
    except ValueError:
        return NAN


def split_csv(line: str, max_fields: int | None = None) -> list[str]:
    """Mirror of the receiver's ``splitCSV()`` - semicolons are NOT separators."""
    fields: list[str] = []
    start = 0
    for i in range(len(line) + 1):
        if i == len(line) or line[i] == ",":
            if max_fields is None or len(fields) < max_fields:
                fields.append(line[start:i])
            start = i + 1
    return fields


def parse_triple(text: str) -> tuple[float, float, float] | None:
    """Mirror of the receiver's ``parseTriple()``: 'x;y;z' -> (x, y, z)."""
    first = text.find(";")
    if first < 1:
        return None
    second = text.find(";", first + 1)
    if second <= first + 1 or second >= len(text) - 1:
        return None
    sx, sy, sz = text[:first].strip(), text[first + 1:second].strip(), text[second + 1:].strip()
    if not (sx and sy and sz):
        return None
    try:
        return float(sx), float(sy), float(sz)
    except ValueError:
        return None


def blank_sample() -> dict:
    """A telemetry dict with every channel present and unknown = NaN."""
    sample: dict[str, Any] = {key: NAN for key in NUMERIC_KEYS}
    sample.update(
        {
            "team_id": "",
            "packet_count": 0,
            "gnss_time": "",
            "gnss_latitude": NAN,
            "gnss_longitude": NAN,
            "gnss_altitude": NAN,
            "gnss_sats": 0,
            "flight_state": "",
            # provenance / diagnostics
            "_source": "",
            "_raw": "",
            "_nbytes": 0,
            "_wall": 0.0,
            "_rx_valid": None,
            "_rx_lost": None,
            "_rx_age_ms": None,
            "_crc_status": "NOT_PRESENT",
            "_crc_received": "",
            "_crc_calculated": "",
        }
    )
    return sample


def _finalise(sample: dict) -> dict:
    """Fill the two derived values that are computed from *received* data."""
    ax, ay, az = sample.get("ax", NAN), sample.get("ay", NAN), sample.get("az", NAN)
    if _finite(ax) and _finite(ay) and _finite(az):
        sample["accel_mag"] = math.sqrt(ax * ax + ay * ay + az * az)
    else:
        sample["accel_mag"] = NAN
    return sample


def _apply_gnss(sample: dict, lat: float, lon: float, alt: float, sats: int,
                gnss_time: str) -> None:
    """Store GNSS only when it is a real fix.

    (0.0, 0.0) is what every GNSS module reports before it has a fix; storing it
    would put the map marker in the Atlantic Ocean, so it is rejected and the
    channel stays NaN -> the map keeps showing 'waiting for fix'.
    """
    sample["gnss_time"] = gnss_time or ""
    if _finite(lat) and _finite(lon) and -90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0:
        if not (abs(lat) < 1e-9 and abs(lon) < 1e-9):
            sample["gnss_latitude"] = lat
            sample["gnss_longitude"] = lon
            # compatibility aliases used by the map tab
            sample["latitude"] = lat
            sample["longitude"] = lon
    if _finite(alt):
        sample["gnss_altitude"] = alt
    try:
        sample["gnss_sats"] = max(0, int(sats))
    except (TypeError, ValueError):
        sample["gnss_sats"] = 0


# --------------------------------------------------------------------------
# CRC-16/CCITT-FALSE wire-integrity helpers
# --------------------------------------------------------------------------
CRC16_POLY = 0x1021
CRC16_INIT = 0xFFFF
CRC16_XOROUT = 0x0000


def crc16_ccitt_false(data: bytes | str) -> int:
    """CRC-16/CCITT-FALSE: poly=0x1021, init=0xFFFF, refin/refout=False."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    crc = CRC16_INIT
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            crc = ((crc << 1) ^ CRC16_POLY) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return crc ^ CRC16_XOROUT


def append_crc16(payload: str) -> str:
    """Return payload with '*ABCD' CRC suffix (CRC covers payload only)."""
    return f"{payload}*{crc16_ccitt_false(payload):04X}"


def extract_and_verify_crc16(payload_with_crc: str) -> tuple[str | None, str, str]:
    """Return (payload, received_crc, calculated_crc); None payload means failure.

    Wire format: <15-field CSV payload>*<4 hexadecimal CRC digits>.
    CRC is calculated over the exact UTF-8 bytes of the CSV payload, excluding
    '@' / 'RX,' framing prefixes and the '*XXXX' suffix.
    """
    if "*" not in payload_with_crc:
        return payload_with_crc, "", ""
    payload, supplied = payload_with_crc.rsplit("*", 1)
    supplied = supplied.strip()
    if len(supplied) != 4 or not re.fullmatch(r"[0-9A-Fa-f]{4}", supplied):
        return None, supplied, f"{crc16_ccitt_false(payload):04X}"
    calculated = f"{crc16_ccitt_false(payload):04X}"
    if supplied.upper() != calculated:
        return None, supplied.upper(), calculated
    return payload, supplied.upper(), calculated


# --------------------------------------------------------------------------
# (a)/(b)/(c)  15-field frame parsers
# --------------------------------------------------------------------------
def parse_zenith_frame(payload: str, source: str = SRC_LORA,
                       team_id_expected: str | None = RECEIVER_TEAM_ID
                       ) -> dict | None:
    """Parse the 15 CSV fields of a '@' frame (or of a 'RX,' echo).

    Returns ``None`` when the frame is rejected.  All rejection rules are the
    ones implemented in ``parseTelemetry()`` of ground_receiver.ino.
    Pass ``team_id_expected=None`` to accept any team ID (bench testing).
    """
    fields = split_csv(payload.strip())
    if len(fields) != EXPECTED_FIELDS:
        return None

    team_id = fields[0]
    if team_id_expected is not None and team_id != team_id_expected:
        return None

    # timestamp and packet count must be pure decimal digits
    if not (fields[1].isdigit() and fields[2].isdigit()):
        return None

    accel = parse_triple(fields[12])
    if accel is None:
        return None
    gyro = parse_triple(fields[13])
    if gyro is None:
        return None

    state = fields[14].strip()
    if state not in VALID_FLIGHT_STATES:
        return None

    sample = blank_sample()
    sample["_source"] = source
    sample["_raw"] = payload.strip()
    sample["_nbytes"] = len(payload.strip()) + 1
    sample["_wall"] = time.time()

    sample["team_id"] = team_id
    sample["time_ms"] = float(int(fields[1]))
    sample["packet_count"] = int(fields[2])
    sample["bmp_alt"] = _to_float(fields[3])
    sample["bmp_press"] = _to_float(fields[4])
    sample["bmp_temp"] = _to_float(fields[5])
    sample["vbus"] = _to_float(fields[6])
    sample["ax"], sample["ay"], sample["az"] = accel
    sample["gx"], sample["gy"], sample["gz"] = gyro
    sample["flight_state"] = state

    _apply_gnss(
        sample,
        _to_float(fields[8]),
        _to_float(fields[9]),
        _to_float(fields[10]),
        int(_to_float(fields[11])) if _finite(_to_float(fields[11])) else 0,
        fields[7].strip(),
    )
    return _finalise(sample)


# --------------------------------------------------------------------------
# (d)  legacy CAN frame of the previous firmware generation
# --------------------------------------------------------------------------
_LEGACY_NUMERIC = (
    "bmp_alt", "bmp_temp", "bmp_press",
    "dps_alt", "dps_temp", "dps_press",
    "ax", "ay", "az", "gx", "gy", "gz",
    "roll", "pitch", "yaw", "vbus", "cur", "pwr",
)


def parse_legacy_frame(payload: str) -> dict | None:
    """Parse ``CAN,time,<18 values>[,lat,lon]`` (20 or 22 fields)."""
    parts = payload.strip().split(",")
    if len(parts) not in (LEGACY_EXPECTED_FIELDS, LEGACY_GPS_FIELDS):
        return None
    if parts[0] != "CAN":
        return None
    try:
        t_ms = int(parts[1])
        values = [float(p) for p in parts[2:20]]
    except ValueError:
        return None

    sample = blank_sample()
    sample["_source"] = SRC_LEGACY
    sample["_raw"] = payload.strip()
    sample["_nbytes"] = len(payload.strip()) + 1
    sample["_wall"] = time.time()
    sample["team_id"] = RECEIVER_TEAM_ID
    sample["time_ms"] = float(t_ms)
    for key, value in zip(_LEGACY_NUMERIC, values):
        sample[key] = value
    if len(parts) == LEGACY_GPS_FIELDS:
        lat, lon = _to_float(parts[20]), _to_float(parts[21])
        _apply_gnss(sample, lat, lon, NAN, 0, "")
    return _finalise(sample)


# --------------------------------------------------------------------------
# (a)  human readable report block of the stock receiver
# --------------------------------------------------------------------------
_REPORT_KEYS = {
    "Team ID": "team_id",
    "Timestamp": "time_ms",
    "Packet count": "packet_count",
    "Altitude": "bmp_alt",
    "Pressure": "bmp_press",
    "Temperature": "bmp_temp",
    "Voltage": "vbus",
    "GNSS time (UTC)": "gnss_time",
    "GNSS latitude": "gnss_latitude",
    "GNSS longitude": "gnss_longitude",
    "GNSS altitude": "gnss_altitude",
    "GNSS satellites": "gnss_sats",
    "Accelerometer": "accel",
    "Gyroscope": "gyro",
    "Flight state": "flight_state",
    "Valid received": "_rx_valid",
    "Packets lost": "_rx_lost",
    "Last packet age": "_rx_age_ms",
}

# lines the receiver prints that are worth showing in the Serial Monitor
_RECEIVER_NOTES = (
    "Rejected packet",
    "Rejected team ID",
    "WARNING:",
    "ERROR:",
    "SD card",
    "Receiver ready",
    "E22",
)


class ReportBlockParser:
    """Accumulates the receiver's pretty-printed report and turns it into a dict.

    The stock receiver prints the block between two rows of '=' characters::

        ========================================
        VALID ROCKET TELEMETRY
        Team ID: INSPACe-Rocketry-032
        ...
        ========================================
    """

    SEPARATOR = "="

    def __init__(self, team_id: str = RECEIVER_TEAM_ID,
                 strict_team_id: bool = True) -> None:
        self.team_id = team_id
        self.strict_team_id = strict_team_id
        self._buf: list[str] = []

    def reset(self) -> None:
        self._buf.clear()

    def feed(self, line: str) -> dict | None:
        """Consume one USB line; return a sample when a block just completed."""
        stripped = line.strip("\r\n")
        if stripped and set(stripped) == {self.SEPARATOR} and len(stripped) >= 10:
            block, self._buf = self._buf, []
            return self._parse(block)
        self._buf.append(stripped)
        return None

    # -- internals ---------------------------------------------------------
    def _parse(self, block: list[str]) -> dict | None:
        if not any("VALID ROCKET TELEMETRY" in line for line in block):
            return None

        raw: dict[str, str] = {}
        for line in block:
            if ":" not in line:
                continue
            key, _, value = line.partition(":")
            key = key.strip()
            if key in _REPORT_KEYS:
                raw[_REPORT_KEYS[key]] = value.strip()

        if "team_id" not in raw:
            return None
        if self.strict_team_id and raw["team_id"] != self.team_id:
            return None

        sample = blank_sample()
        sample["_source"] = SRC_REPORT
        sample["_crc_status"] = "NOT_PRESENT"
        sample["_raw"] = " | ".join(l for l in block if l)
        sample["_nbytes"] = len(sample["_raw"]) + 1
        sample["_wall"] = time.time()
        sample["team_id"] = raw["team_id"]

        def num(key: str) -> float:
            text = raw.get(key, "")
            for suffix in (" ms", " m", " hPa", " C", " V", " mA", " mW", " deg"):
                if text.endswith(suffix):
                    text = text[: -len(suffix)]
            return _to_float(text)

        sample["time_ms"] = num("time_ms")
        try:
            sample["packet_count"] = int(float(raw.get("packet_count", "0")))
        except ValueError:
            sample["packet_count"] = 0
        sample["bmp_alt"] = num("bmp_alt")
        sample["bmp_press"] = num("bmp_press")
        sample["bmp_temp"] = num("bmp_temp")
        sample["vbus"] = num("vbus")

        accel = parse_triple(raw.get("accel", ""))
        if accel is None:
            return None
        gyro = parse_triple(raw.get("gyro", ""))
        if gyro is None:
            return None
        sample["ax"], sample["ay"], sample["az"] = accel
        sample["gx"], sample["gy"], sample["gz"] = gyro

        state = raw.get("flight_state", "").strip()
        if state not in VALID_FLIGHT_STATES:
            return None
        sample["flight_state"] = state

        _apply_gnss(
            sample,
            num("gnss_latitude"),
            num("gnss_longitude"),
            num("gnss_altitude"),
            int(num("gnss_sats")) if _finite(num("gnss_sats")) else 0,
            raw.get("gnss_time", "").strip(),
        )
        for key in ("_rx_valid", "_rx_lost", "_rx_age_ms"):
            if key in raw:
                try:
                    sample[key] = int(float(raw[key]))
                except ValueError:
                    pass
        return _finalise(sample)


# --------------------------------------------------------------------------
# dispatcher
# --------------------------------------------------------------------------
class LineDispatcher:
    """Turns a stream of USB/serial text lines into validated telemetry dicts.

    ``feed(chunk)`` accepts an arbitrary slice of the serial stream (it may
    contain zero, one or many lines, and may end in the middle of a line).
    It returns ``(samples, messages)`` where *messages* is a list of
    ``(level, text)`` tuples (level in ``{'info', 'warn', 'error'}``) that the
    caller forwards to the Serial Monitor.
    """

    def __init__(self, team_id: str = RECEIVER_TEAM_ID,
                 strict_team_id: bool = True,
                 max_line_bytes: int = MAX_LINE_BYTES) -> None:
        # ``strict_team_id`` mirrors #define RECEIVER_TEAM_ID in the sketch:
        # when False, any team ID is accepted (useful for bench testing with a
        # second payload).  The flight configuration is strict.
        self.team_id = team_id
        self.strict_team_id = strict_team_id
        self.max_line_bytes = max_line_bytes
        self.report = ReportBlockParser(team_id=team_id,
                                        strict_team_id=strict_team_id)
        self._pending = ""            # tail of a line not yet terminated
        self.counts = {
            "lines": 0,
            "frames_ok": 0,
            "frames_rejected": 0,
            "frames_short": 0,
            "notes": 0,
            "dropped": 0,             # lines discarded for being absurdly long
        }

    def reset(self) -> None:
        self.report.reset()
        self._pending = ""
        for key in self.counts:
            self.counts[key] = 0

    # ------------------------------------------------------------------
    def feed(self, chunk: str) -> tuple[list[dict], list[tuple[str, str]]]:
        """Split *chunk* into lines and dispatch each complete one."""
        samples: list[dict] = []
        messages: list[tuple[str, str]] = []
        text = self._pending + (chunk or "")
        if "\n" not in text:
            # no complete line yet - keep buffering (bounded, see below)
            if len(text) > self.max_line_bytes:
                self.counts["dropped"] += 1
                messages.append(
                    ("warn", "[RX] oversized line discarded; resynchronizing"))
                self._pending = ""
            else:
                self._pending = text
            return samples, messages

        parts = text.split("\n")
        self._pending = parts.pop()          # last element is the partial tail
        for line in parts:
            s2, m2 = self._feed_line(line)
            samples.extend(s2)
            messages.extend(m2)
        return samples, messages

    # ------------------------------------------------------------------
    def _feed_line(self, line: str) -> tuple[list[dict], list[tuple[str, str]]]:

    # ------------------------------------------------------------------
        self.counts["lines"] += 1
        samples: list[dict] = []
        messages: list[tuple[str, str]] = []

        text = line.rstrip("\r\n")
        if not text.strip():
            return samples, messages

        # --- multiplexed records from the single Teensy USB serial link ---
        # Tagged line format from firmware:
        #   {Roc}<15-field payload>  -> rocket avionics
        #   {Can}<15-field payload>  -> CanSat avionics
        # The optional leading '@' after a tag is tolerated for compatibility.
        tagged_source = None
        if text.startswith(ROCKET_STREAM_PREFIX):
            tagged_source = SRC_ROCKET_TAG
            payload_text = text[len(ROCKET_STREAM_PREFIX):].lstrip()
            expected_team = self.team_id if self.strict_team_id else None
        elif text.startswith(CANSAT_STREAM_PREFIX):
            tagged_source = SRC_CANSAT_TAG
            payload_text = text[len(CANSAT_STREAM_PREFIX):].lstrip()
            # CanSat has its own Team ID; the tag is the authoritative source.
            expected_team = None
        if tagged_source is not None:
            if payload_text.startswith(FRAME_START):
                payload_text = payload_text[1:]
            payload, crc_rx, crc_calc = extract_and_verify_crc16(payload_text)
            if payload is None:
                self.counts["frames_rejected"] += 1
                messages.append(("error", f"[CRC] {tagged_source} frame rejected: received={crc_rx or 'INVALID'} calculated={crc_calc}"))
                return samples, messages
            sample = parse_zenith_frame(
                payload, tagged_source, team_id_expected=expected_team)
            if sample is None:
                self.counts["frames_rejected"] += 1
                messages.append(("error", f"[RX] rejected {tagged_source} frame: {text[:120]}"))
                return samples, messages
            sample["_crc_status"] = "OK" if crc_rx else "NOT_PRESENT"
            sample["_crc_received"] = crc_rx
            sample["_crc_calculated"] = crc_calc
            if not crc_rx:
                messages.append(("warn", f"[CRC] {tagged_source} frame has no CRC; accepted in compatibility mode"))
            self.counts["frames_ok"] += 1
            samples.append(sample)
            return samples, messages

        # --- (c) raw '@' frame with optional CRC-16 suffix ----------------
        if text.startswith(FRAME_START):
            payload, crc_rx, crc_calc = extract_and_verify_crc16(text[1:])
            if payload is None:
                self.counts["frames_rejected"] += 1
                messages.append(("error", f"[CRC] raw frame rejected: received={crc_rx or 'INVALID'} calculated={crc_calc}"))
                return samples, messages
            sample = parse_zenith_frame(payload, SRC_LORA)
            if sample is None:
                self.counts["frames_rejected"] += 1
                messages.append(("error", f"[RX] rejected '@' frame: {text[:120]}"))
            else:
                sample["_crc_status"] = "OK" if crc_rx else "NOT_PRESENT"
                sample["_crc_received"] = crc_rx
                sample["_crc_calculated"] = crc_calc
                if not crc_rx:
                    messages.append(("warn", "[CRC] raw frame has no CRC; accepted in compatibility mode"))
                self.counts["frames_ok"] += 1
                samples.append(sample)
            return samples, messages

        # --- (b) 'RX,' echo from the patched receiver with optional CRC ---
        if text.startswith(RX_ECHO_PREFIX):
            payload, crc_rx, crc_calc = extract_and_verify_crc16(text[len(RX_ECHO_PREFIX):])
            if payload is None:
                self.counts["frames_rejected"] += 1
                messages.append(("error", f"[CRC] echoed frame rejected: received={crc_rx or 'INVALID'} calculated={crc_calc}"))
                return samples, messages
            sample = parse_zenith_frame(payload, SRC_RX_ECHO)
            if sample is None:
                self.counts["frames_rejected"] += 1
                messages.append(("error", f"[RX] rejected echoed frame: {text[:120]}"))
            else:
                sample["_crc_status"] = "OK" if crc_rx else "NOT_PRESENT"
                sample["_crc_received"] = crc_rx
                sample["_crc_calculated"] = crc_calc
                if not crc_rx:
                    messages.append(("warn", "[CRC] RX echo has no CRC; accepted in compatibility mode"))
                self.counts["frames_ok"] += 1
                samples.append(sample)
            return samples, messages

        # --- (d) legacy CAN frame ----------------------------------------
        if text.startswith(LEGACY_PREFIX):
            sample = parse_legacy_frame(text)
            if sample is None:
                self.counts["frames_rejected"] += 1
                messages.append(("error", f"[RX] rejected legacy CAN frame: {text[:120]}"))
            else:
                self.counts["frames_ok"] += 1
                samples.append(sample)
            return samples, messages

        # --- (a) report block of the stock receiver -----------------------
        if set(text.strip()) == {ReportBlockParser.SEPARATOR} and len(text.strip()) >= 10:
            sample = self.report.feed(text)
            if sample is not None:
                self.counts["frames_ok"] += 1
                samples.append(sample)
            return samples, messages

        if self.report._buf or "Team ID:" in text or "VALID ROCKET" in text:
            sample = self.report.feed(text)
            if sample is not None:
                self.counts["frames_ok"] += 1
                samples.append(sample)
            elif any(text.startswith(n) for n in _RECEIVER_NOTES):
                self.counts["notes"] += 1
                messages.append(self._classify(text))
            return samples, messages

        # --- anything else: informational chatter -------------------------
        if any(text.startswith(n) for n in _RECEIVER_NOTES):
            self.counts["notes"] += 1
            messages.append(self._classify(text))
        return samples, messages

    @staticmethod
    def _classify(text: str) -> tuple[str, str]:
        if text.startswith("Rejected") or text.startswith("ERROR"):
            return ("error", f"[RX] {text}")
        if text.startswith("WARNING"):
            return ("warn", f"[RX] {text}")
        return ("info", f"[RX] {text}")


# --------------------------------------------------------------------------
# Serial-Monitor rendering
# --------------------------------------------------------------------------
def _fmt(value: Any, digits: int = 2) -> str:
    """Render a numeric channel, or '--' when it was not transmitted."""
    if not _finite(value):
        return "--"
    return f"{float(value):.{digits}f}"


def format_monitor_line(sample: dict, wall_time: float | None = None) -> str:
    """One readable Serial-Monitor line: names, values and units of what arrived."""
    stamp = time.strftime("%H:%M:%S", time.localtime(wall_time or sample.get("_wall") or time.time()))
    src = sample.get("_source", "")
    parts = [
        f"ALT {_fmt(sample.get('bmp_alt'))} m",
        f"P {_fmt(sample.get('bmp_press'))} hPa",
        f"T {_fmt(sample.get('bmp_temp'))} C",
        f"VBUS {_fmt(sample.get('vbus'), 3)} V",
        "ACC "
        + ";".join(_fmt(sample.get(k)) for k in ("ax", "ay", "az"))
        + " m/s^2",
        "GYR "
        + ";".join(_fmt(sample.get(k)) for k in ("gx", "gy", "gz"))
        + " deg/s",
    ]
    if _finite(sample.get("gnss_latitude")):
        parts.append(
            f"GNSS {sample.get('gnss_time') or '--'} "
            f"{sample['gnss_latitude']:.6f},{sample['gnss_longitude']:.6f} "
            f"{_fmt(sample.get('gnss_altitude'))} m sats {sample.get('gnss_sats', 0)}"
        )
    else:
        parts.append(f"GNSS no fix (sats {sample.get('gnss_sats', 0)})")
    parts.append(f"STATE {sample.get('flight_state') or '--'}")
    crc_state = sample.get("_crc_status", "NOT_PRESENT")
    parts.append(f"CRC {crc_state}")
    return (
        f"[{stamp}] RX#{sample.get('packet_count', 0):05d} "
        f"T+{_fmt(sample.get('time_ms'), 0)} ms ({src}) | " + " | ".join(parts)
    )


def csv_header(extra: Iterable[str] = ()) -> list[str]:
    header = ["Wall_Time", "Source"]
    header += [c.name for c in _channels()]
    header += [
        "Accel_Mag",
        "Alt_Diff",
        "Packet_Count",
        "GNSS_Time",
        "GNSS_Lat",
        "GNSS_Lon",
        "GNSS_Alt_m",
        "GNSS_Sats",
        "Flight_State",
        "Packet_Size_B",
        "CRC_Status",
        "CRC_Received",
        "CRC_Calculated",
    ]
    header += list(extra)
    return header


def _channels():
      # local import avoids a cycle at import time

    return CHANNELS


def csv_row(sample: dict) -> list:
    

    wall = time.strftime("%H:%M:%S", time.localtime(sample.get("_wall") or time.time()))
    row: list = [wall, sample.get("_source", "")]
    for c in CHANNELS:
        value = sample.get(c.key, NAN)
        row.append("" if not _finite(value) else round(float(value), 6))
    row.append("" if not _finite(sample.get("accel_mag")) else round(sample["accel_mag"], 6))
    row.append(sample.get("packet_count", 0))
    row.append(sample.get("gnss_time", ""))
    for key in ("gnss_latitude", "gnss_longitude", "gnss_altitude"):
        value = sample.get(key, NAN)
        row.append("" if not _finite(value) else round(float(value), 7))
    row.append(sample.get("gnss_sats", 0))
    row.append(sample.get("flight_state", ""))
    row.append(sample.get("_nbytes", 0))
    row.append(sample.get("_crc_status", "NOT_PRESENT"))
    row.append(sample.get("_crc_received", ""))
    row.append(sample.get("_crc_calculated", ""))
    return row

# ==========================================================================
