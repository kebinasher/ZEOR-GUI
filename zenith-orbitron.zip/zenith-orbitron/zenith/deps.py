from __future__ import annotations


# ==========================================================================

"""Optional-dependency probe.

The GUI must start even when the map stack or the 3D stack is not installed;
each tab degrades to an explanatory placeholder instead of crashing.
"""


try:
    import folium  # noqa: F401
    from PyQt6.QtWebEngineWidgets import QWebEngineView  # noqa: F401

    MAP_SUPPORT_AVAILABLE = True
except Exception:  # pragma: no cover - depends on the host
    folium = None
    QWebEngineView = None
    MAP_SUPPORT_AVAILABLE = False

try:
    import numpy as np  # noqa: F401
    import trimesh  # noqa: F401
    import pyqtgraph.opengl as gl  # noqa: F401
    from PyQt6.QtGui import QVector3D  # noqa: F401

    STL_3D_AVAILABLE = True
except Exception:  # pragma: no cover - depends on the host
    np = None
    trimesh = None
    gl = None
    QVector3D = None
    STL_3D_AVAILABLE = False

# ==========================================================================
